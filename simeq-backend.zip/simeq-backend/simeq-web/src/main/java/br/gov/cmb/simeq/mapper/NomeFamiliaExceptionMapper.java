package br.gov.cmb.simeq.mapper;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import br.gov.cmb.simeq.exception.NomeFamiliaException;

@Provider
public class NomeFamiliaExceptionMapper implements ExceptionMapper<NomeFamiliaException> {

	@Override
	public Response toResponse(NomeFamiliaException e) {
		String mensagem = "Já existe uma Família com este nome cadastrado.";
		return Response.status(Response.Status.BAD_REQUEST)
				.entity("{\"erros\": [\""+ mensagem +"\"]}")
				.type(MediaType.APPLICATION_JSON)
				.build();
	}

}
