package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.StatusManutencaoCorretivaService;
import br.gov.cmb.simeq.vo.DashboardVO;
import br.gov.cmb.simeq.vo.HistoricoStatusManutencaoFiltroVO;
import br.gov.cmb.simeq.vo.HistoricoStatusManutencaoVO;
import io.swagger.annotations.Api;

@Api("Status Manutenção Corretiva")
@Path("/status-manutencao")
public class StatusManutencaoCorretivaResource extends AbstractResource{
	
	@Inject
	private StatusManutencaoCorretivaService statusService;
	
	@GET
	public List<LabelValueDTO> buscarTodos() {
		return this.statusService.buscarTodos();
	}
	
	@GET
	@Path("/manutencao/{idManutencao}")
	public List<LabelValueDTO> buscarStatusCombo(@PathParam("idManutencao")Long idManutencao) {
		return statusService.buscarStatusCombo(idManutencao);
	}
	
	@POST
	@Path("/pagina")
	public Pagina<HistoricoStatusManutencaoVO> buscarHistoricoStatusVO(HistoricoStatusManutencaoFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro, @QueryParam("tamanho") Integer tamanho) {
		Pagina<HistoricoStatusManutencaoVO> pagina = new Pagina<HistoricoStatusManutencaoVO>(filtro, primeiroRegistro, tamanho);
		return statusService.filtrar(pagina);
	}
	
	@POST
	@Path("/dashboard")
	public Response buscarDashboard(DashboardVO dashboardVO){
		return Response.status(Status.OK).entity(this.statusService.buscarDashboard(dashboardVO)).build();
	}
	
	@GET
	@Path("/historico/{idManutencao}")
	public Response buscarHistoricoData(@PathParam("idManutencao")Long idManutencao){
		return Response.status(Status.OK).entity(this.statusService.buscarHistoricoData(idManutencao)).build();
	}

}
