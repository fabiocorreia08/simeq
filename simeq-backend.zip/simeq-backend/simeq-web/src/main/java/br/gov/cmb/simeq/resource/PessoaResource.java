package br.gov.cmb.simeq.resource;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.service.PessoaViewService;
import br.gov.cmb.simeq.vo.AssistenteProducaoFiltroVO;
import br.gov.cmb.simeq.vo.AssistenteProducaoVO;
import io.swagger.annotations.Api;

@Api("Pessoa")
@Path("/pessoas")
public class PessoaResource extends AbstractResource {
	
	@Inject
	private PessoaViewService pessoaViewService;
	
	@GET
	@Path("/matricula/{matricula}")
	public AssistenteProducaoVO bsucarAssistenteProducaoPorMatricula(@PathParam("matricula")String matricula) {
		return this.pessoaViewService.buscarAssistenteProducaoPorMatricula(matricula);
	}
	
	@POST
	@Path("/pagina-assistente-producao")
	public Pagina<AssistenteProducaoVO> filtrarMaterial(AssistenteProducaoFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<AssistenteProducaoVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return pessoaViewService.filtrarAssistenteProducao(pagina);
	}

	@GET
	@Path("/{matricula}")
	public TecnicoDTO buscarTecnico(@PathParam("matricula") String matricula) {
		return pessoaViewService.buscarTecnico(matricula);
	}
}
