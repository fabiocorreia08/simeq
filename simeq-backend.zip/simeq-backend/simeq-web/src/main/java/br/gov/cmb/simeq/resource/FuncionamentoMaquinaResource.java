package br.gov.cmb.simeq.resource;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import br.gov.cmb.simeq.dto.FuncionamentoMaquinaDTO;
import br.gov.cmb.simeq.service.FuncionamentoMaquinaService;
import br.gov.cmb.simeq.vo.FuncionamentoMaquinaVO;
import io.swagger.annotations.Api;

@Api("FuncionamentoMaquina")
@Path("funcionamento-maquina")
public class FuncionamentoMaquinaResource extends AbstractResource {

	@Inject
	private FuncionamentoMaquinaService funcionamentoService;


	@POST
	public Response salvar(FuncionamentoMaquinaDTO funcionamentoMaquina) {
		try {
			return Response.status(Response.Status.OK).entity(funcionamentoService.salvar(funcionamentoMaquina))
					.build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}

	}

	@GET
	public Response filtrarFuncionamentoMaquina(@BeanParam FuncionamentoMaquinaVO filtro) {
		try {
			return Response.status(Response.Status.OK).entity(funcionamentoService.buscarFuncionamentoMaquina(filtro))
					.build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}

	}

	@PUT
	public Response editar(FuncionamentoMaquinaDTO funcionamentoMaquinaDTO) {
		try {
			return Response.status(Response.Status.OK).entity(funcionamentoService.editar(funcionamentoMaquinaDTO))
					.build();
		} catch (Exception e) {
			return Response.status(Response.Status.BAD_REQUEST).build();

		}
	}

}
