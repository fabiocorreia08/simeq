package br.gov.cmb.simeq.resource;

import io.swagger.annotations.Api;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.AprovacaoReprovacaoManutencaoCorretivaDTO;
import br.gov.cmb.simeq.dto.AvaliacaoManutencaoCorretivaDTO;
import br.gov.cmb.simeq.service.AvaliacaoSolicitacaoService;
import br.gov.cmb.simeq.vo.AvaliacaoManutencaoCorretivaVO;

@Api("Avaliacao-Solicitacao")
@Path("/avaliacao-solicitacao")
public class AvaliacaoSolicitacaoResource {

	@Inject
	private AvaliacaoSolicitacaoService avaliacaoSolicitacaoService;
	
	@POST
	@Path("/filtrar")
	public Pagina<AvaliacaoManutencaoCorretivaDTO> filtrarAvaliacoes(AvaliacaoManutencaoCorretivaVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<AvaliacaoManutencaoCorretivaDTO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return avaliacaoSolicitacaoService.filtrarAvaliacoes(pagina);
	}
	
	@POST
	@Path("/aprovar")
	public void aprovar(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO){
		avaliacaoSolicitacaoService.aprovar(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}
	
	@POST
	@Path("/reprovar")
	public void repprovar(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO){
		avaliacaoSolicitacaoService.reprovar(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}
	
	@POST
	@Path("/enviar-email-aprovacao")
	public void enviarEmailAprovacao(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO){
		avaliacaoSolicitacaoService.enviarEmailAprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}
	
	@POST
	@Path("/enviar-email-reprovacao")
	public void enviarEmailReprovacao(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO){
		avaliacaoSolicitacaoService.enviarEmailReprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}
}
