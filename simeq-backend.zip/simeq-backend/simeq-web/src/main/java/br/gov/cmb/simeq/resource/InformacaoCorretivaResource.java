package br.gov.cmb.simeq.resource;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;
import br.gov.cmb.simeq.service.InformacaoCorretivaService;
import br.gov.cmb.simeq.service.InformacaoPreventivaService;
import br.gov.cmb.simeq.utils.VerificaClasseUtil;
import br.gov.cmb.simeq.vo.InformacaoFiltroVO;
import br.gov.cmb.simeq.vo.InformacaoVO;
import io.swagger.annotations.Api;

@Api("Informaçoes")
@Path("/informacoes")
@Consumes("application/json;charset=UTF-8")
@Produces("application/json;charset=UTF-8")
public class InformacaoCorretivaResource {
	
	@Inject
	private InformacaoCorretivaService informacaoCorretivaService;
	
	@Inject
	private InformacaoPreventivaService informacaoPreventivaService;
	
	@POST
	public InformacaoVO salvar(InformacaoVO informacaoVO) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(informacaoVO.getNumeroSolicitacao());
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return informacaoCorretivaService.salvar(informacaoVO);
		} else {
			return informacaoPreventivaService.salvar(informacaoVO);
		}
	}
	
	@POST
	@Path("/pagina")
	public Pagina<InformacaoVO> filtrar(InformacaoFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<InformacaoVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(filtro.getNumeroSolicitacao());
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return informacaoCorretivaService.filtrar(pagina);
		} else {
			return informacaoPreventivaService.filtrar(pagina);
		}
	}

}
