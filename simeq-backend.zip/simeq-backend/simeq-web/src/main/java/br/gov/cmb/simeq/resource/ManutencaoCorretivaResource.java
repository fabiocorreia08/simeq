package br.gov.cmb.simeq.resource;

import java.io.ByteArrayInputStream;
import java.text.ParseException;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;
import br.gov.cmb.simeq.relatorio.vo.RelatorioRankEquipamentoVO;
import br.gov.cmb.simeq.service.CentroCustoService;
import br.gov.cmb.simeq.service.GerarRelatorioService;
import br.gov.cmb.simeq.service.ManutencaoCorretivaService;
import br.gov.cmb.simeq.service.ManutencaoPreventivaService;
import br.gov.cmb.simeq.utils.CalendarioUtil;
import br.gov.cmb.simeq.utils.VerificaClasseUtil;
import br.gov.cmb.simeq.vo.AlocacaoTecnicoFiltroVO;
import br.gov.cmb.simeq.vo.HistoricoManutencaoEquipamentoVO;
import br.gov.cmb.simeq.vo.HistoricoStatusManutencaoFiltroVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaConsultaVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaFiltroVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.RelatorioRankEquipamentoFiltroVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoCorretivaVO;
import io.swagger.annotations.Api;

@Api("Manutenções Corretivas")
@Path("/manutencoes-corretivas")
@Consumes("application/json;charset=UTF-8")
@Produces("application/json;charset=UTF-8")
public class ManutencaoCorretivaResource extends AbstractResource {
	
	@Inject
	private ManutencaoCorretivaService manutencaoCorretivaService;
	
	@Inject
	private ManutencaoPreventivaService manutencaoPreventivaService;
	
	@Inject
	private CentroCustoService centroCustoService;
	
	@Inject
	private GerarRelatorioService geradorRelatorio;
	
	@POST
	@Path("/pagina")
	public Pagina<ManutencaoCorretivaConsultaVO> filtrar(ManutencaoCorretivaFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<ManutencaoCorretivaConsultaVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return manutencaoCorretivaService.filtrar(pagina);
	}
	
	@POST
	@Path("/pagina/aberta-reaberta")
	public Pagina<ManutencaoCorretivaConsultaVO> buscarPaginadaAbertaReaberta(String matricula, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho) throws ParseException {
		List<String> centroCusto = centroCustoService.buscarTodosPorHierarquiaPerfilTecnico(matricula);
		AlocacaoTecnicoFiltroVO filtro = new AlocacaoTecnicoFiltroVO(centroCusto);
		Pagina<ManutencaoCorretivaConsultaVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return manutencaoCorretivaService.buscarPaginadaAbertaReaberta(pagina, matricula);
	}
	
	@GET
	@Path("/classes-manutencao")
	public List<LabelValueDTO> buscarClassesManutencao() {
		return manutencaoCorretivaService.buscarClassesManutencaoCorretiva();
	}
	
	@GET
	@Path("/{id}")
	public ManutencaoCorretivaVO buscarPorId(@PathParam("id") Long id) {
		return manutencaoCorretivaService.buscarPorId(id);
	}
	
	@GET
	@Path("/{id}/{numeroSolicitacao}")
	public ManutencaoVO buscarPorId(@PathParam("id") Long id, @PathParam("numeroSolicitacao") String numeroSolicitaca) {
		
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitaca); 
		ManutencaoVO manutencaoVO = new ManutencaoVO();

	 	if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
	 		manutencaoVO = manutencaoCorretivaService.buscarPorIdManutencao(id);
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 			
			manutencaoVO = manutencaoPreventivaService.buscarPorIdManutencao(id);
		} 
	 	
		return manutencaoVO;
	}
	
	@GET
	@Path("numero-solicitacao/{numeroSolicitacao}")
	public ManutencaoCorretivaVO buscarPorNumeroSolicitacao(@PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return manutencaoCorretivaService.buscarPorNumeroSolicitacao(numeroSolicitacao);
	}
	
	@GET
	@Path("/numero-solicitacao/hierarquia/{numeroSolicitacao}/{idPerfil}/{matricula}")
	public ManutencaoVO buscarPorNumeroSolicitacaoPorHierarquia(@PathParam("numeroSolicitacao") String numeroSolicitacao, @PathParam("idPerfil") Integer idPerfil,
			@PathParam("matricula") String matricula) {
	
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao); 
		ManutencaoVO manutencaoVO = new ManutencaoVO();
		
	 	if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
	 		manutencaoVO = manutencaoCorretivaService.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao, idPerfil, matricula);
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 			
			manutencaoVO = manutencaoPreventivaService.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao, idPerfil, matricula);
		} 
	 	
	 	if(manutencaoVO == null) {
	 		return null;
	 	}else if(manutencaoVO.getIdManutencao() == null) {
	 		return null;
	 	}
		
		return manutencaoVO ;
	}
	
	@POST
	public ManutencaoCorretivaVO salvar(ManutencaoCorretivaVO manutencaoCorretiva) {
		return manutencaoCorretivaService.salvar(manutencaoCorretiva);
	}
	
	@POST
	@Path("/enviar-email-criacao")
	public void enviarEmailAprovacao(ManutencaoCorretivaVO manutencaoCorretiva){
		manutencaoCorretivaService.enviarEmailCriacaoManutencaoCorretiva(manutencaoCorretiva);
	}
	
	@PUT
	public ManutencaoCorretivaVO atualizar(ManutencaoCorretivaVO manutencao) {
		return manutencaoCorretivaService.atualizar(manutencao);
	}
	
	
	@GET
	@Path("/solicitacao-por-perfil/{matricula}/{numeroSolicitacao}/{idPerfil}")
	public ManutencaoVO buscarPoPerfil(@PathParam("matricula") String matricula, @PathParam("numeroSolicitacao") String numeroSolicitacao, @PathParam("idPerfil") Integer idPerfil) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return manutencaoCorretivaService.buscarPorPerfil(idPerfil, matricula, numeroSolicitacao);
		} else {
			return manutencaoPreventivaService.buscarPorPerfil(idPerfil, matricula, numeroSolicitacao);
		}
	}
	
	@POST
	@Path("/equipamento")
	public Pagina<HistoricoManutencaoEquipamentoVO> buscarHistoricoPorEquipamento(HistoricoStatusManutencaoFiltroVO filtro,  @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<HistoricoManutencaoEquipamentoVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(filtro.getNumeroSolicitacao());
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return pagina;
		} else {
			return manutencaoCorretivaService.buscarHistoricoPorEquipamento(pagina);
		}
		
	}
	
	@GET
	@Path("/download-relatorio-corretiva/{idCorretiva}")
	public Response downloadRelatorioCorretiva(@PathParam("idCorretiva") Long id) throws Exception{
		RelatorioManutencaoCorretivaVO relatorio = manutencaoCorretivaService.buscarRelatorioManutencaoCorretiva(id);
		try {
			byte[] arquivo = geradorRelatorio.gerarRelatorioManutencaoCorretiva(relatorio).getArquivo();
			ResponseBuilder response = Response.ok((Object) new ByteArrayInputStream(arquivo));
			response.header("Content-Disposition", "attachment;filename=Relatorio_manutencao_corretiva.pdf");
			response.header("Content-Type", "application/pdf");
			return response.build();
		} catch (Exception e) {
			throw e;
		}

	}
	
	@GET
	@Path("/tempo-refresh")
	public Integer buscarTempoRefresh(){
		return manutencaoCorretivaService.buscarParamentroTempoRefresh();
	}
	
	@POST
	@Path("/relatorio-rank-equipamento")
	public Response downloadRelatorioRankEquipamento(RelatorioRankEquipamentoFiltroVO filtro) {
		
		RelatorioRankEquipamentoVO relatorio = new RelatorioRankEquipamentoVO(CalendarioUtil.formatarData(filtro.getPeriodoInicio()),
				CalendarioUtil.formatarData(filtro.getPeriodoFim()), manutencaoCorretivaService.gerarRankEquipamento(filtro),
				centroCustoService.siglasCentrosCustosParaRelatorio(filtro.getCentroCustos()));
		
		try {
			byte[] arquivo = geradorRelatorio.gerarRelatorioRankEquipamento(relatorio).getArquivo();
			ResponseBuilder response = Response.ok((Object) new ByteArrayInputStream(arquivo));
			response.header("Content-Disposition", "attachment;filename=Relatorio_rank_equipamento.pdf");
			response.header("Content-Type", "application/pdf");
			return response.build();
		} catch (Exception e) {
			throw e;
		}
	}

}
