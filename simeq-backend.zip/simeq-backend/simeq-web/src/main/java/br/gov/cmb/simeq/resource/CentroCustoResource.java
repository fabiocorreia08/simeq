package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.CentroCustoService;
import io.swagger.annotations.Api;

@Api("Centro Custo")
@Path("/centro-custo")
public class CentroCustoResource extends AbstractResource {

	@Inject
	private CentroCustoService centroCustoService;

	@GET
	public List<LabelValueDTO> buscarTodos() {
		return centroCustoService.buscarTodos();
	}
	
	@GET
	@Path("/nomes")
	public List<LabelValueDTO> buscarTodosNomes() {
		return centroCustoService.buscarTodosNomes();
	}
	
	@GET
	@Path("/hierarquia-usuario-logado/{perfil}/{matricula}")
	public List<LabelValueDTO> buscarCentroCustoHierarquiaUsuarioLogado(@PathParam("perfil")Integer perfil, @PathParam("matricula")String matricula){
		return centroCustoService.buscarTodosPorHierarquiaPerfil(perfil, matricula);
	}
	
	@GET
	@Path("/usuario-logado/{perfil}/{matricula}")
	public List<String> buscarCentroCustoUsuarioLogado(@PathParam("perfil")Integer perfil, @PathParam("matricula")String matricula){
		return centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
	}
}
