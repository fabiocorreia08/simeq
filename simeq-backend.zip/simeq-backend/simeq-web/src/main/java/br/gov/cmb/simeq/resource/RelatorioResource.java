package br.gov.cmb.simeq.resource;

import java.io.ByteArrayInputStream;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import br.gov.cmb.simeq.service.EquipamentoService;
import br.gov.cmb.simeq.service.GerarRelatorioService;
import br.gov.cmb.simeq.service.ManutencaoCorretivaService;
import br.gov.cmb.simeq.service.ManutencaoPreventivaService;
import br.gov.cmb.simeq.vo.RelatorioCapacidadeProdutivaEquipamentoFiltroVO;
import br.gov.cmb.simeq.vo.RelatorioGestaoEstrategicaFiltroVO;
import br.gov.cmb.simeq.vo.RelatorioManutencaoPreventivaAnualFiltro;
import br.gov.cmb.simeq.vo.relatorio.RelatorioCapacidadeProdutivaEquipamentoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaAnualVO;
import io.swagger.annotations.Api;

@Api("Relatorio")
@Path("/relatorio")
public class RelatorioResource extends AbstractResource {

	@Inject
	private ManutencaoPreventivaService manutencaoPreventivaService;
	
	@Inject
	private ManutencaoCorretivaService manutencaoCorretivaService;

	@Inject
	private GerarRelatorioService geradorRelatorio;

	@Inject
	private EquipamentoService equipamentoService;

	@GET
	@Path("/download-relatorio-preventiva-anual")
	public Response downloadRelatorioPreventivaAnual(@BeanParam RelatorioManutencaoPreventivaAnualFiltro filtro)
			throws Exception {
		RelatorioManutencaoPreventivaAnualVO relatorio = new RelatorioManutencaoPreventivaAnualVO(filtro.getAno(),
				this.manutencaoPreventivaService.gerarSubRelatorioManutencaoPreventivaAnual(filtro));
		try {
			byte[] arquivo = geradorRelatorio.gerarRelatorioManutencaoPreventivaAnual(relatorio);
			ResponseBuilder response = Response.ok((Object) new ByteArrayInputStream(arquivo));
			response.header("Content-Disposition", "attachment;filename=Relatorio_manutencao_preventiva_anual.pdf");
			response.header("Content-Type", "application/pdf");
			return response.build();
		} catch (Exception e) {
			throw e;
		}

	}

	@GET
	@Path("/download-relatorio-capacidade-produtiva")
	public Response downloadRelatorioCapacidadeProdutiva(
			@BeanParam RelatorioCapacidadeProdutivaEquipamentoFiltroVO filtro) throws Exception {
		RelatorioCapacidadeProdutivaEquipamentoVO relatorio = new RelatorioCapacidadeProdutivaEquipamentoVO(
				filtro.getDataInicial(), filtro.getDataFinal(), filtro.getSoPreventivas(),
				equipamentoService.gerarSubRelatorioCapacidadeProdutivaEquipamento(filtro));
		try {
			byte[] arquivo = geradorRelatorio.gerarRelatorioCapacidadeProdutivaEquipamento(relatorio);
			ResponseBuilder response = Response.ok((Object) new ByteArrayInputStream(arquivo));
			response.header("Content-Disposition",
					"attachment;filename=Relatorio_capacidade_produtiva_equipamento.pdf");
			response.header("Content-Type", "application/pdf");
			return response.build();
		} catch (Exception e) {
			throw e;
		}

	}

	@GET
	@Path("/download-relatorio-gestao-estrategica")
	public Response downloadRelatorioGestaoEstrategica(@BeanParam RelatorioGestaoEstrategicaFiltroVO filtro)
			throws Exception {

		try {
			byte[] arquivo = geradorRelatorio.gerarRelatorioGestaoEstrategica(
					manutencaoCorretivaService.gerarRelatorioGestaoEstrategicaDia(filtro),
					manutencaoCorretivaService.gerarRelatorioGestaoEstrategicaGrupo(filtro),
					manutencaoCorretivaService.gerarRelatorioGestaoEstrategicaMaterial(filtro),
					manutencaoCorretivaService.gerarRelatorioGestaoEstrategicaSolicitacao(filtro),
					manutencaoCorretivaService.gerarRelatorioGestaoEstrategicaParametros(filtro));
			ResponseBuilder response = Response.ok((Object) new ByteArrayInputStream(arquivo));
			response.header("Content-Disposition",
					"attachment;filename=Relatorio_gestao_estrategica.pdf");
			response.header("Content-Type", "application/pdf");
			return response.build();
		} catch (Exception e) {
			throw e;
		}

	}
}
