package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;
import br.gov.cmb.simeq.service.TecnicoService;
import br.gov.cmb.simeq.utils.VerificaClasseUtil;
import br.gov.cmb.simeq.vo.AtividadeFiltroTecnicoVO;
import br.gov.cmb.simeq.vo.TecnicoVO;
import io.swagger.annotations.Api;

@Api("Tecnico")
@Path("/tecnico")
public class TecnicoResource extends AbstractResource {

	@Inject
	private TecnicoService tecnicoService;

	@GET
	@Path("id/{id}")
	public TecnicoDTO buscarPor(@PathParam("id") Long idTecnico) {
		return tecnicoService.buscarPor(idTecnico);
	}

	@POST
	public TecnicoDTO salvar(TecnicoDTO tecnicoDTO) {
		return tecnicoService.salvar(tecnicoDTO);
	}
	
	@GET
	@Path("matricula-valida/{matricula}")
	public TecnicoDTO buscarPor(@PathParam("matricula") String matricula) {
		return tecnicoService.buscarPor(matricula, true);
	}
	
	@GET
	@Path("matricula/{matricula}")
	public TecnicoDTO buscarPorMatricula(@PathParam("matricula") String matricula) {
		return tecnicoService.buscarPor(matricula, false);
	}
	
	@GET
	@Path("alocado-permissao")
	public Pagina<TecnicoDTO> buscarPorMatriculaSemvalidacao(@BeanParam AtividadeFiltroTecnicoVO filtro, 
			@QueryParam("tamanho") Integer tamanho, @QueryParam("primeiroRegistro") Integer primeiroRegistro) {
		
		Pagina<TecnicoDTO> paginaTecnico = new Pagina<>(filtro, primeiroRegistro, tamanho);
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(filtro.getNumeroSolicitacao()); 
		
	 	if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
	 		return paginaTecnico = tecnicoService.buscarPorMatriculaAlocado(paginaTecnico);
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 			
			return paginaTecnico = tecnicoService.buscarPorMatriculaAlocadoPreventiva(paginaTecnico);
		} 
		
		return paginaTecnico;
	}
	
	@POST
	@Path("/filtrar")
	public Pagina<TecnicoDTO> filtrar(TecnicoVO filtro, @QueryParam("tamanho") Integer tamanho, @QueryParam("primeiroRegistro") Integer primeiroRegistro) {
		Pagina<TecnicoDTO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return tecnicoService.filtrar(pagina);
	}
	
	@GET
	public List<LabelValueDTO> buscarTodosTecnico() {
		return tecnicoService.buscarTodosTecnico();
	}
	
	@GET
	@Path("/cargos")
	public List<LabelValueDTO> buscarTodosCargos() {
		return tecnicoService.buscarTodosCargos();
	}
	
	@GET
	@Path("/funcoes")
	public List<LabelValueDTO> buscarTodasFuncoes() {
		return tecnicoService.buscarTodasFuncoes();
	}
	
}
