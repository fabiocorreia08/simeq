package br.gov.cmb.simeq.config;

import io.swagger.jaxrs.config.BeanConfig;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import br.gov.cmb.simeq.resource.AbstractResource;

@ApplicationPath("/api")
public class ApplicationConfig extends Application {

	public ApplicationConfig() {
		BeanConfig beanConfig = new BeanConfig();
		beanConfig.setVersion("1.0.0");
		beanConfig.setTitle("CMB - Sistema de Equipamentos - RestFul API");
		beanConfig.setSchemes(new String[] { "http" });
		beanConfig.setBasePath("simeq-web/api");
		beanConfig.setResourcePackage(AbstractResource.class.getPackage().getName());
		beanConfig.setScan(true);
	}

}
