package br.gov.cmb.simeq.resource;

import java.io.ByteArrayInputStream;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.service.GerarRelatorioService;
import br.gov.cmb.simeq.service.ManutencaoPreventivaService;
import br.gov.cmb.simeq.vo.AprovacaoManutencaoPreventivaFiltroVO;
import br.gov.cmb.simeq.vo.AprovacaoPreventivaConsultaTabelaVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.PreventivaCadastroVO;
import br.gov.cmb.simeq.vo.PreventivaConsultaFiltroVO;
import br.gov.cmb.simeq.vo.PreventivaConsultaTabelaVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaVO;
import io.swagger.annotations.Api;

@Api("Manutenções Preventivas")
@Path("/manutencoes-preventivas")
@Consumes("application/json;charset=UTF-8")
@Produces("application/json;charset=UTF-8")
public class ManutencaoPreventivaResource extends AbstractResource {
	
	@Inject
	private ManutencaoPreventivaService manutencaoPreventivaService;
	
	@Inject
	private GerarRelatorioService geradorRelatorio;
	
	@GET
	@Path("/meses")
	public List<LabelValueDTO> buscarTodosMeses() {
		return manutencaoPreventivaService.buscarTodosMeses();
	}
	
	@GET
	@Path("/equipamento/{idEquipamento}/centro-custo/{centroCusto}")
	public List<PreventivaCadastroVO> buscarPreventivasPorEquipamentoCentroCusto(@PathParam("idEquipamento") Long idEquipamento, @PathParam("centroCusto") String centroCusto) {
		return manutencaoPreventivaService.buscarPreventivasPorEquipamentoCentroCusto(idEquipamento, centroCusto);
	}
	
	@GET
	@Path("/{id}")
	public PreventivaCadastroVO buscarPorId(@PathParam("id") Long id) {
		return manutencaoPreventivaService.buscarPorId(id);
	}
	
	@POST
	public void salvar(List<PreventivaCadastroVO> preventivas) {
		manutencaoPreventivaService.salvar(preventivas);
	}
	
	@PUT
	public void atualizar(PreventivaCadastroVO preventiva) {
		manutencaoPreventivaService.atualizar(preventiva);
	} 
	
	@GET
	@Path("/numero-solicitacao/{numeroSolicitacao}")
	public PreventivaCadastroVO buscarPreventivaPorNumeroSolicitacao(@PathParam("numeroSolicitacao")String numeroSolicitacao) {
		return manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao);
	}
	
	@GET
	@Path("/{numeroSolicitacao}")
	public PreventivaCadastroVO buscarPreventivaPorSolicitacao(@PathParam("numeroSolicitacao")String numeroSolicitacao) {
		return manutencaoPreventivaService.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao);
	}
	
	@POST
	@Path("/pagina")
	public Pagina<PreventivaConsultaTabelaVO> filtrar(PreventivaConsultaFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<PreventivaConsultaTabelaVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return manutencaoPreventivaService.filtrar(pagina);
	}
	
	@POST
	@Path("/aprovacao/pagina")
	public Pagina<AprovacaoPreventivaConsultaTabelaVO> filtrarManutencaoAprovacao(AprovacaoManutencaoPreventivaFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<AprovacaoPreventivaConsultaTabelaVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		if(!filtro.contemValor()) {
			return pagina;
		}
		filtro.setIdStatus(StatusManutencaoPreventivaEnum.ABERTA.getCodigo());
		
		return manutencaoPreventivaService.filtrarManutencaoAprovacao(pagina);
	}
	
	@GET
	@Path("/solicitacao-por-perfil/{matricula}/{numeroSolicitacao}/{idPerfil}")
	public ManutencaoVO buscarPoPerfil(@PathParam("matricula") String matricula, @PathParam("numeroSolicitacao") String numeroSolicitacao, @PathParam("idPerfil") Integer idPerfil) {
		return manutencaoPreventivaService.buscarPorPerfil(idPerfil, matricula, numeroSolicitacao);
	}
	
	@GET
	@Path("/download-relatorio-preventiva/{idPreventiva}")
	public Response downloadRelatorioCorretiva(@PathParam("idPreventiva") Long id) throws Exception{
		RelatorioManutencaoPreventivaVO relatorio = manutencaoPreventivaService.buscarRelatorioManutencaoPreventiva(id);
		try {
			byte[] arquivo = geradorRelatorio.gerarRelatorioManutencaoPreventiva(relatorio).getArquivo();
			ResponseBuilder response = Response.ok((Object) new ByteArrayInputStream(arquivo));
			response.header("Content-Disposition", "attachment;filename=Relatorio_manutencao_preventiva.pdf");
			response.header("Content-Type", "application/pdf");
			return response.build();
		} catch (Exception e) {
			throw e;
		}

	}
	
	
}
