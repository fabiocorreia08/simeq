package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.EquipamentoDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.EquipamentoService;
import br.gov.cmb.simeq.vo.EquipamentoVO;
import io.swagger.annotations.Api;

@Api("Equipamento")
@Path("/equipamento")
public class EquipamentoResource extends AbstractResource {
	
	@Inject
	private EquipamentoService equipamentoService;
	
	@GET
	@Path("/{id}")
	public EquipamentoDTO buscarPor(@PathParam("id") Long idEquipamento) {
		return equipamentoService.buscarPor(idEquipamento);
	}
	
	@POST
	@Path("/filtrar")
	public Pagina<EquipamentoDTO> filtrar(EquipamentoVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<EquipamentoDTO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return equipamentoService.filtrar(pagina);
	}
	
	@GET
	@Path("/buscar-codigo-nome")
	public List<EquipamentoDTO> buscarPorCodigoManutencaoNomeEquipamento(@QueryParam("codigoManutencao") String codigoManutencao, @QueryParam("nomeEquipamento") String nomeEquipamento) {
		return equipamentoService.buscarPorCodigoManutencaoNomeEquipamento(codigoManutencao, nomeEquipamento);
	}
	
	@POST
	public EquipamentoDTO salvar(EquipamentoDTO equipamentoDTO){
		return equipamentoService.salvar(equipamentoDTO);
	}
	
	@PUT
	public EquipamentoDTO atualizar(EquipamentoDTO equipamentoDTO){
		return equipamentoService.atualizar(equipamentoDTO);
	}
	
	@GET
	public List<LabelValueDTO> buscarTodosEquipamentoLabelValue() {
		return this.equipamentoService.buscarTodosEquipamentoLabelValue();
	}
	
	@GET
	@Path("/hierarquia/{perfil}/{matricula}")
	public List<LabelValueDTO> buscarHierarquiaCCUsuarioLogado(@PathParam("perfil")Integer perfil, @PathParam("matricula")String matricula) {
		return this.equipamentoService.buscarHierarquiaCCUsuarioLogado(perfil, matricula);
	}
	
	@GET
	@Path("/hierarquia/familia/{perfil}/{matricula}")
	public List<LabelValueDTO> buscarHierarquiaFamilia(@PathParam("perfil")Integer perfil, @PathParam("matricula")String matricula) {
		return this.equipamentoService.buscarHierarquiaFamilia(perfil, matricula);
	}
}
