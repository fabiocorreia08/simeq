package br.gov.cmb.simeq.resource;

import javax.inject.Inject;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import br.gov.cmb.simeq.dto.AprovacaoReprovacaoManutencaoPreventivaDTO;
import br.gov.cmb.simeq.service.AprovacaoSolicitacaoPreventivaService;
import io.swagger.annotations.Api;

@Api("Aprovacao-Solicitacao-preventiva")
@Path("/aprovacao-solicitacao-preventiva")
public class AprovacaoSolicitacaoPreventivaResource {

	@Inject
	private AprovacaoSolicitacaoPreventivaService aprovacaoSolicitacaoService;
	
	@POST
	@Path("/reprovar")
	public void repprovar(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO){
		aprovacaoSolicitacaoService.reprovar(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
	
	@POST
	@Path("/aprovar")
	public void aprovar(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO){
		aprovacaoSolicitacaoService.aprovar(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
	
	@POST
	@Path("/enviar-email-aprovacao")
	public void enviarEmailAprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO){
		aprovacaoSolicitacaoService.enviarEmailAprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
	
	@POST
	@Path("/enviar-email-reprovacao")
	public void enviarEmailReprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO){
		aprovacaoSolicitacaoService.enviarEmailReprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
}
