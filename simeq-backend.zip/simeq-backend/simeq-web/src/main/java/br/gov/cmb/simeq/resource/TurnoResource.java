package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.TurnoService;
import io.swagger.annotations.Api;

@Api("Turno")
@Path("/turno")
public class TurnoResource {
	
	@Inject
	private TurnoService turnoService;
	
	@GET
	public List<LabelValueDTO> buscarTodos() {
		return turnoService.buscarTodos();
	}

	
}
