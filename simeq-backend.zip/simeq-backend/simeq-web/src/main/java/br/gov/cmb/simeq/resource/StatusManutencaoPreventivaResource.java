package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.StatusManutencaoPreventivaService;
import br.gov.cmb.simeq.vo.HistoricoStatusPreventivaFiltroVO;
import br.gov.cmb.simeq.vo.HistoricoStatusPreventivaVO;
import io.swagger.annotations.Api;

@Api("Status Manutenção Preventiva")
@Path("/status-preventiva")
public class StatusManutencaoPreventivaResource extends AbstractResource {
	
	@Inject
	private StatusManutencaoPreventivaService statusManutencaoPreventivaService;
	
	@GET
	public List<LabelValueDTO> buscarTodos() {
		return this.statusManutencaoPreventivaService.buscarTodos();
	}
	
	@GET
	@Path("/manutencao/{idManutencao}")
	public List<LabelValueDTO> buscarStatusCombo(@PathParam("idManutencao")Long idManutencao) {
		return statusManutencaoPreventivaService.buscarStatusCombo(idManutencao);
	}
	
	@POST
	@Path("/pagina")
	public Pagina<HistoricoStatusPreventivaVO> buscarHistoricoStatusVO(HistoricoStatusPreventivaFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro, 
			@QueryParam("tamanho") Integer tamanho) {
		Pagina<HistoricoStatusPreventivaVO> pagina = new Pagina<HistoricoStatusPreventivaVO>(filtro, primeiroRegistro, tamanho);
		return statusManutencaoPreventivaService.filtrar(pagina);
	}
}
