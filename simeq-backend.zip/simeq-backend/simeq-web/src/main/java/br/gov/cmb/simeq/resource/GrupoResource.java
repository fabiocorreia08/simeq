package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import br.gov.cmb.simeq.dto.GrupoDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.GrupoService;
import io.swagger.annotations.Api;

@Api("Grupo")
@Path("/grupo")
public class GrupoResource extends AbstractResource {

	@Inject
	private GrupoService grupoService;

	@GET
	@Path("/{idGrupo}")
	public GrupoDTO buscarGrupo(@PathParam("idGrupo") Long idGrupo) {
		return grupoService.buscarGrupo(idGrupo);
	}
	
	@GET
	@Path("/grupos-pai/{idEquipamento}")
	public List<GrupoDTO> buscarGruposPai(@PathParam("idEquipamento") Long idEquipamento) {
		return grupoService.buscarGruposPai(idEquipamento);
	}
	
	@GET
	@Path("/grupos-filho/{idGrupoPai}")
	public List<GrupoDTO> buscarGruposFilho(@PathParam("idGrupoPai") Long idGrupoPai) {
		return grupoService.buscarGruposFilho(idGrupoPai);
	}
	
	@POST
	public Long salvar(GrupoDTO grupoDTO) {
		return grupoService.inserirGrupo(grupoDTO);
	}

	@POST
	@Path("/{retornarCodigo}")
	public Long salvar(GrupoDTO grupoDTO, @PathParam("retornarCodigo") Boolean retornarCodigo) {
		return grupoService.inserirGrupo(grupoDTO, retornarCodigo);
	}
	
	@PUT
	public GrupoDTO atualizar(GrupoDTO grupoDTO) {
		return grupoService.atualizarGrupo(grupoDTO);
	}
	
	@DELETE
	@Path("/{idGrupo}")
	public void remover(@PathParam("idGrupo") Long idGrupo) {
		grupoService.removerGrupo(idGrupo);
	}
	
	@GET
	@Path("/equipamento/{idEquipamento}")
	public List<LabelValueDTO> buscarGruposPorEquipamento(@PathParam("idEquipamento") Long idEquipamento) {
		return this.grupoService.buscarGruposPorEquipamento(idEquipamento);
	}
}
	