package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import br.gov.cmb.simeq.dto.HistoricoSituacaoEquipamentoDTO;
import br.gov.cmb.simeq.service.HistoricoSituacaoEquipamentoService;
import io.swagger.annotations.Api;

@Api("Historico Situação Equipamento")
@Path("/historico-situacao-equipamento")
public class HistoricoSituacaoEquipamentoResource extends AbstractResource {

	@Inject
	private HistoricoSituacaoEquipamentoService historicoSituacaoEquipamentoService;

	@GET
	@Path("/todos/{id}")
	public List<HistoricoSituacaoEquipamentoDTO> buscarTodosPor(@PathParam("id") Long idEquipamento) {
		return historicoSituacaoEquipamentoService.buscarTodosPor(idEquipamento);
	}
	
	@GET
	@Path("/{id}")
	public HistoricoSituacaoEquipamentoDTO buscarPor(@PathParam("id") Long idHistoricoSituacaoEquipamento) {
		return historicoSituacaoEquipamentoService.buscarPor(idHistoricoSituacaoEquipamento);
	}
	
	@GET
	@Path("centro-custo-ativo/{idEquipamento}")
	public HistoricoSituacaoEquipamentoDTO buscarUltimoCentroCusto(@PathParam("idEquipamento") Long idEquipamento) {
		return historicoSituacaoEquipamentoService.buscarUltimoCentroCusto(idEquipamento);
	}

	@DELETE
	@Path("/{id}")
	public void remover(@PathParam("id") Long idHistoricoSituacaoEquipamento) {
		historicoSituacaoEquipamentoService.remover(idHistoricoSituacaoEquipamento);
	}

	@POST
	public HistoricoSituacaoEquipamentoDTO salvar(HistoricoSituacaoEquipamentoDTO historicoSituacaoEquipamentoDTO) {
		return historicoSituacaoEquipamentoService.salvar(historicoSituacaoEquipamentoDTO);
	}

	@PUT
	public HistoricoSituacaoEquipamentoDTO atualizar(HistoricoSituacaoEquipamentoDTO historicoSituacaoEquipamentoDTO) {
		return historicoSituacaoEquipamentoService.atualizar(historicoSituacaoEquipamentoDTO);
	}
	
	@GET
	@Path("equipamento-centro-custo-instalacao/{idEquipamento}")
	public HistoricoSituacaoEquipamentoDTO buscarCentroCustoInstalacao(@PathParam("idEquipamento") Long idEquipamento) {
		return historicoSituacaoEquipamentoService.buscarCentroCustoInstalacao(idEquipamento);
	}

}
