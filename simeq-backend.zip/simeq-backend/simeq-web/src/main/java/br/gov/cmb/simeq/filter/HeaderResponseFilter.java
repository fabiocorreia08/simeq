package br.gov.cmb.simeq.filter;

import java.io.IOException;

import javax.inject.Inject;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;

import br.gov.cmb.simeq.security.SimeqAuthentication;
import br.gov.cmb.common.ejb.configuracao.Configuracao;
import br.gov.cmb.common.rest.security.AuthenticationContext;
import br.gov.cmb.common.rest.util.JwtTokenHelper;

@Provider
public class HeaderResponseFilter implements ContainerResponseFilter {

	@Inject
	private AuthenticationContext authenticationContext;

	@Inject @Configuracao("jwt.tempoexpiracao")
	private Integer tempoExpiracao;

	@Inject @Configuracao("jwt.signkey")
	private String signKey;

	@Override
	public void filter(ContainerRequestContext requestContext, ContainerResponseContext responseContext)
			throws IOException {

		JwtTokenHelper jwtTokenHelper = new JwtTokenHelper(tempoExpiracao, signKey);

		SimeqAuthentication authentication = (SimeqAuthentication) authenticationContext.getAuthentication();
		String token = authenticationContext.getAuthentication() != null ? authentication.getToken() : null;

		if (isUnauthorized(responseContext) && jwtTokenHelper.isValid(token)) {
			String refreshToken = jwtTokenHelper.handleRefreshToken(token);
			responseContext.getHeaders().add(JwtTokenHelper.HEADER_TOKEN, refreshToken);
		}
	}

	private boolean isUnauthorized(ContainerResponseContext responseContext) {
		return responseContext.getStatus() != Status.UNAUTHORIZED.getStatusCode();
	}

}
