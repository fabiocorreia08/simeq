package br.gov.cmb.simeq.filter;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.ext.Provider;

import br.gov.cmb.common.ejb.configuracao.Configuracao;
import br.gov.cmb.common.rest.security.AuthenticationContext;
import br.gov.cmb.common.rest.util.JwtTokenHelper;
import br.gov.cmb.simeq.exception.UsuarioNaoAutorizadoException;
import br.gov.cmb.simeq.resource.LoginResource;
import br.gov.cmb.simeq.security.SimeqAuthentication;

@Provider
public class HeaderRequestFilter implements ContainerRequestFilter {

	private static final String HEADER_TOKEN_UNDEFINED = "undefined";
	
	@Inject @Configuracao("jwt.tempoexpiracao")
	private Integer tempoExpiracao;

	@Inject @Configuracao("jwt.signkey")
	private String signKey;
	
	@Inject AuthenticationContext authenticationContext;
	
	@Override
    public void filter(ContainerRequestContext ctx) throws IOException {
		if(!LoginResource.class.equals(ctx.getUriInfo().getMatchedResources().get(0).getClass().getSuperclass())) {
			JwtTokenHelper jwtTokenHelper = new JwtTokenHelper(tempoExpiracao, signKey);
			String token = ctx.getHeaders().getFirst(JwtTokenHelper.HEADER_TOKEN);
			if(token != null && !HEADER_TOKEN_UNDEFINED.equals(token)) {
				List<String> permissions = jwtTokenHelper.getPermissions(token);
				String username = jwtTokenHelper.getUsername(token);
				Object details = jwtTokenHelper.getDetails(token);
				
				authenticationContext.setAuthentication(new SimeqAuthentication(username, permissions, details));
			} else {
				throw new UsuarioNaoAutorizadoException();
			}			
		}
	}
}