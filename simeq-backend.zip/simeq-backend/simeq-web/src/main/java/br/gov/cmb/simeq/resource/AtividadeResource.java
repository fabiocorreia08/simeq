package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.AtividadeService;
import br.gov.cmb.simeq.vo.AtividadeConsultaVO;
import br.gov.cmb.simeq.vo.AtividadeDetalharVO;
import br.gov.cmb.simeq.vo.AtividadeFiltroVO;
import br.gov.cmb.simeq.vo.AtividadeMaterialFiltroVO;
import br.gov.cmb.simeq.vo.AtividadeVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.MaterialVO;
import io.swagger.annotations.Api;

@Api("Atividade")
@Path("/atividades")
public class AtividadeResource extends AbstractResource {
	
	@Inject
	private AtividadeService atividadeService;
	
	@GET
	@Path("/{id}/{numeroSolicitacao}")
	public AtividadeVO buscarAtividadePorId(@PathParam("id") Long id, @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return atividadeService.buscarAtividadeVOPorId(id, numeroSolicitacao);
	}
	
	@POST
	public AtividadeVO salvar(AtividadeVO atividadeVO){
		return atividadeService.salvar(atividadeVO);
	}
	
	@PUT
	public AtividadeVO atualizar(AtividadeVO atividadeVO) {
		return atividadeService.atualizar(atividadeVO);
	}
	
	@POST
	@Path("/pagina")
	public Pagina<AtividadeConsultaVO> filtrar(AtividadeFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<AtividadeConsultaVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return atividadeService.filtrar(pagina);
	}
	
	@POST
	@Path("/pagina-material")
	public Pagina<MaterialVO> filtrarMaterial(AtividadeMaterialFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<MaterialVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return atividadeService.filtrarMaterial(pagina);
	}
	
	@GET
	@Path("/acao")
	public List<LabelValueDTO> buscarTodasAcoesLabelValue() {
		return atividadeService.buscarTodasAcoesLabelValue();
	}
	
	@GET
	@Path("/componente")
	public List<LabelValueDTO> buscarTodosComponentesLabelValue() {
		return atividadeService.buscarTodosComponentesLabelValue();
	}
	
	@GET
	@Path("/meses")
	public List<LabelValueDTO> buscarMesesLabelValue() {
		return atividadeService.buscarMeses(null);
	}
	
	@GET
	@Path("/unidades")
	public List<LabelValueDTO> buscarUnidadesLabelValue() {
		return atividadeService.buscarUnidadesLabelValue();
	}

	@GET
	@Path("/meses-solicitacao/{numeroSolicitacao}")
	public List<LabelValueDTO> buscarMesesSolicitacaoLabelValue(@PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return atividadeService.buscarMeses(numeroSolicitacao);
	}
	
	@GET
	@Path("/material/{codigo}")
	public MaterialVO buscarMaterialPorId(@PathParam("codigo") String codigo) {
		return atividadeService.buscarMaterialPorId(codigo);
	}
	
	@DELETE
	@Path("/{id}/{numeroSolicitacao}")
	public void removerAtividade(@PathParam("id") Long idAtividade, @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		atividadeService.removerAtividade(idAtividade, numeroSolicitacao);
	}
	
	@GET
	@Path("/autorizacao-usuario-edicao/{numeroSolicitacao}/{matricula}/{idAtividade}/{idPerfil}")
	public boolean permitirEditar(@PathParam("numeroSolicitacao") String numeroSolicitacao, @PathParam("matricula") String matricula, @PathParam("idAtividade") Long idAtividade, @PathParam("idPerfil") Integer idPerfil) {
		return atividadeService.permitirEditar(numeroSolicitacao, matricula, idAtividade, idPerfil);
	}
	
	@GET
	@Path("/tecnico-alocado/{numeroSolicitacao}/{matricula}")
	public ManutencaoVO buscarSolicitacaoTecnicoAlocado(@PathParam("numeroSolicitacao") String numeroSolicitacao, @PathParam("matricula") String matriculaTecnico) {
		return atividadeService.buscarSolicitacaoTecnicoAlocado(numeroSolicitacao, matriculaTecnico);
	}
	
	@GET
	@Path("/detalhe/{id}/{numeroSolicitacao}")
	public AtividadeDetalharVO buscarAtividadeDetalhe(@PathParam("id") Long idAtividade, @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return atividadeService.buscarAtividadeDetalhe(idAtividade, numeroSolicitacao);
	}
	
	@GET
	@Path("/manutencao-corretiva/{idManutencao}/{numeroSolicitacao}")
	public List<AtividadeConsultaVO> buscarAtividadeConsultaPorManutencao(@PathParam("idManutencao") Long idManutencao,  @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return atividadeService.buscarAtividadeConsultaPorManutencao(idManutencao, numeroSolicitacao);
	}
}
