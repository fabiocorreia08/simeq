package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.SetorManutencaoService;
import io.swagger.annotations.Api;

@Api("Setor Manutencao")
@Path("/setor-manutencao")
public class SetorManutencaoResource extends AbstractResource{
	
	@Inject
	private SetorManutencaoService setorManutencaoService;
	
	@GET
	public List<LabelValueDTO> buscarTodosSetores(){
		return setorManutencaoService.buscarTodosSetores();
	}
	
	@GET
	@Path("/familia/{idFamilia}")
	public List<LabelValueDTO> buscarPorIdFamilia(@PathParam("idFamilia")Long idFamilia) {
		return setorManutencaoService.buscarPorIdFamilia(idFamilia);
	}
	
}
