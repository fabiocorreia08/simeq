package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;
import br.gov.cmb.simeq.service.ManutencaoCorretivaTecnicoService;
import br.gov.cmb.simeq.service.ManutencaoPreventivaTecnicoService;
import br.gov.cmb.simeq.utils.VerificaClasseUtil;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarFiltroVO;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;
import br.gov.cmb.simeq.vo.AlocacaoDetalharFiltroVO;
import br.gov.cmb.simeq.vo.AlocacaoDetalharVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaTecnicoConsultaVO;
import br.gov.cmb.simeq.vo.AlocacaoTecnicoVO;
import br.gov.cmb.simeq.vo.CadastroAlocacaoTecnicoVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaTecnicoFiltroVO;
import io.swagger.annotations.Api;

@Api("Manutenções Corretivas Técnicos")
@Path("/manutencoes-corretivas-tecnicos")
public class ManutencaoCorretivaTecnicoResource extends AbstractResource {
	
	@Inject
	private ManutencaoCorretivaTecnicoService manutencaoCorretivaTecnicoService;
	
	@Inject
	private ManutencaoPreventivaTecnicoService manutencaoPreventivaTecnicoService;
	
	@POST
	@Path("/pagina-listagem")
	public Pagina<AlocacaoDetalharVO> buscarAlocacaoManutencao(AlocacaoDetalharFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,
			@QueryParam("tamanho") Integer tamanho ) {
		Pagina<AlocacaoDetalharVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return manutencaoCorretivaTecnicoService.buscarAlocacaoManutencao(pagina);
	}
	
	@POST
	@Path("/tecnico")
	public AlocacaoTecnicoVO salvarTecnico(AlocacaoTecnicoVO alocacao) {
		return manutencaoCorretivaTecnicoService.salvarTecnico(alocacao);
	}
	
	@POST
	@Path("/alocacao")
	public CadastroAlocacaoTecnicoVO salvarAlocacao(CadastroAlocacaoTecnicoVO cadastroAlocacaoTecnicoVO) {
		return manutencaoCorretivaTecnicoService.salvarAlocacao(cadastroAlocacaoTecnicoVO);
	}
	
	@POST
	@Path("/pagina")
	public Pagina<ManutencaoCorretivaTecnicoConsultaVO> filtrar(ManutencaoCorretivaTecnicoFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<ManutencaoCorretivaTecnicoConsultaVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		return manutencaoCorretivaTecnicoService.filtrar(pagina);
	}
	
	@POST
	@Path("/pagina-tecnicos-cadastro-alocacao")
	public Pagina<AlocacaoCadastrarVO> filtrarTecnicosParaCadastro(AlocacaoCadastrarFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<AlocacaoCadastrarVO> pagina = new Pagina<>(filtro, primeiroRegistro, tamanho);
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(filtro.getNumeroSolicitacao());
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return manutencaoCorretivaTecnicoService.filtrarTecnicosParaCadastro(pagina);
		} else {
			return manutencaoPreventivaTecnicoService.filtrarTecnicosParaCadastro(pagina);
		}
	}
	
	@GET
	@Path("/tecnicos-alocado/{numeroSolicitacao}/{idPerfil}/{matricula}")
	public List<AlocacaoCadastrarVO> buscarTecnicosAlocados(@PathParam("numeroSolicitacao") String numeroSolicitacao, @PathParam("idPerfil") Integer idPerfil, 
			@PathParam("matricula") String matricula) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return manutencaoCorretivaTecnicoService.buscarTecnicosAlocados(numeroSolicitacao, idPerfil, matricula);
		} else {
			return manutencaoPreventivaTecnicoService.buscarTecnicosAlocados(numeroSolicitacao, idPerfil, matricula);
		}
	}
	
	@GET
	@Path("/tecnico-disponivel-solicitacao/{matriculaTecnico}/{numeroSolicitacao}")
	public boolean buscarManutencaoComPermissaoTecnico(@PathParam("matriculaTecnico") String matriculaTecnico, @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return manutencaoCorretivaTecnicoService.buscarManutencaoComPermissaoTecnico(matriculaTecnico, numeroSolicitacao);
	}
	
	@GET
	@Path("/exclusao-manutencao/{matriculaTecnico}/{numeroSolicitacao}")
	public boolean excluirAlocacao(@PathParam("matriculaTecnico") String matriculaTecnico, @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return manutencaoCorretivaTecnicoService.excluirAlocacao(matriculaTecnico, numeroSolicitacao);
	}
	
	@GET
	@Path("/pemitido-exclusao-alocacao/{matriculaTecnico}/{numeroSolicitacao}")
	public boolean isPermitdoexcluirAlocacao(@PathParam("matriculaTecnico") String matriculaTecnico, @PathParam("numeroSolicitacao") String numeroSolicitacao) {
		return manutencaoCorretivaTecnicoService.isPermitdoexcluirAlocacao(matriculaTecnico, numeroSolicitacao);
	}

}
