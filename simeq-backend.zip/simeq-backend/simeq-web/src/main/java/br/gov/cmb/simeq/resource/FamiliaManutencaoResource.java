package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.FamiliaDTO;
import br.gov.cmb.simeq.dto.FamiliaTabelaDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.service.FamiliaManutencaoService;
import br.gov.cmb.simeq.vo.FamiliaFiltroVO;
import io.swagger.annotations.Api;

@Api("Familia Manutencao")
@Path("/familia-manutencao")
public class FamiliaManutencaoResource extends AbstractResource {

	@Inject
	FamiliaManutencaoService familiaManutencaoService;

	@GET
	public List<FamiliaDTO> buscarTodos() {
		return familiaManutencaoService.buscarTodos();
	}

	@GET
	@Path("/{id}")
	public Response buscarPorId(@PathParam("id") Long id) {
		try {
			return Response.status(Response.Status.OK).entity(familiaManutencaoService.buscarPorId(id)).build();
		} catch (Exception e) {
			return Response.status(Response.Status.NOT_FOUND).entity(e.getMessage()).build();
		}
	}

	@POST
	public Response salvarFamilia(FamiliaDTO familiaDTO) {
		
		familiaManutencaoService.salvarFamilia(familiaDTO);
		return Response.status(Response.Status.CREATED).build();
	}

	@PUT
	public Response editarFamilia(FamiliaDTO familiaDTO) {
	
		familiaManutencaoService.editarFamilia(familiaDTO);
		return Response.status(Response.Status.ACCEPTED).build();
	}

	@POST
	@Path("/pagina")
	public Pagina<FamiliaTabelaDTO> filtrar(FamiliaFiltroVO filtro, @QueryParam("primeiroRegistro") Integer primeiroRegistro,@QueryParam("tamanho") Integer tamanho ) {
		Pagina<FamiliaTabelaDTO> pagina = new Pagina<FamiliaTabelaDTO>(filtro, primeiroRegistro, tamanho);
		return familiaManutencaoService.filtrar(pagina);
	}
	
	@GET
	@Path("/assistente-producao/{centroCusto}")
	public List<LabelValueDTO> buscarPorCentroCustoAssistenteProducao(@PathParam("centroCusto")String centroCusto) {
		return familiaManutencaoService.buscarPorCentroCustoAssistenteProducao(centroCusto);
	}
	
	@DELETE
	@Path("/{id}")
	public Response deletar(@PathParam("id") Long id) {
		try {
			familiaManutencaoService.deletarFamilia(id);
			return Response.status(Response.Status.OK).build();
		}catch (Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
		}
	}
	
	@GET
	@Path("/setores-familia/{centroCusto}")
	public Response buscarSetoresPorCC(@PathParam("centroCusto")String centroCusto){
		return Response.status(Response.Status.OK).entity(this.familiaManutencaoService.buscarSetoresPorCC(centroCusto)).build();
	}
}
