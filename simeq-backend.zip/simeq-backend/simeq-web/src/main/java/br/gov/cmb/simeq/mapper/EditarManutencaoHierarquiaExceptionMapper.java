package br.gov.cmb.simeq.mapper;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import br.gov.cmb.simeq.exception.EditarManutencaoHierarquiaException;

@Provider
public class EditarManutencaoHierarquiaExceptionMapper implements ExceptionMapper<EditarManutencaoHierarquiaException>{

	@Override
	public Response toResponse(EditarManutencaoHierarquiaException e) {
		String mensagem = "Não é permitido a alteraração de manutenções de outros Centros de Custo.";
		return Response.status(Response.Status.CONFLICT)
				.entity("{\"erros\": [\""+mensagem+"\"]}")
				.type(MediaType.APPLICATION_JSON)
				.build();
	}

}
