package br.gov.cmb.simeq.mapper;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import br.gov.cmb.simeq.exception.ErroEnvioEmailException;

@Provider
public class ErroEnvioEmailExceptionMapper implements ExceptionMapper<ErroEnvioEmailException> {

	public Response toResponse(ErroEnvioEmailException e) {
		String mensagem = "Ocorreu um erro ao enviar o e-mail.";
		return Response.status(Response.Status.BAD_REQUEST).entity("{\"erros\": [\""+mensagem+"\"]}").type(MediaType.APPLICATION_JSON).build();
	}
}
