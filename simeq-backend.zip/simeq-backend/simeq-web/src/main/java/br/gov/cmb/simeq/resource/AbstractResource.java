package br.gov.cmb.simeq.resource;

import br.gov.cmb.common.rest.util.JwtTokenHelper;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@ApiImplicitParams({
		@ApiImplicitParam(name = JwtTokenHelper.HEADER_TOKEN, dataType = "string", paramType = "header") })
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AbstractResource {

}
