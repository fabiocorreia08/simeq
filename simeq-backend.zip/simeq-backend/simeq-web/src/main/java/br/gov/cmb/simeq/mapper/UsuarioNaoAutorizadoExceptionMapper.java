package br.gov.cmb.simeq.mapper;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import br.gov.cmb.simeq.exception.UsuarioNaoAutorizadoException;

@Provider
public class UsuarioNaoAutorizadoExceptionMapper implements ExceptionMapper<UsuarioNaoAutorizadoException>{

	@Override
	public Response toResponse(UsuarioNaoAutorizadoException exception) {
		String mensagem = "Usuário não autorizado";
		return Response.status(Response.Status.FORBIDDEN).entity("{\"erros\": [\""+mensagem+"\"]}").type(MediaType.APPLICATION_JSON).build();
	}

}
