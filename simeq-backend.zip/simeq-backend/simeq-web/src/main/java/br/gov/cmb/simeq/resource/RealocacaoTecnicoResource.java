package br.gov.cmb.simeq.resource;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import br.gov.cmb.simeq.dto.RealocacaoTecnicoDTO;
import br.gov.cmb.simeq.service.RealocacaoTecnicoService;
import io.swagger.annotations.Api;

@Api("Realocacoes Técnico")
@Path("/realocacao-tecnico")
public class RealocacaoTecnicoResource extends AbstractResource{
	
	@Inject
	private RealocacaoTecnicoService realocacaoTecnicoService;
	
	@GET
	@Path("/{id}")
	public List<RealocacaoTecnicoDTO> buscarPor(@PathParam("id") Long idTecnico) {
		return realocacaoTecnicoService.buscarPor(idTecnico);
	}
	
	@GET
	@Path("buscar-realocacao/{id}")
	public RealocacaoTecnicoDTO buscarRealocacaoPorId(@PathParam("id") Long idRealocacao) {
		return realocacaoTecnicoService.buscarRealocacaoPorId(idRealocacao);
	}
	
	@DELETE
	@Path("/{id}")
	public void remover(@PathParam("id") Long idRealocacao) {
		realocacaoTecnicoService.remover(idRealocacao);
	}
	
	@POST
	public RealocacaoTecnicoDTO salvar(RealocacaoTecnicoDTO realocacaoTecnicoDTO) {
		return realocacaoTecnicoService.salvar(realocacaoTecnicoDTO);
	}
	
	@PUT
	public RealocacaoTecnicoDTO atualizar(RealocacaoTecnicoDTO realocacaoTecnicoDTO) {
		return realocacaoTecnicoService.atualizar(realocacaoTecnicoDTO);
	}

	
}
