package br.gov.cmb.simeq.resource;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.gov.cmb.common.rest.security.Authentication;
import br.gov.cmb.simeq.security.SimeqAuthentication;
import br.gov.cmb.simeq.security.SimeqAuthenticationProvider;
import io.swagger.annotations.Api;

@Api("Login")
@Path("/login")
public class LoginResource {
	
	@Inject
	private SimeqAuthenticationProvider authenticationProvider;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Authentication login(SimeqAuthentication authentication) {
		return authenticationProvider.authenticate(authentication);
	}
	
}