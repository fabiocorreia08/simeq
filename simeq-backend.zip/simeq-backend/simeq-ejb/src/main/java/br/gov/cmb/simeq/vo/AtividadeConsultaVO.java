package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

public class AtividadeConsultaVO implements Serializable {

	private static final long serialVersionUID = -3453073135231230884L;
	
	private Long id;
	private String grupoSubGrupo;
	private String acao;
	private String componente;
	private String hht;
	private String matriculaExecutante;
	private Date dataCriacao;
	
	public AtividadeConsultaVO(){}
	
	public AtividadeConsultaVO(Long id, String grupo, String subGrupo, String acao, String componente, Integer horasTrabalhadas, Integer minutosTrabalhados,
			String matriculaExecutante, Date dataCriacao) {
		this.id = id;
		this.grupoSubGrupo = grupo + "/" + subGrupo;
		this.acao = acao;
		this.componente = componente;
		formatarHorasMinutosAtividade(horasTrabalhadas, minutosTrabalhados);
		this.matriculaExecutante = matriculaExecutante;
		this.dataCriacao = dataCriacao;
	}
	
	private void formatarHorasMinutosAtividade(Integer horasTrabalhadas, Integer minutosTrabalhados) {
		String horas = horasTrabalhadas.toString();
		String minutos = minutosTrabalhados.toString();
		while (horas.length() < 3) {
			horas = "0" + horas;
		}
		while (minutos.length() < 2) {
			minutos = "0" + minutos;
		}
		this.hht = horas.concat(":").concat(minutos);
	}

	public String getGrupoSubGrupo() {
		return grupoSubGrupo;
	}

	public void setGrupoSubGrupo(String grupoSubGrupo) {
		this.grupoSubGrupo = grupoSubGrupo;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public String getComponente() {
		return componente;
	}

	public void setComponente(String componente) {
		this.componente = componente;
	}

	public String getHht() {
		return hht;
	}

	public void setHht(String hht) {
		this.hht = hht;
	}

	public String getMatriculaExecutante() {
		return matriculaExecutante;
	}

	public void setMatriculaExecutante(String matriculaExecutante) {
		this.matriculaExecutante = matriculaExecutante;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

}
