package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ManutencaoCorretivaConsultaVO implements Serializable{

	private static final long serialVersionUID = -5814610780258739351L;
	
	private Long idManutencao;
	private String numeroSolicitacao;
	private String tipo;
	private String status;
	private Date dataCadastro;
	private Date dataAlteracao;
	private String codigoManutencaoEquipamento;
	private String centroCusto;
	private boolean paralizacao;
	private Long idStatus;
	private List<Long> idSetoresFamilia = new ArrayList<Long>();
	
	public ManutencaoCorretivaConsultaVO(Long idManutencao, String numeroSolicitacao, String status, Date dataCadastro, Date dataAlteracao, String codigoManutencaoEquipamento,
			String centroCusto, boolean paralizacao, Long idStatus) {
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.status = status;
		this.dataCadastro = dataCadastro;
		this.dataAlteracao = dataAlteracao;
		this.codigoManutencaoEquipamento = codigoManutencaoEquipamento;
		this.centroCusto = centroCusto;
		this.paralizacao = paralizacao;
		this.idStatus = idStatus;
	}
	
	public ManutencaoCorretivaConsultaVO(Long idManutencao, String numeroSolicitacao, String tipo, String status, Date dataCadastro, Date dataAlteracao, String codigoManutencaoEquipamento,
			String centroCusto, boolean paralizacao, Long idStatus) {
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.tipo = tipo.toString();
		this.status = status;
		this.dataCadastro = dataCadastro;
		this.dataAlteracao = dataAlteracao;
		this.codigoManutencaoEquipamento = codigoManutencaoEquipamento;
		this.centroCusto = centroCusto;
		this.paralizacao = paralizacao;
		this.idStatus = idStatus;
	}
	
	public ManutencaoCorretivaConsultaVO(Long idManutencao, String numeroSolicitacao, String tipo, String status, Date dataCadastro, Date dataAlteracao, String codigoManutencaoEquipamento,
			String centroCusto) {
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.tipo = tipo.toString();
		this.status = status;
		this.dataCadastro = dataCadastro;
		this.dataAlteracao = dataAlteracao;
		this.codigoManutencaoEquipamento = codigoManutencaoEquipamento;
		this.centroCusto = centroCusto;
	}
	
	public ManutencaoCorretivaConsultaVO(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	
	public Long getIdManutencao() {
		return idManutencao;
	}
	
	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	
	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}
	
	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Date getDataCadastro() {
		return dataCadastro;
	}
	
	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	public Date getDataAlteracao() {
		return dataAlteracao;
	}
	
	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}
	
	public String getCodigoManutencaoEquipamento() {
		return codigoManutencaoEquipamento;
	}
	
	public void setCodigoManutencaoEquipamento(String codigoManutencaoEquipamento) {
		this.codigoManutencaoEquipamento = codigoManutencaoEquipamento;
	}
	
	public String getCentroCusto() {
		return centroCusto;
	}
	
	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public boolean isParalizacao() {
		return paralizacao;
	}

	public void setParalizacao(boolean paralizacao) {
		this.paralizacao = paralizacao;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public List<Long> getIdSetoresFamilia() {
		return idSetoresFamilia;
	}

	public void setIdSetoresFamilia(List<Long> idSetoresFamilia) {
		this.idSetoresFamilia = idSetoresFamilia;
	}
	
}
