package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;

@Audited
@Entity
@Table(name = "TECNICO")
@SqlResultSetMappings({
		@SqlResultSetMapping(name = "alocacaoCorretivaMapping", classes = {
				@ConstructorResult(targetClass = AlocacaoCadastrarVO.class, columns = {
						@ColumnResult(name = "CD_MATRICULA", type = String.class),
						@ColumnResult(name = "NM_EMPREGADO", type = String.class),
						@ColumnResult(name = "NM_CARGO", type = String.class),
						@ColumnResult(name = "NM_FUNCAO", type = String.class),
						@ColumnResult(name = "ID_TECNICO", type = Long.class),
						@ColumnResult(name = "CD_SIT_FOLHA", type = String.class),
						@ColumnResult(name = "nm_turno", type = String.class) }) }),
		@SqlResultSetMapping(name = "alocacaoPreventivaMapping", classes = {
				@ConstructorResult(targetClass = AlocacaoCadastrarVO.class, columns = {
						@ColumnResult(name = "CD_MATRICULA", type = String.class),
						@ColumnResult(name = "NM_EMPREGADO", type = String.class),
						@ColumnResult(name = "NM_CARGO", type = String.class),
						@ColumnResult(name = "NM_FUNCAO", type = String.class),
						@ColumnResult(name = "ID_TECNICO", type = Long.class),
						@ColumnResult(name = "CD_SIT_FOLHA", type = String.class),
						@ColumnResult(name = "nm_turno", type = String.class) }) })

})

@NamedNativeQueries({
		@NamedNativeQuery(name = "alocacaoCorretiva", query = "SELECT DISTINCT T.CD_MATRICULA,IT.NM_EMPREGADO, IT.NM_CARGO, IT.NM_FUNCAO, T.ID_TECNICO, IT.CD_SIT_FOLHA, TV.nm_turno "
				+ "FROM TECNICO AS T " + "INNER JOIN VW_ERP_CORPO_TECNICO AS IT ON T.CD_MATRICULA = IT.CD_MATRICULA "
				+ "INNER JOIN VW_DN_PESSOA AS PW ON T.CD_MATRICULA = PW.CD_MATRICULA "
				+ "INNER JOIN VW_DN_TURNO AS TV ON PW.CD_TURNO = TV.cd_turno "
				+ "LEFT JOIN REALOCACAO_TECNICO AS R ON T.ID_TECNICO = R.ID_TECNICO "
				+ "													AND (R.DT_PERIODO_ATE IS NULL OR CONVERT(VARCHAR(10), getdate(),23) <= CONVERT(VARCHAR(10), DT_PERIODO_ATE,23)) "
				+ "														AND CONVERT(VARCHAR(10), getdate(),23) >= CONVERT(VARCHAR(10), R.DT_PERIODO_DE,23)"
				+ "WHERE T.CD_MATRICULA IN (SELECT CT.CD_MATRICULA FROM VW_ERP_CORPO_TECNICO CT WHERE R.CD_CENTRO_CUSTO IN (:centroCustosHierarquia)) "
				+ "OR (R.CD_CENTRO_CUSTO IS NULL AND T.CD_MATRICULA IN (SELECT CT.CD_MATRICULA FROM VW_ERP_CORPO_TECNICO CT WHERE CT.CD_CENTRO_CUSTO IN (:centroCustosHierarquia))) "
				+ "OR PW.TX_SIGLA_CENTRO_CUSTO = (SELECT S.NM_SETOR_MANUTENCAO "
				+ "			FROM MANUTENCAO_CORRETIVA M "
				+ "			INNER JOIN SETOR_MANUTENCAO AS S ON M.ID_SETOR_MANUTENCAO = S.ID_SETOR_MANUTENCAO "
				+ "			WHERE M.NR_SOLICITACAO = :numeroSolicitacao) "
				+ "AND (:nomeCargo IS NULL or IT.NM_CARGO = :nomeCargo) "
				+ "AND (:idTecnico IS NULL or T.ID_TECNICO = :idTecnico) "
				+ "AND (:nomeFuncao IS NULL or IT.NM_FUNCAO = :nomeFuncao) "
				+ "AND (:codigoTurno IS NULL or IT.NM_CARGO = :codigoTurno) " + "EXCEPT "
				+ "SELECT DISTINCT T.CD_MATRICULA,IT.NM_EMPREGADO, IT.NM_CARGO, IT.NM_FUNCAO, T.ID_TECNICO, IT.CD_SIT_FOLHA, TV.nm_turno "
				+ "FROM TECNICO AS T " + "INNER JOIN VW_ERP_CORPO_TECNICO AS IT ON T.CD_MATRICULA = IT.CD_MATRICULA "
				+ "INNER JOIN VW_DN_PESSOA AS PW ON T.CD_MATRICULA = PW.CD_MATRICULA "
				+ "INNER JOIN VW_DN_TURNO AS TV ON PW.CD_TURNO = TV.cd_turno "
				+ "WHERE T.ID_TECNICO IN (SELECT MT.ID_TECNICO FROM MANUTENCAO_CORRETIVA M "
				+ "						INNER JOIN MANUTENCAO_CORRETIVA_TECNICO MT ON M.ID_MANUTENCAO_CORRETIVA IN (MT.ID_MANUTENCAO_CORRETIVA) "
				+ "						WHERE M.NR_SOLICITACAO = :numeroSolicitacao)", 
				resultSetMapping = "alocacaoCorretivaMapping"),
		@NamedNativeQuery(name = "alocacaoPreventiva", query = "SELECT DISTINCT T.CD_MATRICULA,IT.NM_EMPREGADO, IT.NM_CARGO, IT.NM_FUNCAO, T.ID_TECNICO, IT.CD_SIT_FOLHA, TV.nm_turno "
				+ "FROM TECNICO AS T " + "INNER JOIN VW_ERP_CORPO_TECNICO AS IT ON T.CD_MATRICULA = IT.CD_MATRICULA "
				+ "INNER JOIN VW_DN_PESSOA AS PW ON T.CD_MATRICULA = PW.CD_MATRICULA "
				+ "INNER JOIN VW_DN_TURNO AS TV ON PW.CD_TURNO = TV.cd_turno "
				+ "LEFT JOIN REALOCACAO_TECNICO AS R ON T.ID_TECNICO = R.ID_TECNICO "
				+ "													AND (R.DT_PERIODO_ATE IS NULL OR CONVERT(VARCHAR(10), getdate(),23) <= CONVERT(VARCHAR(10), DT_PERIODO_ATE,23)) "
				+ "														AND CONVERT(VARCHAR(10), getdate(),23) >= CONVERT(VARCHAR(10), R.DT_PERIODO_DE,23)"
				+ "WHERE T.CD_MATRICULA IN (SELECT CT.CD_MATRICULA FROM VW_ERP_CORPO_TECNICO CT WHERE R.CD_CENTRO_CUSTO IN (:centroCustosHierarquia)) "
				+ "OR (R.CD_CENTRO_CUSTO IS NULL AND T.CD_MATRICULA IN (SELECT CT.CD_MATRICULA FROM VW_ERP_CORPO_TECNICO CT WHERE CT.CD_CENTRO_CUSTO IN (:centroCustosHierarquia))) "
				+ "OR PW.TX_SIGLA_CENTRO_CUSTO = (SELECT S.NM_SETOR_MANUTENCAO "
				+ "			FROM MANUTENCAO_PREVENTIVA M "
				+ "			INNER JOIN SETOR_MANUTENCAO AS S ON M.ID_SETOR_MANUTENCAO = S.ID_SETOR_MANUTENCAO "
				+ "			WHERE M.NR_SOLICITACAO = :numeroSolicitacao) "
				+ "AND (:nomeCargo IS NULL or IT.NM_CARGO = :nomeCargo) "
				+ "AND (:idTecnico IS NULL or T.ID_TECNICO = :idTecnico) "
				+ "AND (:nomeFuncao IS NULL or IT.NM_FUNCAO = :nomeFuncao) "
				+ "AND (:codigoTurno IS NULL or IT.NM_CARGO = :codigoTurno) " + "EXCEPT "
				+ "SELECT DISTINCT T.CD_MATRICULA,IT.NM_EMPREGADO, IT.NM_CARGO, IT.NM_FUNCAO, T.ID_TECNICO, IT.CD_SIT_FOLHA, TV.nm_turno "
				+ "FROM TECNICO AS T " + "INNER JOIN VW_ERP_CORPO_TECNICO AS IT ON T.CD_MATRICULA = IT.CD_MATRICULA "
				+ "INNER JOIN VW_DN_PESSOA AS PW ON T.CD_MATRICULA = PW.CD_MATRICULA "
				+ "INNER JOIN VW_DN_TURNO AS TV ON PW.CD_TURNO = TV.cd_turno "
				+ "WHERE T.ID_TECNICO IN (SELECT MT.ID_TECNICO FROM MANUTENCAO_PREVENTIVA M "
				+ "						INNER JOIN MANUTENCAO_PREVENTIVA_TECNICO MT ON M.ID_MANUTENCAO_PREVENTIVA IN (MT.ID_MANUTENCAO_PREVENTIVA) "
				+ "						WHERE M.NR_SOLICITACAO = :numeroSolicitacao)", resultSetMapping = "alocacaoPreventivaMapping") })
public class Tecnico implements Serializable {

	private static final long serialVersionUID = -5640784910011327478L;

	@Id
	@Column(name = "ID_TECNICO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idTecnico;

	@Column(name = "CD_MATRICULA")
	private String codigoMatricula;

	@NotAudited
	@ManyToOne
	@JoinColumn(name = "CD_MATRICULA", insertable = false, updatable = false)
	private PessoaView tecnico;

	@OneToMany(mappedBy = "tecnico")
	private List<RealocacaoTecnico> realocacoes = new ArrayList<>();

	@NotAudited
	@OneToOne
	@JoinColumn(name = "CD_MATRICULA", insertable = false, updatable = false)
	private CorpoTecnicoView informacoesTecnico;

	@OneToMany(mappedBy = "tecnico")
	private List<ManutencaoCorretivaTecnico> manutencaoCorretivaTecnico = new ArrayList<>();

	public Tecnico() {
	}

	public Tecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public Tecnico(String codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	public Tecnico(Long idTecnico, String codigoMatricula) {
		this.idTecnico = idTecnico;
		this.codigoMatricula = codigoMatricula;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public String getCodigoMatricula() {
		return codigoMatricula;
	}

	public void setCodigoMatricula(String codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	public List<RealocacaoTecnico> getRealocacoes() {
		return realocacoes;
	}

	public void setRealocacoes(List<RealocacaoTecnico> realocacoes) {
		this.realocacoes = realocacoes;
	}

	public CorpoTecnicoView getInformacoesTecnico() {
		return informacoesTecnico;
	}

	public void setInformacoesTecnico(CorpoTecnicoView informacoesTecnico) {
		this.informacoesTecnico = informacoesTecnico;
	}

	public PessoaView getTecnico() {
		return tecnico;
	}

	public void setTecnico(PessoaView tecnico) {
		this.tecnico = tecnico;
	}

	public String getCodigoCentroCustoAlocado() {
		if (!CollectionUtils.isNullOrEmpty(realocacoes)) {
			RealocacaoTecnico realocacao = realocacoes.get(realocacoes.size() - 1);
			if (realocacao.isTecnicoPeriodoAlocaco()) {
				return realocacao.getCodigoCentroCusto();
			}
		}
		return informacoesTecnico.getCentroCusto().getCodigoCentroCusto();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idTecnico == null) ? 0 : idTecnico.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tecnico other = (Tecnico) obj;
		if (idTecnico == null) {
			if (other.idTecnico != null)
				return false;
		} else if (!idTecnico.equals(other.idTecnico))
			return false;
		return true;
	}

	public List<ManutencaoCorretivaTecnico> getManutencaoCorretivaTecnico() {
		return manutencaoCorretivaTecnico;
	}

	public void setManutencaoCorretivaTecnico(List<ManutencaoCorretivaTecnico> manutencaoCorretivaTecnico) {
		this.manutencaoCorretivaTecnico = manutencaoCorretivaTecnico;
	}

}
