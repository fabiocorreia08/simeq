package br.gov.cmb.simeq.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.cmb.simeq.dto.LabelValueDTO;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ManutencaoCorretivaVO implements Serializable {

	private static final long serialVersionUID = 6302204711733232972L;
	
	private Long idManutencao;
	private String dataCriacao;
	private String horaCriacao;
	private String numeroSolicitacao;
	private Long idEquipamento;
	private String codigoCentroCusto;
	private String matriculaAssistenteProducao;
	private String nomeAssistenteProducao;
	private LabelValueDTO classeManutencao;
	private Boolean paralizacao;
	private String avaria;
	private String matriculaSolicitante;
	private String nomeSolicitante;
	private Long idStatus;
	private String nomeEquipamento;
	private String centroCustoEquipamento;
	private String siglaCentroCusto;
	private String hierarquiaCentroCusto;
	private String nomeStatus;
	private String matriculaUsuarioLogado;
	private Long idSetor;
	private String nomeSetor;
	
	public ManutencaoCorretivaVO(){}
	
	public ManutencaoCorretivaVO(Long idManutencao, String dataCriacao, String horaCriacao, String numeroSolicitacao, Long idEquipamento, String codigoCentroCusto, 
			String matriculaAssistenteProducao, String nomeAssistenteProducao, LabelValueDTO classeManutencao, 
			Boolean paralizacao, String avaria, String matriculaSolicitante, Long idSetor,  String nomeSetor) {
		this.idManutencao = idManutencao;
		this.dataCriacao = dataCriacao;
		this.horaCriacao = horaCriacao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.idEquipamento = idEquipamento;
		this.codigoCentroCusto = codigoCentroCusto;
		this.matriculaAssistenteProducao = matriculaAssistenteProducao;
		this.nomeAssistenteProducao = nomeAssistenteProducao;
		this.classeManutencao = classeManutencao;
		this.paralizacao = paralizacao;
		this.avaria = avaria;
		this.matriculaSolicitante = matriculaSolicitante;
		this.idSetor = idSetor;
		this.nomeSetor = nomeSetor;
	}

	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}
	
	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}
	
	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public String getMatriculaAssistenteProducao() {
		return matriculaAssistenteProducao;
	}
	
	public void setMatriculaAssistenteProducao(String matriculaAssistenteProducao) {
		this.matriculaAssistenteProducao = matriculaAssistenteProducao;
	}
	
	public LabelValueDTO getClasseManutencao() {
		return classeManutencao;
	}
	
	public void setClasseManutencao(LabelValueDTO classeManutencao) {
		this.classeManutencao = classeManutencao;
	}
	
	public Boolean getParalizacao() {
		if(paralizacao == null) {
			return false;
		}
		return paralizacao;
	}
	
	public void setParalizacao(Boolean paralizacao) {
		this.paralizacao = paralizacao;
	}
	
	public String getAvaria() {
		return avaria;
	}
	
	public void setAvaria(String avaria) {
		this.avaria = avaria;
	}

	public String getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(String dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getHoraCriacao() {
		return horaCriacao;
	}

	public void setHoraCriacao(String horaCriacao) {
		this.horaCriacao = horaCriacao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getNomeAssistenteProducao() {
		return nomeAssistenteProducao;
	}

	public void setNomeAssistenteProducao(String nomeAssistenteProducao) {
		this.nomeAssistenteProducao = nomeAssistenteProducao;
	}

	public String getMatriculaSolicitante() {
		return matriculaSolicitante;
	}

	public void setMatriculaSolicitante(String matriculaSolicitante) {
		this.matriculaSolicitante = matriculaSolicitante;
	}

	public String getNomeSolicitante() {
		return nomeSolicitante;
	}

	public void setNomeSolicitante(String nomeSolicitante) {
		this.nomeSolicitante = nomeSolicitante;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public String getNomeEquipamento() {
		return nomeEquipamento;
	}

	public void setNomeEquipamento(String nomeEquipamento) {
		this.nomeEquipamento = nomeEquipamento;
	}

	public String getSiglaCentroCusto() {
		return siglaCentroCusto;
	}

	public void setSiglaCentroCusto(String siglaCentroCusto) {
		this.siglaCentroCusto = siglaCentroCusto;
	}

	public String getNomeStatus() {
		return nomeStatus;
	}

	public void setNomeStatus(String nomeStatus) {
		this.nomeStatus = nomeStatus;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

	public String getCentroCustoEquipamento() {
		return centroCustoEquipamento;
	}

	public void setCentroCustoEquipamento(String centroCustoEquipamento) {
		this.centroCustoEquipamento = centroCustoEquipamento;
	}

	public Long getIdSetor() {
		return idSetor;
	}

	public void setIdSetor(Long idSetor) {
		this.idSetor = idSetor;
	}

	public String getNomeSetor() {
		return nomeSetor;
	}

	public void setNomeSetor(String nomeSetor) {
		this.nomeSetor = nomeSetor;
	}
	
}
