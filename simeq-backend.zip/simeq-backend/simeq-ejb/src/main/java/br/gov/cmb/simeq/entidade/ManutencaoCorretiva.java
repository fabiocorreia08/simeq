package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.google.common.base.Objects;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaDiaVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaGrupoVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaMaterialVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaSolicitacaoVO;

@Audited
@Entity
@Table(name = "MANUTENCAO_CORRETIVA")
@SqlResultSetMappings({
		@SqlResultSetMapping(name="filtrarGestaoEstrategicaSolicitacaoMapping",
		classes={@ConstructorResult(
				targetClass=SubRelatorioGestaoEstrategicaSolicitacaoVO.class,
					columns={	@ColumnResult(name="codigoEquipamento", type=String.class),
								@ColumnResult(name="numeroSolicitacao", type=String.class),
								@ColumnResult(name="avariaAnormalidade", type=String.class),
								@ColumnResult(name="tempoComParalisacao", type=String.class),
								@ColumnResult(name="tempoSemParalisacao", type=String.class)}
				)}
					
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaGrupoMapping",
		classes={@ConstructorResult(
				targetClass=SubRelatorioGestaoEstrategicaGrupoVO.class,
					columns={	@ColumnResult(name="codigoEquipamento", type=String.class),
								@ColumnResult(name="equipamento", type=String.class),
								@ColumnResult(name="grupo", type=String.class),
								@ColumnResult(name="tempoComParalisacao", type=String.class),
								@ColumnResult(name="custoTotal", type=Double.class)}
				)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaMaterialMapping",
					classes={@ConstructorResult(
							targetClass=SubRelatorioGestaoEstrategicaMaterialVO.class,
								columns={	@ColumnResult(name="codigoMaterial", type=String.class),
											@ColumnResult(name="descricaoMaterial", type=String.class),
											@ColumnResult(name="quantidadeMaterial", type=Integer.class),
											@ColumnResult(name="valorMaterial", type=Double.class)}
							)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaDiaMapping",
				classes={@ConstructorResult(
						targetClass=SubRelatorioGestaoEstrategicaDiaVO.class,
							columns={	@ColumnResult(name="hora", type=String.class),
										@ColumnResult(name="quantidade", type=Integer.class)}
						)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaQuantidadeSolicitacoesMapping",
				classes={@ConstructorResult(
						targetClass=Integer.class,
							columns={	@ColumnResult(name="quantidadeSolicitacoes", type=String.class)}
						)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaValorMaterialMapping",
				classes={@ConstructorResult(
						targetClass=Double.class,
							columns={	@ColumnResult(name="valorMaterial", type=String.class)}
						)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaPrincipalAvariaMapping",
				classes={@ConstructorResult(
						targetClass=String.class,
							columns={	@ColumnResult(name="principalAvaria", type=String.class)}
						)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaValorMaoObraMapping",
				classes={@ConstructorResult(
						targetClass=Double.class,
							columns={	@ColumnResult(name="valorMaoObra", type=String.class)}
						)}
		),@SqlResultSetMapping(name="filtrarGestaoEstrategicaGrupoQueMaisFalhaMapping",
				classes={@ConstructorResult(
						targetClass=String.class,
							columns={	@ColumnResult(name="grupoQueMaisFalha", type=String.class)}
						)}
		)
})
@NamedNativeQueries({
    @NamedNativeQuery(
            name = "filtrarGestaoEstrategicaSolicitacao",
            query = " select tabela_corretiva.CD_MANUTENCAO as codigoEquipamento, " + 
            		"		tabela_corretiva.NR_SOLICITACAO as numeroSolicitacao, " + 
            		"		tabela_corretiva.DS_OBSERVACAO as avariaAnormalidade, " + 
            		"		convert(varchar, sum(tabela_corretiva.TEMPO_COM_PARALISACAO)/60)+':'+right('00' + convert(varchar, sum(tabela_corretiva.TEMPO_COM_PARALISACAO)%60), 2) as tempoComParalisacao, " + 
            		"		convert(varchar, sum(tabela_corretiva.TEMPO_SEM_PARALISACAO)/60)+':'+right('00' + convert(varchar, sum(tabela_corretiva.TEMPO_SEM_PARALISACAO)%60), 2) as tempoSemParalisacao " + 
            		" from ( " + 
            		" select	e.ID_EQUIPAMENTO, " + 
            		"		e.CD_MANUTENCAO, " + 
            		"		mc.NR_SOLICITACAO, " + 
            		"		mc.DS_OBSERVACAO, " + 
            		"		(ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO) as TEMPO_COM_PARALISACAO, " + 
            		"		(ac.QT_HORA_SEM_PARALISACAO*60 + ac.QT_MIN_SEM_PARALISACAO) as TEMPO_SEM_PARALISACAO from EQUIPAMENTO e " + 
            		"	inner join MANUTENCAO_CORRETIVA mc on mc.ID_EQUIPAMENTO = e.ID_EQUIPAMENTO " + 
            		"	inner join ATIVIDADE_CORRETIVA ac on ac.ID_MANUTENCAO_CORRETIVA = mc.ID_MANUTENCAO_CORRETIVA " + 
            		"	where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		") tabela_corretiva group by tabela_corretiva.CD_MANUTENCAO, " + 
            		"	tabela_corretiva.NR_SOLICITACAO, " + 
            		"	tabela_corretiva.DS_OBSERVACAO; ",
                    resultSetMapping="filtrarGestaoEstrategicaSolicitacaoMapping"
        ),
    @NamedNativeQuery(
            name = "filtrarGestaoEstrategicaGrupo",
            query = "select tabela_corretiva_grupo.CD_MANUTENCAO codigoEquipamento, " + 
            		"	tabela_corretiva_grupo.NM_EQUIPAMENTO as equipamento, " + 
            		"	tabela_corretiva_grupo.DS_GRUPO as grupo, " + 
            		"	convert(varchar, sum(tabela_corretiva_grupo.TEMPO_COM_PARALISACAO)/60)+':'+right('00' + convert(varchar, sum(tabela_corretiva_grupo.TEMPO_COM_PARALISACAO)%60), 2) as tempoComParalisacao, " + 
            		"	coalesce(sum(tabela_corretiva_grupo.CUSTO_TOTAL), 0.0) as custoTotal " + 
            		"from ( " + 
            		"select e.CD_MANUTENCAO, " + 
            		"	e.NM_EQUIPAMENTO, " + 
            		"	g.DS_GRUPO, " + 
            		"	ac.ID_ATIVIDADE, " + 
            		"	ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO as TEMPO_COM_PARALISACAO, " + 
            		"	convert(float, (ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO)) * (ac.VL_SALARIO_EXECUTANTE / (60.0*8.0*20.0)) as CUSTO_TOTAL " + 
            		"from GRUPO g " + 
            		"	inner join EQUIPAMENTO e on e.ID_EQUIPAMENTO = g.ID_EQUIPAMENTO " + 
            		"	inner join ATIVIDADE_CORRETIVA ac on ac.ID_SUBGRUPO = g.ID_GRUPO " + 
            		"	inner join MANUTENCAO_CORRETIVA mc on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " + 
            		"	where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		") tabela_corretiva_grupo group by tabela_corretiva_grupo.CD_MANUTENCAO, " + 
            		"	tabela_corretiva_grupo.NM_EQUIPAMENTO, " + 
            		"	tabela_corretiva_grupo.DS_GRUPO, " + 
            		"	tabela_corretiva_grupo.ID_ATIVIDADE ",
                    resultSetMapping="filtrarGestaoEstrategicaGrupoMapping"
        ),
    @NamedNativeQuery(
            name = "filtrarGestaoEstrategicaMaterial",
            query = "select tabela_material.CD_MATERIAL as codigoMaterial, " + 
            		"	tabela_material.Nome as descricaoMaterial," + 
            		"	sum(tabela_material.QTD_MATERIAL) as quantidadeMaterial, " + 
            		"	coalesce(sum(tabela_material.VLR_MATERIAL), 0.0) as valorMaterial " + 
            		"from ( " + 
            		"select amc.CD_MATERIAL, " + 
            		"	m.Nome, " + 
            		"	amc.QT_MATERIAL as QTD_MATERIAL, " + 
            		"	amc.QT_MATERIAL*m.ValorUnitario as VLR_MATERIAL " + 
            		"from ATIVIDADE_MATERIAL_CORRETIVA amc " + 
            		"	inner join VW_MATERIAL m on amc.CD_MATERIAL = m.Codigo and amc.DS_UNIDADE_MEDICA=m.UnidadeMedida " +
            		"	inner join ATIVIDADE_CORRETIVA ac on ac.ID_ATIVIDADE = amc.ID_ATIVIDADE " +
            		"	inner join MANUTENCAO_CORRETIVA mc on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " +
            		"where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		") tabela_material group by tabela_material.CD_MATERIAL, " + 
            		"	tabela_material.Nome ",
                    resultSetMapping="filtrarGestaoEstrategicaMaterialMapping"
        ),
    @NamedNativeQuery(
            name = "filtrarGestaoEstrategicaDia",
            query = "select tabela_corretiva_dia.hora hora, " + 
            		"	count(tabela_corretiva_dia.ID_MANUTENCAO_CORRETIVA) quantidade " + 
            		"from ( " + 
            		"select mc.ID_MANUTENCAO_CORRETIVA, datepart(hour, mc.DT_CRIACAO) hora " + 
            		" from MANUTENCAO_CORRETIVA mc " + 
            		"	inner join ATIVIDADE_CORRETIVA ac on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " +
            		" where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		") tabela_corretiva_dia " + 
            		"group by tabela_corretiva_dia.hora " + 
            		"	order by tabela_corretiva_dia.hora ",
                    resultSetMapping="filtrarGestaoEstrategicaDiaMapping"
        ),
    @NamedNativeQuery(
            name = "retornarGestaoEstrategicaQuantidadeSolicitacoes",
            query = "select coalesce(count(mc.ID_MANUTENCAO_CORRETIVA), 0) as quantidadeSolicitacoes from MANUTENCAO_CORRETIVA mc " +
            		"	inner join ATIVIDADE_CORRETIVA ac on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " +
            		" where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal ",
                    resultSetMapping="filtrarGestaoEstrategicaQuantidadeSolicitacoesMapping"
        ),
    @NamedNativeQuery(
            name = "retornarGestaoEstrategicaValorMaterial",
            query = "select coalesce(sum(tabela_material.VLR_MATERIAL), 0.0) as valorMaterial " + 
            		"from ( " + 
            		"select amc.QT_MATERIAL*m.ValorUnitario as VLR_MATERIAL " + 
            		"from ATIVIDADE_MATERIAL_CORRETIVA amc " + 
            		"	inner join VW_MATERIAL m on amc.CD_MATERIAL = m.Codigo and amc.DS_UNIDADE_MEDICA=m.UnidadeMedida " + 
            		"	inner join ATIVIDADE_CORRETIVA ac on ac.ID_ATIVIDADE = amc.ID_ATIVIDADE " +
            		"	inner join MANUTENCAO_CORRETIVA mc on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " +
            		"where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		") tabela_material ",
                    resultSetMapping="filtrarGestaoEstrategicaValorMaterialMapping"
        ),
    @NamedNativeQuery(
            name = "retornarGestaoEstrategicaPrincipalAvaria",
            query = "select top 1 tabela_final.principalAvaria from ( " +
            		"select	0 as indice, tabela_corretiva.avariaAnormalidade + ' / ' + convert(varchar, (tabela_corretiva.TEMPO_COM_PARALISACAO)/60)+':'+convert(varchar, (tabela_corretiva.TEMPO_COM_PARALISACAO)%60) as principalAvaria " + 
            		"from ( " + 
            		"	select	mc.DS_OBSERVACAO as avariaAnormalidade, " + 
            		"		sum(ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO) as TEMPO_COM_PARALISACAO " + 
            		"	from MANUTENCAO_CORRETIVA mc " + 
            		"		inner join ATIVIDADE_CORRETIVA ac on ac.ID_MANUTENCAO_CORRETIVA = mc.ID_MANUTENCAO_CORRETIVA " + 
            		"	where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		"	group by mc.ID_MANUTENCAO_CORRETIVA, " + 
            		"		mc.DS_OBSERVACAO " + 
            		") tabela_corretiva " + 
            		"where convert(varchar, (tabela_corretiva.TEMPO_COM_PARALISACAO)/60)+':'+convert(varchar, (tabela_corretiva.TEMPO_COM_PARALISACAO)%60) = ( " + 
            		"	select convert(varchar, max(tabela_corretiva_max_avaria.TEMPO_COM_PARALISACAO)/60)+':'+convert(varchar, max(tabela_corretiva_max_avaria.TEMPO_COM_PARALISACAO)%60) as tempoComParalisacao " + 
            		"	from ( " + 
            		"		select	sum(ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO) as TEMPO_COM_PARALISACAO " + 
            		"		from MANUTENCAO_CORRETIVA mc " + 
            		"			inner join ATIVIDADE_CORRETIVA ac on ac.ID_MANUTENCAO_CORRETIVA = mc.ID_MANUTENCAO_CORRETIVA " + 
            		"		where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		"		group by mc.ID_MANUTENCAO_CORRETIVA " + 
            		"	) tabela_corretiva_max_avaria " + 
            		") union select 1 as indice, 'N/A' as principalAvaria) tabela_final order by tabela_final.indice ",
                    resultSetMapping="filtrarGestaoEstrategicaPrincipalAvariaMapping"
        ),
    @NamedNativeQuery(
            name = "retornarGestaoEstrategicaValorMaoObra",
            query = "select coalesce(sum(convert(float, (ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO)) * (ac.VL_SALARIO_EXECUTANTE / (60.0*8.0*20.0))), 0.0) as valorMaoObra " + 
            		"from ATIVIDADE_CORRETIVA ac " +
            		"	inner join MANUTENCAO_CORRETIVA mc on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " +
            		"where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal ",
                    resultSetMapping="filtrarGestaoEstrategicaValorMaoObraMapping"
        ),
    @NamedNativeQuery(
            name = "retornarGestaoEstrategicaGrupoQueMaisFalha",
            query = "select top 1 tabela_final.grupoQueMaisFalha from ( " +
            		"select 0 as indice, tabela_corretiva_grupo.CD_MANUTENCAO+'-'+tabela_corretiva_grupo.NM_EQUIPAMENTO+' '+ " + 
            		"	tabela_corretiva_grupo.DS_GRUPO+' / '+ " +
            		"	convert(varchar, (tabela_corretiva_grupo.TEMPO_COM_PARALISACAO)/60)+':'+right('00' + convert(varchar, (tabela_corretiva_grupo.TEMPO_COM_PARALISACAO)%60), 2) as grupoQueMaisFalha " + 
            		"from ( " + 
            		"select e.CD_MANUTENCAO, " + 
            		"	e.NM_EQUIPAMENTO, " + 
            		"	g.DS_GRUPO, " + 
            		"	sum(ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO) as TEMPO_COM_PARALISACAO " + 
            		"from GRUPO g " + 
            		"	inner join EQUIPAMENTO e on e.ID_EQUIPAMENTO = g.ID_EQUIPAMENTO " + 
            		"	inner join ATIVIDADE_CORRETIVA ac on ac.ID_SUBGRUPO = g.ID_GRUPO " + 
            		"	inner join MANUTENCAO_CORRETIVA mc on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " + 
            		"where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		"group by e.CD_MANUTENCAO, " + 
            		"	e.NM_EQUIPAMENTO, " + 
            		"	g.DS_GRUPO, " + 
            		"	g.ID_GRUPO " + 
            		") tabela_corretiva_grupo " + 
            		"where tabela_corretiva_grupo.TEMPO_COM_PARALISACAO = ( " + 
            		"	select max(tabela_corretiva_grupo_max.TEMPO_COM_PARALISACAO) " + 
            		"	from ( " + 
            		"		select sum(ac.QT_HORA_COM_PARALISACAO*60 + ac.QT_MIN_COM_PARALISACAO) as TEMPO_COM_PARALISACAO " + 
            		"		from GRUPO g " + 
            		"			inner join ATIVIDADE_CORRETIVA ac on ac.ID_SUBGRUPO = g.ID_GRUPO " + 
            		"			inner join MANUTENCAO_CORRETIVA mc on mc.ID_MANUTENCAO_CORRETIVA = ac.ID_MANUTENCAO_CORRETIVA " + 
            		"		where ( :centrosCustoSize = 0 OR mc.CD_CENTRO_CUSTO in :centrosCusto ) and convert(date, ac.DT_CADASTRO)  >= :dataInicial and convert(date, ac.DT_CADASTRO) <= :dataFinal " +
            		"		group by g.DS_GRUPO, " + 
            		"			g.ID_GRUPO " + 
            		"	) tabela_corretiva_grupo_max " + 
            		") union select 1 as indice, 'N/A' as grupoQueMaisFalha) tabela_final order by tabela_final.indice ",
                    resultSetMapping="filtrarGestaoEstrategicaGrupoQueMaisFalhaMapping"
        )
})
public class ManutencaoCorretiva implements Serializable {

	private static final long serialVersionUID = -5349343549489551040L;

	@Id
	@Column(name = "ID_MANUTENCAO_CORRETIVA")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "NR_SOLICITACAO")
	private String numeroSolicitacao;
	
	@ManyToOne
	@JoinColumn(name = "ID_EQUIPAMENTO")
	private Equipamento equipamento;
	
	@NotAudited
	@ManyToOne
	@JoinColumn(name = "CD_CENTRO_CUSTO")
	private CentroCustoView centroCusto;
	
	@NotAudited
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_MATRIC_ASSISTENTE_PRODUCAO")
	private PessoaView assitenteProducao;
	
	@Column(name = "FL_CLASSE_MANUTENCAO")
	@Enumerated(EnumType.STRING)
	private ClasseManutencaoEnum flagClasseManutencao;
	
	@Column(name = "FL_PARALISACAO")
	private Boolean paralisacao;
	
	@Column(name = "DS_OBSERVACAO")
	private String observacao;
	
	@Column(name = "DT_CRIACAO", updatable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "CD_MATRIC_SOLICITANTE")
	private String matriculaSolicitante;
	
	@OneToMany(mappedBy="manutencaoCorretiva")
	private List<HistoricoStatusManutencaoCorretiva> historicoStatus = new ArrayList<>();
	
	@ManyToOne
	@JoinColumn(name = "ID_SETOR_MANUTENCAO")
	private SetorManutencao setor;
	
	public ManutencaoCorretiva(){}
	
	public ManutencaoCorretiva(Long id){
		this.id = id;
	}
	
	public ManutencaoCorretiva(Long id, String numeroSolicitacao, Long idEquipamento, String codigoCentroCusto, String matriculaAssistente, 
			String classeManutencao, Boolean paralizacao, String observacao, String matriculaSolicitante, Long idSetor) {
		this.id = id;
		this.numeroSolicitacao = numeroSolicitacao;
		this.equipamento = new Equipamento(idEquipamento);
		this.centroCusto = new CentroCustoView(codigoCentroCusto);
		this.assitenteProducao = new PessoaView(matriculaAssistente);
		this.flagClasseManutencao = ClasseManutencaoEnum.getClasseManutencaoEnumPor(classeManutencao);
		this.paralisacao = paralizacao;
		this.observacao = observacao;
		this.matriculaSolicitante = matriculaSolicitante;
		this.setor = new SetorManutencao(idSetor);
	}
	
	public ManutencaoCorretiva(String numeroSolicitacao, Long idEquipamento, String codigoCentroCusto, String matriculaSolicitante) {
		this.numeroSolicitacao = numeroSolicitacao;
		this.equipamento = new Equipamento(idEquipamento);
		this.centroCusto = new CentroCustoView(codigoCentroCusto);
		this.flagClasseManutencao = ClasseManutencaoEnum.getClasseManutencaoEnumPor(ClasseManutencaoEnum.S.name());
		this.paralisacao = false;
		this.matriculaSolicitante = matriculaSolicitante;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Equipamento getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(Equipamento equipamento) {
		this.equipamento = equipamento;
	}

	public CentroCustoView getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(CentroCustoView centroCusto) {
		this.centroCusto = centroCusto;
	}

	public PessoaView getAssitenteProducao() {
		return assitenteProducao;
	}

	public void setAssitenteProducao(PessoaView assitenteProducao) {
		this.assitenteProducao = assitenteProducao;
	}

	public ClasseManutencaoEnum getFlagClasseManutencao() {
		return flagClasseManutencao;
	}

	public void setFlagClasseManutencao(ClasseManutencaoEnum flagClasseManutencao) {
		this.flagClasseManutencao = flagClasseManutencao;
	}

	public Boolean getParalisacao() {
		return paralisacao;
	}

	public void setParalisacao(Boolean paralisacao) {
		this.paralisacao = paralisacao;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public List<HistoricoStatusManutencaoCorretiva> getHistoricoStatus() {
		return historicoStatus;
	}

	public void setHistoricoStatus(List<HistoricoStatusManutencaoCorretiva> historicoStatus) {
		this.historicoStatus = historicoStatus;
	}

	public String getMatriculaSolicitante() {
		return matriculaSolicitante;
	}

	public void setMatriculaSolicitante(String matriculaSolicitante) {
		this.matriculaSolicitante = matriculaSolicitante;
	}
	
	public String getTextoDataCriacao(){		
		return DataUtils.formatarddMMyyyy(dataCriacao);
	}
	
	public String getHoraCriacao(){
		return DataUtils.formatarHoraHHmm(dataCriacao);		
	}

	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof ManutencaoCorretiva)) {
			return false;
		}
		ManutencaoCorretiva castOther = (ManutencaoCorretiva) other;
		return Objects.equal(id, castOther.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}

	public SetorManutencao getSetor() {
		return setor;
	}

	public void setSetor(SetorManutencao setor) {
		this.setor = setor;
	}

}
