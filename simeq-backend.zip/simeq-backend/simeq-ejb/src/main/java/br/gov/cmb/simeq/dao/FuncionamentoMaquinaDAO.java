package br.gov.cmb.simeq.dao;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.entidade.FuncionamentoMaquina;
import br.gov.cmb.simeq.vo.FuncionamentoMaquinaVO;

public class FuncionamentoMaquinaDAO extends GenericoPaginadoDAO<FuncionamentoMaquina, Long> {

	private static final long serialVersionUID = -7959595222679666133L;

	public FuncionamentoMaquina buscarFuncionamentoMaquina(FuncionamentoMaquinaVO maquinaVO) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("m")
				.from(FuncionamentoMaquina.class, "m")
				.innerJoin("m.equipamento", "e")
				.innerJoin("m.centroCusto", "c")
				.where("e.idEquipamento = ?1")
				.and("m.ano = ?2")
				.and("m.mes = ?3");
		
		return buscaSeguraUmResultado(builder.builder(), 
				FuncionamentoMaquina.class, 
				maquinaVO.getIdEquipamento(),
				maquinaVO.getAno(),
				maquinaVO.getMes());

	}

}
