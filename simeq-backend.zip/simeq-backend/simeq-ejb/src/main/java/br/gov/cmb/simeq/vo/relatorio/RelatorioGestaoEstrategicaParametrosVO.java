package br.gov.cmb.simeq.vo.relatorio;

import java.io.InputStream;
import java.util.Date;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorioParametros")
public class RelatorioGestaoEstrategicaParametrosVO {

	private InputStream logo;
	private Date dataInicial;
	private Date dataFinal;
	private Integer quantidadeSolicitacoes;
	private Double valorMaterial;
	private String principalAvaria;
	private Double valorMaoObra;
	private String grupoQueMaisFalha;
	
	public RelatorioGestaoEstrategicaParametrosVO() {
	}

	public InputStream getLogo() {
		return logo;
	}

	public void setLogo(InputStream logo) {
		this.logo = logo;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}

	public Integer getQuantidadeSolicitacoes() {
		return quantidadeSolicitacoes;
	}

	public void setQuantidadeSolicitacoes(Integer quantidadeSolicitacoes) {
		this.quantidadeSolicitacoes = quantidadeSolicitacoes;
	}

	public Double getValorMaterial() {
		return valorMaterial;
	}

	public void setValorMaterial(Double valorMaterial) {
		this.valorMaterial = valorMaterial;
	}

	public String getPrincipalAvaria() {
		return principalAvaria;
	}

	public void setPrincipalAvaria(String principalAvaria) {
		this.principalAvaria = principalAvaria;
	}

	public Double getValorMaoObra() {
		return valorMaoObra;
	}

	public void setValorMaoObra(Double valorMaoObra) {
		this.valorMaoObra = valorMaoObra;
	}

	public String getGrupoQueMaisFalha() {
		return grupoQueMaisFalha;
	}

	public void setGrupoQueMaisFalha(String grupoQueMaisFalha) {
		this.grupoQueMaisFalha = grupoQueMaisFalha;
	}
	
	public Double calcularValorTotal() {
		return valorMaoObra + valorMaterial;
	}
}
