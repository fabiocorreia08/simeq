package br.gov.cmb.simeq.vo.relatorio;

public class SubRelatorioCapacidadeProdutivaEquipamentoVO {

	private String codigo;
	private String equipamento;
	private Double indice;
	private String diasUteis;
	private String totalHorasFuncionamento;
	private String quantidadeHorasPreventivaPrevista;
	private String quantidadeHorasPreventivaExecutada;
	private String quantidadeHorasCorretiva;


	public SubRelatorioCapacidadeProdutivaEquipamentoVO(String codigo, String equipamento, Double indice,
			String diasUteis, String totalHorasFuncionamento, String quantidadeHorasPreventivaPrevista,
			String quantidadeHorasPreventivaExecutada, String quantidadeHorasCorretiva) {
		super();
		this.codigo = codigo;
		this.equipamento = equipamento;
		this.indice = indice;
		this.diasUteis = diasUteis;
		this.totalHorasFuncionamento = totalHorasFuncionamento;
		this.quantidadeHorasPreventivaPrevista = quantidadeHorasPreventivaPrevista;
		this.quantidadeHorasPreventivaExecutada = quantidadeHorasPreventivaExecutada;
		this.quantidadeHorasCorretiva = quantidadeHorasCorretiva;

	}

	public SubRelatorioCapacidadeProdutivaEquipamentoVO() {
		super();
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(String equipamento) {
		this.equipamento = equipamento;
	}

	public Double getIndice() {
		return indice;
	}

	public void setIndice(Double indice) {
		this.indice = indice;
	}

	public String getDiasUteis() {
		return diasUteis;
	}

	public void setDiasUteis(String diasUteis) {
		this.diasUteis = diasUteis;
	}

	public String getTotalHorasFuncionamento() {
		return totalHorasFuncionamento;
	}

	public void setTotalHorasFuncionamento(String totalHorasFuncionamento) {
		this.totalHorasFuncionamento = totalHorasFuncionamento;
	}

	public String getQuantidadeHorasPreventivaPrevista() {
		return quantidadeHorasPreventivaPrevista;
	}

	public void setQuantidadeHorasPreventivaPrevista(String quantidadeHorasPreventivaPrevista) {
		this.quantidadeHorasPreventivaPrevista = quantidadeHorasPreventivaPrevista;
	}

	public String getQuantidadeHorasPreventivaExecutada() {
		return quantidadeHorasPreventivaExecutada;
	}

	public void setQuantidadeHorasPreventivaExecutada(String quantidadeHorasPreventivaExecutada) {
		this.quantidadeHorasPreventivaExecutada = quantidadeHorasPreventivaExecutada;
	}

	public String getQuantidadeHorasCorretiva() {
		return quantidadeHorasCorretiva;
	}

	public void setQuantidadeHorasCorretiva(String quantidadeHorasCorretiva) {
		this.quantidadeHorasCorretiva = quantidadeHorasCorretiva;
	}

}
