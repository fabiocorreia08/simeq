package br.gov.cmb.simeq.dao;

import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.entidade.Parametro;

public class ParametroDAO extends GenericoPaginadoDAO<Parametro, Long> {

	private static final long serialVersionUID = -8459514348769650828L;

}
