package br.gov.cmb.simeq.service;

import java.util.Date;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.cmb.common.ejb.configuracao.Configuracao;
import br.gov.cmb.common.email.VO.EmailVO;
import br.gov.cmb.common.email.util.EmailUtil;
import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.common.util.PropertiesUtils;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.PessoaView;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.exception.ErroEnvioEmailException;
import br.gov.cmb.simeq.utils.CalendarioUtil;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;

@Stateless
public class EmailService {
	private static final Logger logger = LoggerFactory.getLogger(EmailService.class);
	
	private static final String KEY_LOGO_CMG = "simeq.parametro.emailLogoCmb";
	public static final String NOME_PARAMETRO_LOGO_CMB = "imgEmail";
	private static final String KEY_SERVICO_EMAIL = "url.servicoEmail";
	private static final String KEY_URL_SISTEMA = "simeq.urlSistema";
	
	@Inject
	@Configuracao(KEY_LOGO_CMG)
	private String logotipoCmb;
	
	public void enviarEmailManutencaoPreventivaQuinzeDias(String emailDestinatario, ManutencaoPreventiva manutencao, PessoaView pessoaView) {
		EmailVO emailVO = inicializarEmailVO(PropertiesUtils.getProperty("simeq.parametro.emailTemplateManutencaoPreventivaQuinzeDias"));

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", manutencao.getNumeroSolicitacao());
	    emailVO.adicionarParametro("usuarioLogado", pessoaView.getNome());
	    emailVO.adicionarParametro("dataInicio", manutencao.getTextoDataInicio());
	    emailVO.adicionarParametro("dataFim", manutencao.getTextoDataFim());
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, PropertiesUtils.getProperty("simeq.parametro.emailTemplateManutencaoPreventivaQuinzeDias"));
		
}
	
	public void enviarEmailCriacaoManutencaoCorretiva(String emailDestinatario, ManutencaoCorretivaVO manutencao) {
			EmailVO emailVO = inicializarEmailVO(PropertiesUtils.getProperty("simeq.parametro.emailTemplateCriacaoManutencaoCorretiva"));

		    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
		    emailVO.adicionarParametro("numeroSolicitacao", manutencao.getNumeroSolicitacao());
		    emailVO.adicionarParametro("usuarioLogado", manutencao.getNomeSolicitante());
		    emailVO.adicionarParametro("data", manutencao.getDataCriacao());
		    emailVO.adicionarParametro("hora", manutencao.getHoraCriacao());
		    emailVO.adicionarParametro("classeManutencao", manutencao.getClasseManutencao().getLabel());
		    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
		    if(manutencao.getParalizacao()) {		    	
		    	emailVO.adicionarParametro("paralizacao", "Com Paralisação");
		    } else {
		    	emailVO.adicionarParametro("paralizacao", "Sem Paralisação");
		    }
		    
		    emailVO.setDestinatario(emailDestinatario);
			dispararEmail(emailVO, PropertiesUtils.getProperty("simeq.parametro.emailTemplateCriacaoManutencaoCorretiva"));
	}
	
	public void enviarEmailStatusConcluidaManutencaoCorretiva(String emailDestinatario, ManutencaoCorretivaVO manutencao) {
		EmailVO emailVO = inicializarEmailVO(PropertiesUtils.getProperty("simeq.parametro.emailTemplateStatusConcluidaManutencaoCorretiva"));

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", manutencao.getNumeroSolicitacao());
	    emailVO.adicionarParametro("usuarioLogado", manutencao.getNomeSolicitante());
	    emailVO.adicionarParametro("data", manutencao.getDataCriacao());
	    emailVO.adicionarParametro("hora", manutencao.getHoraCriacao());
	    emailVO.adicionarParametro("classeManutencao", manutencao.getClasseManutencao().getLabel());
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, PropertiesUtils.getProperty("simeq.parametro.emailTemplateStatusConcluidaManutencaoCorretiva"));
	}
	
	public void enviarEmailAprovacaoSolicitacao(String emailDestinatario, HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva) {
		String nomeTemplateEmail = PropertiesUtils.getProperty("simeq.parametro.emailTemplateAprovarReprovarManutencaoCorretiva");
		EmailVO emailVO = inicializarEmailVO(nomeTemplateEmail);

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getNumeroSolicitacao());
	    emailVO.adicionarParametro("statusSolicitacao", getStatusManutencaoCorretiva(historicoStatusManutencaoCorretiva));
	    emailVO.adicionarParametro("usuarioLogado", historicoStatusManutencaoCorretiva.getUsuarioResponsavelPelaAlteracao().getNome());
	    emailVO.adicionarParametro("dataHoraAlteracao", CalendarioUtil.formatarDataHora(historicoStatusManutencaoCorretiva.getDataCriacao()));
	    emailVO.adicionarParametro("classeManutencao", ClasseManutencaoEnum.C.equals(historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getFlagClasseManutencao()) ? "Corretiva" : "Serviço de Apoio");
	    emailVO.adicionarParametro("isParalisacao", historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getParalisacao() ? "Sim" : "Não");
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, nomeTemplateEmail);
	}
	
	public void enviarEmailAprovacaoSolicitacaoPreventiva(String emailDestinatario, HistoricoStatusManutencaoPreventiva historicoStatusManutencaoPreventiva) {
		String nomeTemplateEmail = PropertiesUtils.getProperty("simeq.parametro.emailTemplateAprovarManutencaoPreventiva");
		EmailVO emailVO = inicializarEmailVO(nomeTemplateEmail);

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getNumeroSolicitacao());
	    emailVO.adicionarParametro("statusSolicitacao", "Aprovada pelo Gestor");
	    emailVO.adicionarParametro("usuarioLogado", historicoStatusManutencaoPreventiva.getUsuarioResponsavelPelaAlteracao().getNome());
	    emailVO.adicionarParametro("dataHoraAlteracao", CalendarioUtil.formatarDataHora(historicoStatusManutencaoPreventiva.getDataCriacao()));
	    emailVO.adicionarParametro("dataSolicitacao",  historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getTextoDataInicio() + " a " +
	    	    historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getTextoDataFim());
	    emailVO.adicionarParametro("classeManutencao", ClasseManutencaoEnum.P.getDescricao());
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, nomeTemplateEmail);
	}
	
	public void enviarEmailReprovacaoSolicitacaoPreventiva(String emailDestinatario, HistoricoStatusManutencaoPreventiva historicoStatusManutencaoPreventiva) {
		String nomeTemplateEmail = PropertiesUtils.getProperty("simeq.parametro.emailTemplateReprovarManutencaoPreventiva");
		EmailVO emailVO = inicializarEmailVO(nomeTemplateEmail);

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getNumeroSolicitacao());
	    emailVO.adicionarParametro("statusSolicitacao", "Reprovada pelo Gestor");
	    emailVO.adicionarParametro("usuarioLogado", historicoStatusManutencaoPreventiva.getUsuarioResponsavelPelaAlteracao().getNome());
	    emailVO.adicionarParametro("dataHoraAlteracao", CalendarioUtil.formatarDataHora(historicoStatusManutencaoPreventiva.getDataCriacao()));
	    emailVO.adicionarParametro("dataSolicitacao",  historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getTextoDataInicio() + " a " +
	    historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getTextoDataFim());
	    emailVO.adicionarParametro("classeManutencao", ClasseManutencaoEnum.P.getDescricao());
	    emailVO.adicionarParametro("motivo", historicoStatusManutencaoPreventiva.getDescricaoStatus());
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, nomeTemplateEmail);
	}
	
	private String getStatusManutencaoCorretiva(HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva) {
		if(StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo().equals(historicoStatusManutencaoCorretiva.getId().getIdStatusManutencao())) {
			return "Concluída";
		} else if(StatusManutencaoCorretivaEnum.AG_APROPRIACAO.getCodigo().equals(historicoStatusManutencaoCorretiva.getId().getIdStatusManutencao())) {
			return "Aguardando apropriação de horas";
		} else {
			return "Reaberta";
		}
	}
	
	public void enviarEmailReprovacaoSolicitacao(String emailDestinatario, HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva) {
		String nomeTemplateEmail = PropertiesUtils.getProperty("simeq.parametro.emailTemplateAprovarReprovarManutencaoCorretiva");
		EmailVO emailVO = inicializarEmailVO(nomeTemplateEmail);

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getNumeroSolicitacao());
	    emailVO.adicionarParametro("statusSolicitacao", getStatusManutencaoCorretiva(historicoStatusManutencaoCorretiva));
	    emailVO.adicionarParametro("usuarioLogado", historicoStatusManutencaoCorretiva.getUsuarioResponsavelPelaAlteracao().getNome());
	    emailVO.adicionarParametro("dataHoraAlteracao", CalendarioUtil.formatarDataHora(historicoStatusManutencaoCorretiva.getDataCriacao()));
	    emailVO.adicionarParametro("classeManutencao", ClasseManutencaoEnum.C.equals(historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getFlagClasseManutencao()) ? "Corretiva" : "Serviço de Apoio");
	    emailVO.adicionarParametro("isParalisacao", historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getParalisacao() ? "Sim" : "Não");
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, nomeTemplateEmail);
	}
	

	public void enviarEmailAlocacaoTecnico(String emailDestinatario, String numeroSolicitacao, String nomeSolicitante, String classeManutencao, boolean paralizacao) {
		EmailVO emailVO = inicializarEmailVO(PropertiesUtils.getProperty("simeq.parametro.emailTemplateAlocacaoTecnico"));

	    emailVO.adicionarParametro(NOME_PARAMETRO_LOGO_CMB, PropertiesUtils.getProperty(KEY_LOGO_CMG));
	    emailVO.adicionarParametro("numeroSolicitacao", numeroSolicitacao);
	    emailVO.adicionarParametro("usuarioLogado", nomeSolicitante);
	    emailVO.adicionarParametro("data", DataUtils.formatarddMMyyyy(new Date()));
	    emailVO.adicionarParametro("hora", DataUtils.formatarHoraHHmm(new Date()));
	    emailVO.adicionarParametro("classeManutencao", classeManutencao);
	    emailVO.adicionarParametro("urlSistema", PropertiesUtils.getProperty(KEY_URL_SISTEMA));
	    if(paralizacao) {		    	
	    	emailVO.adicionarParametro("paralizacao", "Com Paralisação");
	    } else {
	    	emailVO.adicionarParametro("paralizacao", "Sem Paralisação");
	    }
	    
	    emailVO.setDestinatario(emailDestinatario);
		dispararEmail(emailVO, PropertiesUtils.getProperty("simeq.parametro.emailTemplateAlocacaoTecnico"));
	}
	
	private void dispararEmail(EmailVO emailVO, String templateEmail){
		try{
			EmailUtil.enviarEmail(PropertiesUtils.getProperty(KEY_SERVICO_EMAIL), emailVO);
		} catch (Exception e) {
			logger.error("Erro Email" + templateEmail, e);
			throw new ErroEnvioEmailException();
		}
	}
	
	private EmailVO inicializarEmailVO(String nomeTemplate) {
		EmailVO emailVO = new EmailVO(nomeTemplate);
		emailVO.setRemetente(PropertiesUtils.getProperty("simeq.parametro.emailRemetente"));
		return emailVO;
	}
}
