package br.gov.cmb.simeq.converter;

import java.util.Date;

import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.InformacaoCorretiva;
import br.gov.cmb.simeq.vo.InformacaoVO;

public class InformacaoCorretivaConverter {
	
	public static InformacaoVO converter(InformacaoCorretiva informacao) {
		HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva = 
								informacao.getHistoricoStatusManutencaoCorretiva() != null ? 
								informacao.getHistoricoStatusManutencaoCorretiva() : 
								null;
													
		return new InformacaoVO(informacao.getId(), 
								historicoStatusManutencaoCorretiva != null ? historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getId(): null,
								historicoStatusManutencaoCorretiva != null ? historicoStatusManutencaoCorretiva.getManutencaoCorretiva().getNumeroSolicitacao(): null, 
								historicoStatusManutencaoCorretiva != null ? historicoStatusManutencaoCorretiva.getId().getIdStatusManutencao(): null, 
								informacao.getCodigoMatriculaFuncionario(), 
								informacao.getDescricaoInformacao());
	}
	
	public static InformacaoCorretiva converter(InformacaoVO informacaoVO) {
		
		return new InformacaoCorretiva(informacaoVO.getMatriculaUsuarioLogado(), 
								new Date(), 
								informacaoVO.getDescricaoInformacao());
		
	}

}
