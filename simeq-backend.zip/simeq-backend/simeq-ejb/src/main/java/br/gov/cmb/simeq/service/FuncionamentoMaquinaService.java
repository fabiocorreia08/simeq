package br.gov.cmb.simeq.service;

import java.util.Objects;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.simeq.converter.FuncionamentoMaquinaConverter;
import br.gov.cmb.simeq.dao.FuncionamentoMaquinaDAO;
import br.gov.cmb.simeq.dto.FuncionamentoMaquinaDTO;
import br.gov.cmb.simeq.entidade.FuncionamentoMaquina;
import br.gov.cmb.simeq.vo.FuncionamentoMaquinaVO;

@Stateless
public class FuncionamentoMaquinaService {

	@Inject
	private FuncionamentoMaquinaDAO funcionamentoMaquinaDAO;

	public FuncionamentoMaquinaDTO salvar(FuncionamentoMaquinaDTO funcionamentoDTO) {
		FuncionamentoMaquina funcionamento = FuncionamentoMaquinaConverter.converter(funcionamentoDTO);
		atribuirDias(funcionamento);
		return FuncionamentoMaquinaConverter.converter(funcionamentoMaquinaDAO.salvar(funcionamento));
	}

	public FuncionamentoMaquinaDTO buscarFuncionamentoMaquina(FuncionamentoMaquinaVO filtro) {
		FuncionamentoMaquina funcionamento = funcionamentoMaquinaDAO.buscarFuncionamentoMaquina(filtro);
		if(Objects.nonNull(funcionamento)) {			
			return FuncionamentoMaquinaConverter.converter(funcionamentoMaquinaDAO.buscarFuncionamentoMaquina(filtro));
		}
		return null;
	}
	
	public FuncionamentoMaquinaDTO editar(FuncionamentoMaquinaDTO funcionamentoDTO) {
		FuncionamentoMaquina funcionamento = FuncionamentoMaquinaConverter.converter(funcionamentoDTO);
		atribuirDias(funcionamento);
		return FuncionamentoMaquinaConverter.converter(funcionamentoMaquinaDAO.atualizar(funcionamento));
	}

	private void atribuirDias(FuncionamentoMaquina funcionamento) {
		funcionamento.getDiasFuncionamento().stream().forEach(n -> {
			n.setFuncionamentoMaquina(funcionamento);
		});
	}

}
