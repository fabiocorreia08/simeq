package br.gov.cmb.simeq.service;

import javax.inject.Inject;
import javax.transaction.Transactional;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.converter.InformacaoPreventivaConverter;
import br.gov.cmb.simeq.dao.HistStatusManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.InformacaoPreventivaDAO;
import br.gov.cmb.simeq.entidade.InformacaoPreventiva;
import br.gov.cmb.simeq.vo.InformacaoVO;

public class InformacaoPreventivaService {
	
	@Inject
	private InformacaoPreventivaDAO informacaoDAO;
	
	@Inject
	private HistStatusManutencaoPreventivaDAO historicoStatusManutencaoPreventivaDAO;
	
	public Pagina<InformacaoVO> filtrar(Pagina<InformacaoVO> pagina) {
		return this.informacaoDAO.filtrar(pagina);
	}
	
	@Transactional
	public InformacaoVO salvar(InformacaoVO informacaoVO) {
		InformacaoPreventiva informacao = InformacaoPreventivaConverter.converter(informacaoVO);
		informacao.setHistoricoStatusManutencaoPreventiva(
				historicoStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInserido(informacaoVO.getIdManutencao()));

		return InformacaoPreventivaConverter.converter(informacaoDAO.salvar(informacao));
	}

}
