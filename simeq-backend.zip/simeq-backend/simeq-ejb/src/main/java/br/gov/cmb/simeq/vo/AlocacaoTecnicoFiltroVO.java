package br.gov.cmb.simeq.vo;

import java.util.List;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AlocacaoTecnicoFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 8690874498684893504L;
	
	@ParametroNomeado
	private List<String> centroCustosHierarquia = Lists.newArrayList();
	
	@ParametroNomeado
	private Long idTecnico;
	
	public AlocacaoTecnicoFiltroVO(List<String> centroCustosHierarquia) {
		this.centroCustosHierarquia = centroCustosHierarquia;
	}

	public List<String> getCentroCustosHierarquia() {
		return centroCustosHierarquia;
	}

	public void setCentroCustosHierarquia(List<String> centroCustosHierarquia) {
		this.centroCustosHierarquia = centroCustosHierarquia;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}
	
}
