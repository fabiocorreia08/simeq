package br.gov.cmb.simeq.vo;

import java.util.Date;
import java.util.List;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class HistoricoStatusManutencaoFiltroVO extends ModeloVO {

	private static final long serialVersionUID = -1372310609387562676L;
	
	@ParametroNomeado
	private Long idManutencao;
	
	private String numeroSolicitacao;
	
	@ParametroNomeado
	private Long idEquipamento;
	
	@ParametroNomeado
	private List<Long> idsStatus;
	
	@ParametroNomeado
	private Date dtUltimaManutencao;	

	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public List<Long> getIdsStatus() {
		return idsStatus;
	}

	public void setIdsStatus(List<Long> idsStatus) {
		this.idsStatus = idsStatus;
	}

	public Date getDtUltimaManutencao() {
		return dtUltimaManutencao;
	}

	public void setDtUltimaManutencao(Date dtUltimaManutencao) {
		this.dtUltimaManutencao = dtUltimaManutencao;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}
}
