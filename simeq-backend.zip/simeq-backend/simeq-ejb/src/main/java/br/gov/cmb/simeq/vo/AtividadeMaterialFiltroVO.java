package br.gov.cmb.simeq.vo;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AtividadeMaterialFiltroVO extends ModeloVO {

	private static final long serialVersionUID = -574594258226258586L;
	
	@ParametroNomeado
	private String codigoMaterial;
	
	@ParametroNomeado(like = true)
	private String nomePradronizado;

	public String getCodigoMaterial() {
		return codigoMaterial;
	}

	public void setCodigoMaterial(String codigoMaterial) {
		this.codigoMaterial = codigoMaterial;
	}

	public String getNomePradronizado() {
		return nomePradronizado;
	}

	public void setNomePradronizado(String nomePradronizado) {
		this.nomePradronizado = nomePradronizado;
	}
	
}
