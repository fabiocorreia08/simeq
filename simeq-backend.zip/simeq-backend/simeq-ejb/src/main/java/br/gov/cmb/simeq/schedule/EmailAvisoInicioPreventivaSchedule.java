package br.gov.cmb.simeq.schedule;

import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.cmb.common.ejb.scheduler.AbstractScheduler;
import br.gov.cmb.common.util.PropertiesUtils;
import br.gov.cmb.simeq.service.ManutencaoPreventivaService;

@Startup
@Singleton
public class EmailAvisoInicioPreventivaSchedule extends AbstractScheduler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PreventivaExpiradaSchedule.class);
	private static final String DIA_MES="*";
	private static final String HORA_ENVIO_EMAIL = "simeq.parametro.horaAvisoInicioPreventiva";
	private static final String MINUTOS_ENVIO_EMAIL = "simeq.parametro.minutosAvisoInicioPreventiva";
	
	@Inject
	private ManutencaoPreventivaService manutencaoPreventivaService;

	@Override
	public void execute() {
		try {			
			LOGGER.info("INICIO DA EXECUCAO ROTINA ENVIAR E-MAIL INÍCIO DA MANUTENÇÃO PREVENTIVA");
			manutencaoPreventivaService.enviarEmailPreventivaComQuinzeDiasAntecedencia();
		} catch (Exception exception) {
			LOGGER.error(exception.getMessage());
		}
		
	}

	@Override
	public String getDiaDoMes() {
		return DIA_MES;
	}

	@Override
	public String getDiaSemana() {
		return "*";
	}

	@Override
	public String getHora() {
		return PropertiesUtils.getProperty(HORA_ENVIO_EMAIL);
	}

	@Override
	public String getMinutos() {
		return PropertiesUtils.getProperty(MINUTOS_ENVIO_EMAIL);
	}

	@Override
	public String getNome() {
		return "Envio de e-mail Início da Manutenção Preventiva";
	}
}
