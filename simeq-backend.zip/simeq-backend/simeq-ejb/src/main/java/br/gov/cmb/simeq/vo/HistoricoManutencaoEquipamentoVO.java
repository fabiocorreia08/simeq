package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

public class HistoricoManutencaoEquipamentoVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idManutencao;
	private String numeroSolicitacao;
	private String equipamento;
	private Date dtAlteracao;
	private String codManutencao;
	private String centroCusto;
	private Date dtSolicitacao;
	
	public HistoricoManutencaoEquipamentoVO() {
		// TODO Auto-generated constructor stub
	}
	
	public HistoricoManutencaoEquipamentoVO(Long idManutencao, String numeroSolicitacao, String equipamento,
			Date dtAlteracao, String codManutencao, String centroCusto, Date dtSolicitacao) {
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.equipamento = equipamento;
		this.dtAlteracao = dtAlteracao;
		this.codManutencao = codManutencao;
		this.centroCusto = centroCusto;
		this.dtSolicitacao = dtSolicitacao;
	}
	
	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}
	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}
	public Date getDtAlteracao() {
		return dtAlteracao;
	}
	public void setDtAlteracao(Date dtAlteracao) {
		this.dtAlteracao = dtAlteracao;
	}
	public String getCodManutencao() {
		return codManutencao;
	}
	public void setCodManutencao(String codManutencao) {
		this.codManutencao = codManutencao;
	}
	public String getCentroCusto() {
		return centroCusto;
	}
	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}
	public Date getDtSolicitacao() {
		return dtSolicitacao;
	}
	public void setDtSolicitacao(Date dtSolicitacao) {
		this.dtSolicitacao = dtSolicitacao;
	}

	public String getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(String equipamento) {
		this.equipamento = equipamento;
	}

	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}

}
