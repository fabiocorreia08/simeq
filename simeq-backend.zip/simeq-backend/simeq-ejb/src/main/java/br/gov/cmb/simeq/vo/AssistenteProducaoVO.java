package br.gov.cmb.simeq.vo;

import java.io.Serializable;

public class AssistenteProducaoVO implements Serializable {

	private static final long serialVersionUID = 727419250117908683L;
	
	private String matricula;
	private String nome;
	private String situacao;
	private String centroCusto;
	
	public AssistenteProducaoVO(){}
	
	public AssistenteProducaoVO(String matricula, String nome, String situacao, String centroCusto) {
		this.matricula = matricula;
		this.nome = nome;
		this.situacao = situacao;
		this.centroCusto = centroCusto;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}
	
}
