package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.entidade.PessoaView;
import br.gov.cmb.simeq.vo.AssistenteProducaoVO;

public class PessoaViewDAO extends GenericoPaginadoDAO<PessoaView, String> {

	private static final long serialVersionUID = 4334285072617805166L;
	
	public AssistenteProducaoVO buscarAssistenteProducaoPorMatricula(String matricula) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.vo.AssistenteProducaoVO(p.matricula, p.nome, p.flagSituacaoPessoa, p.centroCusto)")
				.from(PessoaView.class, "p")
				.where("p.matricula = ?");
		List<AssistenteProducaoVO> assistente = buscar(builder.builder(), AssistenteProducaoVO.class, matricula);
		
		if(!assistente.isEmpty()) {
			return assistente.get(0);
		}
		return null;
	}
	
	public TecnicoDTO buscarTecnico(String matricula) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.TecnicoDTO(p.matricula, p.nome, p.centroCusto, p.hierarquia)")
				.from(PessoaView.class, "p")
				.where("p.matricula = ?");
		return buscarUmResultado(builder.builder(), TecnicoDTO.class, matricula);
	}
	
	public PessoaView buscarPorMatricula(String matricula) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("p")
				.from(PessoaView.class, "p")
				.where("p.matricula = ?");
		return buscarUmResultado(builder.builder(), matricula);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<AssistenteProducaoVO> filtrar(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.vo.AssistenteProducaoVO(p.matricula, p.nome, p.flagSituacaoPessoa, p.centroCusto)")
				.from(PessoaView.class, "p")
				.where(pagina.getModelVO(), "p.matricula = [matricula]")
				.and("p.nome LIKE [nome]");
		Pagina<AssistenteProducaoVO> paginaResultado = ((Pagina<AssistenteProducaoVO>)buscar(pagina, builder.builder()));
		List<AssistenteProducaoVO> listaMateriais = paginaResultado.getRegistros();
				
		paginaResultado.setRegistros(listaMateriais);
		return paginaResultado;
	}
}
