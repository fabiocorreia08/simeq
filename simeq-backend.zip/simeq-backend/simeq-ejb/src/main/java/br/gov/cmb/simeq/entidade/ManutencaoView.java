package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "VW_SIMEQ_MANUTENCAO")
public class ManutencaoView implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "CD_MATRICULA")
	private String matricula;
	
	@Column(name = "NM_EMPREGADO")
	private String empregado;
	
	@Column(name = "NR_SOLICITACAO")
	private String numeroSolicitacao;
	
	@Column(name = "FL_CLASSE_MANUTENCAO")
	private String classeManutencao;
	
	@Column(name = "NM_CARGO")
	private String cargo;
	
	@Column(name= "ID_TECNICO")
	private Long tecnico; 
	
	@ManyToOne
	@JoinColumn(name = "CD_CENTRO_CUSTO")
	private CentroCustoView centroCusto;
	
	@ManyToOne
	@JoinColumn(name = "CD_TURNO")
	private TurnoView turno;
	
	@Column(name = "DT_ALOCACAO")
	private Date dataAlocacao;
	
	@Column(name = "CD_MATRICULA_RESPONSAVEL")
	private String matriculaResponsavel;
	
	@ManyToOne
	@JoinColumn(name = "ID_SETOR_MANUTENCAO")
	private SetorManutencao setor;
	
	public ManutencaoView() {
		// TODO Auto-generated constructor stub
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getEmpregado() {
		return empregado;
	}

	public void setEmpregado(String empregado) {
		this.empregado = empregado;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getMatriculaResponsavel() {
		return matriculaResponsavel;
	}

	public void setMatriculaResponsavel(String matriculaResponsavel) {
		this.matriculaResponsavel = matriculaResponsavel;
	}

	public Date getDataAlocacao() {
		return dataAlocacao;
	}

	public void setDataAlocacao(Date dataAlocacao) {
		this.dataAlocacao = dataAlocacao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public CentroCustoView getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(CentroCustoView centroCusto) {
		this.centroCusto = centroCusto;
	}

	public TurnoView getTurno() {
		return turno;
	}

	public void setTurno(TurnoView turno) {
		this.turno = turno;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public Long getTecnico() {
		return tecnico;
	}

	public void setTecnico(Long tecnico) {
		this.tecnico = tecnico;
	}

	public SetorManutencao getSetor() {
		return setor;
	}

	public void setSetor(SetorManutencao setor) {
		this.setor = setor;
	}



}
