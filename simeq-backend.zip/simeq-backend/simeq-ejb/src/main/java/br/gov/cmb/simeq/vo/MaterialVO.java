package br.gov.cmb.simeq.vo;

import java.io.Serializable;

public class MaterialVO implements Serializable {

	private static final long serialVersionUID = 4090174978464199151L;
	
	private int sequencial;
	private String codigo;
	private String nome;
	private String descricao;
	private Float quantidade;
	
	public MaterialVO(String codigo, String nome, String descricao, Float quantidade) {
		this.codigo = codigo;
		this.nome = nome;
		this.descricao = descricao;
		this.quantidade = quantidade;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getDescricao() {
		return descricao;
	}
	
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getSequencial() {
		return sequencial;
	}

	public void setSequencial(int sequencial) {
		this.sequencial = sequencial;
	}

	public Float getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Float quantidade) {
		this.quantidade = quantidade;
	}
	
	
}
