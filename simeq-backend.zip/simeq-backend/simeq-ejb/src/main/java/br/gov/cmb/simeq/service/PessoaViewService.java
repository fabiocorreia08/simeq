package br.gov.cmb.simeq.service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.vo.AssistenteProducaoVO;

@Stateless
public class PessoaViewService {
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	public AssistenteProducaoVO buscarAssistenteProducaoPorMatricula(String matricula) {
		return this.pessoaViewDAO.buscarAssistenteProducaoPorMatricula(matricula);
	}

	public Pagina<AssistenteProducaoVO> filtrarAssistenteProducao(Pagina<AssistenteProducaoVO> pagina) {
		return pessoaViewDAO.filtrar(pagina);
	}
	
	public TecnicoDTO buscarTecnico(String matricula) {
		return this.pessoaViewDAO.buscarTecnico(matricula);
	}
}
