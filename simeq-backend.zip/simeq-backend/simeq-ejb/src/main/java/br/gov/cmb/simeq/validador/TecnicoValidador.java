package br.gov.cmb.simeq.validador;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaTecnicoDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaTecnicoDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.entidade.CorpoTecnicoView;
import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;

@Stateless
public class TecnicoValidador extends AbstractValidador {

	@Inject
	private TecnicoDAO tecnicoDAO;
	
	@Inject
	private ManutencaoCorretivaTecnicoDAO manutencaoCorretivaTecnicoDAO;
	
	@Inject
	private ManutencaoPreventivaTecnicoDAO manutencaoPreventivaTecnicoDAO;
	
	
	@RegraDeValidacao
	public void validarMatriculaCadastradaPreviamente(String matricula) {
		if(this.tecnicoDAO.buscarTecnicoPorMatricula(matricula) != null) {
			throw new ValidacaoException("Matrícula já cadastrada.");
		}
	}
	
	@RegraDeValidacao
	public CorpoTecnicoView validarMatriculaInexistenteErp(String matricula) {
		CorpoTecnicoView corpoTecnicoView = this.tecnicoDAO.buscarInformacoesTecnicoPor(matricula);
		if(corpoTecnicoView == null) {
			throw new ValidacaoException("Matrícula não localizada.");
		}
		return corpoTecnicoView;
	}
	
	@RegraDeValidacao
	public void validarPermissaoTecnicoManutencao(ManutencaoCorretivaTecnico corretivaTecnicoPermissao, String matriculaTecnico, String numeroSolicitacao) {
		ManutencaoCorretivaTecnico corretivaTecnico = manutencaoCorretivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
		if (corretivaTecnicoPermissao == null && corretivaTecnico != null) {
			throw new ValidacaoException("Usuário sem permissão para acesso à colaboradores de outro Centro de Custo.");
		}
		if(tecnicoDAO.buscarTecnicoPorMatricula(matriculaTecnico) == null) {
			throw new ValidacaoException("Matrícula não encontrada.");
		}
		if(corretivaTecnicoPermissao == null) {
			throw new ValidacaoException("Executante não se encontra alocado na solicitação.");
		}
		if(corretivaTecnicoPermissao.getTecnico().getInformacoesTecnico().getCodigoSituacaoFolha().trim().length() != 0) {
			throw new ValidacaoException("Matrícula inativa.");
		}
	}
	
	@RegraDeValidacao
	public void validarPermissaoTecnicoManutencao(ManutencaoPreventivaTecnico corretivaTecnicoPermissao, String matriculaTecnico, String numeroSolicitacao) {
		ManutencaoPreventivaTecnico preventivaTecnico = manutencaoPreventivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
		if (corretivaTecnicoPermissao == null && preventivaTecnico != null) {
			throw new ValidacaoException("Usuário sem permissão para acesso à colaboradores de outro Centro de Custo.");
		}
		if(tecnicoDAO.buscarTecnicoPorMatricula(matriculaTecnico) == null) {
			throw new ValidacaoException("Matrícula não encontrada.");
		}
		if(corretivaTecnicoPermissao == null) {
			throw new ValidacaoException("Executante não se encontra alocado na solicitação.");
		}
		if(corretivaTecnicoPermissao.getTecnico().getInformacoesTecnico().getCodigoSituacaoFolha().trim().length() != 0) {
			throw new ValidacaoException("Matrícula inativa.");
		}
	}
}
