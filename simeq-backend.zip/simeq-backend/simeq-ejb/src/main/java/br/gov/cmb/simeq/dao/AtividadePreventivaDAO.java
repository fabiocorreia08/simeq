package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import br.gov.cmb.simeq.vo.AtividadeConsultaVO;
import br.gov.cmb.simeq.vo.AtividadeDetalharVO;

public class AtividadePreventivaDAO extends GenericoPaginadoDAO<AtividadePreventiva, Long>{

	private static final long serialVersionUID = -7144198898339821172L;
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<AtividadeConsultaVO> filtrar(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.AtividadeConsultaVO(a.id, subgrupo.grupoPai.descricaoGrupo, subgrupo.descricaoGrupo, a.acao.nome, a.componente.nome, "
						+ "a.horaAtividade, a.minutosAtividade, a.executante.nome, a.dataCriacao)")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.subGrupo", "subgrupo")
				.where(pagina.getModelVO(), "a.manutencaoPreventiva.numeroSolicitacao = [numeroSolicitacao]")
				.and("cast(a.dataCriacao as date) >= cast([periodoInicio] as date)")
				.and("cast(a.dataCriacao as date) <= cast([periodoFim] as date)")
				.and("a.executante.matricula = [matriculaExecutante]")
				.and("a.manutencaoPreventiva.centroCusto.codigoCentroCusto IN ([centroCustosHierarquia])")
				.order("a.id");
		return (Pagina<AtividadeConsultaVO>)buscar(pagina, builder.builder(), "distinct a.id");
	}
	
	public List<AtividadePreventiva> buscarPorGrupo(Long id) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("a")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.subGrupo", "subgrupo")
				.innerJoin("subGrupo.grupoPai", "grupo")
				.where("a.subGrupo.idGrupo = ?1");
		return buscar(builder.builder(), AtividadePreventiva.class, id);
	}
	
	public AtividadePreventiva buscarPorId(Long id) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("a")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.manutencaoPreventiva", "m")
				.innerJoin("a.executante", "e")
				.innerJoin("a.subGrupo", "subgrupo")
				.innerJoin("subGrupo.grupoPai", "grupo")
				.innerJoin("a.acao", "acao")
				.innerJoin("a.componente", "c")
				.leftJoin("a.materiais", "materiais")
				.innerJoin("m.equipamento", "equipamento")
				.innerJoin("equipamento.historicosSituacaoEquipamento", "historicosSituacaoEquipamento")
				.innerJoin("historicosSituacaoEquipamento.centroCusto", "centroCusto")
				.leftJoin("materiais.materialView", "materialView")
				.where("a.id = ?1")
				.and("historicosSituacaoEquipamento.idHistoricoSituacaoEquipamento = (SELECT MAX(hse.idHistoricoSituacaoEquipamento)"
						+ "	FROM HistoricoSituacaoEquipamento hse WHERE hse.equipamento.idEquipamento = equipamento.idEquipamento)");
		return buscarUmResultado(builder.builder(), AtividadePreventiva.class, id);
	}
	
	public AtividadeDetalharVO buscarAtividadeDetalhe(Long idAtividade) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.AtividadeDetalharVO(m.numeroSolicitacao, m.dataCriacao, e.matricula, e.nome,"
						+ " CONCAT(centroCusto.textoHierarquiaCentroCusto, ' - ', centroCusto.codigoCentroCusto), equipamento.codigoManutencao, grupo.descricaoGrupo, "
						+ " subgrupo.descricaoGrupo, acao.nome, c.nome, a.observacao, a.salario, a.horaAtividade, a.minutosAtividade)")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.manutencaoPreventiva", "m")
				.innerJoin("a.executante", "e")
				.innerJoin("a.subGrupo", "subgrupo")
				.innerJoin("subGrupo.grupoPai", "grupo")
				.innerJoin("a.acao", "acao")
				.innerJoin("a.componente", "c")
				.leftJoin("a.materiais", "materiais")
				.innerJoin("m.equipamento", "equipamento")
				.innerJoin("equipamento.historicosSituacaoEquipamento", "historicosSituacaoEquipamento")
				.innerJoin("historicosSituacaoEquipamento.centroCusto", "centroCusto")
				.leftJoin("materiais.materialView", "materialView")
				.where("a.id = ?1")
				.and("historicosSituacaoEquipamento.idHistoricoSituacaoEquipamento = (SELECT MAX(hse.idHistoricoSituacaoEquipamento)"
						+ "	FROM HistoricoSituacaoEquipamento hse WHERE hse.equipamento.idEquipamento = equipamento.idEquipamento)");
		List<AtividadeDetalharVO> atividadeDetalharVOs = buscar(builder.builder(), AtividadeDetalharVO.class, idAtividade);
		if (CollectionUtils.isNullOrEmpty(atividadeDetalharVOs)) {
			return null;
		}
		return atividadeDetalharVOs.get(0);
	}
	
	public List<AtividadeConsultaVO> buscarAtividadeConsultaPorManutencao(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.AtividadeConsultaVO(a.id, subgrupo.grupoPai.descricaoGrupo, subgrupo.descricaoGrupo, a.acao.nome, a.componente.nome, "
						+ "a.horaAtividade, a.minutosAtividade, a.executante.nome, a.dataCriacao)")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.manutencaoPreventiva", "m")
				.innerJoin("a.subGrupo", "subgrupo")
				.where("m.id = ?");
		return buscar(builder.builder(), AtividadeConsultaVO.class, idManutencao);
	}
	
	public AtividadePreventiva buscarPorIdManutencao(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("a")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.manutencaoPreventiva", "m")
				.where("m.id = ?");
		List<AtividadePreventiva> atividades = buscar(builder.builder(), idManutencao);
		
		if(CollectionUtils.isNullOrEmpty(atividades)) {
			return null;
		}
		
		return atividades.get(0);
	}
	
	public List<AtividadePreventiva> buscarAtividadePorManutencao(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("a")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.manutencaoPreventiva", "m")
				.innerJoin("a.subGrupo", "subgrupo")
				.innerJoin("subGrupo.grupoPai", "grupoPai")
				.innerJoin("a.acao", "acao")
				.innerJoin("a.componente", "c")
				.where("m.id = ?");
		return buscar(builder.builder(), AtividadePreventiva.class, idManutencao);
	}

}
