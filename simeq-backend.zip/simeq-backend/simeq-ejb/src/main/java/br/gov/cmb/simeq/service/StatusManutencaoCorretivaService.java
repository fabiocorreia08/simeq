package br.gov.cmb.simeq.service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dao.StatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dto.DashboardDTO;
import br.gov.cmb.simeq.dto.HistoricoDataDTO;
import br.gov.cmb.simeq.dto.HorasMinutosDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.vo.DashboardVO;
import br.gov.cmb.simeq.vo.HistoricoStatusManutencaoVO;

@Stateless
public class StatusManutencaoCorretivaService {

	@Inject
	private StatusManutencaoCorretivaDAO statusDao;

	@Inject
	private HistoricoStatusManutencaoCorretivaDAO statusManutencaoDAO;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	public List<LabelValueDTO> buscarTodos() {
		return this.statusDao.buscar().stream().map(s -> new LabelValueDTO(s.getNome(), s.getId()))
				.collect(Collectors.toList());
	}

	public List<LabelValueDTO> buscarStatusCombo(Long idManutencao) {
		HistoricoStatusManutencaoCorretiva status = statusManutencaoDAO.buscarUltimoHistoricoInserido(idManutencao);
		List<Long> idsStatusBuscar = StatusManutencaoCorretivaEnum.getStatus(status.getId().getIdStatusManutencao())
				.getIdsStatusCombo();
		List<LabelValueDTO> statusLabelValue = statusDao.buscarStatusCombo(idsStatusBuscar);
		statusLabelValue.add(new LabelValueDTO(status.getStatusManutencaoCorretiva().getNome(),
				status.getId().getIdStatusManutencao()));
		return statusLabelValue;
	}

	public Pagina<HistoricoStatusManutencaoVO> filtrar(Pagina<HistoricoStatusManutencaoVO> pagina) {
		return statusManutencaoDAO.filtrar(pagina);
	}
	
	public List<DashboardDTO> buscarDashboard(DashboardVO dashboardVO) {
		String setor;
		if (dashboardVO.getPerfil().equals(PerfilEnum.SOLICITANTE.getIdPerfil())) {
			setor = "";
		} else {
			setor = (this.pessoaViewDAO.buscarPorMatricula(dashboardVO.getMatricula())).getSiglaCentroCusto();
		}

		return statusDao.buscarDashboard(dashboardVO.getListaCC(), setor);
	}

	public HorasMinutosDTO buscarHistoricoData(Long idManutencao) {

		HistoricoDataDTO historico = statusDao.buscarDataHistorico(idManutencao);
		if (historico.getIdStatus().equals(StatusManutencaoCorretivaEnum.AG_ACEITE.getCodigo())
				|| historico.getIdStatus().equals(StatusManutencaoCorretivaEnum.AG_APROPRIACAO.getCodigo())
				|| historico.getIdStatus().equals(StatusManutencaoCorretivaEnum.AG_FORNECEDOR.getCodigo())
				|| historico.getIdStatus().equals(StatusManutencaoCorretivaEnum.MANUTENCAO.getCodigo())) {

			LocalDateTime startTime = LocalDateTime.ofInstant(historico.getDataCriacao().toInstant(),
					ZoneId.systemDefault());
			LocalDateTime lastTime = LocalDateTime.ofInstant(historico.getDataStatus().toInstant(),
					ZoneId.systemDefault());

			Long minutes = ChronoUnit.MINUTES.between(startTime, lastTime);

			HorasMinutosDTO horasMinutosDTO = new HorasMinutosDTO(minutes);
			return horasMinutosDTO;
		} else {
			HorasMinutosDTO horasMinutosDTO = new HorasMinutosDTO();
			return horasMinutosDTO;
		}

	}

}
