package br.gov.cmb.simeq.validador;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaTecnicoDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.service.CentroCustoService;
import br.gov.cmb.simeq.vo.PreventivaCadastroVO;

@Stateless
public class ManutencaoCorretivaTecnicoValidador extends AbstractValidador {
	
	@Inject
	private CentroCustoService centroCustoService;
	
	@Inject
	private ManutencaoCorretivaDAO manutencaoCorretivaDAO;
	
	@Inject
	private ManutencaoPreventivaDAO manutencaoPreventivaDAO;
	
	@Inject
	private ManutencaoCorretivaTecnicoDAO manutencaoCorretivaTecnicoDAO;
	
	@Inject
	private AtividadeCorretivaDAO atividadeDAO;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	@RegraDeValidacao
	public void validarNumeroSolicitacaoTecnico(String matriculaTecnico, String numeroSolicitacao) {
		List<String> codigosCentroDeCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(PerfilEnum.TECNICO.getIdPerfil(), matriculaTecnico);
		String setor = (this.pessoaViewDAO.buscarPorMatricula(matriculaTecnico)).getSiglaCentroCusto();
		ManutencaoCorretiva manutencaoCorretiva = manutencaoCorretivaDAO.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao, codigosCentroDeCustoHierarquia, setor);
		if(manutencaoCorretiva == null) {
			throw new ValidacaoException("Usuário sem permissão para acesso a solicitação de outro Centro de Custo.");
		}
		ManutencaoCorretivaTecnico manutencaoCorretivaTecnico = manutencaoCorretivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
		if(manutencaoCorretivaTecnico != null) {
			throw new ValidacaoException("Técnico já alocado na solicitação.");
		}
	}
	
	@RegraDeValidacao
	public void validarSeAlocacaoPossuiAtividadeCorretiva(Long idManutencao, String matriculaTecnico) {
		if (atividadeDAO.buscarAtividadePorManutencaoTecnicoAlocadoCorretiva(idManutencao, matriculaTecnico) != null) {
			throw new ValidacaoException("O técnico possui atividade registrada e portanto não poderá ser excluído. Exclua primeiro a(s) atividade(s) para excluir o técnico.");
		}
	}
	
	@RegraDeValidacao
	public void validarSeAlocacaoPossuiAtividadePreventiva(Long idManutencao, String matriculaTecnico) {
		if (atividadeDAO.buscarAtividadePorManutencaoTecnicoAlocadoPreventiva(idManutencao, matriculaTecnico) != null) {
			throw new ValidacaoException("O técnico possui atividade registrada e portanto não poderá ser excluído. Exclua primeiro a(s) atividade(s) para excluir o técnico.");
		}
	}
	
	@RegraDeValidacao
	public void validarStatusAlocacaoPreventiva(String numeroSolicitacao) {
		PreventivaCadastroVO prev = manutencaoPreventivaDAO.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao);
		if ((prev.getIdStatus() != StatusManutencaoPreventivaEnum.APROVADA_GESTOR.getCodigo()) 
				&& (prev.getIdStatus() != StatusManutencaoPreventivaEnum.RECURSO_ALOCADO.getCodigo())
				&& (prev.getIdStatus() != StatusManutencaoPreventivaEnum.EM_MANUTENCAO.getCodigo())
				&& (prev.getIdStatus() != StatusManutencaoPreventivaEnum.REPROGRAMADA.getCodigo())) {
			throw new ValidacaoException("Não é permitido realizar a operação para esta solicitação.");
		}
	}

}
