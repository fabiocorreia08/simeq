package br.gov.cmb.simeq.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.converter.ManutencaoPreventivaConverter;
import br.gov.cmb.simeq.dao.HistStatusManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.InformacaoPreventivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dao.SetorManutencaoDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.InformacaoPreventiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.PessoaView;
import br.gov.cmb.simeq.entidade.SetorManutencao;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.MesEnum;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.utils.GeradorNumeroSolicitacao;
import br.gov.cmb.simeq.validador.ManutencaoPreventivaValidador;
import br.gov.cmb.simeq.vo.AprovacaoManutencaoPreventivaFiltroVO;
import br.gov.cmb.simeq.vo.AprovacaoPreventivaConsultaTabelaVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.PreventivaCadastroVO;
import br.gov.cmb.simeq.vo.PreventivaConsultaFiltroVO;
import br.gov.cmb.simeq.vo.PreventivaConsultaTabelaVO;
import br.gov.cmb.simeq.vo.RelatorioManutencaoPreventivaAnualFiltro;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoAtividadesVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoPreventivaAnualVO;

@Stateless
public class ManutencaoPreventivaService {
	
	@Inject
	private ManutencaoPreventivaDAO manutencaoPreventivaDAO;
	
	@Inject 
	private HistStatusManutencaoPreventivaDAO histStatusManutencaoPreventivaDAO;
	
	@Inject
	private ManutencaoPreventivaValidador manutencaoPreventivaValidador;
	
	@Inject 
	private CentroCustoService centroCustoService;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	@Inject
	private EmailService emailService;
	
	@Inject
	private ManutencaoCorretivaDAO manutencaoDAO;
	
	@Inject
	private TecnicoDAO tecnicoDAO;
	
	@Inject
	private ManutencaoPreventivaValidador manutencaoValidador;
	
	@Inject
	private HistoricoStatusManutencaoCorretivaDAO historicoManutencaoCorretivaDAO;
	
	@Inject
	private SetorManutencaoDAO setorManutencaoDAO;
	
	@Inject 
	private InformacaoPreventivaDAO informacaoPreventivaDAO;
	
	@Inject
	private FamiliaManutencaoService familiaManutencaoService;
	
	
	public List<LabelValueDTO> buscarTodosMeses() {
		List<LabelValueDTO> mesesLabelValue = Lists.newArrayList();
		
		for (MesEnum mes : MesEnum.values()) {
			mesesLabelValue.add(new LabelValueDTO(mes.getDescricao(), mes.getCodigo()));
		}
		return mesesLabelValue;
	}
	
	public List<PreventivaCadastroVO> buscarPreventivasPorEquipamentoCentroCusto(Long idEquipamento, String codigoCentroCusto) {
		return manutencaoPreventivaDAO.buscarPreventivasPorEquipamentoCentroCusto(idEquipamento, codigoCentroCusto);
	}
	
	public List<ManutencaoPreventiva> buscarPreventivaCadastradaMesAno(Long idEquipamento, String codigoCentroCusto, Integer ano, Integer mes, Long idPreventiva) {
		return manutencaoPreventivaDAO.buscarPreventivasJaCadastrada(idEquipamento, codigoCentroCusto, ano, mes, idPreventiva);
	}
	
	public void salvar(List<PreventivaCadastroVO> preventivas) {
		String novoNumeroSolicitacao;
		for (PreventivaCadastroVO preventivaCadastroVO : preventivas) {
			if(preventivaCadastroVO.getId() == null) {
				SetorManutencao setorManutencao = setorManutencaoDAO.buscar(preventivaCadastroVO.getIdSetor());	
				
				ManutencaoPreventiva ultimaManutencaoCadastrada = manutencaoPreventivaDAO.buscarUltimoRegistroCadastradoPorSetor(preventivaCadastroVO.getIdSetor());
				if(ultimaManutencaoCadastrada != null) {
					novoNumeroSolicitacao = GeradorNumeroSolicitacao.gerar(ultimaManutencaoCadastrada.getNumeroSolicitacao(), new Date(), setorManutencao.getNomeSetor(), false);
				} else {			
					novoNumeroSolicitacao = GeradorNumeroSolicitacao.gerar(null, new Date(), setorManutencao.getNomeSetor(), false);
				}
				preventivaCadastroVO.setNumeroSolicitacao(novoNumeroSolicitacao);
				ManutencaoPreventiva manutencaoPreventiva = manutencaoPreventivaDAO.salvar(ManutencaoPreventivaConverter.converter(preventivaCadastroVO));
				preventivaCadastroVO.setId(manutencaoPreventiva.getId());
				adicionarHistoricoStatusManutencao(preventivaCadastroVO, StatusManutencaoPreventivaEnum.ABERTA.getCodigo());
			}
		}
	}
	
	private void adicionarHistoricoStatusManutencao(PreventivaCadastroVO preventiva, Long idStatus) {
		HistoricoStatusManutencaoPreventiva ultimoHistoricoCadastrado = histStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInserido(preventiva.getId());
		HistoricoStatusManutencaoPreventiva historico;
		historico = new HistoricoStatusManutencaoPreventiva(preventiva.getId(), idStatus, new Long(1), preventiva.getMatriculaUsuarioLogado());
		if(ultimoHistoricoCadastrado != null && !idStatus.equals(ultimoHistoricoCadastrado.getId().getIdStatusManutencao())) {
			historico = new HistoricoStatusManutencaoPreventiva(preventiva.getId(), idStatus, ultimoHistoricoCadastrado.getProximoSequencial(), preventiva.getMatriculaUsuarioLogado());
			histStatusManutencaoPreventivaDAO.salvar(historico);
			return;
		}
		if(ultimoHistoricoCadastrado == null) {			
			histStatusManutencaoPreventivaDAO.salvar(historico);
			return;
		}
	}
	
	public void atualizar(PreventivaCadastroVO preventiva) {
		manutencaoPreventivaValidador.validarPreventivaJaCadastrada(preventiva);
		manutencaoPreventivaDAO.atualizar(ManutencaoPreventivaConverter.converter(preventiva));
		if(preventiva.getIdStatus().equals(preventiva.getIdStatusAntigo()) &&
				(!preventiva.getDiaInicio().equals(preventiva.getDiaInicioAntigo()) || !preventiva.getDiaFim().equals(preventiva.getDiaFimAntigo()))) {
			adicionarHistoricoStatusManutencao(preventiva, StatusManutencaoPreventivaEnum.REPROGRAMADA.getCodigo());
		} else {			
			adicionarHistoricoStatusManutencao(preventiva, preventiva.getIdStatus());
		}
	}
	
	public PreventivaCadastroVO buscarPreventivaPorNumeroSolicitacao(String numeroSolicitacao) {
		return manutencaoPreventivaDAO.buscarPreventivaPorNumeroSolicitacao(numeroSolicitacao);
	}
	
	
	public ManutencaoVO buscarPorNumeroSolicitacaoPorHierarquia(String numeroSolicitacao, Integer idPerfil, String matricula) {
		List<String> codigosCentroCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(idPerfil, matricula);
		ManutencaoPreventiva manutencao = manutencaoPreventivaDAO.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao, codigosCentroCustoHierarquia);
		manutencaoPreventivaValidador.validarManutencaoCorretivaPermissao(manutencao, numeroSolicitacao);
		if(manutencao == null) {
			return null;
		}
		PreventivaCadastroVO manutencaoPreventivaVO = ManutencaoPreventivaConverter.converter(manutencao);
		
		ManutencaoVO manutencaoVO = new ManutencaoVO();
		manutencaoVO.setIdManutencao(manutencao.getId());
		manutencaoVO.setIdEquipamento(manutencaoPreventivaVO.getIdEquipamento());
		manutencaoVO.setDataCriacao(manutencao.getTextoDataCriacao());
		manutencaoVO.setNomeEquipamento(manutencao.getEquipamento().getCodigoManutencao() + " - " +manutencao.getEquipamento().getNomeEquipamento());
		manutencaoVO.setCentroCustoEquipamento(manutencao.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + 
				manutencao.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getCodigoCentroCusto());
		manutencaoVO.setClasseManutencao(ClasseManutencaoEnum.P.getDescricao());
		manutencaoVO.setTipoManutencao(ClasseManutencaoEnum.P.name().charAt(0));
		
		return manutencaoVO;
	}
	
	public void enviarEmailPreventivaComQuinzeDiasAntecedencia() {
		 List<ManutencaoPreventiva> manutencoes = manutencaoPreventivaDAO.buscarPreventivaComQuinzeDiasAntecedencia();
		 if (!CollectionUtils.isNullOrEmpty(manutencoes)) {
			 for (ManutencaoPreventiva manutencaoPreventiva : manutencoes) {
				String emailDestinatario = manutencaoPreventiva.getCentroCusto().getTextoSiglaCentroCusto().concat("@cmb.gov.br");
				PessoaView pessoaView = pessoaViewDAO.buscarPorMatricula(manutencaoPreventiva.getMatriculaSolicitante());
				emailService.enviarEmailManutencaoPreventivaQuinzeDias(emailDestinatario, manutencaoPreventiva, pessoaView);
			}
		 }
	}
	
	public Pagina<PreventivaConsultaTabelaVO> filtrar(Pagina<PreventivaConsultaTabelaVO> pagina) {
		Integer perfil = ((PreventivaConsultaFiltroVO)pagina.getModelVO()).getPerfil();
		String matricula = ((PreventivaConsultaFiltroVO)pagina.getModelVO()).getMatricula();
		List<String> codigosCentroCusto = centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		((PreventivaConsultaFiltroVO)pagina.getModelVO()).setCentroCustosHierarquia(codigosCentroCusto);
		
		String setor;
		if (perfil == PerfilEnum.SOLICITANTE.getIdPerfil()) {
			setor = "";
		} else {
			setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
		}

		return this.manutencaoPreventivaDAO.filtrar(pagina, setor);
	}
	
	public Pagina<AprovacaoPreventivaConsultaTabelaVO> filtrarManutencaoAprovacao(Pagina<AprovacaoPreventivaConsultaTabelaVO> pagina) {
		String matricula = ((AprovacaoManutencaoPreventivaFiltroVO) pagina.getModelVO()).getMatricula();
		Integer perfil = ((AprovacaoManutencaoPreventivaFiltroVO) pagina.getModelVO()).getPerfil();
		List<Long> setores;
		if(perfil == PerfilEnum.SOLICITANTE.getIdPerfil()) {
			setores = new ArrayList<>();
		} else {
			String centroCustoUsuario = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getCentroCusto();
			setores = this.familiaManutencaoService.buscarSetoresPorCC(centroCustoUsuario);
		}
		
		return this.manutencaoPreventivaDAO.filtrarManutencaoAprovacao(pagina, setores);
	}
	
	public void criarManutencoesExperidas() {
		List<ManutencaoPreventiva> manutencoes = manutencaoPreventivaDAO.buscarPreventivaExperida();
		
		if(CollectionUtils.isNullOrEmpty(manutencoes)) {
			return;
		}
		
		for (ManutencaoPreventiva manutencaoPreventiva : manutencoes) {
			PreventivaCadastroVO preventivaVO = ManutencaoPreventivaConverter.converter(manutencaoPreventiva);
			adicionarHistoricoStatusManutencao(preventivaVO, StatusManutencaoPreventivaEnum.MANUTENCAO_EXPERIDA.getCodigo());
			ManutencaoCorretiva corretivaSalva = salvarManutencaoCorretiva(manutencaoPreventiva);
			adicionarStatusAbertaCorretiva(corretivaSalva);
		}
	}
	
	public void aprovarManutencaoQuinzeDias() {
		List<ManutencaoPreventiva> manutencoes = manutencaoPreventivaDAO.buscarPreventivaComQuinzeDiasRealizada();
		
		if(CollectionUtils.isNullOrEmpty(manutencoes)) {
			return;
		}
		
		for (ManutencaoPreventiva manutencaoPreventiva : manutencoes) {
			PreventivaCadastroVO preventivaVO = ManutencaoPreventivaConverter.converter(manutencaoPreventiva);
			adicionarHistoricoStatusManutencao(preventivaVO, StatusManutencaoPreventivaEnum.APROVADA_GESTOR.getCodigo());
		}
	}
	
	private ManutencaoCorretiva salvarManutencaoCorretiva(ManutencaoPreventiva manutencaoPreventiva) {
		ManutencaoPreventiva ultimaManutencaoCadastrada = manutencaoPreventivaDAO.buscarUltimoRegistroCadastradoPorSetor(manutencaoPreventiva.getSetor().getIdSetor());
		SetorManutencao setorManutencao = setorManutencaoDAO.buscar(manutencaoPreventiva.getSetor().getIdSetor());	
		
		String novoNumeroSolicitacao;
		if(ultimaManutencaoCadastrada != null) {
			novoNumeroSolicitacao = GeradorNumeroSolicitacao.gerar(ultimaManutencaoCadastrada.getNumeroSolicitacao(), new Date(), setorManutencao.getNomeSetor(), true);
		} else {			
			novoNumeroSolicitacao = GeradorNumeroSolicitacao.gerar(null, new Date(), setorManutencao.getNomeSetor(), true);
		}
		ManutencaoCorretiva corretiva = new ManutencaoCorretiva(novoNumeroSolicitacao, manutencaoPreventiva.getEquipamento().getIdEquipamento(), 
				manutencaoPreventiva.getCentroCusto().getCodigoCentroCusto(), manutencaoPreventiva.getMatriculaSolicitante());
		return manutencaoDAO.salvar(corretiva);
	}
	
	private void adicionarStatusAbertaCorretiva(ManutencaoCorretiva corretivaSalva) {
		HistoricoStatusManutencaoCorretiva historico = new HistoricoStatusManutencaoCorretiva(corretivaSalva.getId(), StatusManutencaoPreventivaEnum.ABERTA.getCodigo(), new Long(1));
		historicoManutencaoCorretivaDAO.salvar(historico);
	}
	
	public ManutencaoVO buscarPorPerfil(Integer idPerfil, String matricula, String numeroSolicitacao) {
		ManutencaoPreventiva manutencao = manutencaoPreventivaDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
		
		if(PerfilEnum.TECNICO.getIdPerfil().equals(idPerfil)) {
			Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(matricula);
			manutencaoValidador.validarAlocacaoTecnincoManutencao(manutencao, tecnico);
		}
		

		return manutencao != null ? ManutencaoPreventivaConverter.converterGenerica(manutencao) : null;
	}

	public PreventivaCadastroVO buscarPorId(Long id) {
		ManutencaoPreventiva man = manutencaoPreventivaDAO.buscar(id);
		PreventivaCadastroVO manVO = ManutencaoPreventivaConverter.converter(man);	
		return manVO;
	}
	
	public ManutencaoVO buscarPorIdManutencao(Long id) {
		ManutencaoPreventiva manutencaoPreventiva = manutencaoPreventivaDAO.buscar(id);
		PreventivaCadastroVO manutencaoPreventivaVO = ManutencaoPreventivaConverter.converter(manutencaoPreventiva);
		
		ManutencaoVO manutencaoVO = new ManutencaoVO();
		manutencaoVO.setIdManutencao(manutencaoPreventiva.getId());
		manutencaoVO.setIdEquipamento(manutencaoPreventivaVO.getIdEquipamento());
		manutencaoVO.setNomeEquipamento(manutencaoPreventiva.getEquipamento().getCodigoManutencao() + " - " +manutencaoPreventiva.getEquipamento().getNomeEquipamento());
		manutencaoVO.setDataCriacao(manutencaoPreventiva.getTextoDataCriacao());
		manutencaoVO.setCentroCustoEquipamento(manutencaoPreventiva.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + 
				manutencaoPreventiva.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getCodigoCentroCusto());
		manutencaoVO.setClasseManutencao(ClasseManutencaoEnum.P.getDescricao().toString());
		manutencaoVO.setTipoManutencao(ClasseManutencaoEnum.P.name().charAt(0));
		
		manutencaoVO.setNumeroSolicitacao(manutencaoPreventiva.getNumeroSolicitacao());
		manutencaoVO.setHierarquiaCentroCusto(manutencaoPreventiva.getCentroCusto().getTextoHierarquiaCentroCusto());
		
		return manutencaoVO;
	}
	
	public RelatorioManutencaoPreventivaVO buscarRelatorioManutencaoPreventiva(Long idManutencao) {
		RelatorioManutencaoPreventivaVO relatorio = manutencaoPreventivaDAO.buscarRelatorioManutencaoPreventiva(idManutencao);
		relatorio.setAtividades(manutencaoPreventivaDAO.buscarSubRelatorioPreventivaAtividades(idManutencao));
		int sequencialAtividade = 1;
		for (SubRelatorioManutencaoAtividadesVO atividade : relatorio.getAtividades()) {
			if(!Strings.isNullOrEmpty(atividade.getObservacao())) {
				if(Strings.isNullOrEmpty(relatorio.getObservacaoAtividade())){				
					relatorio.setObservacaoAtividade(" " + sequencialAtividade + " - "+ atividade.getObservacao() + " \n");
					continue;
				}
				relatorio.setObservacaoAtividade(relatorio.getObservacaoAtividade() + " " + (++sequencialAtividade) + " - "+ atividade.getObservacao() + " \n");
			}
		}
		List<InformacaoPreventiva> informacoes = informacaoPreventivaDAO.buscarPorIdManutencao(relatorio.getIdManutencaoPreventiva());
		relatorio.setarInformacoesPreventiva(informacoes);
		relatorio.setMateriais(manutencaoPreventivaDAO.buscarSubRelatorioPreventivaMateriais(idManutencao));
		return relatorio;
	}
	
	public List<SubRelatorioManutencaoPreventivaAnualVO> gerarSubRelatorioManutencaoPreventivaAnual(
			RelatorioManutencaoPreventivaAnualFiltro filtro) {
		return manutencaoPreventivaDAO.gerarSubRelatorioManutencaoPreventivaAnual(filtro);
	}
	
}
