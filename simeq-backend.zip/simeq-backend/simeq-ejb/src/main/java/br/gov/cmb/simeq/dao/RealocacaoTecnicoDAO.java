package br.gov.cmb.simeq.dao;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.entidade.RealocacaoTecnico;

public class RealocacaoTecnicoDAO extends GenericoPaginadoDAO<RealocacaoTecnico, Long>{

	private static final long serialVersionUID = 1L;

	public List<RealocacaoTecnico> buscarPor(Long idTecnico) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("rt")
				.from(RealocacaoTecnico.class,"rt")
				.innerJoinFetch("rt.centroCusto", "c")
				.where("rt.tecnico.idTecnico = ?")
				.order("rt.idRealocacaoTecnico");
		return buscar(builder.builder(), idTecnico);
	}
	
	public RealocacaoTecnico buscarPorId(Long id) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("rt")
				.from(RealocacaoTecnico.class,"rt")
				.innerJoinFetch("rt.centroCusto", "c")
				.where("rt.idRealocacaoTecnico = ?")
				.order("rt.idRealocacaoTecnico");
		return buscarUmResultado(builder.builder(), id);
	}


	public RealocacaoTecnico buscarUltimoOuPenultimoRegistro(Boolean ultimo,Long idTecnico) {
		StringBuilder stringBuilder = new StringBuilder("SELECT * FROM REALOCACAO_TECNICO as rt,"
													+ "(SELECT row_number() OVER (ORDER BY ID_REALOCACAO_TECNICO DESC) AS indice,"
													+ "ID_REALOCACAO_TECNICO as indice_realocacao FROM REALOCACAO_TECNICO where ID_TECNICO = :idTecnico) as realocacoes_tabela where "
													+ "realocacoes_tabela.indice = :parametro and realocacoes_tabela.indice_realocacao = rt.ID_REALOCACAO_TECNICO");
		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString(),RealocacaoTecnico.class);
		query.setParameter("parametro", (ultimo) ? 1 : 2);
		query.setParameter("idTecnico", idTecnico);
		try {			
			return  (RealocacaoTecnico) query.getSingleResult();
		}catch (NoResultException e) {
			return null;
		}
	}
	
}
