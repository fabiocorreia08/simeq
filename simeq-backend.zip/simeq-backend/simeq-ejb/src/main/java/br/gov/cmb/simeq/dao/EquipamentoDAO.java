package br.gov.cmb.simeq.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.commons.lang.StringUtils;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.EquipamentoDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.Equipamento;
import br.gov.cmb.simeq.enums.AtivoInativoEnum;
import br.gov.cmb.simeq.enums.SimNaoEnum;
import br.gov.cmb.simeq.utils.StringUtil;
import br.gov.cmb.simeq.vo.RelatorioCapacidadeProdutivaEquipamentoFiltroVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioCapacidadeProdutivaEquipamentoVO;

public class EquipamentoDAO extends GenericoPaginadoDAO<Equipamento, Long> {

	private static final long serialVersionUID = 1L;

	public static final String NULL = "null";

	public Equipamento buscarEquipamento(Long idEquipamento) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("e").from(Equipamento.class, "e")
				.where("e.idEquipamento= ? ");
		return buscaSeguraUmResultado(builder.builder(), idEquipamento);
	}

	@SuppressWarnings("unchecked")
	public List<LabelValueDTO> buscarEquipamentoLabelValue() {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"new br.gov.cmb.simeq.dto.LabelValueDTO(CONCAT(e.codigoManutencao, ' - ', e.nomeEquipamento), e.idEquipamento)")
				.from(Equipamento.class, "e")
				.order("CONCAT(e.codigoManutencao, ' - ', e.nomeEquipamento)");
		return buscar(this.criarConsulta(builder.builder()), List.class);
	}

	@SuppressWarnings("unchecked")
	public List<EquipamentoDTO> buscarPorCodigoManutencaoNomeEquipamento(String codigoManutencao,
			String nomeEquipamento) {
		StringBuilder stringBuilder = new StringBuilder(
				"select new br.gov.cmb.simeq.dto.EquipamentoDTO(e.idEquipamento, e.codigoManutencao, e.nomeEquipamento, e.numeroAno, e.dataInstalacao) from Equipamento e "
						+ "	where (:codigoManutencao is null or e.codigoManutencao LIKE :codigoManutencao) "
						+ "		and (:nomeEquipamento is null or e.nomeEquipamento LIKE :nomeEquipamento) ");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("codigoManutencao", StringUtil.getParametroComLike(codigoManutencao));
		query.setParameter("nomeEquipamento", StringUtil.getParametroComLike(nomeEquipamento));
		return this.buscar(query, List.class);
	}

	@SuppressWarnings("unchecked")
	public Pagina<EquipamentoDTO> filtrar(Pagina<EquipamentoDTO> pagina) {
		StringBuilder stringBuilder = new StringBuilder(
				"SELECT new br.gov.cmb.simeq.dto.EquipamentoDTO(e.idEquipamento, e.codigoManutencao, e.nomeEquipamento, e.numeroAno, e.dataInstalacao, hse.flagStatus, "
						+ "	CONCAT(hse.centroCusto.textoHierarquiaCentroCusto, ' - ', hse.centroCusto.codigoCentroCusto)) "
						+ "	FROM Equipamento e" + " INNER JOIN e.historicosSituacaoEquipamento as hse "
						+ "	WHERE (:codigoManutencao IS NULL OR e.codigoManutencao = :codigoManutencao)"
						+ "	AND (:flagStatus IS NULL OR (:flagStatus = hse.flagStatus))"
						+ "	AND (:nomeEquipamento IS NULL OR e.nomeEquipamento LIKE :nomeEquipamento)"
						+ "	AND (:numeroAno IS NULL OR e.numeroAno =:numeroAno)"
						+ " AND (:codigoCentroCusto IS NULL OR hse.codigoCentroCusto = :codigoCentroCusto)"
						+ " AND (hse.idHistoricoSituacaoEquipamento = (SELECT MAX(se.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento se WHERE se.equipamento.idEquipamento = e.idEquipamento))");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("codigoManutencao", pagina.getModelVO().getParametros().get("codigoManutencao"));
		query.setParameter("flagStatus",
				NULL.equals(pagina.getModelVO().getParametros().get("flagStatus")) ? null
						: AtivoInativoEnum.getAtivoInativoEnumPor(
								pagina.getModelVO().getParametros().get("flagStatus").toString()));
		query.setParameter("nomeEquipamento",
				StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("nomeEquipamento")));
		query.setParameter("numeroAno", pagina.getModelVO().getParametros().get("numeroAno"));
		query.setParameter("codigoCentroCusto",
				NULL.equals(pagina.getModelVO().getParametros().get("codigoCentroCusto")) ? null
						: pagina.getModelVO().getParametros().get("codigoCentroCusto"));
		query.setFirstResult(pagina.getPrimeiroRegistro()).setMaxResults(pagina.getTamanho());
		pagina.setRegistros(this.buscar(query, List.class));
		pagina.setTotalDeRegistros(this.filtrarNumeroDeRegistros(pagina));
		return pagina;
	}

	private Integer filtrarNumeroDeRegistros(Pagina<EquipamentoDTO> pagina) {
		StringBuilder stringBuilder = new StringBuilder("SELECT DISTINCT new java.lang.Long(count(*)) "
				+ "	FROM Equipamento e" + " INNER JOIN e.historicosSituacaoEquipamento as hse "
				+ "	WHERE (:codigoManutencao IS NULL OR e.codigoManutencao = :codigoManutencao)"
				+ "	AND (:flagStatus IS NULL OR (:flagStatus = hse.flagStatus))"
				+ "	AND (:nomeEquipamento IS NULL OR e.nomeEquipamento LIKE :nomeEquipamento)"
				+ "	AND (:numeroAno IS NULL OR e.numeroAno =:numeroAno)"
				+ " AND (:codigoCentroCusto IS NULL OR hse.codigoCentroCusto = :codigoCentroCusto)"
				+ " AND (hse.idHistoricoSituacaoEquipamento = (SELECT MAX(se.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento se WHERE se.equipamento.idEquipamento = e.idEquipamento))");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("codigoManutencao", pagina.getModelVO().getParametros().get("codigoManutencao"));
		query.setParameter("flagStatus",
				NULL.equals(pagina.getModelVO().getParametros().get("flagStatus")) ? null
						: AtivoInativoEnum.getAtivoInativoEnumPor(
								pagina.getModelVO().getParametros().get("flagStatus").toString()));
		query.setParameter("nomeEquipamento",
				StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("nomeEquipamento")));
		query.setParameter("numeroAno", pagina.getModelVO().getParametros().get("numeroAno"));
		query.setParameter("codigoCentroCusto",
				NULL.equals(pagina.getModelVO().getParametros().get("codigoCentroCusto")) ? null
						: pagina.getModelVO().getParametros().get("codigoCentroCusto"));
		return ((Long) this.buscar(query, List.class).get(0)).intValue();
	}

	public EquipamentoDTO salvar(EquipamentoDTO equipamentoDTO) {
		StringBuilder stringBuilder = new StringBuilder("insert into EQUIPAMENTO (NM_EQUIPAMENTO," + "NR_PATRIMONIO,"
				+ "NR_TENSAO," + "NR_POTENCIA," + "NM_TIPO_POTENCIA," + "NR_PESO," + "NR_ANO," + "DT_INSTALACAO,"
				+ "FL_PREVENTIVA," + "DS_PRE_REQUISITO_INFORMACAO," + "DS_OBSERVACAO," + "CD_MANUTENCAO)"
				+ " output Inserted.ID_EQUIPAMENTO, Inserted.CD_MANUTENCAO " + "values (" + ":nomeEquipamento,"
				+ ":numeroPatrimonio," + ":numeroTensao," + ":numeroPotencia," + ":nomeTipoPotencia," + ":numeroPeso,"
				+ ":numeroAno," + ":dataInstalacao," + ":flagPreventiva," + ":descricaoPreRequisitoInformacao,"
				+ ":descricaoObservacao,"
				+ "(SELECT CONCAT(:codigoManutencao,RIGHT('000'+CAST(coalesce(MAX(CAST(SUBSTRING(CD_MANUTENCAO,4,3) AS int))+1,1) as varchar), 3)) "
				+ "FROM EQUIPAMENTO e WHERE SUBSTRING(e.CD_MANUTENCAO, 1, 3) like :codigoManutencaoComLike))");

		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString());
		query.setParameter("nomeEquipamento", equipamentoDTO.getNomeEquipamento());
		query.setParameter("numeroPatrimonio", equipamentoDTO.getNumeroPatrimonio());
		query.setParameter("numeroTensao", equipamentoDTO.getNumeroTensao());
		query.setParameter("numeroPotencia", equipamentoDTO.getNumeroPotencia());
		query.setParameter("nomeTipoPotencia", equipamentoDTO.getNomeTipoPotencia());
		query.setParameter("numeroPeso", equipamentoDTO.getNumeroPeso());
		query.setParameter("numeroAno", equipamentoDTO.getNumeroAno());
		query.setParameter("dataInstalacao", equipamentoDTO.getDataInstalacao());
		query.setParameter("flagPreventiva", equipamentoDTO.getFlagPreventiva().label);
		query.setParameter("descricaoPreRequisitoInformacao",
				StringUtils.isNotBlank(equipamentoDTO.getDescricaoPreRequisitoInformacao())
						? equipamentoDTO.getDescricaoPreRequisitoInformacao()
						: null);
		query.setParameter("descricaoObservacao",
				StringUtils.isNotBlank(equipamentoDTO.getDescricaoObservacao())
						? equipamentoDTO.getDescricaoObservacao()
						: null);
		query.setParameter("codigoManutencao", equipamentoDTO.getCodigoManutencao());
		query.setParameter("codigoManutencaoComLike",
				StringUtil.getParametroComLikeADireita(equipamentoDTO.getCodigoManutencao()));
		Object[] objetos = (Object[]) query.getSingleResult();
		return new EquipamentoDTO(Long.valueOf(objetos[0].toString()), objetos[1].toString());
	}

	public List<SubRelatorioCapacidadeProdutivaEquipamentoVO> gerarSubRelatorioCapacidadeProdutivaEquipamento(
			RelatorioCapacidadeProdutivaEquipamentoFiltroVO filtro) {
		List<SubRelatorioCapacidadeProdutivaEquipamentoVO> registros = ((TypedQuery<SubRelatorioCapacidadeProdutivaEquipamentoVO>) this
				.preencherParametros(this.getEntityManager().createNamedQuery("filtrarCapacidadeEquipamento",
						SubRelatorioCapacidadeProdutivaEquipamentoVO.class), filtro)).getResultList();
		return registros;
	}

	private TypedQuery<SubRelatorioCapacidadeProdutivaEquipamentoVO> preencherParametros(
			TypedQuery<SubRelatorioCapacidadeProdutivaEquipamentoVO> typedQuery,
			RelatorioCapacidadeProdutivaEquipamentoFiltroVO relatorio) {
		Integer centrosCustoSize = centrosCustoSize(relatorio.getCentrosCusto());
		List<String> centrosCusto = buscarCentroCusto(relatorio.getCentrosCusto());

		typedQuery.setParameter("dataInicial", relatorio.getDataInicial())
				.setParameter("dataFinal", relatorio.getDataFinal()).setParameter("centrosCustoSize", centrosCustoSize)
				.setParameter("centrosCusto", centrosCusto).setParameter("soPreventivas",
						(relatorio.getSoPreventivas() == true) ? SimNaoEnum.S.label : SimNaoEnum.N.label);

		return typedQuery;

	}

	private Integer centrosCustoSize(List<String> centroCusto) {
		if (centroCusto != null && centroCusto.size() > 0) {
			return centroCusto.size();
		}
		return 0;
	}

	private List<String> buscarCentroCusto(List<String> centrosCusto) {
		if (centrosCusto != null && centrosCusto.size() > 0) {
			return centrosCusto;
		}
		return Arrays.asList("0");
	}

	public List<LabelValueDTO> buscarHierarquiaCCUsuarioLogado(List<String> listaCC) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO(CONCAT(e.codigoManutencao, ' - ', e.nomeEquipamento), e.idEquipamento)")
				.from(Equipamento.class, "e").innerJoin("e.historicosSituacaoEquipamento", "h")
				.where("h.codigoCentroCusto in ?1 ")
				.and("h.idHistoricoSituacaoEquipamento = (SELECT MAX(h2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento h2 WHERE h2.equipamento.idEquipamento = h.equipamento.idEquipamento)")
				.order("CONCAT(e.codigoManutencao, ' - ', e.nomeEquipamento)");
		return buscar(builder.builder(), LabelValueDTO.class, listaCC);
	}

	public List<LabelValueDTO> buscarHierarquiaFamilia(List<String> listaCC) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO(CONCAT(e.codigoManutencao, ' - ', e.nomeEquipamento), e.idEquipamento)")
				.from(Equipamento.class, "e").innerJoin("e.historicosSituacaoEquipamento", "h")
				.where("h.codigoCentroCusto in ?1 ");
		return buscar(builder.builder(), LabelValueDTO.class, listaCC);
	}

}