package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.cmb.simeq.enums.TipoRealocacaoTecnicoEnum;
@JsonIgnoreProperties(ignoreUnknown=true)
public class RealocacaoTecnicoDTO implements Serializable {

	private static final long serialVersionUID = -8998983459565085445L;

	private Long id;
	private Long tecnico;
	private TipoRealocacaoTecnicoEnum tipoRealocacao;
	private String centroCusto;
	private String hierarquiaCentroCusto;
	private Date periodoInicio;
	private Date periodoFim;
	private String motivo;
	private Boolean isUltima;

	public RealocacaoTecnicoDTO() {

	}

	public RealocacaoTecnicoDTO(Long id, Long tecnico, TipoRealocacaoTecnicoEnum tipoRealocacao, String centroCusto,
			Date periodoInicio, Date periodoFim, String motivo) {
		this.id = id;
		this.tecnico = tecnico;
		this.tipoRealocacao = tipoRealocacao;
		this.centroCusto = centroCusto;
		this.periodoInicio = periodoInicio;
		this.periodoFim = periodoFim;
		this.motivo = motivo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTecnico() {
		return tecnico;
	}

	public void setTecnico(Long tecnico) {
		this.tecnico = tecnico;
	}

	public TipoRealocacaoTecnicoEnum getTipoRealocacao() {
		return tipoRealocacao;
	}

	public void setTipoRealocacao(TipoRealocacaoTecnicoEnum tipoRealocacao) {
		this.tipoRealocacao = tipoRealocacao;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public Date getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(Date periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public Date getPeriodoFim() {
		return periodoFim;
	}

	public void setPeriodoFim(Date periodoFim) {
		this.periodoFim = periodoFim;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public Boolean getIsUltima() {
		return isUltima;
	}

	public void setIsUltima(Boolean isUltima) {
		this.isUltima = isUltima;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

}
