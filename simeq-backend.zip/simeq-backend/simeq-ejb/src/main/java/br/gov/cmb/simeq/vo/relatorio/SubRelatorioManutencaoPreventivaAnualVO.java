package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

public class SubRelatorioManutencaoPreventivaAnualVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3077488323070932901L;
	
	private String equipamento;
	private String horasJaneiro;
	private String horasFevereiro;
	private String horasMarco;
	private String horasAbril;
	private String horasMaio;
	private String horasJunho;
	private String horasJulho;
	private String horasAgosto;
	private String horasSetembro;
	private String horasOutubro;
	private String horasNovembro;
	private String horasDezembro;

	public SubRelatorioManutencaoPreventivaAnualVO() {
		super();
	}

	public SubRelatorioManutencaoPreventivaAnualVO(String equipamento, String horasJaneiro, String horasFevereiro,
			String horasMarco, String horasAbril, String horasMaio, String horasJunho, String horasJulho,
			String horasAgosto, String horasSetembro, String horasOutubro, String horasNovembro, String horasDezembro) {
		super();
		this.equipamento = equipamento;
		this.horasJaneiro = horasJaneiro;
		this.horasFevereiro = horasFevereiro;
		this.horasMarco = horasMarco;
		this.horasAbril = horasAbril;
		this.horasMaio = horasMaio;
		this.horasJunho = horasJunho;
		this.horasJulho = horasJulho;
		this.horasAgosto = horasAgosto;
		this.horasSetembro = horasSetembro;
		this.horasOutubro = horasOutubro;
		this.horasNovembro = horasNovembro;
		this.horasDezembro = horasDezembro;
	}

	public String getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(String equipamento) {
		this.equipamento = equipamento;
	}

	public String getHorasJaneiro() {
		return horasJaneiro;
	}

	public void setHorasJaneiro(String horasJaneiro) {
		this.horasJaneiro = horasJaneiro;
	}

	public String getHorasFevereiro() {
		return horasFevereiro;
	}

	public void setHorasFevereiro(String horasFevereiro) {
		this.horasFevereiro = horasFevereiro;
	}

	public String getHorasMarco() {
		return horasMarco;
	}

	public void setHorasMarco(String horasMarco) {
		this.horasMarco = horasMarco;
	}

	public String getHorasAbril() {
		return horasAbril;
	}

	public void setHorasAbril(String horasAbril) {
		this.horasAbril = horasAbril;
	}

	public String getHorasMaio() {
		return horasMaio;
	}

	public void setHorasMaio(String horasMaio) {
		this.horasMaio = horasMaio;
	}

	public String getHorasJunho() {
		return horasJunho;
	}

	public void setHorasJunho(String horasJunho) {
		this.horasJunho = horasJunho;
	}

	public String getHorasJulho() {
		return horasJulho;
	}

	public void setHorasJulho(String horasJulho) {
		this.horasJulho = horasJulho;
	}

	public String getHorasAgosto() {
		return horasAgosto;
	}

	public void setHorasAgosto(String horasAgosto) {
		this.horasAgosto = horasAgosto;
	}

	public String getHorasSetembro() {
		return horasSetembro;
	}

	public void setHorasSetembro(String horasSetembro) {
		this.horasSetembro = horasSetembro;
	}

	public String getHorasOutubro() {
		return horasOutubro;
	}

	public void setHorasOutubro(String horasOutubro) {
		this.horasOutubro = horasOutubro;
	}

	public String getHorasNovembro() {
		return horasNovembro;
	}

	public void setHorasNovembro(String horasNovembro) {
		this.horasNovembro = horasNovembro;
	}

	public String getHorasDezembro() {
		return horasDezembro;
	}

	public void setHorasDezembro(String horasDezembro) {
		this.horasDezembro = horasDezembro;
	}
}
