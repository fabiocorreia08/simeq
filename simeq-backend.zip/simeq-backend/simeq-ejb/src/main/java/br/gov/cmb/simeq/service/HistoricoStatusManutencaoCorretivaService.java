package br.gov.cmb.simeq.service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;

import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ParametroDAO;
import br.gov.cmb.simeq.dto.AprovacaoReprovacaoManutencaoCorretivaDTO;
import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.enums.ParametroEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;

@Stateless
public class HistoricoStatusManutencaoCorretivaService {

	@Inject
	private HistoricoStatusManutencaoCorretivaDAO historicoStatusManutencaoCorretivaDAO;
	
	@Inject
	private AtividadeCorretivaDAO atividadeDAO;
	
	@Inject
	private ParametroDAO parametroDAO;
	
	@Inject
	private EmailService emailService;
	
	@Transactional
	public void aprovar(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {

		List<HistoricoStatusManutencaoCorretiva> historicosStatusManutencaoCorretiva = construirHistoricosStatusManutencaoCorretivaAprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO);
		for(HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva: historicosStatusManutencaoCorretiva) {
			verificarAtividades(historicoStatusManutencaoCorretiva);
			historicoStatusManutencaoCorretivaDAO.salvar(historicoStatusManutencaoCorretiva);
		}
	}
	
	private List<HistoricoStatusManutencaoCorretiva> construirHistoricosStatusManutencaoCorretivaAprovacao(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		List<HistoricoStatusManutencaoCorretiva> historicosStatusManutencaoCorretiva = new ArrayList<HistoricoStatusManutencaoCorretiva>();
		for(Long id: aprovacaoReprovacaoManutencaoCorretivaDTO.getIds()) {
			HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoStatusManutencaoCorretivaDAO.buscarUltimoHistoricoInserido(id);
			historicosStatusManutencaoCorretiva.add(new HistoricoStatusManutencaoCorretiva(id, StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo(), ultimoHistoricoCadastrado.getProximoSequencial(), aprovacaoReprovacaoManutencaoCorretivaDTO.getMatriculaUsuarioLogado(), aprovacaoReprovacaoManutencaoCorretivaDTO.getMotivo()));
		}
		return historicosStatusManutencaoCorretiva;
	}
	
	private void verificarAtividades(HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva) {
		List<AtividadeCorretiva> atividades = atividadeDAO.buscarAtividadePorManutencao(historicoStatusManutencaoCorretiva.getId().getIdManutencaoCorretiva());
		if(atividades.isEmpty()) {
			historicoStatusManutencaoCorretiva.getId().setIdStatusManutencao(StatusManutencaoCorretivaEnum.AG_APROPRIACAO.getCodigo());
		}
	}
	
	@Transactional
	public void reprovar(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {

		List<HistoricoStatusManutencaoCorretiva> historicosStatusManutencaoCorretiva = construirHistoricosStatusManutencaoCorretivaReprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO);
		for(HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva: historicosStatusManutencaoCorretiva) {
			historicoStatusManutencaoCorretivaDAO.salvar(historicoStatusManutencaoCorretiva);
		}
	}
	
	private List<HistoricoStatusManutencaoCorretiva> construirHistoricosStatusManutencaoCorretivaReprovacao(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		List<HistoricoStatusManutencaoCorretiva> historicosStatusManutencaoCorretiva = new ArrayList<HistoricoStatusManutencaoCorretiva>();
		for(Long id: aprovacaoReprovacaoManutencaoCorretivaDTO.getIds()) {
			HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoStatusManutencaoCorretivaDAO.buscarUltimoHistoricoInserido(id);
			historicosStatusManutencaoCorretiva.add(new HistoricoStatusManutencaoCorretiva(id, StatusManutencaoCorretivaEnum.REABERTA.getCodigo(), ultimoHistoricoCadastrado.getProximoSequencial(), aprovacaoReprovacaoManutencaoCorretivaDTO.getMatriculaUsuarioLogado(), aprovacaoReprovacaoManutencaoCorretivaDTO.getMotivo()));
		}
		return historicosStatusManutencaoCorretiva;
	}
	
	public void enviarEmailAprovacao(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		String destinatario = parametroDAO.buscar(ParametroEnum.SETOR_MANUTENCAO.getCodigoParametro()).getValor();
		for(Long id: aprovacaoReprovacaoManutencaoCorretivaDTO.getIds()) {
			HistoricoStatusManutencaoCorretiva ultimoHistoricoStatusManutencaoCorretiva = historicoStatusManutencaoCorretivaDAO.buscarUltimoHistoricoInseridoComManutencaoCorretivaEUsuarioResponsavelPelaAlteracao(id);
			emailService.enviarEmailAprovacaoSolicitacao(destinatario, ultimoHistoricoStatusManutencaoCorretiva);
		}
	}

	public void enviarEmailReprovacao(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		String destinatario = parametroDAO.buscar(ParametroEnum.SETOR_MANUTENCAO.getCodigoParametro()).getValor();
		for(Long id: aprovacaoReprovacaoManutencaoCorretivaDTO.getIds()) {
			HistoricoStatusManutencaoCorretiva ultimoHistoricoStatusManutencaoCorretiva = historicoStatusManutencaoCorretivaDAO.buscarUltimoHistoricoInseridoComManutencaoCorretivaEUsuarioResponsavelPelaAlteracao(id);
			emailService.enviarEmailReprovacaoSolicitacao(destinatario, ultimoHistoricoStatusManutencaoCorretiva);
		}
	}
}
