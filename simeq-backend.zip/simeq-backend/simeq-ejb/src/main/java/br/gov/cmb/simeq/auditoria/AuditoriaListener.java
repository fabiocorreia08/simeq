package br.gov.cmb.simeq.auditoria;

import javax.enterprise.context.ContextNotActiveException;

import org.apache.commons.lang.StringUtils;
import org.hibernate.envers.RevisionListener;

import br.gov.cmb.common.rest.security.AuthenticationContext;
import br.gov.cmb.common.util.CDIUtils;

public class AuditoriaListener implements RevisionListener {

	private static final String MATRICULA_SISTEMA = "AUTO";

	@Override
	public void newRevision(Object revisionEntity) {
		try {			
			AuthenticationContext auth = CDIUtils.recuperarBean(AuthenticationContext.class);
			Auditoria auditoria = (Auditoria) revisionEntity;
			if (StringUtils.isBlank(auth.getUsername()) || StringUtils.equalsIgnoreCase("ANONYMOUS", auth.getUsername())) {
				auditoria.setMatricula(MATRICULA_SISTEMA);
			} else {
				auditoria.setMatricula(auth.getUsername());
			}
		} catch (ContextNotActiveException e) {
			Auditoria auditoria = (Auditoria) revisionEntity;
			auditoria.setMatricula("AUTO");
		}
	}

}
