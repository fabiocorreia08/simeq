package br.gov.cmb.simeq.vo.relatorio;

import java.util.List;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorioDia")
public class RelatorioGestaoEstrategicaDiaVO extends RelatorioDataSource<SubRelatorioGestaoEstrategicaDiaVO> {

	private static final long serialVersionUID = 3558125760197835388L;
	
	public RelatorioGestaoEstrategicaDiaVO(List<SubRelatorioGestaoEstrategicaDiaVO> lista) {
		super(lista);
	}
}
