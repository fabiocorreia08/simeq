package br.gov.cmb.simeq.converter;

import br.gov.cmb.simeq.dto.GrupoDTO;
import br.gov.cmb.simeq.entidade.Grupo;

public class GrupoConverter {

	public static Grupo converter(GrupoDTO grupoDTO) {
		return new Grupo(	grupoDTO.getIdGrupo(),
							grupoDTO.getIdEquipamento(),
							grupoDTO.getIdGrupoPai(),
							grupoDTO.getCodigoSequencia(),
							grupoDTO.getDescricaoGrupo(),
							grupoDTO.getFlagMecanico().name(),
							grupoDTO.getFlagEletricista().name(),
							grupoDTO.getFlagEletronico().name(),
							grupoDTO.getFlagTI().name(),
							grupoDTO.getFlagUtilidades().name(),
							grupoDTO.getFlagEngenharia().name(),
							grupoDTO.getFlagPreventiva().name(),
							grupoDTO.getDescricaoObservacao());
	}

	public static GrupoDTO converter(Grupo grupo) {
		return new GrupoDTO(grupo.getIdGrupo(),
							(grupo.getGrupoPai() != null) ? grupo.getGrupoPai().getIdGrupo() : null,
							grupo.getEquipamento().getIdEquipamento(),
							grupo.getCodigoSequencia(),
							(grupo.getGrupoPai() != null) ? grupo.getGrupoPai().getCodigoSequencia() : null,
							grupo.getDescricaoGrupo(),
							grupo.getFlagMecanico(),
							grupo.getFlagEletricista(),
							grupo.getFlagEletronico(),
							grupo.getFlagTI(),
							grupo.getFlagUtilidades(),
							grupo.getFlagEngenharia(),
							grupo.getFlagPreventiva(),
							grupo.getFlagPreventiva(),
							grupo.getDescricaoObservacao());
	}
}
