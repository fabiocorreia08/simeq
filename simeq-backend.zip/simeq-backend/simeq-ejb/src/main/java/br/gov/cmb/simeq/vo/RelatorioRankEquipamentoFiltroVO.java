package br.gov.cmb.simeq.vo;

import java.util.Date;
import java.util.List;

import javax.inject.Named;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

@Named
public class RelatorioRankEquipamentoFiltroVO extends ModeloVO {

	private static final long serialVersionUID = -3554112828208435522L;

	@ParametroNomeado
	private List<String> centroCustos = Lists.newArrayList();
	
	@ParametroNomeado
	private Date periodoInicio;
	
	@ParametroNomeado
	private Date periodoFim;
	

	public List<String> getCentroCustos() {
		return centroCustos;
	}

	public void setCentroCustos(List<String> centroCustos) {
		this.centroCustos = centroCustos;
	}

	public Date getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(Date periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public Date getPeriodoFim() {
		return periodoFim;
	}

	public void setPeriodoFim(Date periodoFim) {
		this.periodoFim = periodoFim;
	}
	
}
