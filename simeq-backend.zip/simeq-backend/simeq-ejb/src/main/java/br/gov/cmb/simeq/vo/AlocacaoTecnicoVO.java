package br.gov.cmb.simeq.vo;

import java.io.Serializable;

public class AlocacaoTecnicoVO implements Serializable {

	private static final long serialVersionUID = 3212959646591140278L;
	
	private Long idManutencao;
	private String numeroSolicitacao;
	private String matriculaTecnico;
	private Long idTecnico;
	
	public AlocacaoTecnicoVO(){}
	
	public AlocacaoTecnicoVO(Long idManutencao, String matriculaTecnico, Long idTecnico) {
		this.idManutencao = idManutencao;
		this.matriculaTecnico = matriculaTecnico;
		this.idTecnico = idTecnico;
	}
	
	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public String getMatriculaTecnico() {
		return matriculaTecnico;
	}
	
	public void setMatriculaTecnico(String matriculaTecnico) {
		this.matriculaTecnico = matriculaTecnico;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}
	
}
