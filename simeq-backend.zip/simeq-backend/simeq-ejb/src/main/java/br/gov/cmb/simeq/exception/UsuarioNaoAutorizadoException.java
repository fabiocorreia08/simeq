package br.gov.cmb.simeq.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class UsuarioNaoAutorizadoException extends RuntimeException{

	private static final long serialVersionUID = -1000348400672890335L;
	
	public UsuarioNaoAutorizadoException() {
		super();
	}
	
}
