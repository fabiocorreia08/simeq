package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

public class SubRelatorioGestaoEstrategicaMaterialVO implements Serializable {

	private static final long serialVersionUID = -2167670648364013465L;

	private String codigoMaterial;
	private String descricaoMaterial;
	private Integer quantidadeMaterial;
	private Double valorMaterial;

	public SubRelatorioGestaoEstrategicaMaterialVO() {
		super();
	}

	public SubRelatorioGestaoEstrategicaMaterialVO(String codigoMaterial, String descricaoMaterial,
			Integer quantidadeMaterial, Double valorMaterial) {
		super();
		this.codigoMaterial = codigoMaterial;
		this.descricaoMaterial = descricaoMaterial;
		this.quantidadeMaterial = quantidadeMaterial;
		this.valorMaterial = valorMaterial;
	}

	public String getCodigoMaterial() {
		return codigoMaterial;
	}

	public void setCodigoMaterial(String codigoMaterial) {
		this.codigoMaterial = codigoMaterial;
	}

	public String getDescricaoMaterial() {
		return descricaoMaterial;
	}

	public void setDescricaoMaterial(String descricaoMaterial) {
		this.descricaoMaterial = descricaoMaterial;
	}

	public Integer getQuantidadeMaterial() {
		return quantidadeMaterial;
	}

	public void setQuantidadeMaterial(Integer quantidadeMaterial) {
		this.quantidadeMaterial = quantidadeMaterial;
	}

	public Double getValorMaterial() {
		return valorMaterial;
	}

	public void setValorMaterial(Double valorMaterial) {
		this.valorMaterial = valorMaterial;
	}

}
