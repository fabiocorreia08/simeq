package br.gov.cmb.simeq.vo;

import java.util.List;

import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AlocacaoCadastrarFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 2926166022857407255L;
	
	private String numeroSolicitacao;
	
	private String nomeCargo;
	
	private Long idTecnico;
	
	private String nomeFuncao;
	
	private List<String> centroCustosHierarquia;
	
	private String codigoTurno;

	private String matricula;
	
	private Integer perfil;
	
	public String getNomeCargo() {
		return nomeCargo;
	}

	public void setNomeCargo(String nomeCargo) {
		this.nomeCargo = nomeCargo;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public String getNomeFuncao() {
		return nomeFuncao;
	}

	public void setNomeFuncao(String nomeFuncao) {
		this.nomeFuncao = nomeFuncao;
	}

	public List<String> getCentroCustosHierarquia() {
		return centroCustosHierarquia;
	}

	public void setCentroCustosHierarquia(List<String> centroCustosHierarquia) {
		this.centroCustosHierarquia = centroCustosHierarquia;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getCodigoTurno() {
		return codigoTurno;
	}

	public void setCodigoTurno(String codigoTurno) {
		this.codigoTurno = codigoTurno;
	}	

}
