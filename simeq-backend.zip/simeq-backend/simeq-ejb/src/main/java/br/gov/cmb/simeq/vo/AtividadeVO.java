package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.google.common.collect.Lists;

import br.gov.cmb.common.util.DataUtils;

public class AtividadeVO implements Serializable {

	private static final long serialVersionUID = 5446293612828595340L;
	
	private Long id;
	private Long idManutencao;
	private String classeManutencao;
	private String dataCadastroManutencao;
	private String matriculaExecutante;
	private String nomeExecutante;
	private String hierarquiaCentroCustoEquipamento;
	private Long idSubGrupo;
	private Long idGrupo;
	private String decricaoAcao;
	private String codigoAcao;
	private String codigoComponente;
	private String nomeComponente;
	private Integer mesReferencia;
	private String horasAtividade;
	private String observacao;
	private List<AtividadeMaterialVO> materiais = Lists.newArrayList();
	private String numeroSolicitacao;
	private String matriculaUsuarioLogado;
	private String nomeUsuarioLogado;
	private String tipoManutencao;
	private BigDecimal salario;
	private String horasComParalisacao;
	private String horasSemParalisacao;
	
	public AtividadeVO() {}
	
	public AtividadeVO(Long id, Long idManutencao, String classeManutencao, String matriculaExecutante, Date dataCadastroManutencao, String nomeExecutante, Long idGrupo, 
			Long idSubGrupo, String decricaoAcao, String codigoAcao, String hierarquiaCentroCustoEquipamento, String codigoComponente, String nomeComponente, Integer mesReferencia, 
			String horasAtividade, String observacao,List<AtividadeMaterialVO> materiais, String numeroSolicitacao, BigDecimal salario, String horasComParalisacao, 
			String horasSemParalisacao) {
		this.id = id;
		this.idManutencao = idManutencao;
		this.classeManutencao = classeManutencao;
		this.matriculaExecutante = matriculaExecutante;
		this.dataCadastroManutencao = DataUtils.formatar(dataCadastroManutencao, DataUtils.FORMATO_HORA_DDMMYYYY_HHMM);
		this.nomeExecutante = nomeExecutante;
		this.idGrupo = idGrupo;
		this.idSubGrupo = idSubGrupo;
		this.decricaoAcao = decricaoAcao;
		this.codigoAcao = codigoAcao;
		this.hierarquiaCentroCustoEquipamento = hierarquiaCentroCustoEquipamento;
		this.codigoComponente = codigoComponente;
		this.nomeComponente = nomeComponente;
		this.mesReferencia = mesReferencia;
		this.horasAtividade = horasAtividade;
		this.observacao = observacao;
		this.materiais = materiais;
		this.numeroSolicitacao = numeroSolicitacao;
		this.salario = salario;
		this.horasComParalisacao = horasComParalisacao;
		this.horasSemParalisacao = horasSemParalisacao;
	}
	
	public String getHorasComParalisacao() {
		return horasComParalisacao;
	}

	public void setHorasComParalisacao(String horasComParalisacao) {
		this.horasComParalisacao = horasComParalisacao;
	}

	public String getHorasSemParalisacao() {
		return horasSemParalisacao;
	}

	public void setHorasSemParalisacao(String horasSemParalisacao) {
		this.horasSemParalisacao = horasSemParalisacao;
	}

	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getIdManutencao() {
		return idManutencao;
	}
	
	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	
	public String getMatriculaExecutante() {
		return matriculaExecutante;
	}
	
	public void setMatriculaExecutante(String matriculaExecutante) {
		this.matriculaExecutante = matriculaExecutante;
	}
	
	public Long getIdSubGrupo() {
		return idSubGrupo;
	}
	
	public void setIdSubGrupo(Long idSubGrupo) {
		this.idSubGrupo = idSubGrupo;
	}
	
	public String getDecricaoAcao() {
		return decricaoAcao;
	}

	public void setDecricaoAcao(String decricaoAcao) {
		this.decricaoAcao = decricaoAcao;
	}

	public String getCodigoAcao() {
		return codigoAcao;
	}

	public void setCodigoAcao(String codigoAcao) {
		this.codigoAcao = codigoAcao;
	}
	
	public String getCodigoComponente() {
		return codigoComponente;
	}

	public void setCodigoComponente(String codigoComponente) {
		this.codigoComponente = codigoComponente;
	}

	public String getNomeComponente() {
		return nomeComponente;
	}

	public void setNomeComponente(String nomeComponente) {
		this.nomeComponente = nomeComponente;
	}

	public Integer getMesReferencia() {
		return mesReferencia;
	}
	
	public void setMesReferencia(Integer mesReferencia) {
		this.mesReferencia = mesReferencia;
	}
	
	public String getHorasAtividade() {
		return horasAtividade;
	}
	
	public void setHorasAtividade(String horasAtividade) {
		this.horasAtividade = horasAtividade;
	}
	
	public String getObservacao() {
		return observacao;
	}
	
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public String getDataCadastroManutencao() {
		return dataCadastroManutencao;
	}

	public void setDataCadastroManutencao(String dataCadastroManutencao) {
		this.dataCadastroManutencao = dataCadastroManutencao;
	}

	public String getNomeExecutante() {
		return nomeExecutante;
	}

	public void setNomeExecutante(String nomeExecutante) {
		this.nomeExecutante = nomeExecutante;
	}

	public String getHierarquiaCentroCustoEquipamento() {
		return hierarquiaCentroCustoEquipamento;
	}

	public void setHierarquiaCentroCustoEquipamento(String hierarquiaCentroCustoEquipamento) {
		this.hierarquiaCentroCustoEquipamento = hierarquiaCentroCustoEquipamento;
	}

	public Long getIdGrupo() {
		return idGrupo;
	}

	public void setIdGrupo(Long idGrupo) {
		this.idGrupo = idGrupo;
	}

	public List<AtividadeMaterialVO> getMateriais() {
		return materiais;
	}

	public void setMateriais(List<AtividadeMaterialVO> materiais) {
		this.materiais = materiais;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public String getNomeUsuarioLogado() {
		return nomeUsuarioLogado;
	}

	public void setNomeUsuarioLogado(String nomeUsuarioLogado) {
		this.nomeUsuarioLogado = nomeUsuarioLogado;
	}

	public String getTipoManutencao() {
		return tipoManutencao;
	}

	public void setTipoManutencao(String tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}

	public BigDecimal getSalario() {
		return salario;
	}

	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}
	
}
