package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;

@Audited
@Entity
@Table(name = "RE_STT_MANUTENCAO_CORRETIVA")
public class HistoricoStatusManutencaoCorretiva implements Serializable {

	private static final long serialVersionUID = 4734000638700896497L;
	
	@Id
	private HistStatusManutencaoCorretivaId id;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MANUTENCAO_CORRETIVA", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private ManutencaoCorretiva manutencaoCorretiva;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_STATUS", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private StatusManutencaoCorretiva statusManutencaoCorretiva;
	
	@Column(name = "DT_STATUS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "CD_MATRIC_STATUS")
	private String matriculaUsuario;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CD_MATRIC_STATUS", insertable = false, updatable = false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private PessoaView usuarioResponsavelPelaAlteracao;
	
	@Column(name = "DS_STATUS")
	private String descricaoStatus;
	
	@OneToMany(mappedBy = "historicoStatusManutencaoCorretiva", fetch = FetchType.LAZY)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private List<InformacaoCorretiva> informacoes;
	
	public HistoricoStatusManutencaoCorretiva(){}
	
	public HistoricoStatusManutencaoCorretiva(Long idManutencaoCorretiva, Long idStatusManutencao, Long idSequencial, String matriculaUsuarioLogado) {
		this.id = new HistStatusManutencaoCorretivaId(idManutencaoCorretiva, idStatusManutencao, idSequencial);
		this.usuarioResponsavelPelaAlteracao = new PessoaView(matriculaUsuarioLogado);
		this.matriculaUsuario = matriculaUsuarioLogado;
	}
	
	public HistoricoStatusManutencaoCorretiva(Long idManutencaoCorretiva, Long idStatusManutencao, Long idSequencial, String matriculaUsuarioLogado, String descricaoStatus) {
		this.id = new HistStatusManutencaoCorretivaId(idManutencaoCorretiva, idStatusManutencao, idSequencial);
		this.usuarioResponsavelPelaAlteracao = new PessoaView(matriculaUsuarioLogado);
		this.matriculaUsuario = matriculaUsuarioLogado;
		this.descricaoStatus = descricaoStatus;
	}
	
	public HistoricoStatusManutencaoCorretiva(Long idManutencaoCorretiva, Long idStatusManutencao, Long idSequencial) {
		this.id = new HistStatusManutencaoCorretivaId(idManutencaoCorretiva, idStatusManutencao, idSequencial);
	}
	
	public HistStatusManutencaoCorretivaId getId() {
		return id;
	}

	public void setId(HistStatusManutencaoCorretivaId id) {
		this.id = id;
	}
	
	public ManutencaoCorretiva getManutencaoCorretiva() {
		return manutencaoCorretiva;
	}

	public void setManutencaoCorretiva(ManutencaoCorretiva manutencaoCorretiva) {
		this.manutencaoCorretiva = manutencaoCorretiva;
	}

	public StatusManutencaoCorretiva getStatusManutencaoCorretiva() {
		return statusManutencaoCorretiva;
	}

	public void setStatusManutencaoCorretiva(StatusManutencaoCorretiva statusManutencaoCorretiva) {
		this.statusManutencaoCorretiva = statusManutencaoCorretiva;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	
	public String getMatriculaUsuario() {
		return matriculaUsuario;
	}

	public void setMatriculaUsuario(String matriculaUsuario) {
		this.matriculaUsuario = matriculaUsuario;
	}
	
	public String getDescricaoStatus() {
		return descricaoStatus;
	}

	public void setDescricaoStatus(String descricaoStatus) {
		this.descricaoStatus = descricaoStatus;
	}
	
	public Long getProximoSequencial() {
		Long sequencial = this.id.getIdSequencial(); 
		return sequencial + 1;
	}

	public PessoaView getUsuarioResponsavelPelaAlteracao() {
		return usuarioResponsavelPelaAlteracao;
	}

	public void setUsuarioResponsavelPelaAlteracao(PessoaView usuarioResponsavelPelaAlteracao) {
		this.usuarioResponsavelPelaAlteracao = usuarioResponsavelPelaAlteracao;
	}

	public List<InformacaoCorretiva> getInformacoes() {
		return informacoes;
	}

	public void setInformacoes(List<InformacaoCorretiva> informacoes) {
		this.informacoes = informacoes;
	}

	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof HistoricoStatusManutencaoCorretiva)) {
			return false;
		}
		HistoricoStatusManutencaoCorretiva castOther = (HistoricoStatusManutencaoCorretiva) other;
		return Objects.equal(id, castOther.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}

}
