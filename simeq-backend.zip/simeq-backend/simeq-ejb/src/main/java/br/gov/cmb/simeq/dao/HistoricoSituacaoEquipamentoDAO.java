package br.gov.cmb.simeq.dao;

import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoDAO;
import br.gov.cmb.simeq.entidade.HistoricoSituacaoEquipamento;

public class HistoricoSituacaoEquipamentoDAO extends GenericoDAO<HistoricoSituacaoEquipamento, Long> {

	private static final long serialVersionUID = 1L;
			
	public List<HistoricoSituacaoEquipamento> buscarTodosPor(Long idEquipamento){
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("hse")
				.from(HistoricoSituacaoEquipamento.class, "hse")
				.where("hse.equipamento.idEquipamento = ?")
				.order("hse.dataInicio")
				.desc();
		return buscar(builder.builder(), idEquipamento);
	}
	
	public HistoricoSituacaoEquipamento buscarUltimoOuPenultimoRegistro(Boolean ultimo,Long idEquipamento) {
		StringBuilder stringBuilder = new StringBuilder("SELECT * "
													+ " FROM HISTORICO_SITUACAO_EQUIPAMENTO as se INNER JOIN VW_DN_CENTRO_CUSTO as C ON se.CD_CENTRO_CUSTO = C.CD_CENTRO_CUSTO,"
													+ "(SELECT row_number() OVER (ORDER BY ID_HISTORICO_SITUACAO_EQUIPAMENTO DESC) AS indice,"
													+ "ID_HISTORICO_SITUACAO_EQUIPAMENTO as indice_situacao FROM HISTORICO_SITUACAO_EQUIPAMENTO where ID_EQUIPAMENTO = :idEquipamento) as situacoes_tabela where "
													+ "situacoes_tabela.indice = :parametro and situacoes_tabela.indice_situacao = se.ID_HISTORICO_SITUACAO_EQUIPAMENTO");
		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString(),HistoricoSituacaoEquipamento.class);
		query.setParameter("parametro", (ultimo) ? 1 : 2);
		query.setParameter("idEquipamento", idEquipamento);
		try {			
			return  (HistoricoSituacaoEquipamento) query.getSingleResult();
		}catch (NoResultException e) {
			return null;
		}
	}
	
	public HistoricoSituacaoEquipamento buscarCentroCustoInstalacao(Long idEquipamento) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("hse")
				.from(HistoricoSituacaoEquipamento.class, "hse")
				.where("hse.idHistoricoSituacaoEquipamento = (SELECT MIN (h2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento h2 WHERE h2.equipamento.idEquipamento = ?) ");
		return buscarUmResultado(builder.builder(), HistoricoSituacaoEquipamento.class, idEquipamento);
	}
	
	public HistoricoSituacaoEquipamento buscarUltimoCentroCusto(Long idEquipamento) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("hse")
				.from(HistoricoSituacaoEquipamento.class, "hse")
				.where("hse.idHistoricoSituacaoEquipamento = (SELECT MAX (hse2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento hse2 WHERE hse2.equipamento.idEquipamento = ?) ");
		return buscarUmResultado(builder.builder(), HistoricoSituacaoEquipamento.class, idEquipamento);
	}
}
