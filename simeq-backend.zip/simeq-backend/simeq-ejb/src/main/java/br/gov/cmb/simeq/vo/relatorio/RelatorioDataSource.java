package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.List;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class RelatorioDataSource<T> implements JRDataSource, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -320392060631884067L;
	
	protected List<T> lista;
	private Integer contador;
	
	public RelatorioDataSource(List<T> lista) {
		this.lista = lista;
		contador = -1;
	}
	
	@Override
	public Object getFieldValue(JRField jrField) {
		try {
			Field field = lista.get(contador).getClass().getDeclaredField(jrField.getName());
			if(field != null) {
				field.setAccessible(true);
				return field.get(lista.get(contador));
			}
		} catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e1) {
			e1.printStackTrace();
		}
		return null;
	}
	
	@Override
	public boolean next() throws JRException {
		contador += 1;
		if(contador < lista.size()) {
			return true;
		}
		return false;
	}
	
	public boolean exists() {
		return !this.lista.isEmpty();
	}
}
