package br.gov.cmb.simeq.vo;

import java.util.List;

import javax.ws.rs.QueryParam;

public class RelatorioManutencaoPreventivaAnualFiltro {

	@QueryParam(value = "ano")
	private String ano;
	
	@QueryParam(value = "centrosCusto")
	private List<String> centrosCusto;

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public List<String> getCentrosCusto() {
		return centrosCusto;
	}

	public void setCentrosCusto(List<String> centrosCusto) {
		this.centrosCusto = centrosCusto;
	}

}
