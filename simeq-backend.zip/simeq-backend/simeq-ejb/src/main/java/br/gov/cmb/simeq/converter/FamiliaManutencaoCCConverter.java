package br.gov.cmb.simeq.converter;

import java.util.List;
import java.util.stream.Collectors;

import br.gov.cmb.simeq.dto.FamiliaCCDTO;
import br.gov.cmb.simeq.entidade.FamiliaManutencao;
import br.gov.cmb.simeq.entidade.FamiliaManutencaoCC;

public class FamiliaManutencaoCCConverter {

	public static FamiliaCCDTO converterFamiliaCCDTO(FamiliaManutencaoCC familiaManutencaoCC) {
		return new FamiliaCCDTO(familiaManutencaoCC.getId(), familiaManutencaoCC.getCodigoCC());

	}

	public static List<FamiliaCCDTO> converterFamiliasCCDTOList(List<FamiliaManutencaoCC> familiasManutencaoCCList) {
		return familiasManutencaoCCList.stream().map(CC -> {
			return FamiliaManutencaoCCConverter.converterFamiliaCCDTO(CC);

		}).collect(Collectors.toList());

	}
	
	public static FamiliaManutencaoCC converterDTOParaFamiliaCC(FamiliaCCDTO familiaCCDTO,
			FamiliaManutencao familiaManutencao) {
		if(familiaCCDTO.getId() != null) {
			return new FamiliaManutencaoCC(familiaCCDTO.getId(), familiaManutencao, familiaCCDTO.getCodigoCC());
		}
		return new FamiliaManutencaoCC(familiaManutencao, familiaCCDTO.getCodigoCC());
	}

	public static List<FamiliaManutencaoCC> converterDTOParaFamiliasCCList(List<FamiliaCCDTO> familiasCCDTO,
			FamiliaManutencao familiaManutencao) {
		return familiasCCDTO.stream().map(CC -> {
			return FamiliaManutencaoCCConverter.converterDTOParaFamiliaCC(CC, familiaManutencao);
			
		}).collect(Collectors.toList());
	}

}
