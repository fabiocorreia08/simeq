package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

public class SubRelatorioGestaoEstrategicaDiaVO implements Serializable {

	private static final long serialVersionUID = -7614762346782127901L;
	
	private String hora;
	private Integer quantidade;
	
	public SubRelatorioGestaoEstrategicaDiaVO() {
		super();
	}

	public SubRelatorioGestaoEstrategicaDiaVO(String hora, Integer quantidade) {
		super();
		this.hora = hora;
		this.quantidade = quantidade;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	
}
