package br.gov.cmb.simeq.vo;

import java.util.List;

import javax.ws.rs.QueryParam;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AtividadeFiltroTecnicoVO extends ModeloVO{

	private static final long serialVersionUID = 8304519976100888966L;
	
	@QueryParam("matricula")
	@ParametroNomeado
	private String matricula;
	
	@QueryParam("nome")
	@ParametroNomeado(like = true)
	private String nome;
	
	@QueryParam("numeroSolicitacao")
	@ParametroNomeado
	private String numeroSolicitacao;
	
	@QueryParam("idPerfil")
	private Integer idPerfil;
	
	@QueryParam("matriculaUsuarioLogado")
	private String matriculaUsuarioLogado;

	@ParametroNomeado
	private List<String> codigosCentroCustoHierarquia;
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Integer getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(Integer idPerfil) {
		this.idPerfil = idPerfil;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public List<String> getCodigosCentroCustoHierarquia() {
		return codigosCentroCustoHierarquia;
	}

	public void setCodigosCentroCustoHierarquia(List<String> codigosCentroCustoHierarquia) {
		this.codigosCentroCustoHierarquia = codigosCentroCustoHierarquia;
	}
	
	

}
