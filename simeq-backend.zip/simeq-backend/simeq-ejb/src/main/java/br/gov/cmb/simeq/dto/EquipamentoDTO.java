package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.cmb.simeq.enums.AtivoInativoEnum;
import br.gov.cmb.simeq.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown=true)
public class EquipamentoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idEquipamento;
	private String codigoManutencao;
	private AtivoInativoEnum flagStatus;
	private String nomeEquipamento;
	private String numeroPatrimonio;
	private Long numeroTensao;
	private Long numeroPotencia;
	private String nomeTipoPotencia;
	private Long numeroPeso;
	private Long numeroAno;
	private Date dataInstalacao;
	private SimNaoEnum flagPreventiva;
	private String descricaoPreRequisitoInformacao;
	private String descricaoObservacao;
	private String codigoCentroCusto;
	private String fabricante;
	private String modelo;

	public EquipamentoDTO() {
	}

	public EquipamentoDTO(Long idEquipamento, String codigoManutencao, String nomeEquipamento, String numeroPatrimonio,
			Long numeroTensao, Long numeroPotencia, String nomeTipoPotencia, Long numeroPeso, Long numeroAno,
			Date dataInstalacao, SimNaoEnum flagPreventiva, String descricaoPreRequisitoInformacao,
			String descricaoObservacao) {
		this.idEquipamento = idEquipamento;
		this.codigoManutencao = codigoManutencao;
		this.nomeEquipamento = nomeEquipamento;
		this.numeroPatrimonio = numeroPatrimonio;
		this.numeroTensao = numeroTensao;
		this.numeroPotencia = numeroPotencia;
		this.nomeTipoPotencia = nomeTipoPotencia;
		this.numeroPeso = numeroPeso;
		this.numeroAno = numeroAno;
		this.dataInstalacao = dataInstalacao;
		this.flagPreventiva = flagPreventiva;
		this.descricaoPreRequisitoInformacao = descricaoPreRequisitoInformacao;
		this.descricaoObservacao = descricaoObservacao;
	}

	public EquipamentoDTO(Long idEquipamento, String codigoManutencao, String nomeEquipamento, Long numeroAno,
			Date dataInstalacao, AtivoInativoEnum flagStatus, String codigoCentroCusto) {
		this.idEquipamento = idEquipamento;
		this.codigoManutencao = codigoManutencao;
		this.nomeEquipamento = nomeEquipamento;
		this.numeroAno = numeroAno;
		this.dataInstalacao = dataInstalacao;
		this.flagStatus = flagStatus;
		this.codigoCentroCusto = codigoCentroCusto;
	}
	
	public EquipamentoDTO(Long idEquipamento, String codigoManutencao, String nomeEquipamento, Long numeroAno,
			Date dataInstalacao) {
		this.idEquipamento = idEquipamento;
		this.codigoManutencao = codigoManutencao;
		this.nomeEquipamento = nomeEquipamento;
		this.numeroAno = numeroAno;
		this.dataInstalacao = dataInstalacao;
	}

	public EquipamentoDTO(Long idEquipamento, String codigoManutencao) {
		this.idEquipamento = idEquipamento;
		this.codigoManutencao = codigoManutencao;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoManutencao() {
		return codigoManutencao;
	}

	public void setCodigoManutencao(String codigoManutencao) {
		this.codigoManutencao = codigoManutencao;
	}

	public AtivoInativoEnum getFlagStatus() {
		return flagStatus;
	}

	public void setFlagStatus(AtivoInativoEnum flagStatus) {
		this.flagStatus = flagStatus;
	}

	public String getNomeEquipamento() {
		return nomeEquipamento;
	}

	public void setNomeEquipamento(String nomeEquipamento) {
		this.nomeEquipamento = nomeEquipamento;
	}

	public String getNumeroPatrimonio() {
		return numeroPatrimonio;
	}

	public void setNumeroPatrimonio(String numeroPatrimonio) {
		this.numeroPatrimonio = numeroPatrimonio;
	}

	public Long getNumeroTensao() {
		return numeroTensao;
	}

	public void setNumeroTensao(Long numeroTensao) {
		this.numeroTensao = numeroTensao;
	}

	public Long getNumeroPotencia() {
		return numeroPotencia;
	}

	public void setNumeroPotencia(Long numeroPotencia) {
		this.numeroPotencia = numeroPotencia;
	}

	public String getNomeTipoPotencia() {
		return nomeTipoPotencia;
	}

	public void setNomeTipoPotencia(String nomeTipoPotencia) {
		this.nomeTipoPotencia = nomeTipoPotencia;
	}

	public Long getNumeroPeso() {
		return numeroPeso;
	}

	public void setNumeroPeso(Long numeroPeso) {
		this.numeroPeso = numeroPeso;
	}

	public Long getNumeroAno() {
		return numeroAno;
	}

	public void setNumeroAno(Long numeroAno) {
		this.numeroAno = numeroAno;
	}

	public Date getDataInstalacao() {
		return dataInstalacao;
	}

	public void setDataInstalacao(Date dataInstalacao) {
		this.dataInstalacao = dataInstalacao;
	}

	public SimNaoEnum getFlagPreventiva() {
		return flagPreventiva;
	}

	public void setFlagPreventiva(SimNaoEnum flagPreventiva) {
		this.flagPreventiva = flagPreventiva;
	}

	public String getDescricaoPreRequisitoInformacao() {
		return descricaoPreRequisitoInformacao;
	}

	public void setDescricaoPreRequisitoInformacao(String descricaoPreRequisitoInformacao) {
		this.descricaoPreRequisitoInformacao = descricaoPreRequisitoInformacao;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public String getFabricante() {
		return fabricante;
	}

	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

}
