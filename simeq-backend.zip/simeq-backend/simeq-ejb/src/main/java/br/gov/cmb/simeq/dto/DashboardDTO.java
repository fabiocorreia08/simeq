package br.gov.cmb.simeq.dto;

import java.io.Serializable;

public class DashboardDTO  implements Serializable{

	private static final long serialVersionUID = 4646556706219203697L;
	
	private Integer idStatus;
	private String nomeStatus;
	private Integer total;

	public DashboardDTO() {
	}

	public DashboardDTO(Integer idStatus, String nomeStatus, Integer total) {
		super();
		this.idStatus = idStatus;
		this.nomeStatus = nomeStatus;
		this.total = total;
	}

	public Integer getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}

	public String getNomeStatus() {
		return nomeStatus;
	}

	public void setNomeStatus(String nomeStatus) {
		this.nomeStatus = nomeStatus;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}
	
}
