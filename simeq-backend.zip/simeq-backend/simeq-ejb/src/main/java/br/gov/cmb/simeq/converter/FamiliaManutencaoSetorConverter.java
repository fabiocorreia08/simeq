package br.gov.cmb.simeq.converter;

import java.util.List;
import java.util.stream.Collectors;

import br.gov.cmb.simeq.dto.FamiliaSetorDTO;
import br.gov.cmb.simeq.entidade.FamiliaManutencao;
import br.gov.cmb.simeq.entidade.FamiliaManutencaoSetor;

public class FamiliaManutencaoSetorConverter {

	public static FamiliaSetorDTO converterFamiliaSetorDTO(FamiliaManutencaoSetor familiaManutencaoSetor) {
		return new FamiliaSetorDTO(familiaManutencaoSetor.getId(), familiaManutencaoSetor.getSetorManutencao().getIdSetor());

	}

	public static List<FamiliaSetorDTO> converterFamiliasSetorDTOList(
			List<FamiliaManutencaoSetor> familiasManutencaoSetorList) {
		return familiasManutencaoSetorList.stream().map(setor -> {
			return new FamiliaSetorDTO(setor.getId(), setor.getSetorManutencao().getIdSetor());
		}).collect(Collectors.toList());

	}

	public static FamiliaManutencaoSetor converterDTOParaFamiliaSetor(FamiliaSetorDTO familiaSetorDTO,
			FamiliaManutencao familiaManutencao) {
		if(familiaSetorDTO.getId() != null) {
			return new FamiliaManutencaoSetor(familiaSetorDTO.getId() ,familiaManutencao, familiaSetorDTO.getIdSetor());
		}
		return new FamiliaManutencaoSetor(familiaManutencao, familiaSetorDTO.getIdSetor());
	}

	public static List<FamiliaManutencaoSetor> converterDTOParaFamiliasSetorList(List<FamiliaSetorDTO> familiasSetorDTO,
			FamiliaManutencao familiaManutencao) {
		return familiasSetorDTO.stream().map(setor -> {
			return FamiliaManutencaoSetorConverter.converterDTOParaFamiliaSetor(setor, familiaManutencao);

		}).collect(Collectors.toList());
	}
}