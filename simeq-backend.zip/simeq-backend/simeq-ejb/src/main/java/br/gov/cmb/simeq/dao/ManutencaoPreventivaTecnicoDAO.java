package br.gov.cmb.simeq.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarFiltroVO;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;
import br.gov.cmb.simeq.vo.AlocacaoDetalharVO;

public class ManutencaoPreventivaTecnicoDAO extends GenericoPaginadoDAO<ManutencaoPreventivaTecnico, Long> {

	private static final long serialVersionUID = 1L;
	
	public ManutencaoPreventivaTecnico buscarAlocacaoTecnico(Long idManutencao, Long idTecninco) {
    	IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("mp")
				.from(ManutencaoPreventivaTecnico.class, "mp")
				.where("mp.manutencaoPreventiva.id = ?")
				.and("mp.tecnico.id = ?");
		List<ManutencaoPreventivaTecnico> alocacoes = buscar(builder.builder(), ManutencaoPreventivaTecnico.class, idManutencao, idTecninco);
		
		if(!alocacoes.isEmpty()) {
			return alocacoes.get(0);
		}
		return null;
    }
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<TecnicoDTO> buscarPaginaPorTecnicoESolicitacaoComPermissao(Pagina pagina) {
	    	IJPQLBuilder builder = JPQLBuilder.getInstance()
	    			.select("new br.gov.cmb.simeq.dto.TecnicoDTO(t.idTecnico, t.codigoMatricula, it.nomeEmpregado, c.codigoCentroCusto, c.textoHierarquiaCentroCusto, it.nomeCargo, it.nomeFuncao, it.codigoSituacaoFolha, it.descricaoSituacaoFolha)")
	    			.from(ManutencaoPreventivaTecnico.class, "mct")
	    			.innerJoin("mct.manutencaoPreventiva", "mc")
	                .innerJoin("mct.tecnico", "t")
	                .innerJoin("t.informacoesTecnico", "it")
	                .innerJoin("it.centroCusto", "c")
	                .where(pagina.getModelVO(), "mc.numeroSolicitacao = [numeroSolicitacao]")
	                .and("c.codigoCentroCusto IN [codigosCentroCustoHierarquia]")
	                .and("it.codigoMatricula = [matricula]")
	                .and("it.nomeEmpregado LIKE [nome]");
	    	return (Pagina<TecnicoDTO>)buscar(pagina, builder.builder());
	}
	
	public ManutencaoPreventivaTecnico buscarPorTecnicoESolicitacaoComPermissao(String matriculaTecnico, String numeroSolicitacao, List<String> codigosCentroCustohierarquia) {
    	IJPQLBuilder builder = JPQLBuilder.getInstance()
    			.select("mct")
    			.from(ManutencaoPreventivaTecnico.class, "mct")
    			.innerJoin("mct.manutencaoPreventiva", "mc")
    			.innerJoin("mct.tecnico", "t")
                .innerJoin("t.informacoesTecnico", "it")
                .innerJoin("it.centroCusto", "c")
                .where("mc.numeroSolicitacao = ?1")
                .and("c.codigoCentroCusto IN (?2)")
                .and("it.codigoMatricula = ?3");
    	List<ManutencaoPreventivaTecnico> manutencao = buscar(builder.builder(), ManutencaoPreventivaTecnico.class, numeroSolicitacao, codigosCentroCustohierarquia, matriculaTecnico);
    	if(CollectionUtils.isNullOrEmpty(manutencao)) {
    		return null;
    	}
    	return manutencao.get(0);
    }
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<AlocacaoCadastrarVO> filtrarTecnicosParaCadastroHierarquia(Pagina pagina){
		
		List<AlocacaoCadastrarVO> listaAlocacoes = (List<AlocacaoCadastrarVO>)
				this.preencherParametros(this.getEntityManager()
				.createNamedQuery("alocacaoPreventiva", AlocacaoCadastrarVO.class), pagina)
				.getResultList();
		
		pagina.setRegistros(listaAlocacoes);
		pagina.setTotalDeRegistros(pagina.getTotalDeRegistros());

		return pagina;
	}
	
	@SuppressWarnings("rawtypes")
	private TypedQuery preencherParametros(TypedQuery typedQuery, Pagina pagina) {
		typedQuery.setParameter("centroCustosHierarquia", ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getCentroCustosHierarquia());
		typedQuery.setParameter("numeroSolicitacao", ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getNumeroSolicitacao());
		typedQuery.setParameter("nomeCargo", ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getNomeCargo());
		typedQuery.setParameter("idTecnico",((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getIdTecnico());
		typedQuery.setParameter("nomeFuncao", ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getNomeFuncao());
		typedQuery.setParameter("codigoTurno", ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getCodigoTurno());
		typedQuery.setFirstResult(pagina.getPrimeiroRegistro()).setMaxResults(pagina.getTamanho());
		return typedQuery;
	}
	
    public ManutencaoPreventivaTecnico buscarPorTecnicoAlocado(String matriculaTecnico, String numeroSolicitacao) {
    	IJPQLBuilder builder = JPQLBuilder.getInstance()
    			.select("mct")
    			.from(ManutencaoPreventivaTecnico.class, "mct")
    			.innerJoin("mct.manutencaoPreventiva", "mc")
    			.innerJoin("mct.tecnico", "t")
    			.innerJoin("t.informacoesTecnico", "it")
                .innerJoin("it.centroCusto", "c")
                .where("mc.numeroSolicitacao = ?1")
                .and("it.codigoMatricula = ?2");
    	List<ManutencaoPreventivaTecnico> manutencao = buscar(builder.builder(), ManutencaoPreventivaTecnico.class, numeroSolicitacao, matriculaTecnico);
    	if(CollectionUtils.isNullOrEmpty(manutencao)) {
    		return null;
    	}
    	return manutencao.get(0);
    }

	public List<AlocacaoCadastrarVO> buscarTecnicosAlocados(String numeroSolicitacao) {
    	IJPQLBuilder builder = JPQLBuilder.getInstance()
                .select("DISTINCT new br.gov.cmb.simeq.vo.AlocacaoCadastrarVO(t.codigoMatricula, it.nomeEmpregado, it.nomeCargo, it.nomeFuncao, mt.dataAlocacao, mt.matriculaResponsavel.matricula, "
                		+ "m.id, t.idTecnico, it.codigoSituacaoFolha, tv.nome)")
                .from(ManutencaoPreventivaTecnico.class, "mt")
                .innerJoin("mt.tecnico", "t")
                .innerJoin("t.tecnico", "pessoaView")
                .innerJoin("pessoaView.turnoView", "tv")
                .innerJoin("mt.manutencaoPreventiva", "m")
                .innerJoin("t.informacoesTecnico", "it")
                .where("m.numeroSolicitacao = ?");
        return buscar(builder.builder(), AlocacaoCadastrarVO.class, numeroSolicitacao);
    }
	
	public ManutencaoPreventivaTecnico buscarPorId(Long idTecnico, Long idManutencao) {
    	IJPQLBuilder builder = JPQLBuilder.getInstance()
    			.select("mpt")
    			.from(ManutencaoPreventivaTecnico.class, "mpt")
    			.innerJoin("mpt.manutencaoPreventiva", "mp")
                .innerJoin("mp.centroCusto", "c")
                .innerJoin("mpt.tecnico", "t")
                .innerJoin("t.informacoesTecnico", "it")
                .where("mpt.id.idTecnico = ?1")
                .and("mpt.id.idManutencaoPreventiva = ?2");
    	List<ManutencaoPreventivaTecnico> manutencao = buscar(builder.builder(), ManutencaoPreventivaTecnico.class, idTecnico, idManutencao);
    	if(CollectionUtils.isNullOrEmpty(manutencao)) {
    		return null;
    	}
    	return manutencao.get(0);
    }
	
	 @SuppressWarnings({ "unchecked", "rawtypes" })
		public Pagina<AlocacaoDetalharVO> buscarAlocacaoManutencao(Pagina pagina) {
			IJPQLBuilder builder = JPQLBuilder.getInstance()
					.select("distinct new br.gov.cmb.simeq.vo.AlocacaoDetalharVO(t.codigoMatricula, ct.nomeEmpregado, ct.nomeCargo, mt.dataAlocacao, p.nome, turno.nome)")
					.from(ManutencaoPreventivaTecnico.class, "mt")
					.innerJoin("mt.manutencaoPreventiva", "m")
					.innerJoin("mt.tecnico", "t")
					.innerJoin("t.informacoesTecnico", "ct")
					.innerJoin("mt.matriculaResponsavel", "p")
					.innerJoin("p.turnoView", "turno")
					.where(pagina.getModelVO(), "m.id = [idManutencao]");
			return (Pagina<AlocacaoDetalharVO>)buscar(pagina, builder.builder(), "distinct t.codigoMatricula");
		}

}
