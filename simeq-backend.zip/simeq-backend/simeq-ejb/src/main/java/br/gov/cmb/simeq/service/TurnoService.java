package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.simeq.dao.TurnoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;

@Stateless
public class TurnoService {
	
	@Inject
	private TurnoDAO turnoDAO;
	
	public List<LabelValueDTO> buscarTodos() {
		return turnoDAO.buscarTodos();
	}

}
