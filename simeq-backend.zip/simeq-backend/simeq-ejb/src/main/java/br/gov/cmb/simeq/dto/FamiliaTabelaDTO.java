package br.gov.cmb.simeq.dto;


public class FamiliaTabelaDTO {

	private Long id;
	private String nomeFamilia;
	private String centrosCusto;
	private String setoresManutencao;
	
	public FamiliaTabelaDTO(Long id, String nomeFamilia, String centroCusto,
			String setorManutencao) {
		
		this.id = id;
		this.nomeFamilia = nomeFamilia;
		this.centrosCusto = centroCusto;
		this.setoresManutencao = setorManutencao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeFamilia() {
		return nomeFamilia;
	}

	public void setNomeFamilia(String nomeFamilia) {
		this.nomeFamilia = nomeFamilia;
	}

	public String getCentroCusto() {
		return centrosCusto;
	}

	public void setCentroCusto(String centrosCusto) {
		this.centrosCusto = centrosCusto;
	}

	public String getSetoresManutencao() {
		return setoresManutencao;
	}

	public void setSetorManutencao(String setoresManutencao) {
		this.setoresManutencao = setoresManutencao;
	}

}
