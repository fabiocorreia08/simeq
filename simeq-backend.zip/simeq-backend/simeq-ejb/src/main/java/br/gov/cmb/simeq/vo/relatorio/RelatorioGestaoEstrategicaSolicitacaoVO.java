package br.gov.cmb.simeq.vo.relatorio;

import java.util.List;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorioSolicitacao")
public class RelatorioGestaoEstrategicaSolicitacaoVO extends RelatorioDataSource<SubRelatorioGestaoEstrategicaSolicitacaoVO>{
	
	private static final long serialVersionUID = -912894546022433975L;
	
	public RelatorioGestaoEstrategicaSolicitacaoVO(List<SubRelatorioGestaoEstrategicaSolicitacaoVO> lista) {
		super(lista);
		// TODO Auto-generated constructor stub
	}

}
