package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.google.common.base.Strings;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.converter.TecnicoConverter;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaTecnicoDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaTecnicoDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.entidade.CorpoTecnicoView;
import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.validador.TecnicoValidador;
import br.gov.cmb.simeq.vo.AtividadeFiltroTecnicoVO;

@Stateless
public class TecnicoService {

	@Inject
	private TecnicoDAO tecnicoDAO;
	
	@Inject
	private TecnicoValidador tecnicoValidador;
	
	@Inject
	private ManutencaoCorretivaTecnicoDAO manutencaoCorretivaTecnicoDAO;
	
	@Inject
	private ManutencaoPreventivaTecnicoDAO manutencaoPreventivaTecnicoDAO;
	
	@Inject
	private CentroCustoService centroCustoService;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	public TecnicoDTO buscarPor(Long idTecnico) {
		Tecnico tecnico = tecnicoDAO.buscar(idTecnico);
		CorpoTecnicoView inFormacoesTecnico = this.tecnicoDAO.buscarInformacoesTecnicoPor(tecnico.getCodigoMatricula());
		return TecnicoConverter.converter(tecnico, inFormacoesTecnico);
	}

	public TecnicoDTO buscarPor(String matricula, boolean isValidarMatriculaCadastrada) {
		if (isValidarMatriculaCadastrada) {			
			tecnicoValidador.validarMatriculaCadastradaPreviamente(matricula);
		}
		TecnicoDTO tecnico = TecnicoConverter.converter(tecnicoValidador.validarMatriculaInexistenteErp(matricula));
		tecnico.setSalario(pessoaViewDAO.buscarPorMatricula(tecnico.getMatricula()).getSalario());
		return tecnico;
	}
	
	public Pagina<TecnicoDTO> buscarPorMatriculaAlocado(Pagina<TecnicoDTO> pagina) {
		AtividadeFiltroTecnicoVO filtro = (AtividadeFiltroTecnicoVO)pagina.getModelVO();
		filtro.setCodigosCentroCustoHierarquia(centroCustoService.getCentroCustoUsuarioLogado(filtro.getIdPerfil(), filtro.getMatriculaUsuarioLogado()));
		if(!Strings.isNullOrEmpty(filtro.getMatricula())) {
			ManutencaoCorretivaTecnico manutencaoCorretivaTecnico = manutencaoCorretivaTecnicoDAO
					.buscarPorTecnicoESolicitacaoComPermissao(filtro.getMatricula(), filtro.getNumeroSolicitacao(),
							filtro.getCodigosCentroCustoHierarquia());
			tecnicoValidador.validarPermissaoTecnicoManutencao(manutencaoCorretivaTecnico, filtro.getMatricula(), filtro.getNumeroSolicitacao());
		}
		Pagina<TecnicoDTO> paginaTecnico = manutencaoCorretivaTecnicoDAO.buscarPaginaPorTecnicoESolicitacaoComPermissao(pagina);
		paginaTecnico.getRegistros().stream().forEach(t -> t.setSalario(pessoaViewDAO.buscarPorMatricula(t.getMatricula()).getSalario()));
		return paginaTecnico;
	}
	
	public Pagina<TecnicoDTO> buscarPorMatriculaAlocadoPreventiva(Pagina<TecnicoDTO> pagina) {
		AtividadeFiltroTecnicoVO filtro = (AtividadeFiltroTecnicoVO)pagina.getModelVO();
		filtro.setCodigosCentroCustoHierarquia(centroCustoService.getCentroCustoUsuarioLogado(filtro.getIdPerfil(), filtro.getMatriculaUsuarioLogado()));
		if(!Strings.isNullOrEmpty(filtro.getMatricula())) {
			ManutencaoPreventivaTecnico manutencaoPreventivaTecnico = manutencaoPreventivaTecnicoDAO
					.buscarPorTecnicoESolicitacaoComPermissao(filtro.getMatricula(), filtro.getNumeroSolicitacao(),
							filtro.getCodigosCentroCustoHierarquia());
			tecnicoValidador.validarPermissaoTecnicoManutencao(manutencaoPreventivaTecnico, filtro.getMatricula(), filtro.getNumeroSolicitacao());
		}
		Pagina<TecnicoDTO> paginaTecnico = manutencaoPreventivaTecnicoDAO.buscarPaginaPorTecnicoESolicitacaoComPermissao(pagina);
		paginaTecnico.getRegistros().stream().forEach(t -> t.setSalario(pessoaViewDAO.buscarPorMatricula(t.getMatricula()).getSalario()));
		return paginaTecnico;
	}

	public TecnicoDTO salvar(TecnicoDTO tecnicoDTO) {
		Tecnico tecnico = TecnicoConverter.converter(tecnicoDTO);
		return TecnicoConverter.converter(tecnicoDAO.salvar(tecnico));
	}
	
	public Pagina<TecnicoDTO> filtrar(Pagina<TecnicoDTO> pagina) {
		return this.tecnicoDAO.buscarPaginaPor(pagina);
	}
	
	public List<LabelValueDTO> buscarTodosTecnico() {
		return tecnicoDAO.buscarTodosTecnico();
	}
	
	public List<LabelValueDTO> buscarTodosCargos() {
		return tecnicoDAO.buscarTodosCargos();
	}
	
	public List<LabelValueDTO> buscarTodasFuncoes() {
		return tecnicoDAO.buscarTodasFuncoes();
	}

}
