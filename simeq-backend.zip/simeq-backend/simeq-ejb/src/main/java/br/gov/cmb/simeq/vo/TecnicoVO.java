package br.gov.cmb.simeq.vo;

import javax.inject.Named;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

@Named
public class TecnicoVO extends ModeloVO {

	private static final long serialVersionUID = 1L;

	@ParametroNomeado
	private String matricula;

	@ParametroNomeado(like = true)
	private String nome;

	@ParametroNomeado(like = true)
	private String cargo;

	@ParametroNomeado(like = true)
	private String funcao;

	@ParametroNomeado
	private String hierarquiaCentroCusto;

	@ParametroNomeado
	private String realocado;

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

	public String getRealocado() {
		return realocado;
	}

	public void setRealocado(String realocado) {
		this.realocado = realocado;
	}

}
