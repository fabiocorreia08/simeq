package br.gov.cmb.simeq.converter;

import java.util.List;
import java.util.stream.Collectors;

import br.gov.cmb.simeq.dto.FamiliaDTO;
import br.gov.cmb.simeq.entidade.FamiliaManutencao;

public class FamiliaConverter {

	public static FamiliaManutencao converteDTOParaFamiliaSalvar(FamiliaDTO familiaDTO) {
		FamiliaManutencao familiaManutencao = new FamiliaManutencao();
		familiaManutencao.setNomeFamilia(familiaDTO.getNomeFamilia());
		familiaManutencao.setFamiliasManutencaoCC(
				FamiliaManutencaoCCConverter.converterDTOParaFamiliasCCList(
						familiaDTO.getccList(), familiaManutencao
						)
				);
		familiaManutencao.setFamiliasManutencaoSetor(
				FamiliaManutencaoSetorConverter.converterDTOParaFamiliasSetorList(
						familiaDTO.getSetorList(), familiaManutencao
						)
				);
		
		return familiaManutencao;
	}

	public static FamiliaManutencao converteDTOParaFamiliaEditar(FamiliaDTO familiaDTO) {
		FamiliaManutencao familiaManutencao = new FamiliaManutencao();
		
		familiaManutencao.setId(familiaDTO.getId());
		familiaManutencao.setNomeFamilia(familiaDTO.getNomeFamilia());
		familiaManutencao.setFamiliasManutencaoCCEdit(
				FamiliaManutencaoCCConverter
				.converterDTOParaFamiliasCCList(familiaDTO.getccList(), familiaManutencao));
		familiaManutencao.setFamiliasManutencaoSetorEdit(
				FamiliaManutencaoSetorConverter
				.converterDTOParaFamiliasSetorList(familiaDTO.getSetorList(), familiaManutencao));

		return familiaManutencao;
	}

	public static FamiliaDTO converterFamiliaParaDTO(FamiliaManutencao familiaManutencao) {
		return new FamiliaDTO(familiaManutencao.getId(), familiaManutencao.getNomeFamilia(),
				FamiliaManutencaoCCConverter.converterFamiliasCCDTOList(familiaManutencao.getFamiliasManutencaoCC()),
				FamiliaManutencaoSetorConverter.converterFamiliasSetorDTOList(familiaManutencao.getFamiliasManutencaoSetor()));
	}

	public static List<FamiliaDTO> converterFamiliasParaDTOList(List<FamiliaManutencao> familiasManutencao) {
		List<FamiliaDTO> familiasDTO = familiasManutencao.stream().map(familia -> {
			return new FamiliaDTO(familia.getId(), familia.getNomeFamilia(),
					FamiliaManutencaoCCConverter.converterFamiliasCCDTOList(familia.getFamiliasManutencaoCC()),
					FamiliaManutencaoSetorConverter.converterFamiliasSetorDTOList(familia.getFamiliasManutencaoSetor()));
		}).collect(Collectors.toList());

		return familiasDTO;
	}

}
