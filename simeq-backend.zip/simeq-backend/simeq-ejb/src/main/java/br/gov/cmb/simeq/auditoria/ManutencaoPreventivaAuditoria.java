package br.gov.cmb.simeq.auditoria;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;

@Entity
@Table(name = "MANUTENCAO_PREVENTIVA_AUD")
public class ManutencaoPreventivaAuditoria implements Serializable {

	private static final long serialVersionUID = 5016871301722097548L;
	
	@EmbeddedId
	private AuditoriaId auditoriaId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_MANUTENCAO_PREVENTIVA", referencedColumnName = "ID_MANUTENCAO_PREVENTIVA", insertable = false, updatable = false)
	private ManutencaoPreventiva manutencaoPreventiva;
	
	@Column(name = "ID_EQUIPAMENTO")
	private Long idEquipamento;
	
	@Column(name = "CD_CENTRO_CUSTO")
	private String centroCusto;
	
	@Column(name = "NR_SOLICITACAO")
	private String numeroSolicitacao;
	
	@Column(name = "NR_ANO")
	private Integer ano;
	
	@Column(name = "NR_MES")
	private Integer mes;
	
	@Column(name = "NR_DIA_INICIO")
	private Integer diaInicio;
	
	@Column(name = "NR_DIA_FIM")
	private Integer diaFim;
	
	@Column(name = "QT_HORAS")
	private String qtdHoras;
	
	@Column(name = "DT_SOLICITACAO", updatable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "CD_MATRIC_SOLICITANTE")
	private String matriculaSolicitante;
	
	@Column(name = "TP_OPERACAO")
	private Short tipoOperacao;

	public AuditoriaId getAuditoriaId() {
		return auditoriaId;
	}

	public void setAuditoriaId(AuditoriaId auditoriaId) {
		this.auditoriaId = auditoriaId;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public Integer getDiaInicio() {
		return diaInicio;
	}

	public void setDiaInicio(Integer diaInicio) {
		this.diaInicio = diaInicio;
	}

	public Integer getDiaFim() {
		return diaFim;
	}

	public void setDiaFim(Integer diaFim) {
		this.diaFim = diaFim;
	}

	public String getQtdHoras() {
		return qtdHoras;
	}

	public void setQtdHoras(String qtdHoras) {
		this.qtdHoras = qtdHoras;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getMatriculaSolicitante() {
		return matriculaSolicitante;
	}

	public void setMatriculaSolicitante(String matriculaSolicitante) {
		this.matriculaSolicitante = matriculaSolicitante;
	}

	public Short getTipoOperacao() {
		return tipoOperacao;
	}

	public void setTipoOperacao(Short tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

	public ManutencaoPreventiva getManutencaoPreventiva() {
		return manutencaoPreventiva;
	}

	public void setManutencaoPreventiva(ManutencaoPreventiva manutencaoPreventiva) {
		this.manutencaoPreventiva = manutencaoPreventiva;
	}
}
