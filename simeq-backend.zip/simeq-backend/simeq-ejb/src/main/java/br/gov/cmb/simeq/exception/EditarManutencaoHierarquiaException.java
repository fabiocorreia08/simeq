package br.gov.cmb.simeq.exception;

public class EditarManutencaoHierarquiaException extends RuntimeException {

	private static final long serialVersionUID = -7171749907989061702L;

	public EditarManutencaoHierarquiaException() {
		super();
	}	
	
}
