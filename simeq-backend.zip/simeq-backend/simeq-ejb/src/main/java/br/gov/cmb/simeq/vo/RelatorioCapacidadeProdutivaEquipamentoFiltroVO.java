package br.gov.cmb.simeq.vo;

import java.util.Date;
import java.util.List;

import javax.ws.rs.QueryParam;

public class RelatorioCapacidadeProdutivaEquipamentoFiltroVO {
	
	@QueryParam(value = "dataInicial")
	private Date dataInicial;
	
	@QueryParam(value = "dataFinal")
	private Date dataFinal;

	@QueryParam(value = "centrosCusto")
	private List<String> centrosCusto;
	
	@QueryParam(value = "soPreventivas")
	private boolean soPreventivas;
	

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}

	public List<String> getCentrosCusto() {
		return centrosCusto;
	}

	public void setCentrosCusto(List<String> centrosCusto) {
		this.centrosCusto = centrosCusto;
	}

	public boolean getSoPreventivas() {
		return soPreventivas;
	}

	public void setSoPreventivas(boolean soPreventivas) {
		this.soPreventivas = soPreventivas;
	}


}
