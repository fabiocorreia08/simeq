package br.gov.cmb.simeq.utils;

import java.util.Objects;

import org.apache.commons.lang.StringUtils;

public class StringUtil {

	public static String trim(String valor) {
		return StringUtils.isNotBlank(valor) ? valor.trim() : valor;
	}

	public static String getParametroComLike(Object parametro) {
		return Objects.nonNull(parametro) ? "%"+parametro.toString()+"%" : null;
	}
	
	public static String getParametroComLikeADireita(Object parametro) {
		return Objects.nonNull(parametro) ? parametro.toString()+"%" : null;
	}
	
	public static String getParametroComLikeAEsquerda(Object parametro) {
		return Objects.nonNull(parametro) ? "%"+parametro.toString() : null;
	}
	
	public static String empty() {
		return "";
	}
	
}
