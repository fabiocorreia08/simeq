package br.gov.cmb.simeq.converter;

import java.util.Objects;
import java.util.ArrayList;
import java.util.List;

import br.gov.cmb.simeq.dto.RealocacaoTecnicoDTO;
import br.gov.cmb.simeq.entidade.RealocacaoTecnico;

public class RealocacaoTecnicoConverter {
	
	public static List<RealocacaoTecnicoDTO> converter(List<RealocacaoTecnico> realocacoesTecnico) {
		List<RealocacaoTecnicoDTO> realocacoesTecnicoDTO = new ArrayList<>();
		for (RealocacaoTecnico realocacaoTecnico : realocacoesTecnico) {
			RealocacaoTecnicoDTO realocacaoDTO = converter(realocacaoTecnico);
			realocacaoDTO.setHierarquiaCentroCusto(realocacaoTecnico.getCentroCusto().getTextoHierarquiaCentroCusto()  + " - " + realocacaoTecnico.getCodigoCentroCusto());
			realocacoesTecnicoDTO.add(realocacaoDTO);
		}
		return realocacoesTecnicoDTO;
	}
	
	public static RealocacaoTecnicoDTO converter(RealocacaoTecnico realocacaoTecnico) {
		return new RealocacaoTecnicoDTO(realocacaoTecnico.getIdRealocacaoTecnico(), 
										realocacaoTecnico.getTecnico().getIdTecnico(),
									    realocacaoTecnico.getFlagTipoRealocacao(), 
									    realocacaoTecnico.getCodigoCentroCusto(),
									    realocacaoTecnico.getDataPeriodoDe(), 
									    realocacaoTecnico.getDataPeriodoAte(), 
									    realocacaoTecnico.getDescricaoMotivo());
	}
	
	public static RealocacaoTecnico converter(RealocacaoTecnicoDTO realocacaoTecnicoDTO) {
		return new RealocacaoTecnico(Objects.nonNull(realocacaoTecnicoDTO.getId()) ? realocacaoTecnicoDTO.getId() : null,
									 realocacaoTecnicoDTO.getTecnico(),
									 realocacaoTecnicoDTO.getTipoRealocacao(),
									 realocacaoTecnicoDTO.getCentroCusto(),
									 realocacaoTecnicoDTO.getPeriodoInicio(),
									 realocacaoTecnicoDTO.getPeriodoFim(),
									 realocacaoTecnicoDTO.getMotivo());
		
	}
	


}

