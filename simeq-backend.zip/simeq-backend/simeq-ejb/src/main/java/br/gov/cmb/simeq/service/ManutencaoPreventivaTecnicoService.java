package br.gov.cmb.simeq.service;

import java.util.List;

import javax.inject.Inject;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaTecnicoDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.validador.ManutencaoPreventivaValidador;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarFiltroVO;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;
import br.gov.cmb.simeq.vo.AlocacaoDetalharVO;

public class ManutencaoPreventivaTecnicoService {
	
	@Inject
	private ManutencaoPreventivaTecnicoDAO manutencaoPreventivaTecnicoDAO;
	
	@Inject
	private ManutencaoPreventivaDAO manutencaoPreventivaDAO;
	
	@Inject
	private ManutencaoPreventivaValidador manutencaoPreventivaValidador;
	
	@Inject
	private TecnicoDAO tecnicoDAO;
	
	@Inject
	private CentroCustoService centroCustoService;
	
	public List<AlocacaoCadastrarVO> buscarTecnicosAlocados(String numeroSolicitacao, Integer idPerfil, String matricula) {
		List<String> codigosCentroCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(idPerfil, matricula);
		ManutencaoPreventiva manutencao = manutencaoPreventivaDAO.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao, codigosCentroCustoHierarquia);
		manutencaoPreventivaValidador.validarManutencaoPreventivaPermissao(manutencao, numeroSolicitacao);
		return manutencaoPreventivaTecnicoDAO.buscarTecnicosAlocados(numeroSolicitacao);
	}
	
	public Pagina<AlocacaoDetalharVO> buscarAlocacaoManutencao(Pagina<AlocacaoDetalharVO> pagina) {
		return manutencaoPreventivaTecnicoDAO.buscarAlocacaoManutencao(pagina);
	}

	public Pagina<AlocacaoCadastrarVO> filtrarTecnicosParaCadastro(Pagina<AlocacaoCadastrarVO> pagina) {
		String matricula = ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getMatricula();
		Integer perfil = ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getPerfil();
		if(PerfilEnum.TECNICO.getIdPerfil().equals(perfil)) {
			pagina.setTamanho(1);
			pagina.setTotalDeRegistros(1);
			AlocacaoCadastrarVO alocacaoCadastrarVO = tecnicoDAO.buscarPerfilTecnico(matricula);
			pagina.setRegistros(Lists.newArrayList(alocacaoCadastrarVO));
			return pagina;
		}
		List<String> codigosCentroCusto = centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).setCentroCustosHierarquia(codigosCentroCusto);
		return manutencaoPreventivaTecnicoDAO.filtrarTecnicosParaCadastroHierarquia(pagina);
	}
	
	

}
