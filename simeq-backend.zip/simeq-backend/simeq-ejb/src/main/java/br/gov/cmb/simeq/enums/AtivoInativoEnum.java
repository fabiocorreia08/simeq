package br.gov.cmb.simeq.enums;

public enum AtivoInativoEnum {

	A("A"), 
	I("I");

	private String codigo;

	private AtivoInativoEnum(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public static AtivoInativoEnum getAtivoInativoEnumPor(String chave) {
		if (AtivoInativoEnum.A.codigo.equals(chave)) {
			return AtivoInativoEnum.A;
		} else if (AtivoInativoEnum.I.codigo.equals(chave)) {
			return AtivoInativoEnum.I;
		} else {
			return null;
		}
	}

}
