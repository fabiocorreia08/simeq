package br.gov.cmb.simeq.converter;

import java.util.Objects;

import br.gov.cmb.simeq.dto.EquipamentoDTO;
import br.gov.cmb.simeq.entidade.Equipamento;

public class EquipamentoConverter {

	public static EquipamentoDTO converter(Equipamento equipamento) {
		return new EquipamentoDTO(equipamento.getIdEquipamento(), 
				equipamento.getCodigoManutencao(), 
				equipamento.getNomeEquipamento(),
				equipamento.getNumeroPatrimonio(), 
				equipamento.getNumeroTensao(), 
				equipamento.getNumeroPotencia(), 
				equipamento.getNomeTipoPotencia(), 
				equipamento.getNumeroPeso(),
				equipamento.getNumeroAno(), 
				equipamento.getDataInstalacao(), 
				equipamento.getFlagPreventiva(),
				equipamento.getDescricaoPreRequisitoInformacao(), 
				equipamento.getDescricaoObservacao());
	}
	
	public static Equipamento converter(EquipamentoDTO equipamentoDTO) {
		return new Equipamento(Objects.nonNull(equipamentoDTO.getIdEquipamento()) ? equipamentoDTO.getIdEquipamento() : null, 
				equipamentoDTO.getCodigoManutencao(), 
				equipamentoDTO.getNomeEquipamento(),
				equipamentoDTO.getNumeroPatrimonio(), 
				equipamentoDTO.getNumeroTensao(), 
				equipamentoDTO.getNumeroPotencia(), 
				equipamentoDTO.getNomeTipoPotencia(), 
				equipamentoDTO.getNumeroPeso(),
				equipamentoDTO.getNumeroAno(), 
				equipamentoDTO.getDataInstalacao(), 
				equipamentoDTO.getFlagPreventiva(),
				equipamentoDTO.getDescricaoPreRequisitoInformacao(), 
				equipamentoDTO.getDescricaoObservacao());
	}

}