package br.gov.cmb.simeq.vo;

import java.io.Serializable;

import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.enums.MesEnum;

public class PreventivaCadastroVO implements Serializable {

	private static final long serialVersionUID = 5031688552461870916L;
	
	private Long id;
	private Long idEquipamento;
	private String codigoCentroCusto;
	private String numeroSolicitacao;
	private Integer ano;
	private Integer mes;
	private String mesAno;
	private Integer diaInicio;
	private Integer diaFim;
	private String qtdHoras;
	private String matriculaSolicitante;
	private String nomeSolicitante;
	private String matriculaUsuarioLogado;
	private LabelValueDTO classeManutencao;
	private Long idStatus;
	private Integer anoAntigo;
	private Integer mesAntigo;
	private Integer diaInicioAntigo;
	private Integer diaFimAntigo;
	private Long idStatusAntigo;
	private String hierarquiaCentroCusto;
	private Long idSetor;
	private String nomeSetor;
	private String qtdHorasExecutadas;
	
	public PreventivaCadastroVO() {}
	
	public PreventivaCadastroVO(Long id, Long idEquipamento, String codigoCentroCusto, String hierarquiaCentroCusto, String numeroSolicitacao, Integer mes, Integer ano, Integer diaInicio, Integer diaFim, 
			String qtdHoras, String matriculaSolicitante, Long idStatus, Long idSetor, String nomeSetor, String qtdHorasExecutadas) {
		this.id = id;
		this.idEquipamento = idEquipamento;
		this.codigoCentroCusto = codigoCentroCusto;
		this.numeroSolicitacao = numeroSolicitacao;
		this.mes = mes;
		this.ano = ano;
		this.diaInicio = diaInicio;
		this.diaFim = diaFim;
		this.qtdHoras = qtdHoras;
		this.mesAno = MesEnum.getDescricaoMesPorCodigo(mes).concat("/").concat(ano.toString());
		this.matriculaSolicitante = matriculaSolicitante;
		this.idStatus = idStatus;
		this.anoAntigo = ano;
		this.mesAntigo = mes;
		this.diaInicioAntigo = diaInicio;
		this.diaFimAntigo = diaFim;
		this.idStatusAntigo = idStatus;
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
		this.idSetor = idSetor;
		this.nomeSetor = nomeSetor;
		this.qtdHorasExecutadas = qtdHorasExecutadas;
	}

	public String getQtdHorasExecutadas() {
		return qtdHorasExecutadas;
	}

	public void setQtdHorasExecutadas(String qtdHorasExecutadas) {
		this.qtdHorasExecutadas = qtdHorasExecutadas;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMesAno() {
		return mesAno;
	}

	public void setMesAno(String mesAno) {
		this.mesAno = mesAno;
	}

	public Integer getDiaInicio() {
		return diaInicio;
	}

	public void setDiaInicio(Integer diaInicio) {
		this.diaInicio = diaInicio;
	}

	public Integer getDiaFim() {
		return diaFim;
	}

	public void setDiaFim(Integer diaFim) {
		this.diaFim = diaFim;
	}

	public String getQtdHoras() {
		return qtdHoras;
	}

	public void setQtdHoras(String qtdHoras) {
		this.qtdHoras = qtdHoras;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public String getMatriculaSolicitante() {
		return matriculaSolicitante;
	}

	public void setMatriculaSolicitante(String matriculaSolicitante) {
		this.matriculaSolicitante = matriculaSolicitante;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public Integer getAnoAntigo() {
		return anoAntigo;
	}

	public void setAnoAntigo(Integer anoAntigo) {
		this.anoAntigo = anoAntigo;
	}

	public Integer getMesAntigo() {
		return mesAntigo;
	}

	public void setMesAntigo(Integer mesAntigo) {
		this.mesAntigo = mesAntigo;
	}

	public Integer getDiaInicioAntigo() {
		return diaInicioAntigo;
	}

	public void setDiaInicioAntigo(Integer diaInicioAntigo) {
		this.diaInicioAntigo = diaInicioAntigo;
	}

	public Integer getDiaFimAntigo() {
		return diaFimAntigo;
	}

	public void setDiaFimAntigo(Integer diaFimAntigo) {
		this.diaFimAntigo = diaFimAntigo;
	}

	public Long getIdStatusAntigo() {
		return idStatusAntigo;
	}

	public void setIdStatusAntigo(Long idStatusAntigo) {
		this.idStatusAntigo = idStatusAntigo;
	}

	public LabelValueDTO getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(LabelValueDTO classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public String getNomeSolicitante() {
		return nomeSolicitante;
	}

	public void setNomeSolicitante(String nomeSolicitante) {
		this.nomeSolicitante = nomeSolicitante;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

	public Long getIdSetor() {
		return idSetor;
	}

	public void setIdSetor(Long idSetor) {
		this.idSetor = idSetor;
	}

	public String getNomeSetor() {
		return nomeSetor;
	}

	public void setNomeSetor(String nomeSetor) {
		this.nomeSetor = nomeSetor;
	}
	
}
