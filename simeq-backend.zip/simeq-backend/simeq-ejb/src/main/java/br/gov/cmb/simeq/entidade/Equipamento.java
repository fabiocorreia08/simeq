
package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.envers.Audited;

import br.gov.cmb.simeq.enums.SimNaoEnum;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioCapacidadeProdutivaEquipamentoVO;

@Audited
@Entity
@Table(name = "EQUIPAMENTO")
@SqlResultSetMappings({
	@SqlResultSetMapping(name="filtrarCapacidadeEquipamentoMapping",
		classes={@ConstructorResult(
			targetClass=SubRelatorioCapacidadeProdutivaEquipamentoVO.class,
				columns={	@ColumnResult(name="codigo", type=String.class),
							@ColumnResult(name="equipamento", type=String.class),
							@ColumnResult(name="indice", type=Double.class),
							@ColumnResult(name="dias_uteis", type=String.class),
							@ColumnResult(name="funcionamento", type=String.class),
							@ColumnResult(name="preventiva_prevista", type=String.class),
							@ColumnResult(name="preventiva_executada", type=String.class),
							@ColumnResult(name="corretiva", type=String.class)}
			)}
		)
})
@NamedNativeQueries({
    @NamedNativeQuery(
        name = "filtrarCapacidadeEquipamento",
        query = " declare @dataInicial date = :dataInicial " +
        		" declare @dataFinal date = :dataFinal " +
        		" SELECT " + 
        		"    tabela_final.CD_MANUTENCAO as codigo, " + 
        		"    tabela_final.NM_EQUIPAMENTO as equipamento, " + 
        		"    case when (tabela_final.minutos_funcionamento_maquina-tabela_final.minutos_previsto_preventiva) != 0 then " + 
        		"    convert(numeric, (tabela_final.minutos_funcionamento_maquina-tabela_final.minutos_gasto_preventiva-tabela_final.minutos_com_paralisacao_corretiva))/convert(numeric, (tabela_final.minutos_funcionamento_maquina-tabela_final.minutos_previsto_preventiva)) " + 
        		"    else 0 end as indice, " + 
        		"    tabela_final.dias_funcionamento_maquina as dias_uteis, " + 
        		"    convert(varchar, tabela_final.minutos_funcionamento_maquina/60)+':'+ right('00' +convert(varchar, tabela_final.minutos_funcionamento_maquina%60), 2) as funcionamento, " + 
        		"    convert(varchar, tabela_final.minutos_previsto_preventiva/60)+':'+ right('00' +convert(varchar, tabela_final.minutos_previsto_preventiva%60), 2) as preventiva_prevista, " + 
        		"    convert(varchar, tabela_final.minutos_gasto_preventiva/60)+':'+ right('00' + convert(varchar, tabela_final.minutos_gasto_preventiva%60), 2) as preventiva_executada, " + 
        		"    convert(varchar, tabela_final.minutos_com_paralisacao_corretiva/60)+':'+ right('00' + convert(varchar, tabela_final.minutos_com_paralisacao_corretiva%60), 2) as corretiva " + 
        		" FROM ( " + 
        		"    SELECT " + 
        		"        e.CD_MANUTENCAO, " + 
        		"        e.NM_EQUIPAMENTO, " + 
        		"        coalesce(tabela_final_corretiva.minutos_com_paralisacao_corretiva, 0) as minutos_com_paralisacao_corretiva, " + 
        		"        coalesce(tabela_final_preventiva.minutos_previsto_preventiva, 0) as minutos_previsto_preventiva, " + 
        		"        coalesce(tabela_final_preventiva.minutos_gasto_preventiva, 0) as minutos_gasto_preventiva, " + 
        		"        coalesce(tabela_final_funcionamento.dias_funcionamento_maquina, 0) as dias_funcionamento_maquina, " + 
        		"        coalesce(tabela_final_funcionamento.minutos_funcionamento_maquina, 0) as minutos_funcionamento_maquina " + 
        		"    FROM EQUIPAMENTO e " +
        		"		INNER JOIN ( " +    		
        		"        SELECT tabela_corretiva.ID_EQUIPAMENTO, " + 
        		"            sum(tabela_corretiva.minutos_com_paralisacao_corretiva) as minutos_com_paralisacao_corretiva " + 
        		"        FROM ( " + 
        		"            SELECT e.ID_EQUIPAMENTO, " + 
        		"                ac.QT_HORA_COM_PARALISACAO*60+ac.QT_MIN_COM_PARALISACAO as minutos_com_paralisacao_corretiva " + 
        		"            FROM EQUIPAMENTO e " + 
        		"  			 INNER JOIN HISTORICO_SITUACAO_EQUIPAMENTO hse on hse.ID_HISTORICO_SITUACAO_EQUIPAMENTO = (" + 
        		"        					 select hse2.ID_HISTORICO_SITUACAO_EQUIPAMENTO " + 
        		"        					 from EQUIPAMENTO e2 " + 
        		"        					 	inner join HISTORICO_SITUACAO_EQUIPAMENTO hse2 on hse2.ID_EQUIPAMENTO=e2.ID_EQUIPAMENTO " + 
        		"        					 where e2.ID_EQUIPAMENTO=e.ID_EQUIPAMENTO and hse2.DT_INICIO = (select max(hse2.DT_INICIO) from EQUIPAMENTO e2 " + 
        		"        					 		inner join HISTORICO_SITUACAO_EQUIPAMENTO hse2 on hse2.ID_EQUIPAMENTO=e2.ID_EQUIPAMENTO " + 
        		"        					 	where e2.ID_EQUIPAMENTO=e.ID_EQUIPAMENTO) " + 
        		"        					 )"+
        		"            INNER JOIN MANUTENCAO_CORRETIVA mc ON e.ID_EQUIPAMENTO = mc.ID_EQUIPAMENTO " + 
        		"                and ( :centrosCustoSize = 0 OR hse.CD_CENTRO_CUSTO in :centrosCusto ) " + 
        		"            INNER JOIN ATIVIDADE_CORRETIVA ac ON ac.ID_MANUTENCAO_CORRETIVA = mc.ID_MANUTENCAO_CORRETIVA " + 
        		"                and ac.DT_CADASTRO between @dataInicial and @dataFinal " + 
        		"            ) AS tabela_corretiva " +
        		"        GROUP BY tabela_corretiva.ID_EQUIPAMENTO) tabela_final_corretiva ON tabela_final_corretiva.ID_EQUIPAMENTO = e.ID_EQUIPAMENTO " + 
        		"    INNER JOIN ( " + 
        		"        SELECT tabela_preventiva.ID_EQUIPAMENTO, " + 
        		"            sum(tabela_preventiva.minutos_previsto_preventiva) as minutos_previsto_preventiva, " + 
        		"            sum(tabela_preventiva.minutos_gasto_preventiva) as minutos_gasto_preventiva " + 
        		"        FROM ( " + 
        		"            SELECT e.ID_EQUIPAMENTO, " + 
        		"                case when len(mp.QT_HORAS) = 5 " +
        		"					then convert(int, substring(mp.QT_HORAS, 1, 2))*60+convert(int, substring(mp.QT_HORAS, 4, 2)) " +
        		"					else convert(int, substring(mp.QT_HORAS, 1, 3))*60+convert(int, substring(mp.QT_HORAS, 5, 2)) end as minutos_previsto_preventiva, " + 
        		"                case when len(mp.QT_HORAS_GASTA) = 5 " +
        		"					then convert(int, substring(mp.QT_HORAS_GASTA, 1, 2))*60+convert(int, substring(mp.QT_HORAS_GASTA, 4, 2)) " +
        		"					else convert(int, substring(mp.QT_HORAS_GASTA, 1, 3))*60+convert(int, substring(mp.QT_HORAS_GASTA, 5, 2)) end as minutos_gasto_preventiva " + 
        		"            FROM EQUIPAMENTO e " + 
        		"  			 INNER JOIN HISTORICO_SITUACAO_EQUIPAMENTO hse on hse.ID_HISTORICO_SITUACAO_EQUIPAMENTO = (" + 
        		"        					 select hse2.ID_HISTORICO_SITUACAO_EQUIPAMENTO " + 
        		"        					 from EQUIPAMENTO e2 " + 
        		"        					 	inner join HISTORICO_SITUACAO_EQUIPAMENTO hse2 on hse2.ID_EQUIPAMENTO=e2.ID_EQUIPAMENTO " + 
        		"        					 where e2.ID_EQUIPAMENTO=e.ID_EQUIPAMENTO and hse2.DT_INICIO = (select max(hse2.DT_INICIO) from EQUIPAMENTO e2 " + 
        		"        					 		inner join HISTORICO_SITUACAO_EQUIPAMENTO hse2 on hse2.ID_EQUIPAMENTO=e2.ID_EQUIPAMENTO " + 
        		"        					 	where e2.ID_EQUIPAMENTO=e.ID_EQUIPAMENTO) " + 
        		"        					 )"+
        		"            INNER JOIN MANUTENCAO_PREVENTIVA mp ON e.ID_EQUIPAMENTO = mp.ID_EQUIPAMENTO " + 
        		"                and ( :centrosCustoSize = 0 OR hse.CD_CENTRO_CUSTO in :centrosCusto ) " + 
        		"                and (mp.NR_ANO is not null and mp.NR_MES is not null and mp.NR_DIA_INICIO is not null) and (convert(date, convert(varchar, mp.NR_ANO)+'-'+right('00' + convert(varchar, mp.NR_MES), 2)+'-'+right('00' + convert(varchar, mp.NR_DIA_INICIO), 2)) between @dataInicial and @dataFinal ) " + 
        		"            ) AS tabela_preventiva " + 
        		"        GROUP BY tabela_preventiva.ID_EQUIPAMENTO) tabela_final_preventiva ON tabela_final_preventiva.ID_EQUIPAMENTO = e.ID_EQUIPAMENTO " + 
        		"    INNER JOIN ( " + 
        		"        SELECT tabela_funcionamento.ID_EQUIPAMENTO, " + 
        		"            count(tabela_funcionamento.ID_FUNCIONAMENTO_MAQUINA_DIA) as dias_funcionamento_maquina,	" + 
        		"            sum(tabela_funcionamento.minutos_funcionamento_maquina) as minutos_funcionamento_maquina " + 
        		"        FROM ( " + 
        		"            SELECT e.ID_EQUIPAMENTO, " + 
        		"                fmd.ID_FUNCIONAMENTO_MAQUINA_DIA, " + 
        		"                fmd.QT_HORAS*60 as minutos_funcionamento_maquina " + 
        		"            FROM EQUIPAMENTO e " + 
        		"  			 INNER JOIN HISTORICO_SITUACAO_EQUIPAMENTO hse on hse.ID_HISTORICO_SITUACAO_EQUIPAMENTO = (" + 
        		"        					 select hse2.ID_HISTORICO_SITUACAO_EQUIPAMENTO " + 
        		"        					 from EQUIPAMENTO e2 " + 
        		"        					 	inner join HISTORICO_SITUACAO_EQUIPAMENTO hse2 on hse2.ID_EQUIPAMENTO=e2.ID_EQUIPAMENTO " + 
        		"        					 where e2.ID_EQUIPAMENTO=e.ID_EQUIPAMENTO and hse2.DT_INICIO = (select max(hse2.DT_INICIO) from EQUIPAMENTO e2 " + 
        		"        					 		inner join HISTORICO_SITUACAO_EQUIPAMENTO hse2 on hse2.ID_EQUIPAMENTO=e2.ID_EQUIPAMENTO " + 
        		"        					 	where e2.ID_EQUIPAMENTO=e.ID_EQUIPAMENTO) " + 
        		"        					 )"+
        		"            INNER JOIN FUNCIONAMENTO_MAQUINA fm ON e.ID_EQUIPAMENTO = fm.ID_EQUIPAMENTO " + 
        		"                and (:centrosCustoSize = 0 OR hse.CD_CENTRO_CUSTO in :centrosCusto ) " + 
        		"            INNER JOIN FUNCIONAMENTO_MAQUINA_DIA fmd ON fm.ID_FUNCIONAMENTO_MAQUINA = fmd.ID_FUNCIONAMENTO_MAQUINA " + 
        		"                and (fm.NR_ANO is not null and fm.NR_MES is not null and fmd.NR_DIA is not null) and (convert(date, convert(varchar, fm.NR_ANO)+'-'+right('00' + convert(varchar, fm.NR_MES), 2)+'-'+right('00' + convert(varchar, fmd.NR_DIA), 2)) between @dataInicial and @dataFinal ) " + 
        		"            ) AS tabela_funcionamento " + 
        		"        GROUP BY tabela_funcionamento.ID_EQUIPAMENTO) tabela_final_funcionamento ON tabela_final_funcionamento.ID_EQUIPAMENTO = e.ID_EQUIPAMENTO " +
        		"		 WHERE (:soPreventivas = 'N' OR e.FL_PREVENTIVA = 'S') " +
        		"		 ) as tabela_final " +
        		"        ORDER BY codigo, equipamento",
                resultSetMapping="filtrarCapacidadeEquipamentoMapping"
    )
})
public class Equipamento implements Serializable {

	private static final long serialVersionUID = -7155667623160459644L;

	@Id
	@Column(name = "ID_EQUIPAMENTO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idEquipamento;

	@Column(name = "CD_MANUTENCAO")
	private String codigoManutencao;

	@Column(name = "NM_EQUIPAMENTO")
	private String nomeEquipamento;

	@Column(name = "NR_PATRIMONIO")
	private String numeroPatrimonio;

	@Column(name = "NR_TENSAO")
	private Long numeroTensao;

	@Column(name = "NR_POTENCIA")
	private Long numeroPotencia;

	@Column(name = "NM_TIPO_POTENCIA")
	private String nomeTipoPotencia;

	@Column(name = "NR_PESO")
	private Long numeroPeso;

	@Column(name = "NR_ANO")
	private Long numeroAno;

	@Column(name = "DT_INSTALACAO")
	@Temporal(TemporalType.DATE)
	private Date dataInstalacao;

	@Column(name = "FL_PREVENTIVA")
	@Enumerated(EnumType.STRING)
	private SimNaoEnum flagPreventiva;

	@Column(name = "DS_PRE_REQUISITO_INFORMACAO")
	private String descricaoPreRequisitoInformacao;

	@Column(name = "DS_OBSERVACAO")
	private String descricaoObservacao;

	@OneToMany(mappedBy = "equipamento")
	private List<HistoricoSituacaoEquipamento> historicosSituacaoEquipamento = new ArrayList<>();

	@OneToMany(mappedBy = "equipamento")
	private List<Grupo> grupos = new ArrayList<>();
	
	@OneToMany(mappedBy = "equipamento")
	private List<FuncionamentoMaquina> funcionamentoMaquinas = new ArrayList<>();
	
	@Transient
	private HistoricoSituacaoEquipamento ultimoHistoricoSituacaoCadastrado;

	public Equipamento() {

	}

	public Equipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public Equipamento(Long idEquipamento, String codigoManutencao, String nomeEquipamento, String numeroPatrimonio,
			Long numeroTensao, Long numeroPotencia, String nomeTipoPotencia, Long numeroPeso, Long numeroAno,
			Date dataInstalacao, SimNaoEnum flagPreventiva, String descricaoPreRequisitoInformacao,
			String descricaoObservacao) {
		this.idEquipamento = idEquipamento;
		this.codigoManutencao = codigoManutencao;
		this.nomeEquipamento = nomeEquipamento;
		this.numeroPatrimonio = numeroPatrimonio;
		this.numeroTensao = numeroTensao;
		this.numeroPotencia = numeroPotencia;
		this.nomeTipoPotencia = nomeTipoPotencia;
		this.numeroPeso = numeroPeso;
		this.numeroAno = numeroAno;
		this.dataInstalacao = dataInstalacao;
		this.flagPreventiva = flagPreventiva;
		this.descricaoPreRequisitoInformacao = descricaoPreRequisitoInformacao;
		this.descricaoObservacao = descricaoObservacao;
	}
	
	public List<FuncionamentoMaquina> getFuncionamentoMaquinas() {
		return funcionamentoMaquinas;
	}

	public void setFuncionamentoMaquinas(List<FuncionamentoMaquina> funcionamentoMaquinas) {
		this.funcionamentoMaquinas = funcionamentoMaquinas;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoManutencao() {
		return codigoManutencao;
	}

	public void setCodigoManutencao(String codigoManutencao) {
		this.codigoManutencao = codigoManutencao;
	}

	public String getNomeEquipamento() {
		return nomeEquipamento;
	}

	public void setNomeEquipamento(String nomeEquipamento) {
		this.nomeEquipamento = nomeEquipamento;
	}

	public String getNumeroPatrimonio() {
		return numeroPatrimonio;
	}

	public void setNumeroPatrimonio(String numeroPatrimonio) {
		this.numeroPatrimonio = numeroPatrimonio;
	}

	public Long getNumeroTensao() {
		return numeroTensao;
	}

	public void setNumeroTensao(Long numeroTensao) {
		this.numeroTensao = numeroTensao;
	}

	public Long getNumeroPotencia() {
		return numeroPotencia;
	}

	public void setNumeroPotencia(Long numeroPotencia) {
		this.numeroPotencia = numeroPotencia;
	}

	public String getNomeTipoPotencia() {
		return nomeTipoPotencia;
	}

	public void setNomePotencia(String numeroTipoPotencia) {
		this.nomeTipoPotencia = numeroTipoPotencia;
	}

	public Long getNumeroPeso() {
		return numeroPeso;
	}

	public void setNumeroPeso(Long numeroPeso) {
		this.numeroPeso = numeroPeso;
	}

	public Long getNumeroAno() {
		return numeroAno;
	}

	public void setNumeroAno(Long numeroAno) {
		this.numeroAno = numeroAno;
	}

	public Date getDataInstalacao() {
		return dataInstalacao;
	}

	public void setDataInstalacao(Date dataInstalacao) {
		this.dataInstalacao = dataInstalacao;
	}

	public SimNaoEnum getFlagPreventiva() {
		return flagPreventiva;
	}

	public void setFlagPreventiva(SimNaoEnum flagPreventiva) {
		this.flagPreventiva = flagPreventiva;
	}

	public String getDescricaoPreRequisitoInformacao() {
		return descricaoPreRequisitoInformacao;
	}

	public void setDescricaoPreRequisitoInformacao(String descricaoPreRequisitoInformacao) {
		this.descricaoPreRequisitoInformacao = descricaoPreRequisitoInformacao;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public List<HistoricoSituacaoEquipamento> getHistoricosSituacaoEquipamento() {
		return historicosSituacaoEquipamento;
	}

	public void setHistoricosSituacaoEquipamento(List<HistoricoSituacaoEquipamento> historicosSituacaoEquipamento) {
		this.historicosSituacaoEquipamento = historicosSituacaoEquipamento;
	}

	public List<Grupo> getGrupos() {
		return grupos;
	}

	public void setGrupos(List<Grupo> grupos) {
		this.grupos = grupos;
	}

	public HistoricoSituacaoEquipamento getUltimoHistoricoSituacaoCadastrado() {
		return ultimoHistoricoSituacaoCadastrado;
	}

	public void setUltimoHistoricoSituacaoCadastrado(HistoricoSituacaoEquipamento ultimoHistoricoSituacaoCadastrado) {
		this.ultimoHistoricoSituacaoCadastrado = ultimoHistoricoSituacaoCadastrado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idEquipamento == null) ? 0 : idEquipamento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Equipamento other = (Equipamento) obj;
		if (idEquipamento == null) {
			if (other.idEquipamento != null)
				return false;
		} else if (!idEquipamento.equals(other.idEquipamento))
			return false;
		return true;
	}

}
