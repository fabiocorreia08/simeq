package br.gov.cmb.simeq.validador;

import java.util.Calendar;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.google.common.base.Strings;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.AtividadePreventivaDAO;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.utils.ConverterHorasMinutosUtil;
import br.gov.cmb.simeq.utils.StringUtil;
import br.gov.cmb.simeq.vo.AtividadeVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;

@Stateless
public class AtividadeValidador extends AbstractValidador {
	
	private static final Integer MINUTOS_LIMITE_MAXIMO = 60;
	
	@Inject
	private AtividadeCorretivaDAO atividadeCorretivaDAO; 
	
	@Inject
	private AtividadePreventivaDAO atividadePreventivaDAO; 
	
	@Inject
	private HistoricoStatusManutencaoCorretivaDAO statusManutencaoDAO;
	
	@RegraDeValidacao
	public void validarCadastroIguaisCorretiva(AtividadeVO atividadeVO) {
		List<AtividadeCorretiva> atividades = atividadeCorretivaDAO.buscarAtividadePorManutencao(atividadeVO.getIdManutencao());
		if(!CollectionUtils.isNullOrEmpty(atividades)) {
			for (AtividadeCorretiva atividade : atividades) {
				if(atividade.getId() != atividadeVO.getId()) {
					if(atividade.getAcao().getCodigo().equals(atividadeVO.getCodigoAcao()) && 
							atividade.getComponente().getCodigo().equals(atividadeVO.getCodigoComponente()) &&
							atividade.getSubGrupo().getIdGrupo().equals(atividadeVO.getIdSubGrupo()) &&
							atividade.getSubGrupo().getGrupoPai().getIdGrupo().equals(atividadeVO.getIdGrupo())) {
						throw new ValidacaoException("Essa atividade já foi cadastrada para essa solicitação.");
					}
				}
			}
		}
	}
	
	@RegraDeValidacao
	public void validarCadastroIguaisPreventiva(AtividadeVO atividadeVO) {
		List<AtividadePreventiva> atividades = atividadePreventivaDAO.buscarAtividadePorManutencao(atividadeVO.getIdManutencao());
		if(!CollectionUtils.isNullOrEmpty(atividades)) {
			for (AtividadePreventiva atividade : atividades) {
				if(atividade.getId() != atividadeVO.getId()) {
					if(atividade.getAcao().getCodigo().equals(atividadeVO.getCodigoAcao()) && 
							atividade.getComponente().getCodigo().equals(atividadeVO.getCodigoComponente()) &&
							atividade.getSubGrupo().getIdGrupo().equals(atividadeVO.getIdSubGrupo()) &&
							atividade.getSubGrupo().getGrupoPai().getIdGrupo().equals(atividadeVO.getIdGrupo())) {
						throw new ValidacaoException("Essa atividade já foi cadastrada para essa solicitação.");
					}
				}
			}
		}
	}
	
	@RegraDeValidacao
	public void validarHht(AtividadeVO atividadeVO) {
		
		if(atividadeVO.getHorasAtividade() != null && !atividadeVO.getHorasAtividade().equals(StringUtil.empty())) {
			String horas = atividadeVO.getHorasAtividade().substring(0, 3);
			if("00".equals(horas)) {
				throw new ValidacaoException("Falta informação obrigatória. Por favor, informe o/a H.H.T.");
			}
			Integer minutosFinal = new Integer(atividadeVO.getHorasAtividade().substring(3, 4));
			if(minutosFinal >= MINUTOS_LIMITE_MAXIMO) {
				throw new ValidacaoException("Informe minutos de produção válido");
			}
		}
	}
	
	@RegraDeValidacao
	public void validarHoraComESemParalisacao(AtividadeVO atividadeVO) {
		Integer minutosSemParalisacao = ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasSemParalisacao());
		if(!Strings.isNullOrEmpty(atividadeVO.getHorasSemParalisacao())) {
			Integer minutosComParalisacao = ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasComParalisacao());
			if(minutosComParalisacao >= MINUTOS_LIMITE_MAXIMO) {
				throw new ValidacaoException("Informe minutos de Hora Com Paralisação válido");
			}
		}
		if(minutosSemParalisacao >= MINUTOS_LIMITE_MAXIMO) {
			throw new ValidacaoException("Informe minutos de Hora Sem Paralisação válido");
		}
	}
	
	@RegraDeValidacao
	public void validarHorasComSemParasalicaoIgualHhht(AtividadeVO atividadeVO) {
		if(!Strings.isNullOrEmpty(atividadeVO.getHorasAtividade())
				&& !Strings.isNullOrEmpty(atividadeVO.getHorasSemParalisacao())) {
			Integer horasHhht = ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasAtividade());
			Integer minutosHhht = ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasAtividade());
			Integer horasSemParalisacao = ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasSemParalisacao());
			Integer minutosSemParalisacao = ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasSemParalisacao());
			Integer horasComParalisacao = ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasComParalisacao());
			Integer minutosComParalisacao = ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasComParalisacao());
			Integer minutosSomados = minutosComParalisacao + minutosSemParalisacao;
			Integer horasSomadas = horasSemParalisacao + horasComParalisacao;
			if(minutosSomados >= MINUTOS_LIMITE_MAXIMO) {
				horasSomadas += minutosSomados / 60;
				minutosSomados = (minutosSomados % 60);
			}
			if(!horasSomadas.equals(horasHhht)  ||
					!minutosSomados.equals(minutosHhht)) {
				throw new ValidacaoException("A soma das Horas com Paralisação e Sem Paralisação deve ser igual a H.H.T");
			}
		}
	}
	
	@RegraDeValidacao
	public void validarPersistenciaAtividadeTecnicoAlocado(ManutencaoCorretivaVO manutencaoVO) {
		HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva = statusManutencaoDAO.buscarUltimoHistoricoInserido(manutencaoVO.getIdManutencao());
		Calendar cal = Calendar.getInstance();
		int mesAtual = cal.get(Calendar.MONTH) + 1;
		int diaAtual = cal.get(Calendar.DATE);
		if(StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo().equals(historicoStatusManutencaoCorretiva.getId().getIdStatusManutencao())) {
			cal.setTime(historicoStatusManutencaoCorretiva.getDataCriacao());
			int mesStatusConcluida = cal.get(Calendar.MONTH);
			if(mesStatusConcluida <= mesAtual && diaAtual > 5) {
				throw new ValidacaoException("Solicitação já passou o prazo para cadastro de atividade.");
			}
		}
	}
	
	@RegraDeValidacao
	public void validarHoras(AtividadeVO atividadeVO) {
		
	}
}
