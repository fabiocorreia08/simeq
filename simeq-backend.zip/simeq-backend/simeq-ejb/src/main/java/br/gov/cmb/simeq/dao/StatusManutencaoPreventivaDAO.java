package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.StatusManutencaoPreventiva;

public class StatusManutencaoPreventivaDAO extends GenericoPaginadoDAO<StatusManutencaoPreventiva, Long> {

	private static final long serialVersionUID = -8000623635445516223L;
	
	public List<LabelValueDTO> buscarStatusCombo(List<Long> idsStatus) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(s.nome, s.id)")
				.from(StatusManutencaoPreventiva.class, "s")
				.where("s.id in ?1")
				.order("s.nome");
		return buscar(builder.builder(), LabelValueDTO.class, idsStatus);
	}
}
