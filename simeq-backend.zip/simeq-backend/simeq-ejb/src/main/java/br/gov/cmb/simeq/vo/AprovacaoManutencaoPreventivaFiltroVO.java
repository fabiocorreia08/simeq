package br.gov.cmb.simeq.vo;

import javax.inject.Named;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

@Named
public class AprovacaoManutencaoPreventivaFiltroVO extends ModeloVO {

	private static final long serialVersionUID = -2160938299845627654L;

	@ParametroNomeado
	private String centroCusto;

	@ParametroNomeado
	private Long idEquipamento;

	@ParametroNomeado
	private Integer ano;

	private Integer perfil;

	private String matricula;

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	@ParametroNomeado
	private Long idStatus;

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

}
