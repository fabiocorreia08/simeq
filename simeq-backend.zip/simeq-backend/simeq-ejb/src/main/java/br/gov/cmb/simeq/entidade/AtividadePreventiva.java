package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.collect.Sets;

@Audited
@Entity
@Table(name = "ATIVIDADE_PREVENTIVA")
public class AtividadePreventiva implements Serializable {

	private static final long serialVersionUID = -9009179293014963911L;
	
	@Id
	@Column(name = "ID_ATIVIDADE")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "ID_MANUTENCAO_PREVENTIVA")
	private ManutencaoPreventiva manutencaoPreventiva;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_MATRICULA_EXECUTANTE")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private PessoaView executante;
	
	@ManyToOne
	@JoinColumn(name = "ID_SUBGRUPO")
	private Grupo subGrupo;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_ACAO")
	private Acao acao;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_COMPONENTE")
	private Componente componente;
	
	@Column(name = "DS_OBSERVACAO")
	private String observacao;
	
	@Column(name = "DT_CADASTRO", updatable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "VL_SALARIO_EXECUTANTE")
	private BigDecimal salario;
	
	@Column(name = "HR_ATIVIDADE")
	private Integer horaAtividade;
	
	@Column(name = "MN_ATIVIDADE")
	private Integer minutosAtividade;
	
	@OneToMany(mappedBy = "atividade", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Set<AtividadeMaterialPreventiva> materiais = Sets.newHashSet();

	public AtividadePreventiva(){}
	
	public AtividadePreventiva(Long id, Long idManutencao, String matriculaExecutante, Long idSubGrupo, String codigoAcao, String codigoComponente,
			String observacao, Set<AtividadeMaterialPreventiva> materiais, BigDecimal salario,Integer horaAtividade, Integer minutoAtividade) {
		this.id = id;
		this.manutencaoPreventiva = new ManutencaoPreventiva(idManutencao);
		this.executante = new PessoaView(matriculaExecutante);
		this.subGrupo = new Grupo(idSubGrupo);
		this.acao = new Acao(codigoAcao);
		this.componente = new Componente(codigoComponente);
		this.observacao = observacao;
		this.setMateriais(materiais);
		this.salario = salario;
		this.horaAtividade = horaAtividade;
		this.minutosAtividade = minutoAtividade;
	}
	
	public Integer getHoraAtividade() {
		return horaAtividade;
	}

	public void setHoraAtividade(Integer horaAtividade) {
		this.horaAtividade = horaAtividade;
	}

	public Integer getMinutosAtividade() {
		return minutosAtividade;
	}

	public void setMinutosAtividade(Integer minutosAtividade) {
		this.minutosAtividade = minutosAtividade;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ManutencaoPreventiva getManutencaoPreventiva() {
		return manutencaoPreventiva;
	}

	public void setManutencaoPreventiva(ManutencaoPreventiva manutencaoPreventiva) {
		this.manutencaoPreventiva = manutencaoPreventiva;
	}

	public PessoaView getExecutante() {
		return executante;
	}

	public void setExecutante(PessoaView executante) {
		this.executante = executante;
	}

	public Grupo getSubGrupo() {
		return subGrupo;
	}

	public void setSubGrupo(Grupo subGrupo) {
		this.subGrupo = subGrupo;
	}

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}

	public Componente getComponente() {
		return componente;
	}

	public void setComponente(Componente componente) {
		this.componente = componente;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public Set<AtividadeMaterialPreventiva> getMateriais() {
		return materiais;
	}

	public void setMateriais(Set<AtividadeMaterialPreventiva> materiais) {
		this.materiais = materiais;
	}

	public BigDecimal getSalario() {
		return salario;
	}

	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}

}
