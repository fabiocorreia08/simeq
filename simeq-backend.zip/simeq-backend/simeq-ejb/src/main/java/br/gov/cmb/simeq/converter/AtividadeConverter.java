package br.gov.cmb.simeq.converter;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;

import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.AtividadeMaterialCorretiva;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import br.gov.cmb.simeq.entidade.AtividadeMaterialPreventiva;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.utils.ConverterHorasMinutosUtil;
import br.gov.cmb.simeq.vo.AtividadeMaterialVO;
import br.gov.cmb.simeq.vo.AtividadeVO;

public class AtividadeConverter {
	
	public static AtividadeCorretiva converter(AtividadeVO atividadeVO) {
		Set<AtividadeMaterialCorretiva> materiais = atividadeVO.getMateriais().stream().map(m -> new AtividadeMaterialCorretiva(m.getId(), 
				m.getCodigoMaterial(), m.getDescricaoMaterialOutros(), m.getNomeMaterialOutros(), m.getQuantidadeMaterialDecimal(), m.getDescricaoUnidadeMedida())).collect(Collectors.toSet());
		AtividadeCorretiva atividade = new AtividadeCorretiva(Objects.nonNull(atividadeVO.getId()) ? atividadeVO.getId() : null,
				atividadeVO.getIdManutencao(), 
				atividadeVO.getMatriculaExecutante(), 
				atividadeVO.getIdSubGrupo(), 
				atividadeVO.getCodigoAcao(), 
				atividadeVO.getCodigoComponente(),
				ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasAtividade()),
				ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasAtividade()),
				atividadeVO.getMesReferencia(), 
				atividadeVO.getObservacao(),
				materiais,
				atividadeVO.getSalario(),
				ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasSemParalisacao()),
				ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasSemParalisacao()),
				ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasComParalisacao()),
				ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasComParalisacao()));
		atividade.getMateriais().stream().forEach(m -> m.setAtividade(atividade));
		return atividade;
	}
	
	public static AtividadePreventiva converterPreventiva(AtividadeVO atividadeVO) {
		Set<AtividadeMaterialPreventiva> materiais = atividadeVO.getMateriais().stream().map(m -> new AtividadeMaterialPreventiva(m.getId(), 
				m.getCodigoMaterial(), m.getDescricaoMaterialOutros(), m.getNomeMaterialOutros(), m.getQuantidadeMaterialDecimal(), m.getDescricaoUnidadeMedida())).collect(Collectors.toSet());
		AtividadePreventiva atividade = new AtividadePreventiva(Objects.nonNull(atividadeVO.getId()) ? atividadeVO.getId() : null,
				atividadeVO.getIdManutencao(), 
				atividadeVO.getMatriculaExecutante(), 
				atividadeVO.getIdSubGrupo(), 
				atividadeVO.getCodigoAcao(), 
				atividadeVO.getCodigoComponente(),			
				atividadeVO.getObservacao(),
				materiais,
				atividadeVO.getSalario(),
				ConverterHorasMinutosUtil.getHora(atividadeVO.getHorasAtividade()),
				ConverterHorasMinutosUtil.getMinutos(atividadeVO.getHorasAtividade()));
		atividade.getMateriais().stream().forEach(m -> m.setAtividade(atividade));
		return atividade;
	}
	
	public static AtividadeVO converter(AtividadeCorretiva atividade) {
		int sequencial = 1;
		List<AtividadeMaterialVO> materiaisVO = Lists.newArrayList();
		for (AtividadeMaterialCorretiva atividadeMaterial : atividade.getMateriais()) {
			materiaisVO.add(new AtividadeMaterialVO(atividadeMaterial.getId(),
					atividade.getId(), 
					atividadeMaterial.getCodigoMaterial() != null ? atividadeMaterial.getCodigoMaterial() : atividadeMaterial.getDescricaoMaterialOutros(), 
					atividadeMaterial.getDescricaoMaterialOutros(), 
					atividadeMaterial.getNomeMaterialOutros(),
					atividadeMaterial.getQuantidadeMaterial(), 
					atividadeMaterial.getDescricaoUnidadeMedica(), 
					sequencial++, 
					atividadeMaterial.getMaterialView() != null ? atividadeMaterial.getMaterialView().getNome() : atividadeMaterial.getNomeMaterialOutros()));
		}
				
		return new AtividadeVO(atividade.getId(), 
				atividade.getManutencaoCorretiva().getId(), 
				atividade.getManutencaoCorretiva().getFlagClasseManutencao() != null ? atividade.getManutencaoCorretiva().getFlagClasseManutencao().getDescricao() : null, 
				atividade.getExecutante().getMatricula(), 
				atividade.getManutencaoCorretiva().getDataCriacao(), 
				atividade.getExecutante().getNome(), 
				atividade.getSubGrupo().getGrupoPai() != null ? atividade.getSubGrupo().getGrupoPai().getIdGrupo() : null, 
				atividade.getSubGrupo().getIdGrupo(),
				atividade.getAcao().getNome(),
				atividade.getAcao().getCodigo(),
				atividade.getManutencaoCorretiva().getEquipamento() != null ? 
						atividade.getManutencaoCorretiva().getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getTextoHierarquiaCentroCusto() : null, 
				atividade.getComponente().getCodigo(), 
				atividade.getComponente().getNome(),
				atividade.getMesReferencia(), 
				ConverterHorasMinutosUtil.getTextoHora(atividade.getHoraAtividade(), atividade.getMinutosAtividade()), 
				atividade.getObservacao(),
				materiaisVO,
				atividade.getManutencaoCorretiva().getNumeroSolicitacao(),
				atividade.getSalario(),
				ConverterHorasMinutosUtil.getTextoHora(atividade.getHorasComParalisacao(), atividade.getMinutosComParalisacao()),
				ConverterHorasMinutosUtil.getTextoHora(atividade.getHorasSemParalisacao(), atividade.getMinutosSemParalisacao()));
	}
	
	public static AtividadeVO converterPreventiva(AtividadePreventiva atividade) {
		int sequencial = 1;
		List<AtividadeMaterialVO> materiaisVO = Lists.newArrayList();
		for (AtividadeMaterialPreventiva atividadeMaterial : atividade.getMateriais()) {
			materiaisVO.add(new AtividadeMaterialVO(atividadeMaterial.getId(),
					atividade.getId(), 
					atividadeMaterial.getCodigoMaterial() != null ? atividadeMaterial.getCodigoMaterial() : atividadeMaterial.getDescricaoMaterialOutros(), 
					atividadeMaterial.getDescricaoMaterialOutros(), 
					atividadeMaterial.getNomeMaterialOutros(),
					atividadeMaterial.getQuantidadeMaterial(), 
					atividadeMaterial.getDescricaoUnidadeMedica(), 
					sequencial++, 
					atividadeMaterial.getMaterialView() != null ? atividadeMaterial.getMaterialView().getNome() : atividadeMaterial.getNomeMaterialOutros()));
		}
				
		return new AtividadeVO(atividade.getId(), 
				atividade.getManutencaoPreventiva().getId(), 
				ClasseManutencaoEnum.P.getDescricao(), 
				atividade.getExecutante().getMatricula(), 
				atividade.getManutencaoPreventiva().getDataCriacao(), 
				atividade.getExecutante().getNome(), 
				atividade.getSubGrupo().getGrupoPai() != null ? atividade.getSubGrupo().getGrupoPai().getIdGrupo() : null, 
				atividade.getSubGrupo().getIdGrupo(),
				atividade.getAcao().getNome(),
				atividade.getAcao().getCodigo(),
				atividade.getManutencaoPreventiva().getEquipamento() != null ? 
						atividade.getManutencaoPreventiva().getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getTextoHierarquiaCentroCusto() : null, 
				atividade.getComponente().getCodigo(), 
				atividade.getComponente().getNome(),
				null, 
				ConverterHorasMinutosUtil.getTextoHora(atividade.getHoraAtividade(), atividade.getMinutosAtividade()), 
				atividade.getObservacao(),
				materiaisVO,
				atividade.getManutencaoPreventiva().getNumeroSolicitacao(),
				atividade.getSalario(),
				null,
				null);
	}
}
