package br.gov.cmb.simeq.enums;

public enum SimNaoEnum {
	S("S"),
	N("N");
	
	public String label;
	
	SimNaoEnum(String label) {
		this.label = label;
	}
}
