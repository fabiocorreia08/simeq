package br.gov.cmb.simeq.vo;

import java.io.Serializable;

public class AprovacaoPreventivaConsultaTabelaVO implements Serializable{
	private static final long serialVersionUID = -2019100102049186875L;

	private Long idManutencao;
	private String numeroSolicitacao;
	private Integer mes;
	private Integer dataInicio;
	private Integer dataFim;
	private String qtdHoras;
	
	public AprovacaoPreventivaConsultaTabelaVO(Long idManutencao, String numeroSolicitacao, Integer mes, Integer dataInicio,
			Integer dataFim, String qtdHoras) {
		super();
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.mes = mes;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
		this.qtdHoras = qtdHoras;
		
	}
	public Long getIdManutencao() {
		return idManutencao;
	}
	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}
	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}
	public Integer getMes() {
		return mes;
	}
	public void setMes(Integer mes) {
		this.mes = mes;
	}
	public Integer getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(Integer dataInicio) {
		this.dataInicio = dataInicio;
	}
	public Integer getDataFim() {
		return dataFim;
	}
	public void setDataFim(Integer dataFim) {
		this.dataFim = dataFim;
	}
	public String getQtdHoras() {
		return qtdHoras;
	}
	public void setQtdHoras(String qtdHoras) {
		this.qtdHoras = qtdHoras;
	}
}
