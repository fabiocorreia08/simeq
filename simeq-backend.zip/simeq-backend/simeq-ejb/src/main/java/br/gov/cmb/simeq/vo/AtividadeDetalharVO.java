package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.MesEnum;
import br.gov.cmb.simeq.utils.ConverterHorasMinutosUtil;

public class AtividadeDetalharVO implements Serializable {

	private static final long serialVersionUID = 6990790245875093132L;
	
	private String numeroSolicitacao;
	private String classeManutencao;
	private String dataCadastroManutencao;
	private String matriculaExecutante;
	private String nomeExecutante;
	private String hierarquiaCentroCustoEquipamento;
	private String equipamento;
	private String grupo;
	private String subgrupo;
	private String acao;
	private String componente;
	private String horasAtividade;
	private String mesReferencia;
	private String observacao;
	private List<MaterialDetalharVO> materiais;
	private char tipoManutencao;
	private BigDecimal salario;
	private String horasComParalisacao;
	private String horasSemParalisacao;
	
	public AtividadeDetalharVO(){}
	
	public AtividadeDetalharVO(String numeroSolicitacao,  ClasseManutencaoEnum classeManutencao, Date dataCadastroManutencao, String matriculaExecutante, String nomeExecutante,
			String hierarquiaCentroCustoEquipamento, String equipamento, String grupo, String subgrupo, String acao, String componente, Integer horasTrabalhadas, Integer minutosTrabalhados,
			Integer mesReferencia, String observacao, BigDecimal salario, Integer horasSemParalisacao, Integer minutosSemParalisacao,
			Integer horasComParalisacao, Integer minutosComParalisacao){
		this.numeroSolicitacao = numeroSolicitacao;
		this.classeManutencao = classeManutencao.getDescricao();
		this.dataCadastroManutencao = DataUtils.formatar(dataCadastroManutencao, DataUtils.FORMATO_HORA_DDMMYYYY_HHMM);
		this.matriculaExecutante = matriculaExecutante;
		this.nomeExecutante = nomeExecutante;
		this.hierarquiaCentroCustoEquipamento = hierarquiaCentroCustoEquipamento;
		this.equipamento = equipamento;
		this.grupo = grupo;
		this.subgrupo = subgrupo;
		this.acao = acao;
		this.componente = componente;
		formatarHorasMinutosAtividade(horasTrabalhadas, minutosTrabalhados);
		this.mesReferencia = MesEnum.getDescricaoMesPorCodigo(mesReferencia);
		this.observacao = observacao;
		this.setTipoManutencao(ClasseManutencaoEnum.C.name().charAt(0));
		this.salario = salario;
		this.horasComParalisacao = ConverterHorasMinutosUtil.getTextoHora(horasComParalisacao, minutosComParalisacao);
		this.horasSemParalisacao = ConverterHorasMinutosUtil.getTextoHora(horasSemParalisacao, minutosSemParalisacao);
	}
	
	public AtividadeDetalharVO(String numeroSolicitacao,  Date dataCadastroManutencao, String matriculaExecutante, String nomeExecutante,
			String hierarquiaCentroCustoEquipamento, String equipamento, String grupo, String subgrupo, String acao, String componente, 
			 String observacao, BigDecimal salario, Integer horasTrabalhadas, Integer minutosTrabalhados){
		this.numeroSolicitacao = numeroSolicitacao;
		this.classeManutencao = ClasseManutencaoEnum.P.getDescricao();
		this.dataCadastroManutencao = DataUtils.formatar(dataCadastroManutencao, DataUtils.FORMATO_HORA_DDMMYYYY_HHMM);
		this.matriculaExecutante = matriculaExecutante;
		this.nomeExecutante = nomeExecutante;
		this.hierarquiaCentroCustoEquipamento = hierarquiaCentroCustoEquipamento;
		this.equipamento = equipamento;
		this.grupo = grupo;
		this.subgrupo = subgrupo;
		this.acao = acao;
		this.componente = componente;
		this.observacao = observacao;
		this.setTipoManutencao(ClasseManutencaoEnum.P.name().charAt(0));
		this.salario = salario;
		formatarHorasMinutosAtividade(horasTrabalhadas, minutosTrabalhados);
	}

	private void formatarHorasMinutosAtividade(Integer horasTrabalhadas, Integer minutosTrabalhados) {
		String horas = horasTrabalhadas.toString();
		String minutos = minutosTrabalhados.toString();
		while (horas.length() < 3) {
			horas = "0" + horas;
		}
		while (minutos.length() < 2) {
			minutos = "0" + minutos;
		}
		this.horasAtividade = horas.concat(":").concat(minutos);
	}
	
	public String getHorasComParalisacao() {
		return horasComParalisacao;
	}

	public void setHorasComParalisacao(String horasComParalisacao) {
		this.horasComParalisacao = horasComParalisacao;
	}

	public String getHorasSemParalisacao() {
		return horasSemParalisacao;
	}

	public void setHorasSemParalisacao(String horasSemParalisacao) {
		this.horasSemParalisacao = horasSemParalisacao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public String getDataCadastroManutencao() {
		return dataCadastroManutencao;
	}

	public void setDataCadastroManutencao(String dataCadastroManutencao) {
		this.dataCadastroManutencao = dataCadastroManutencao;
	}

	public String getMatriculaExecutante() {
		return matriculaExecutante;
	}

	public void setMatriculaExecutante(String matriculaExecutante) {
		this.matriculaExecutante = matriculaExecutante;
	}

	public String getNomeExecutante() {
		return nomeExecutante;
	}

	public void setNomeExecutante(String nomeExecutante) {
		this.nomeExecutante = nomeExecutante;
	}

	public String getHierarquiaCentroCustoEquipamento() {
		return hierarquiaCentroCustoEquipamento;
	}

	public void setHierarquiaCentroCustoEquipamento(String hierarquiaCentroCustoEquipamento) {
		this.hierarquiaCentroCustoEquipamento = hierarquiaCentroCustoEquipamento;
	}

	public String getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(String equipamento) {
		this.equipamento = equipamento;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public String getSubgrupo() {
		return subgrupo;
	}

	public void setSubgrupo(String subgrupo) {
		this.subgrupo = subgrupo;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public String getComponente() {
		return componente;
	}

	public void setComponente(String componente) {
		this.componente = componente;
	}

	public String getHorasAtividade() {
		return horasAtividade;
	}

	public void setHorasAtividade(String horasAtividade) {
		this.horasAtividade = horasAtividade;
	}

	public String getMesReferencia() {
		return mesReferencia;
	}

	public void setMesReferencia(String mesReferencia) {
		this.mesReferencia = mesReferencia;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public List<MaterialDetalharVO> getMateriais() {
		return materiais;
	}

	public void setMateriais(List<MaterialDetalharVO> materiais) {
		this.materiais = materiais;
	}

	public char getTipoManutencao() {
		return tipoManutencao;
	}

	public void setTipoManutencao(char tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}

	public BigDecimal getSalario() {
		return salario;
	}

	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}
	
	
}
