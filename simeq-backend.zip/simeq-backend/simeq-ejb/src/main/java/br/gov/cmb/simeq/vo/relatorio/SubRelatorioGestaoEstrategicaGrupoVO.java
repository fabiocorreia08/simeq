package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

public class SubRelatorioGestaoEstrategicaGrupoVO implements Serializable {

	private static final long serialVersionUID = -522094626705217L;

	private String codigoEquipamento;
	private String equipamento;
	private String grupo;
	private String tempoComParalisacao;
	private Double custoTotal;

	public SubRelatorioGestaoEstrategicaGrupoVO() {
		super();
	}

	public SubRelatorioGestaoEstrategicaGrupoVO(String codigoEquipamento, String equipamento, String grupo,
			String tempoComParalisacao, Double custoTotal) {
		super();
		this.codigoEquipamento = codigoEquipamento;
		this.equipamento = equipamento;
		this.grupo = grupo;
		this.tempoComParalisacao = tempoComParalisacao;
		this.custoTotal = custoTotal;
	}

	public String getCodigoEquipamento() {
		return codigoEquipamento;
	}

	public void setCodigoEquipamento(String codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}

	public String getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(String equipamento) {
		this.equipamento = equipamento;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public String getTempoComParalisacao() {
		return tempoComParalisacao;
	}

	public void setTempoComParalisacao(String tempoComParalisacao) {
		this.tempoComParalisacao = tempoComParalisacao;
	}

	public Double getCustoTotal() {
		return custoTotal;
	}

	public void setCustoTotal(Double custoTotal) {
		this.custoTotal = custoTotal;
	}

}
