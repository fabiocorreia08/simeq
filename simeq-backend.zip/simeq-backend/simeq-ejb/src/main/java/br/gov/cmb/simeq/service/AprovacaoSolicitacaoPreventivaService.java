package br.gov.cmb.simeq.service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.simeq.dto.AprovacaoReprovacaoManutencaoPreventivaDTO;

@Stateless
public class AprovacaoSolicitacaoPreventivaService {


	@Inject
	private HistoricoStatusManutencaoPreventivaService historicoStatusManutencaoPreventivaService;
	
	public void reprovar(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		historicoStatusManutencaoPreventivaService.reprovar(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
	
	public void aprovar(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		historicoStatusManutencaoPreventivaService.aprovar(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
	
	public void enviarEmailAprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		historicoStatusManutencaoPreventivaService.enviarEmailAprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}

	public void enviarEmailReprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		historicoStatusManutencaoPreventivaService.enviarEmailReprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO);
	}
}
