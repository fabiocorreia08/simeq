package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

import br.gov.cmb.common.util.DataUtils;

public class AlocacaoDetalharVO implements Serializable {

	private static final long serialVersionUID = -3172205367054957372L;
	
	private String matriculaTecnico;
	private String nomeTecnico;
	private String cargo;
	private String turno;
	private String dataAlocacao;
	private String nomeResponsavelPelaAlocacao;
	
	public AlocacaoDetalharVO(String matriculaTecnico, String nomeTecnico, String cargo, Date dataAlocacao, String nomeResponsavelPelaAlocacao, String turno) {
		this.matriculaTecnico = matriculaTecnico;
		this.nomeTecnico = nomeTecnico;
		this.cargo = cargo;
		this.dataAlocacao = DataUtils.formatar(dataAlocacao, DataUtils.FORMATO_HORA_DDMMYYYY_HHMM);
		this.nomeResponsavelPelaAlocacao = nomeResponsavelPelaAlocacao;
		this.turno = turno;
	}
	
	public String getMatriculaTecnico() {
		return matriculaTecnico;
	}
	
	public void setMatriculaTecnico(String matriculaTecnico) {
		this.matriculaTecnico = matriculaTecnico;
	}
	
	public String getNomeTecnico() {
		return nomeTecnico;
	}
	
	public void setNomeTecnico(String nomeTecnico) {
		this.nomeTecnico = nomeTecnico;
	}
	
	public String getCargo() {
		return cargo;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public String getTurno() {
		return turno;
	}
	
	public void setTurno(String turno) {
		this.turno = turno;
	}
	
	public String getDataAlocacao() {
		return dataAlocacao;
	}
	
	public void setDataAlocacao(String dataAlocacao) {
		this.dataAlocacao = dataAlocacao;
	}
	
	public String getNomeResponsavelPelaAlocacao() {
		return nomeResponsavelPelaAlocacao;
	}
	
	public void setNomeResponsavelPelaAlocacao(String nomeResponsavelPelaAlocacao) {
		this.nomeResponsavelPelaAlocacao = nomeResponsavelPelaAlocacao;
	}

}
