package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;

import com.google.common.base.Objects;

import br.gov.cmb.simeq.dto.DashboardDTO;
import br.gov.cmb.simeq.dto.HistoricoDataDTO;

@Entity
@Table(name = "STT_MANUTENCAO_CORRETIVA")
@SqlResultSetMappings({
		@SqlResultSetMapping(name = "dashboardMapping", classes = {
				@ConstructorResult(targetClass = DashboardDTO.class, columns = {
						@ColumnResult(name = "ID_STATUS", type = Integer.class),
						@ColumnResult(name = "NM_STATUS", type = String.class),
						@ColumnResult(name = "TOTAL", type = Integer.class) }) }),
		@SqlResultSetMapping(name = "historicoDataMapping", classes = {
				@ConstructorResult(targetClass = HistoricoDataDTO.class, columns = {
						@ColumnResult(name = "dataCriacao", type = Date.class),
						@ColumnResult(name = "idStatus", type = Long.class),
						@ColumnResult(name = "dataStatus", type = Date.class) }) })

})
@NamedNativeQueries({
		@NamedNativeQuery(
				name = "dashboard", 
				query = "SELECT S.ID_STATUS, S.NM_STATUS, ISNULL(RESULT.CONTADOR, 0) AS TOTAL "
				+ "FROM STT_MANUTENCAO_CORRETIVA AS S " + "LEFT JOIN ( "
				+ "		SELECT DISTINCT S.ID_STATUS, S.NM_STATUS, COUNT(*) AS CONTADOR "
				+ "		FROM STT_MANUTENCAO_CORRETIVA AS S "
				+ "		LEFT JOIN RE_STT_MANUTENCAO_CORRETIVA AS SM ON SM.ID_STATUS = S.ID_STATUS "
				+ "		LEFT JOIN MANUTENCAO_CORRETIVA AS M ON M.ID_MANUTENCAO_CORRETIVA = SM.ID_MANUTENCAO_CORRETIVA "
				+ "		INNER JOIN SETOR_MANUTENCAO AS SETOR ON M.ID_SETOR_MANUTENCAO = SETOR.ID_SETOR_MANUTENCAO "
				+ "		WHERE (M.CD_CENTRO_CUSTO IN :listaCC OR SETOR.NM_SETOR_MANUTENCAO = :setor ) "
				+ "		AND SM.ID_SEQUENCIAL = ( SELECT MAX(M1.ID_SEQUENCIAL) FROM RE_STT_MANUTENCAO_CORRETIVA M1 WHERE M.ID_MANUTENCAO_CORRETIVA = M1.ID_MANUTENCAO_CORRETIVA) "
				+ "		GROUP BY S.ID_STATUS, S.NM_STATUS " + "		) AS RESULT "
				+ "ON S.ID_STATUS = RESULT.ID_STATUS; ", 
				resultSetMapping = "dashboardMapping"),
		@NamedNativeQuery(
				name = "historicoData", 
				query = "SELECT M.DT_CRIACAO as dataCriacao, S.ID_STATUS as idStatus, SC.DT_STATUS as dataStatus "
				+ "FROM STT_MANUTENCAO_CORRETIVA AS S "
				+ "INNER JOIN RE_STT_MANUTENCAO_CORRETIVA AS SC ON S.ID_STATUS = SC.ID_STATUS "
				+ "INNER JOIN MANUTENCAO_CORRETIVA AS M ON SC.ID_MANUTENCAO_CORRETIVA = M.ID_MANUTENCAO_CORRETIVA "
				+ "WHERE M.ID_MANUTENCAO_CORRETIVA = :idManutencao "
				+ "AND SC.ID_SEQUENCIAL = (SELECT MAX(SC2.ID_SEQUENCIAL) "
				+ "					   FROM RE_STT_MANUTENCAO_CORRETIVA AS SC2 "
				+ "					   WHERE M.ID_MANUTENCAO_CORRETIVA = SC2.ID_MANUTENCAO_CORRETIVA) ", 
				resultSetMapping = "historicoDataMapping"),

})
public class StatusManutencaoCorretiva implements Serializable {

	private static final long serialVersionUID = 8007129906825425698L;

	@Id
	@Column(name = "ID_STATUS")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "NM_STATUS")
	private String nome;

	@Column(name = "DS_STATUS")
	private String descricao;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof StatusManutencaoCorretiva)) {
			return false;
		}
		StatusManutencaoCorretiva castOther = (StatusManutencaoCorretiva) other;
		return Objects.equal(id, castOther.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}

}
