package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.entidade.AtividadeMaterialCorretiva;
import br.gov.cmb.simeq.entidade.AtividadeMaterialPreventiva;
import br.gov.cmb.simeq.vo.MaterialDetalharVO;

public class AtividadeMaterialPreventivaDAO extends GenericoPaginadoDAO<AtividadeMaterialCorretiva, Long>{

	private static final long serialVersionUID = -1738480253557624541L;

	public List<MaterialDetalharVO> buscarMaterialDetalharVOPorAtividade(Long idAtividade) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.MaterialDetalharVO(atividadeMaterial.id, materialView.codigo, atividadeMaterial.descricaoMaterialOutros, "
						+ "atividadeMaterial.nomeMaterialOutros, materialView.nome, atividadeMaterial.quantidadeMaterial, atividadeMaterial.descricaoUnidadeMedica)")
				.from(AtividadeMaterialPreventiva.class, "atividadeMaterial")
				.innerJoin("atividadeMaterial.atividade", "a")
				.leftJoin("atividadeMaterial.materialView", "materialView")
				.where("a.id = ?");
		return buscar(builder.builder(), MaterialDetalharVO.class, idAtividade);
	}

}
