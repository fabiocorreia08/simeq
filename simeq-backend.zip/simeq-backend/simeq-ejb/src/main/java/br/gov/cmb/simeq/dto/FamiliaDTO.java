package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.util.List;

public class FamiliaDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long id;	
	private String nomeFamilia;
	private List<FamiliaCCDTO> ccList;
	private List<FamiliaSetorDTO> setorList;

	public FamiliaDTO() {
		super();
		
	}
	public FamiliaDTO(Long id, String nomeFamilia, List<FamiliaCCDTO> ccList, List<FamiliaSetorDTO> setorList) {
		super();
		this.id = id;
		this.nomeFamilia = nomeFamilia;
		this.ccList = ccList;
		this.setorList = setorList;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNomeFamilia() {
		return nomeFamilia;
	}

	public void setNomeFamilia(String nome) {
		this.nomeFamilia = nome;
	}
	public List<FamiliaCCDTO> getccList() {
		return ccList;
	}
	public void setccList(List<FamiliaCCDTO> ccList) {
		this.ccList = ccList;
	}
	public List<FamiliaSetorDTO> getSetorList() {
		return setorList;
	}
	public void setSetorList(List<FamiliaSetorDTO> setorList) {
		this.setorList = setorList;
	}
	
}
