package br.gov.cmb.simeq.dto;

import java.io.Serializable;

public class FuncionamentoMaquinaDiaDTO implements Serializable {

	private static final long serialVersionUID = -7539615172240726068L;

	private Long id;
	private Integer dia;
	private Integer quantidadeHoras;

	public FuncionamentoMaquinaDiaDTO(Long id, Integer dia, Integer quantidadeHoras) {
		super();
		this.id = id;
		this.dia = dia;
		this.quantidadeHoras = quantidadeHoras;
	}

	public FuncionamentoMaquinaDiaDTO(Integer dia, Integer quantidadeHoras) {
		super();
		this.dia = dia;
		this.quantidadeHoras = quantidadeHoras;
	}

	public FuncionamentoMaquinaDiaDTO() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getDia() {
		return dia;
	}

	public void setDia(Integer dia) {
		this.dia = dia;
	}

	public Integer getQuantidadeHoras() {
		return quantidadeHoras;
	}

	public void setQuantidadeHoras(Integer quantidadeHoras) {
		this.quantidadeHoras = quantidadeHoras;
	}

}
