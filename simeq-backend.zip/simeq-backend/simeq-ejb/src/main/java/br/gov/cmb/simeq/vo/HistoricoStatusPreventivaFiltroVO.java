package br.gov.cmb.simeq.vo;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class HistoricoStatusPreventivaFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 3541888269311110557L;
	
	@ParametroNomeado
	private String numeroSolicitacao;

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

}
