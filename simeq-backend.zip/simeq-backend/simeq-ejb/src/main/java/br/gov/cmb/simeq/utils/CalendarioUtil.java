package br.gov.cmb.simeq.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CalendarioUtil {

	public static String formatarDataHora(Date data) {
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return format.format(data);
	}
	
	public static String formatarDataHoraBr(Date data) {
		
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		return format.format(data);
	}
	
public static String formatarData(Date data) {
		
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		return format.format(data);
	}
}
