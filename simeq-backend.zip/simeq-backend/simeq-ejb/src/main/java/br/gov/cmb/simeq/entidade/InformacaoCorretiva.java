package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;

@Audited
@Entity
@Table(name = "INFORMACAO_CORRETIVA")
public class InformacaoCorretiva implements Serializable{
	
	private static final long serialVersionUID = 6412404898280296332L;

	@Id
	@Column(name = "ID_INFORMACAO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "CD_MATRIC_FUNC", length = 4000)
	private String codigoMatriculaFuncionario;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DT_CADASTRO")
	private Date dataCadastro;
	
	@Column(name = "DS_INFORMACAO", length = 800)
	private String descricaoInformacao;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REFRESH)
	@JoinColumns({
		@JoinColumn(name = "ID_MANUTENCAO_CORRETIVA", referencedColumnName = "ID_MANUTENCAO_CORRETIVA"),
		@JoinColumn(name = "ID_STATUS", referencedColumnName = "ID_STATUS"),
		@JoinColumn(name = "ID_SEQUENCIAL", referencedColumnName = "ID_SEQUENCIAL")
    })
	private HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva;

	public InformacaoCorretiva() {
	}
	
	public InformacaoCorretiva(String codigoMatriculaFuncionario, Date dataCadsatro, String descricaoInformacao) {
		this.codigoMatriculaFuncionario = codigoMatriculaFuncionario;
		this.dataCadastro = dataCadsatro;
		this.descricaoInformacao = descricaoInformacao;
	}

	public InformacaoCorretiva(String codigoMatriculaFuncionario, Date dataCadsatro, String descricaoInformacao,
			HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva) {
		this.codigoMatriculaFuncionario = codigoMatriculaFuncionario;
		this.dataCadastro = dataCadsatro;
		this.descricaoInformacao = descricaoInformacao;
		this.historicoStatusManutencaoCorretiva = historicoStatusManutencaoCorretiva;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigoMatriculaFuncionario() {
		return codigoMatriculaFuncionario;
	}

	public void setCodigoMatriculaFuncionario(String codigoMatriculaFuncionario) {
		this.codigoMatriculaFuncionario = codigoMatriculaFuncionario;
	}

	public Date getDataCadsatro() {
		return dataCadastro;
	}

	public void setDataCadsatro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public String getDescricaoInformacao() {
		return descricaoInformacao;
	}

	public void setDescricaoInformacao(String descricaoInformacao) {
		this.descricaoInformacao = descricaoInformacao;
	}

	public HistoricoStatusManutencaoCorretiva getHistoricoStatusManutencaoCorretiva() {
		return historicoStatusManutencaoCorretiva;
	}

	public void setHistoricoStatusManutencaoCorretiva(
			HistoricoStatusManutencaoCorretiva historicoStatusManutencaoCorretiva) {
		this.historicoStatusManutencaoCorretiva = historicoStatusManutencaoCorretiva;
	}
	
	

}
