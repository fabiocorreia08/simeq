package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class AtividadeMaterialVO implements Serializable {

	private static final long serialVersionUID = -8923347388782582243L;
	
	private Long id;
	private Long idAtividade;
	private String codigoMaterial;
	private int sequencialMaterial;
	private String nomeMaterial;
	private String descricaoMaterialOutros;
	private String nomeMaterialOutros;
	private String quantidadeMaterial;
	private String descricaoUnidadeMedida;
	private BigDecimal quantidadeMaterialDecimal;
	private boolean codificado;
	
	public AtividadeMaterialVO(){}
	
	public AtividadeMaterialVO(Long id, Long idAtividade, String codigoMaterial, String descricaoMaterialOutros, String nomeMaterialOutros, BigDecimal quantidadeMaterial, String descricaoUnidadeMedida,
			int sequencialMaterial, String nomeMaterial){
		this.id = id;
		this.idAtividade = idAtividade;
		this.codigoMaterial = codigoMaterial;
		this.descricaoMaterialOutros = descricaoMaterialOutros;
		this.nomeMaterialOutros = nomeMaterialOutros;
		this.quantidadeMaterial = quantidadeMaterial.toString().replace(".", ",");
		this.descricaoUnidadeMedida = descricaoUnidadeMedida;
		this.sequencialMaterial = sequencialMaterial;
		this.nomeMaterial = nomeMaterial;
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getIdAtividade() {
		return idAtividade;
	}
	
	public void setIdAtividade(Long idAtividade) {
		this.idAtividade = idAtividade;
	}
	
	public String getCodigoMaterial() {
		return codigoMaterial;
	}
	
	public void setCodigoMaterial(String codigoMaterial) {
		this.codigoMaterial = codigoMaterial;
	}
	
	public String getDescricaoMaterialOutros() {
		return descricaoMaterialOutros;
	}
	
	public void setDescricaoMaterialOutros(String descricaoMaterialOutros) {
		this.descricaoMaterialOutros = descricaoMaterialOutros;
	}
	
	public String getQuantidadeMaterial() {
		return quantidadeMaterial;
	}
	
	public void setQuantidadeMaterial(String quantidadeMaterial) {
		this.quantidadeMaterial = quantidadeMaterial;
	}

	public String getDescricaoUnidadeMedida() {
		return descricaoUnidadeMedida;
	}

	public void setDescricaoUnidadeMedida(String descricaoUnidadeMedida) {
		this.descricaoUnidadeMedida = descricaoUnidadeMedida;
	}

	public int getSequencialMaterial() {
		return sequencialMaterial;
	}

	public void setSequencialMaterial(int sequencialMaterial) {
		this.sequencialMaterial = sequencialMaterial;
	}

	public String getNomeMaterial() {
		return nomeMaterial;
	}

	public void setNomeMaterial(String nomeMaterial) {
		this.nomeMaterial = nomeMaterial;
	}
	
	public BigDecimal getQuantidadeMaterialDecimal() {
		DecimalFormat nf = (DecimalFormat) NumberFormat.getInstance(new Locale("pt", "BR"));
		nf.setParseBigDecimal(true);
		BigDecimal quantidadeMaterial = new BigDecimal(0);
		try {
			quantidadeMaterial = (BigDecimal) nf.parse(this.quantidadeMaterial);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		this.quantidadeMaterialDecimal = quantidadeMaterial;
		return quantidadeMaterialDecimal;
	}

	public void setQuantidadeMaterialDecimal(BigDecimal quantidadeMaterialDecimal) {
		this.quantidadeMaterialDecimal = quantidadeMaterialDecimal;
	}

	public boolean isCodificado() {
		return codificado;
	}

	public void setCodificado(boolean codificado) {
		this.codificado = codificado;
	}

	public String getNomeMaterialOutros() {
		return nomeMaterialOutros;
	}

	public void setNomeMaterialOutros(String nomeMaterialOutros) {
		this.nomeMaterialOutros = nomeMaterialOutros;
	}
}
