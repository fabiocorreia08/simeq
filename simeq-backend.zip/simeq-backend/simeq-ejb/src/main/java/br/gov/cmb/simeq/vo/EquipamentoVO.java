package br.gov.cmb.simeq.vo;

import java.util.Date;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class EquipamentoVO extends ModeloVO {

	private static final long serialVersionUID = 1L;
	
	
	@ParametroNomeado
	private String codigoManutencao;
	
	@ParametroNomeado(like = true)
	private String nomeEquipamento;
	
	@ParametroNomeado
	private Long numeroAno;
	
	@ParametroNomeado
	private String flagStatus;
	
	@ParametroNomeado
	private String codigoCentroCusto;
	
	@ParametroNomeado
	private Date dataInstalacao;
	 

	public String getCodigoManutencao() {
		return codigoManutencao;
	}

	public void setCodigoManutencao(String codigoManutencao) {
		this.codigoManutencao = codigoManutencao;
	}

	public String getNomeEquipamento() {
		return nomeEquipamento;
	}

	public void setNomeEquipamento(String nomeEquipamento) {
		this.nomeEquipamento = nomeEquipamento;
	}

	public Long getNumeroAno() {
		return numeroAno;
	}

	public void setNumeroAno(Long numeroAno) {
		this.numeroAno = numeroAno;
	}

	public String getFlagStatus() {
		return flagStatus;
	}

	public void setFlagStatus(String flagStatus) {
		this.flagStatus = flagStatus;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public Date getDataInstalacao() {
		return dataInstalacao;
	}

	public void setDataInstalacao(Date dataInstalacao) {
		this.dataInstalacao = dataInstalacao;
	}
	
	
	
}
