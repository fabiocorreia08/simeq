package br.gov.cmb.simeq.schedule;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.cmb.common.ejb.scheduler.AbstractScheduler;
import br.gov.cmb.common.util.PropertiesUtils;
import br.gov.cmb.simeq.service.ManutencaoPreventivaService;

@LocalBean
@Startup
@Singleton
public class AprovarPreventivaSchedule extends AbstractScheduler {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AprovarPreventivaSchedule.class);
	private static final String DIA_MES="*";
	private static final String HORA_APROVAR_PREVENTIVA = "simeq.parametro.horasAprovarPreventiva";
	private static final String MINUTOS_APROVAR_PREVENTIVA = "simeq.parametro.minutosAprovarPreventiva";
	
	@Inject
	private ManutencaoPreventivaService manutencaoPreventivaService;

	@Override
	public void execute() {
		try {
			LOGGER.info("INICIO DA EXECUCAO ROTINA APROVAR PREVENTIVA");
			manutencaoPreventivaService.aprovarManutencaoQuinzeDias();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	@Override
	public String getDiaDoMes() {
		return DIA_MES;
	}

	@Override
	public String getDiaSemana() {
		return "*";
	}

	@Override
	public String getHora() {
		return PropertiesUtils.getProperty(HORA_APROVAR_PREVENTIVA);
	}

	@Override
	public String getMinutos() {
		return PropertiesUtils.getProperty(MINUTOS_APROVAR_PREVENTIVA);
	}

	@Override
	public String getNome() {
		return "Verficação de Manutenção Preventiva Para Aprovar";
	}

}
