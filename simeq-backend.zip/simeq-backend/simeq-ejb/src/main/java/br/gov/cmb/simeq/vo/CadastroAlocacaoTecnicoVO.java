package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.List;

public class CadastroAlocacaoTecnicoVO implements Serializable {

	private static final long serialVersionUID = -6151427763380549978L;
	
	private List<AlocacaoCadastrarVO> listaAlocacaoCadastroTabela;
	private List<AlocacaoCadastrarVO> listaAlocacaoRemovidasDaBase;
	private String numeroSolicitacao;
	private String matriculaUsuarioLogado;
	private String nomeUsuarioLogado;
	
	public List<AlocacaoCadastrarVO> getListaAlocacaoCadastroTabela() {
		return listaAlocacaoCadastroTabela;
	}

	public void setListaAlocacaoCadastroTabela(List<AlocacaoCadastrarVO> listaAlocacaoCadastroTabela) {
		this.listaAlocacaoCadastroTabela = listaAlocacaoCadastroTabela;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public List<AlocacaoCadastrarVO> getListaAlocacaoRemovidasDaBase() {
		return listaAlocacaoRemovidasDaBase;
	}

	public void setListaAlocacaoRemovidasDaBase(List<AlocacaoCadastrarVO> listaAlocacaoRemovidasDaBase) {
		this.listaAlocacaoRemovidasDaBase = listaAlocacaoRemovidasDaBase;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public String getNomeUsuarioLogado() {
		return nomeUsuarioLogado;
	}

	public void setNomeUsuarioLogado(String nomeUsuarioLogado) {
		this.nomeUsuarioLogado = nomeUsuarioLogado;
	}
	
	
}
