package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.simeq.dao.SetorManutencaoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;

@Stateless
public class SetorManutencaoService {
	
	@Inject
	private SetorManutencaoDAO setorManutencaoDAO;
	
	public List<LabelValueDTO> buscarTodosSetores(){
		return setorManutencaoDAO.buscarTodosSetores();
	}
	
	public List<LabelValueDTO> buscarPorIdFamilia(Long idFamilia){
		return setorManutencaoDAO.buscarPorIdFamilia(idFamilia);
	}
}
