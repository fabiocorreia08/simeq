package br.gov.cmb.simeq.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.common.base.Strings;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;

public class GeradorNumeroSolicitacao {
	

	private static SimpleDateFormat df = new SimpleDateFormat("yyyy");
	
	public static String gerar(String ultimoNumeroGerado, Date dataCriacaoUltimaManutencao, String setor, boolean isManutencaoCorretiva) {
		String letrasIniciais = isManutencaoCorretiva ? IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA.getDescricao() : IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA.getDescricao();
		StringBuilder numeroSolicitacao = new StringBuilder();
		if(Strings.isNullOrEmpty(ultimoNumeroGerado) || Integer.parseInt(df.format(dataCriacaoUltimaManutencao)) < DataUtils.getAnoAtual()) {
			numeroSolicitacao.append(letrasIniciais)
					.append(setor)
					.append(String.valueOf(DataUtils.getAnoAtual()))
					.append("0001");
			return numeroSolicitacao.toString();
		}
		String numeroSolicitacaoInvertido = new StringBuilder(ultimoNumeroGerado).reverse().toString();
		String sequencialInvertido = numeroSolicitacaoInvertido.substring(0, 4); 
		String sequencial = new StringBuilder(sequencialInvertido).reverse().toString();
		int sequencialNumerico = Integer.valueOf(sequencial);
		sequencialNumerico++;
		StringBuilder novoSequencial = new StringBuilder();
		while (novoSequencial.length() < 4) {
			String sequencialFinal = novoSequencial.toString();
			if(sequencialFinal.concat(String.valueOf(sequencialNumerico)).length() == 4) {
				novoSequencial.append(String.valueOf(sequencialNumerico));
			} else {
				novoSequencial.append("0");
			}
			
		}
		numeroSolicitacao.append(letrasIniciais)
				.append(setor)
				.append(String.valueOf(DataUtils.getAnoAtual()))
				.append(novoSequencial.toString());
		return numeroSolicitacao.toString();
	}

}
