package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ManutencaoCorretivaTecnicoId implements Serializable {

	private static final long serialVersionUID = -8283815310278783314L;
	
	@Column(name = "ID_MANUTENCAO_CORRETIVA")
	private Long idManutencaoCorretiva;
	
	@Column(name = "ID_TECNICO")
	private Long idTecnico;
	
	public ManutencaoCorretivaTecnicoId(){}
	
	public ManutencaoCorretivaTecnicoId(Long idManutencaoCorretiva, Long idTecnico) {
		this.idManutencaoCorretiva = idManutencaoCorretiva;
		this.idTecnico = idTecnico;
	}

	public Long getIdManutencaoCorretiva() {
		return idManutencaoCorretiva;
	}

	public void setIdManutencaoCorretiva(Long idManutencaoCorretiva) {
		this.idManutencaoCorretiva = idManutencaoCorretiva;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}
}
