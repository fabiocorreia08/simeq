package br.gov.cmb.simeq.dto;

public class HorasMinutosDTO {

	private Long horas;
	private Long minutos;

	public HorasMinutosDTO() {
		super();
	}

	public HorasMinutosDTO(Long minutos) {
		super();
		if (minutos > 59) {
			this.horas = minutos / 60;
			this.minutos = minutos % 60;
		} else {
			this.horas = null;
			this.minutos = minutos;
		}

	}

	public Long getHoras() {
		return horas;
	}

	public void setHoras(Long horas) {
		this.horas = horas;
	}

	public Long getMinutos() {
		return minutos;
	}

	public void setMinutos(Long minutos) {
		this.minutos = minutos;
	}
}
