package br.gov.cmb.simeq.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dao.AtividadePreventivaDAO;
import br.gov.cmb.simeq.dao.HistStatusManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.StatusManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.vo.HistoricoStatusPreventivaVO;

@Stateless
public class StatusManutencaoPreventivaService {
	
	@Inject
	private StatusManutencaoPreventivaDAO statusManutencaoPreventivaDAO;
	
	@Inject
	private HistStatusManutencaoPreventivaDAO histStatusManutencaoPreventivaDAO;
	
	@Inject
	private AtividadePreventivaDAO atividadePreventivaDAO;
	
	public List<LabelValueDTO> buscarStatusCombo(Long idManutencao) {
		HistoricoStatusManutencaoPreventiva status = histStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInserido(idManutencao);
		List<Long> idsStatusBuscar = StatusManutencaoPreventivaEnum.getStatus(status.getId().getIdStatusManutencao()).getIdsStatusCombo();
		if(StatusManutencaoPreventivaEnum.getStatus(status.getId().getIdStatusManutencao()).isVerificarAtividadeCadastrada()) {
			AtividadePreventiva atividadePreventiva = atividadePreventivaDAO.buscarPorIdManutencao(idManutencao);
			if(atividadePreventiva == null) {
				idsStatusBuscar.remove(StatusManutencaoPreventivaEnum.CONCLUIDA.getCodigo());
			}
		}
		List<LabelValueDTO> statusLabelValue = statusManutencaoPreventivaDAO.buscarStatusCombo(idsStatusBuscar);
		statusLabelValue.add(new LabelValueDTO(status.getStatusManutencaoPreventiva().getNome(), status.getId().getIdStatusManutencao()));
		return statusLabelValue;
	}
	
	public Pagina<HistoricoStatusPreventivaVO> filtrar(Pagina<HistoricoStatusPreventivaVO> pagina) {
		return histStatusManutencaoPreventivaDAO.filtrar(pagina);
	}

	public List<LabelValueDTO> buscarTodos() {
		return this.statusManutencaoPreventivaDAO.buscar().stream().map(s -> new LabelValueDTO(s.getNome(), s.getId())).collect(Collectors.toList());
	}
}
