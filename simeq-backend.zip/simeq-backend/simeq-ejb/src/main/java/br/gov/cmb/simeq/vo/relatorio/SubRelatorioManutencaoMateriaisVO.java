package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;
import java.math.BigDecimal;

import com.google.common.base.Strings;

public class SubRelatorioManutencaoMateriaisVO implements Serializable {

	private static final long serialVersionUID = 8011004937592654329L;
	
	private String codigoMaterial;
	private String descricao;
	private String quantidadeMaterial;
	
	SubRelatorioManutencaoMateriaisVO(){}
	
	public SubRelatorioManutencaoMateriaisVO(String descricaoMaterialOutros, String codigoView, String descricao, BigDecimal quantidadeMaterial) {
		this.codigoMaterial = Strings.isNullOrEmpty(descricaoMaterialOutros) ? codigoView : descricaoMaterialOutros;
		this.descricao = Strings.isNullOrEmpty(descricao) ? "" : descricao;
		this.quantidadeMaterial = quantidadeMaterial.toString().replace(".", ",");
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getCodigoMaterial() {
		return codigoMaterial;
	}

	public void setCodigoMaterial(String codigoMaterial) {
		this.codigoMaterial = codigoMaterial;
	}

	public String getQuantidadeMaterial() {
		return quantidadeMaterial;
	}

	public void setQuantidadeMaterial(String quantidadeMaterial) {
		this.quantidadeMaterial = quantidadeMaterial;
	}
	
	
}
