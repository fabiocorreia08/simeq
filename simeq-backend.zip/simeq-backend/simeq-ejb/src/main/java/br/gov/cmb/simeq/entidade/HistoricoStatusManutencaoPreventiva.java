package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import com.google.common.base.Objects;

@Audited
@Entity
@Table(name = "RE_STT_MANUTENCAO_PREVENTIVA")
public class HistoricoStatusManutencaoPreventiva implements Serializable{

	private static final long serialVersionUID = -8743434295999016974L;
	
	@Id
	private HistStatusManutencaoPreventivaId id;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MANUTENCAO_PREVENTIVA", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private ManutencaoPreventiva manutencaoPreventiva;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_STATUS", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private StatusManutencaoPreventiva statusManutencaoPreventiva;
	
	@Column(name = "DT_STATUS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "CD_MATRIC_STATUS")
	private String matriculaUsuario;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CD_MATRIC_STATUS", insertable = false, updatable = false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private PessoaView usuarioResponsavelPelaAlteracao;
	
	@Column(name = "DS_STATUS")
	private String descricaoStatus;

	public HistoricoStatusManutencaoPreventiva(){}
	
	public HistoricoStatusManutencaoPreventiva(Long idManutencaoPreventiva, Long idStatusManutencao, Long idSequencial, String matriculaUsuarioLogado) {
		this.id = new HistStatusManutencaoPreventivaId(idManutencaoPreventiva, idStatusManutencao, idSequencial);
		this.matriculaUsuario = matriculaUsuarioLogado;
	}
	

	public HistoricoStatusManutencaoPreventiva(Long idManutencaoPreventiva, Long idStatusManutencao, Long idSequencial, String matriculaUsuarioLogado, String descricaoStatus) {
		this.id = new HistStatusManutencaoPreventivaId(idManutencaoPreventiva, idStatusManutencao, idSequencial);
		this.usuarioResponsavelPelaAlteracao = new PessoaView(matriculaUsuarioLogado);
		this.matriculaUsuario = matriculaUsuarioLogado;
		this.descricaoStatus = descricaoStatus;
	}

	public HistStatusManutencaoPreventivaId getId() {
		return id;
	}

	public void setId(HistStatusManutencaoPreventivaId id) {
		this.id = id;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getMatriculaUsuario() {
		return matriculaUsuario;
	}

	public void setMatriculaUsuario(String matriculaUsuario) {
		this.matriculaUsuario = matriculaUsuario;
	}

	public PessoaView getUsuarioResponsavelPelaAlteracao() {
		return usuarioResponsavelPelaAlteracao;
	}

	public void setUsuarioResponsavelPelaAlteracao(PessoaView usuarioResponsavelPelaAlteracao) {
		this.usuarioResponsavelPelaAlteracao = usuarioResponsavelPelaAlteracao;
	}

	public String getDescricaoStatus() {
		return descricaoStatus;
	}

	public void setDescricaoStatus(String descricaoStatus) {
		this.descricaoStatus = descricaoStatus;
	}

	public ManutencaoPreventiva getManutencaoPreventiva() {
		return manutencaoPreventiva;
	}

	public void setManutencaoPreventiva(ManutencaoPreventiva manutencaoPreventiva) {
		this.manutencaoPreventiva = manutencaoPreventiva;
	}

	public StatusManutencaoPreventiva getStatusManutencaoPreventiva() {
		return statusManutencaoPreventiva;
	}

	public void setStatusManutencaoPreventiva(StatusManutencaoPreventiva statusManutencaoPreventiva) {
		this.statusManutencaoPreventiva = statusManutencaoPreventiva;
	}
	
	public Long getProximoSequencial() {
		Long sequencial = this.id.getIdSequencial(); 
		return sequencial + 1;
	}
	
	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof HistoricoStatusManutencaoPreventiva)) {
			return false;
		}
		HistoricoStatusManutencaoPreventiva castOther = (HistoricoStatusManutencaoPreventiva) other;
		return Objects.equal(id, castOther.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}
}
