package br.gov.cmb.simeq.enums;

public enum ParametroEnum {
	
	DEMAN(new Long(1)),
	CONCLUIDA_ATIVIDADE(new Long(2)),
	SETOR_MANUTENCAO(new Long(3)),
	TEMPO_REFRESH(new Long(4));
	
	private Long codigoParametro;
	
	private ParametroEnum(Long codigoParametro) {
		this.codigoParametro = codigoParametro;
	}

	public Long getCodigoParametro() {
		return codigoParametro;
	}
	
}
