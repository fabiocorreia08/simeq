package br.gov.cmb.simeq.service;

import java.io.BufferedInputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import org.apache.commons.lang.StringUtils;

import br.gov.cmb.common.exporter.VO.DocumentoRequestVO;
import br.gov.cmb.common.exporter.VO.DocumentoResponseVO;
import br.gov.cmb.common.exporter.util.ExporterUtil;
import br.gov.cmb.common.util.PropertiesUtils;
import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;
import br.gov.cmb.simeq.relatorio.vo.RelatorioRankEquipamentoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioCapacidadeProdutivaEquipamentoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaDiaVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaGrupoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaMaterialVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaParametrosVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaSolicitacaoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaAnualVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaVO;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

@Stateless
public class GerarRelatorioService implements Serializable {

	private static final long serialVersionUID = -8318109137397118964L;

	public static final String URL_SERVICO_EXPORTAR_PDF = "simeq.url.servicoExporter";
	public static final String NOME_RELATORIO_MANUTENCAO_CORRETIVA = "Relatorio_manutencao_corretiva";
	public static final String NOME_RELATORIO_MANUTENCAO_PREVENTIVA = "Relatorio_manutencao_preventiva";
	public static final String NOME_RELATORIO_MANUTENCAO_PREVENTIVA_ANUAL = "Relatorio_manutencao_preventiva_anual";
	public static final String NOME_RELATORIO_CAPACIDADE_PRODUTIVA_EQUIPAMENTO = "Relatorio_capacidade_produtiva_equipamento";
	public static final String NOME_RELATORIO_GESTAO_ESTRATEGICA = "Relatorio_gestao_estrategica";
	public static final String NOME_RELATORIO_RANK_EQUIPAMENTO = "Relatorio_rank_equipamento";
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public DocumentoResponseVO gerarRelatorioManutencaoCorretiva(RelatorioManutencaoCorretivaVO relatorio){
		DocumentoRequestVO documentoRequestVO = new DocumentoRequestVO(NOME_RELATORIO_MANUTENCAO_CORRETIVA, relatorio, StringUtils.EMPTY);
		return exportarDocumento(documentoRequestVO);
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public DocumentoResponseVO gerarRelatorioManutencaoPreventiva(RelatorioManutencaoPreventivaVO relatorio){
		DocumentoRequestVO documentoRequestVO = new DocumentoRequestVO(NOME_RELATORIO_MANUTENCAO_PREVENTIVA, relatorio, StringUtils.EMPTY);
		return exportarDocumento(documentoRequestVO);
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public byte[] gerarRelatorioManutencaoPreventivaAnual(RelatorioManutencaoPreventivaAnualVO relatorio){
		relatorio.setLogo(new BufferedInputStream(GerarRelatorioService.class.getClassLoader().getResourceAsStream("cmb-logo.png")));
		return this.gerarPdf(NOME_RELATORIO_MANUTENCAO_PREVENTIVA_ANUAL, relatorio);
	}
	
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public byte[] gerarRelatorioCapacidadeProdutivaEquipamento(RelatorioCapacidadeProdutivaEquipamentoVO relatorio){
		relatorio.setLogo(new BufferedInputStream(GerarRelatorioService.class.getClassLoader().getResourceAsStream("cmb-logo.png")));
		return this.gerarPdf(NOME_RELATORIO_CAPACIDADE_PRODUTIVA_EQUIPAMENTO, relatorio);
	}
	
	public byte[] gerarRelatorioGestaoEstrategica(RelatorioGestaoEstrategicaDiaVO relatorioDia, 
												  RelatorioGestaoEstrategicaGrupoVO relatorioGrupo,
												  RelatorioGestaoEstrategicaMaterialVO relatorioMaterial,
												  RelatorioGestaoEstrategicaSolicitacaoVO relatorioSolicitacao,
												  RelatorioGestaoEstrategicaParametrosVO relatorioParametros){
		relatorioParametros.setLogo(new BufferedInputStream(GerarRelatorioService.class.getClassLoader().getResourceAsStream("cmb-logo.png")));
		return this.gerarPdf(NOME_RELATORIO_GESTAO_ESTRATEGICA, relatorioDia, 
							relatorioGrupo, relatorioMaterial, relatorioSolicitacao, relatorioParametros);
	}
	 
	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public DocumentoResponseVO gerarRelatorioRankEquipamento(RelatorioRankEquipamentoVO relatorio){
		DocumentoRequestVO documentoRequestVO = new DocumentoRequestVO(NOME_RELATORIO_RANK_EQUIPAMENTO, relatorio, StringUtils.EMPTY);
		return exportarDocumento(documentoRequestVO);
	}
	
	private DocumentoResponseVO exportarDocumento(DocumentoRequestVO documentoRequestVO) {
		return ExporterUtil.exportarRelatorio(PropertiesUtils.getProperty(URL_SERVICO_EXPORTAR_PDF), documentoRequestVO);
	}

	private byte[] gerarPdf(String sourceFilename, Object ...parametros) {
	  Map<String, Object> parameters = new HashMap<String, Object>();
      parameters.put(JRParameter.REPORT_LOCALE, new Locale("pt", "BR"));
	  for(Object parametro: parametros) {
    	  if(parametro.getClass().isAnnotationPresent(ParametroRelatorioAnotacao.class)) {
	    	  parameters.put(parametro.getClass().getAnnotation(ParametroRelatorioAnotacao.class).nome(), parametro);
    	  }
      }
      try {
		 JasperReport jasperReport = JasperCompileManager.compileReport(GerarRelatorioService.class.getClassLoader().getResourceAsStream(sourceFilename+".jrxml"));
		 parameters.put(JRParameter.REPORT_LOCALE, new Locale("pt", "BR"));
         JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, new JREmptyDataSource());
		 return JasperExportManager.exportReportToPdf(jasperPrint);
		 } catch (JRException e) {
         e.printStackTrace();
      }
      return null;
   }
}
