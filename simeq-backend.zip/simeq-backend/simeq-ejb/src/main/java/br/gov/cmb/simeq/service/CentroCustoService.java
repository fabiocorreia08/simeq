package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.dao.CentroCustoDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dao.RealocacaoTecnicoDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.CentroCustoView;
import br.gov.cmb.simeq.entidade.CorpoTecnicoView;
import br.gov.cmb.simeq.entidade.RealocacaoTecnico;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.enums.PerfilEnum;

@Stateless
public class CentroCustoService {

	@Inject
	private CentroCustoDAO centroCustoDAO;
	
	@Inject
	private PessoaViewDAO pessoaDAO;
	
	@Inject
	private TecnicoDAO tecnicoDAO;
	
	@Inject
	private RealocacaoTecnicoDAO realocacaoTecnicoDAO;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;

	public List<LabelValueDTO> buscarTodos() {
		return centroCustoDAO.buscarTodos();
	}
	
	public List<LabelValueDTO> buscarTodosNomes() {
		return centroCustoDAO.buscarTodosNomes();
	}
	
	public List<LabelValueDTO> buscarTodosPorHierarquiaPerfil(Integer perfil, String matricula) {
		if(PerfilEnum.TECNICO.getIdPerfil().equals(perfil)) {
			Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(matricula);
			List<RealocacaoTecnico> realocacoes = realocacaoTecnicoDAO.buscarPor(tecnico.getIdTecnico());
			CorpoTecnicoView corpoTecnicoView = tecnicoDAO.buscarInformacoesTecnicoPor(matricula);
			if(!CollectionUtils.isNullOrEmpty(realocacoes)) {				
				RealocacaoTecnico realocacao = realocacoes.get(realocacoes.size() - 1);
				if(realocacao.isTecnicoPeriodoAlocaco()) {
					return centroCustoDAO.buscarHierarquiaCentroCustoView(realocacao.getCodigoCentroCusto());
				}
			}
			return centroCustoDAO.buscarHierarquiaCentroCustoView(corpoTecnicoView.getCentroCusto().getCodigoCentroCusto());
			
		}
		if(PerfilEnum.SOLICITANTE.getIdPerfil().equals(perfil) || PerfilEnum.GESTOR.getIdPerfil().equals(perfil)) {
			String centroCusto = pessoaDAO.buscarPorMatricula(matricula).getCentroCusto();
			return centroCustoDAO.buscarHierarquiaCentroCustoView(centroCusto);
		}
		return this.buscarTodos();
	}
	
	public List<String> buscarTodosPorHierarquiaPerfilTecnico(String matricula) {
		Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(matricula);
		List<RealocacaoTecnico> realocacoes = realocacaoTecnicoDAO.buscarPor(tecnico.getIdTecnico());
		CorpoTecnicoView corpoTecnicoView = tecnicoDAO.buscarInformacoesTecnicoPor(matricula);
		CentroCustoView centroCusto;			
		if(!CollectionUtils.isNullOrEmpty(realocacoes)) {				
			RealocacaoTecnico realocacao = realocacoes.get(realocacoes.size() - 1);
			if(realocacao.isTecnicoPeriodoAlocaco()) {
				return centroCustoDAO.buscarStringHierarquiaCentroCustoView(realocacao.getCodigoCentroCusto());
			}
		}
		centroCusto = centroCustoDAO.buscar(corpoTecnicoView.getCentroCusto().getCodigoCentroCusto());
		return centroCustoDAO.buscarStringHierarquiaCentroCustoView(centroCusto.getCodigoCentroCusto());
	}
	
	public List<String> getCentroCustoUsuarioLogado(Integer perfil, String matricula){
		if(PerfilEnum.TECNICO.getIdPerfil().equals(perfil)) {
			Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(matricula);
			List<RealocacaoTecnico> realocacoes = realocacaoTecnicoDAO.buscarPor(tecnico.getIdTecnico());
			CorpoTecnicoView corpoTecnicoView = tecnicoDAO.buscarInformacoesTecnicoPor(matricula);
			CentroCustoView centroCusto;
			if(!CollectionUtils.isNullOrEmpty(realocacoes)) {				
				RealocacaoTecnico realocacao = realocacoes.get(realocacoes.size() - 1);
				if(realocacao.isTecnicoPeriodoAlocaco()) {
					centroCusto = centroCustoDAO.buscar(realocacao.getCodigoCentroCusto());
					return centroCustoDAO.buscarHierarquiaCodigoCentroCusto(centroCusto.getCodigoCentroCusto());
				}
			}
			return centroCustoDAO.buscarHierarquiaCodigoCentroCusto(corpoTecnicoView.getCentroCusto().getCodigoCentroCusto());
			
		}
		if(PerfilEnum.SOLICITANTE.getIdPerfil().equals(perfil) || PerfilEnum.GESTOR.getIdPerfil().equals(perfil)) {
			String centroCusto = pessoaViewDAO.buscarPorMatricula(matricula).getCentroCusto();
			return centroCustoDAO.buscarHierarquiaCodigoCentroCusto(centroCusto);
		} else if(PerfilEnum.MASTER.getIdPerfil().equals(perfil) || PerfilEnum.ADMINISTRADOR.getIdPerfil().equals(perfil) || PerfilEnum.VISITANTE.getIdPerfil().equals(perfil)){ 
				return centroCustoDAO.buscarTodosCodigoCentroCusto();
		} else {
			throw new IllegalArgumentException("Perfil Inexistente");
		}
		
	}
	
	public CentroCustoView buscarCentroDeCustoPorCodigo(String codigoCentroCusto) {
		CentroCustoView centroCusto = centroCustoDAO.buscar(codigoCentroCusto);
		return centroCusto;
	}
	
	public String siglasCentrosCustosParaRelatorio(List<String> codCentroCustos) {
		String cc = "(";
		
		for (int i = 0; i < codCentroCustos.size(); i++) {
			cc += buscarCentroDeCustoPorCodigo(codCentroCustos.get(i)).getTextoSiglaCentroCusto();
		
			if(i != codCentroCustos.size()-1) {
				cc += ", ";
			}
		}
		
		cc += ")";
		return cc;
	}
}
