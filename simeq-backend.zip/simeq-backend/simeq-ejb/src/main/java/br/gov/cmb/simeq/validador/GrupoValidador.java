package br.gov.cmb.simeq.validador;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.AtividadePreventivaDAO;
import br.gov.cmb.simeq.dao.GrupoDAO;
import br.gov.cmb.simeq.dto.GrupoDTO;
import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import io.jsonwebtoken.lang.Collections;

@Stateless
public class GrupoValidador extends AbstractValidador {
	
	@Inject
	private GrupoDAO grupoDAO;
	
	@Inject
	private AtividadeCorretivaDAO atvCorretivaDAO;
	
	@Inject
	private AtividadePreventivaDAO atvPreventivaDAO;
	
	@RegraDeValidacao
	public void validarGrupoComSubgrupo(Long IdGrupopai) {
		List<GrupoDTO>  subgrupos = grupoDAO.buscarGruposFilho(IdGrupopai);
		if(!Collections.isEmpty(subgrupos)) {
			throw new ValidacaoException("Não é possível excluir grupo que possui subgrupo");
		}
	}
	
	@RegraDeValidacao
	public void validarSubgrupoComAtividade(Long IdGrupopai) {
		List<AtividadePreventiva> prevs = atvPreventivaDAO.buscarPorGrupo(IdGrupopai);
		List<AtividadeCorretiva> corres = atvCorretivaDAO.buscarPorGrupo(IdGrupopai);
		if(!Collections.isEmpty(prevs) || !Collections.isEmpty(corres) ) {
			throw new ValidacaoException("Este subgrupo não pode ser excluído pois existe(m) atividade(s) associada(s) a ele");
		}
	}

}
