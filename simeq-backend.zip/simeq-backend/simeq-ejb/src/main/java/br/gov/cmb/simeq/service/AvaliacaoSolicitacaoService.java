package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dto.AprovacaoReprovacaoManutencaoCorretivaDTO;
import br.gov.cmb.simeq.dto.AvaliacaoManutencaoCorretivaDTO;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.vo.AvaliacaoManutencaoCorretivaVO;

@Stateless
public class AvaliacaoSolicitacaoService {

	@Inject
	private ManutencaoCorretivaDAO manutencaoCorretivaDAO;

	@Inject
	private HistoricoStatusManutencaoCorretivaService historicoStatusManutencaoCorretivaService;

	@Inject
	private PessoaViewDAO pessoaViewDAO;

	public Pagina<AvaliacaoManutencaoCorretivaDTO> filtrarAvaliacoes(Pagina<AvaliacaoManutencaoCorretivaDTO> pagina) {
		String matricula = ((AvaliacaoManutencaoCorretivaVO) pagina.getModelVO()).getMatriculaUsuarioLogado();
		List<Long> perfis = ((AvaliacaoManutencaoCorretivaVO) pagina.getModelVO()).getPerfisUsuarioLogado();
		String setor;
		Boolean trava = false;
		for (Long perfil : perfis) {
			if (perfil.intValue() == PerfilEnum.SOLICITANTE.getIdPerfil()) {
				trava = true;
			}
		}

		if (trava) {
			setor = "";
		} else {
			setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
		}

		return manutencaoCorretivaDAO.filtrarAvaliacoes(pagina, setor);
	}

	public void aprovar(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		historicoStatusManutencaoCorretivaService.aprovar(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}

	public void reprovar(AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		historicoStatusManutencaoCorretivaService.reprovar(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}

	public void enviarEmailAprovacao(
			AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		historicoStatusManutencaoCorretivaService.enviarEmailAprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}

	public void enviarEmailReprovacao(
			AprovacaoReprovacaoManutencaoCorretivaDTO aprovacaoReprovacaoManutencaoCorretivaDTO) {
		historicoStatusManutencaoCorretivaService.enviarEmailReprovacao(aprovacaoReprovacaoManutencaoCorretivaDTO);
	}
}
