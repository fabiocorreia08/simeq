package br.gov.cmb.simeq.relatorio.vo;

import java.util.ArrayList;
import java.util.List;

public class RelatorioRankEquipamentoVO {

	private String periodoInicio;
	private String periodoFim;
	private List<RankEquipamentoVO> rankEquipamento = new ArrayList<>();
	private String centrosCustos;
	
	public RelatorioRankEquipamentoVO(String periodoInicio, String periodoFim, List<RankEquipamentoVO> rankEquipamento,
			String centrosCustos) {
		super();
		this.periodoInicio = periodoInicio;
		this.periodoFim = periodoFim;
		this.rankEquipamento = rankEquipamento;
		this.centrosCustos = centrosCustos;
	}


	public RelatorioRankEquipamentoVO() {
		super();
	}

	public String getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(String periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public String getPeriodoFim() {
		return periodoFim;
	}

	public void setPeriodoFim(String periodoFim) {
		this.periodoFim = periodoFim;
	}

	public List<RankEquipamentoVO> getRankEquipamento() {
		return rankEquipamento;
	}

	public void setRankEquipamento(List<RankEquipamentoVO> rankEquipamento) {
		this.rankEquipamento = rankEquipamento;
	}

	public String getCentrosCustos() {
		return centrosCustos;
	}

	public void setCentrosCustos(String centrosCustos) {
		this.centrosCustos = centrosCustos;
	}


}
