package br.gov.cmb.simeq.vo;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ManutencaoVO implements Serializable {

	private static final long serialVersionUID = -5732707778344054538L;
	
	private Long idManutencao;	
	private String numeroSolicitacao;
	private String nomeEquipamento;
	private Long idEquipamento;
	private String dataCriacao;
	private String centroCustoEquipamento;
	private String classeManutencao;
	private char tipoManutencao;
	private Long idStatus;
	private String siglaCentroCusto;
	private Boolean paralizacao;
	
	private String matriculaAssistenteProducao ;
	private String nomeAssistenteProducao ;
	private String hierarquiaCentroCusto;

	public ManutencaoVO(){}
	
	public ManutencaoVO(Long idManutencao, String numeroSolicitacao, String classeManutencao) {
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.classeManutencao = classeManutencao;
	}
	
	public ManutencaoVO(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	
	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}


	public String getNomeEquipamento() {
		return nomeEquipamento;
	}

	public void setNomeEquipamento(String nomeEquipamento) {
		this.nomeEquipamento = nomeEquipamento;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(String dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getCentroCustoEquipamento() {
		return centroCustoEquipamento;
	}

	public void setCentroCustoEquipamento(String centroCustoEquipamento) {
		this.centroCustoEquipamento = centroCustoEquipamento;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public char getTipoManutencao() {
		return tipoManutencao;
	}

	public void setTipoManutencao(char tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Long getIdStatus() {
		return idStatus;
	}
	
	public String getSiglaCentroCusto() {
		return siglaCentroCusto;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}
	
	public void setSiglaCentroCusto(String siglaCentroCusto) {
		this.siglaCentroCusto = siglaCentroCusto;
	}

	public String getMatriculaAssistenteProducao() {
		return matriculaAssistenteProducao;
	}

	public void setMatriculaAssistenteProducao(String matriculaAssistenteProducao) {
		this.matriculaAssistenteProducao = matriculaAssistenteProducao;
	}

	public String getNomeAssistenteProducao() {
		return nomeAssistenteProducao;
	}

	public void setNomeAssistenteProducao(String nomeAssistenteProducao) {
		this.nomeAssistenteProducao = nomeAssistenteProducao;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

	public Boolean getParalizacao() {
		return paralizacao;
	}

	public void setParalizacao(Boolean paralizacao) {
		this.paralizacao = paralizacao;
	}

}
