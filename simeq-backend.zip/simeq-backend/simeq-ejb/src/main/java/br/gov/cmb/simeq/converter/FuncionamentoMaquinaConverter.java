package br.gov.cmb.simeq.converter;

import org.joda.time.format.DateTimeFormat;

import br.gov.cmb.simeq.dto.FuncionamentoMaquinaDTO;
import br.gov.cmb.simeq.entidade.FuncionamentoMaquina;

public class FuncionamentoMaquinaConverter {

	
	public static FuncionamentoMaquina converter(FuncionamentoMaquinaDTO funcionamentoDTO) {
		
		
		return new FuncionamentoMaquina(funcionamentoDTO.getId(), 
										funcionamentoDTO.getIdEquipamento(), 
										funcionamentoDTO.getCodigoCentroCusto(), 
										funcionamentoDTO.getAno(), 
										funcionamentoDTO.getMes(), 
										funcionamentoDTO.getQuantidadeHorasPadrao(), 
										funcionamentoDTO.getCodigoUsuario(),
										funcionamentoDTO.getTimestamp(),
										FuncionamentoMaquinaDiaConverter.converterLista(funcionamentoDTO.getDiasFuncionamento()));	
		}
		
	public static FuncionamentoMaquinaDTO converter(FuncionamentoMaquina funcionamento) {
		return new FuncionamentoMaquinaDTO(funcionamento.getId(), 
				funcionamento.getEquipamento().getIdEquipamento(), 
				funcionamento.getCentroCusto().getCodigoCentroCusto(), 
				funcionamento.getAno(), 
				funcionamento.getMes(), 
				funcionamento.getQuantidadeHorasPadrao(),
				funcionamento.getCodigoUsuario(),
				DateTimeFormat.forPattern("dd/MM/yyyy - HH:mm").print(funcionamento.getDataUltimaAlteracao().getTime()),
				FuncionamentoMaquinaDiaConverter.converterListaDTO(funcionamento.getDiasFuncionamento()));
	}
	
}

