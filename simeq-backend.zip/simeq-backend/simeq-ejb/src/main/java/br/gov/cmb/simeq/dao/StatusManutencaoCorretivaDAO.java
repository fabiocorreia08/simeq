package br.gov.cmb.simeq.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.TypedQuery;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.DashboardDTO;
import br.gov.cmb.simeq.dto.HistoricoDataDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.StatusManutencaoCorretiva;

public class StatusManutencaoCorretivaDAO extends GenericoPaginadoDAO<StatusManutencaoCorretiva, Long>{

	private static final long serialVersionUID = 8260640769560023027L;
	
	public List<LabelValueDTO> buscarStatusCombo(List<Long> idsStatus) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(s.nome, s.id)")
				.from(StatusManutencaoCorretiva.class, "s")
				.where("s.id in ?1");
		return buscar(builder.builder(), LabelValueDTO.class, idsStatus);
	}
	
	@SuppressWarnings("unchecked")
	public List<DashboardDTO> buscarDashboard(List<String> listaCC,String setor){
		
		List<DashboardDTO> dashboard = (
				(List<DashboardDTO>)
				this.preencherParametros(this.getEntityManager()
				.createNamedQuery("dashboard", DashboardDTO.class), listaCC, setor)
				.getResultList());

		return dashboard;
	}
	
	public HistoricoDataDTO buscarDataHistorico(Long idManutencao){
		
		HistoricoDataDTO historicoData = (HistoricoDataDTO) (
				this.preencherIdManutencao(this.getEntityManager()
				.createNamedQuery("historicoData", HistoricoDataDTO.class), idManutencao)
				.getSingleResult());

		return historicoData;
	}
	
	@SuppressWarnings("rawtypes")
	public TypedQuery preencherIdManutencao(TypedQuery typedQuery, Long idManutencao) {
		typedQuery.setParameter("idManutencao", idManutencao);
		 return typedQuery;
	}
	
	@SuppressWarnings("rawtypes")
	public TypedQuery preencherParametros(TypedQuery typedQuery, List<String> listaCC,String setor) {
		typedQuery.setParameter("listaCC", verificarCentroCusto(listaCC));
		typedQuery.setParameter("setor", setor);
		return typedQuery;
	}
	
	private List<String> verificarCentroCusto(List<String>centrosCusto){
		if(centrosCusto != null && centrosCusto.size() > 0) {
			return centrosCusto;
		}
		return Arrays.asList("0");
	}

}
