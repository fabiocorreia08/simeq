package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.TurnoView;

public class TurnoDAO extends GenericoPaginadoDAO<TurnoView, String>{
	
	private static final long serialVersionUID = -5378534826921987275L;

	public List<LabelValueDTO> buscarTodos() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(t.nome, t.codigo)")
				.from(TurnoView.class, "t");
		return buscar(builder.builder(), LabelValueDTO.class);
	}

}
