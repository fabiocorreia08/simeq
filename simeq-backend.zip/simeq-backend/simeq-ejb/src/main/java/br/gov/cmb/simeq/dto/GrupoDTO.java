package br.gov.cmb.simeq.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.cmb.simeq.enums.SimNaoEnum;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GrupoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idGrupo;
	private Long idGrupoPai;
	private Long idEquipamento;
	private String codigoSequencia;
	private String codigoSequenciaPai;
	private String descricaoGrupo;
	private SimNaoEnum flagMecanico;
	private SimNaoEnum flagEletricista;
	private SimNaoEnum flagEletronico;
	private SimNaoEnum flagTI;
	private SimNaoEnum flagUtilidades;
	private SimNaoEnum flagEngenharia;
	private SimNaoEnum flagPreventiva;
	private SimNaoEnum flagPreventivaAnterior;
	private String descricaoObservacao;
	
	public GrupoDTO() {
	}
	
	public GrupoDTO(Long idGrupo,
					Long idEquipamento,
					String codigoSequencia,
					String descricaoGrupo,
					SimNaoEnum flagMecanico,
					SimNaoEnum flagEletricista,
					SimNaoEnum flagEletronico,
					SimNaoEnum flagTI,
					SimNaoEnum flagUtilidades,
					SimNaoEnum flagEngenharia,
					SimNaoEnum flagPreventiva,
					SimNaoEnum flagPreventivaAnterior,
					String descricaoObservacao) {
		
		this.idGrupo = idGrupo;
		this.idEquipamento = idEquipamento;
		this.codigoSequencia = codigoSequencia;
		this.descricaoGrupo = descricaoGrupo;
		this.flagMecanico = flagMecanico;
		this.flagEletricista = flagEletricista;
		this.flagEletronico = flagEletronico;
		this.flagTI = flagTI;
		this.flagUtilidades = flagUtilidades;
		this.flagEngenharia = flagEngenharia;
		this.flagPreventiva = flagPreventiva;
		this.flagPreventivaAnterior = flagPreventiva;
		this.descricaoObservacao = descricaoObservacao;
		}
	
	public GrupoDTO(Long idGrupo,
					Long idGrupoPai,
					Long idEquipamento,
					String codigoSequencia,
					String codigoSequenciaPai,
					String descricaoGrupo,
					SimNaoEnum flagMecanico,
					SimNaoEnum flagEletricista,
					SimNaoEnum flagEletronico,
					SimNaoEnum flagTI,
					SimNaoEnum flagUtilidades,
					SimNaoEnum flagEngenharia,
					SimNaoEnum flagPreventiva,
					SimNaoEnum flagPreventivaAnterior,
					String descricaoObservacao) {
		
		this.idGrupo = idGrupo;
		this.idGrupoPai = idGrupoPai;
		this.idEquipamento = idEquipamento;
		this.codigoSequencia = codigoSequencia;
		this.codigoSequenciaPai = codigoSequenciaPai;
		this.descricaoGrupo = descricaoGrupo;
		this.flagMecanico = flagMecanico;
		this.flagEletricista = flagEletricista;
		this.flagEletronico = flagEletronico;
		this.flagTI = flagTI;
		this.flagUtilidades = flagUtilidades;
		this.flagEngenharia = flagEngenharia;
		this.flagPreventiva = flagPreventiva;
		this.flagPreventivaAnterior = flagPreventiva;
		this.descricaoObservacao = descricaoObservacao;
	}

	public Long getIdGrupo() {
		return idGrupo;
	}

	public void setIdGrupo(Long idGrupo) {
		this.idGrupo = idGrupo;
	}

	public Long getIdGrupoPai() {
		return idGrupoPai;
	}

	public void setIdGrupoPai(Long idGrupoPai) {
		this.idGrupoPai = idGrupoPai;
	}
	
	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoSequencia() {
		return codigoSequencia;
	}

	public void setCodigoSequencia(String codigoSequencia) {
		this.codigoSequencia = codigoSequencia;
	}
	
	public String getCodigoSequenciaPai() {
		return codigoSequenciaPai;
	}

	public void setCodigoSequenciaPai(String codigoSequenciaPai) {
		this.codigoSequenciaPai = codigoSequenciaPai;
	}

	public String getDescricaoGrupo() {
		return descricaoGrupo;
	}

	public void setDescricaoGrupo(String descricaoGrupo) {
		this.descricaoGrupo = descricaoGrupo;
	}

	public SimNaoEnum getFlagMecanico() {
		return flagMecanico;
	}

	public void setFlagMecanico(SimNaoEnum flagMecanico) {
		this.flagMecanico = flagMecanico;
	}

	public SimNaoEnum getFlagEletricista() {
		return flagEletricista;
	}

	public void setFlagEletricista(SimNaoEnum flagEletricista) {
		this.flagEletricista = flagEletricista;
	}

	public SimNaoEnum getFlagEletronico() {
		return flagEletronico;
	}

	public void setFlagEletronico(SimNaoEnum flagEletronico) {
		this.flagEletronico = flagEletronico;
	}

	public SimNaoEnum getFlagTI() {
		return flagTI;
	}

	public void setFlagTI(SimNaoEnum flagTI) {
		this.flagTI = flagTI;
	}

	public SimNaoEnum getFlagUtilidades() {
		return flagUtilidades;
	}

	public void setFlagUtilidades(SimNaoEnum flagUtilidades) {
		this.flagUtilidades = flagUtilidades;
	}

	public SimNaoEnum getFlagEngenharia() {
		return flagEngenharia;
	}

	public void setFlagEngenharia(SimNaoEnum flagEngenharia) {
		this.flagEngenharia = flagEngenharia;
	}

	public SimNaoEnum getFlagPreventiva() {
		return flagPreventiva;
	}

	public void setFlagPreventiva(SimNaoEnum flagPreventiva) {
		this.flagPreventiva = flagPreventiva;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public SimNaoEnum getFlagPreventivaAnterior() {
		return flagPreventivaAnterior;
	}

	public void setFlagPreventivaAnterior(SimNaoEnum flagPreventivaAnterior) {
		this.flagPreventivaAnterior = flagPreventivaAnterior;
	}
	
}
