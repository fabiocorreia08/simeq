package br.gov.cmb.simeq.vo.relatorio;

import java.io.InputStream;
import java.util.List;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorio")
public class RelatorioManutencaoPreventivaAnualVO extends RelatorioDataSource<SubRelatorioManutencaoPreventivaAnualVO> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3776755817882254132L;
	
	private String anoExercicio;
	
	private InputStream logo;
	
	public RelatorioManutencaoPreventivaAnualVO(String anoExercicio,
			List<SubRelatorioManutencaoPreventivaAnualVO> subRelatorio) {
		super(subRelatorio);
		this.anoExercicio = anoExercicio;
	}
	
	public String getAnoExercicio() {
		return anoExercicio;
	}

	public void setAnoExercicio(String anoExercicio) {
		this.anoExercicio = anoExercicio;
	}

	public InputStream getLogo() {
		return logo;
	}

	public void setLogo(InputStream logo) {
		this.logo = logo;
	}
}
