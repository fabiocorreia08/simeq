package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.google.common.base.Objects;
import com.google.common.collect.Sets;

@Audited
@Entity
@Table(name = "ATIVIDADE_CORRETIVA")
public class AtividadeCorretiva implements Serializable {

	private static final long serialVersionUID = -1583101141612250613L;
	
	@Id
	@Column(name = "ID_ATIVIDADE")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "ID_MANUTENCAO_CORRETIVA")
	private ManutencaoCorretiva manutencaoCorretiva;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_MATRICULA_EXECUTANTE")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private PessoaView executante;
	
	@ManyToOne
	@JoinColumn(name = "ID_SUBGRUPO")
	private Grupo subGrupo;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_ACAO")
	private Acao acao;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_COMPONENTE")
	private Componente componente;
	
	@Column(name = "HR_ATIVIDADE")
	private Integer horaAtividade;
	
	@Column(name = "MN_ATIVIDADE")
	private Integer minutosAtividade;
	
	@Column(name = "NR_MES_REFERENCIA")
	private Integer mesReferencia;
	
	@Column(name = "DS_OBSERVACAO")
	private String observacao;
	
	@Column(name = "VL_SALARIO_EXECUTANTE")
	private BigDecimal salario;
	
	@Column(name = "DT_CADASTRO", updatable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "QT_HORA_SEM_PARALISACAO")
	private Integer horasSemParalisacao;
	
	@Column(name = "QT_MIN_SEM_PARALISACAO")
	private Integer minutosSemParalisacao;
	
	@Column(name = "QT_HORA_COM_PARALISACAO")
	private Integer horasComParalisacao;
	
	@Column(name = "QT_MIN_COM_PARALISACAO")
	private Integer minutosComParalisacao;
	
	@OneToMany(mappedBy = "atividade", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Set<AtividadeMaterialCorretiva> materiais = Sets.newHashSet();
	
	public AtividadeCorretiva(){}
	
	public AtividadeCorretiva(Long id){
		this.id = id;
	}
	
	public AtividadeCorretiva(Long id, Long idManutencao, String matriculaExecutante, Long idSubGrupo, String codigoAcao, String codigoComponente,
			Integer horaAtividade, Integer minutoAtividade, Integer mesReferencia, String observacao, Set<AtividadeMaterialCorretiva> materiais,
			BigDecimal salario, Integer horasSemParalisacao, Integer minutosSemParalisacao, Integer horasComParalisacao, Integer minutosComParalisacao) {
		this.id = id;
		this.manutencaoCorretiva = new ManutencaoCorretiva(idManutencao);
		this.executante = new PessoaView(matriculaExecutante);
		this.subGrupo = new Grupo(idSubGrupo);
		this.acao = new Acao(codigoAcao);
		this.componente = new Componente(codigoComponente);
		this.horaAtividade = horaAtividade;
		this.minutosAtividade = minutoAtividade;
		this.mesReferencia = mesReferencia;
		this.observacao = observacao;
		this.materiais = materiais;
		this.salario = salario;
		this.horasSemParalisacao = horasSemParalisacao;
		this.minutosSemParalisacao = minutosSemParalisacao;
		this.horasComParalisacao = horasComParalisacao;
		this.minutosComParalisacao = minutosComParalisacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ManutencaoCorretiva getManutencaoCorretiva() {
		return manutencaoCorretiva;
	}

	public void setManutencaoCorretiva(ManutencaoCorretiva manutencaoCorretiva) {
		this.manutencaoCorretiva = manutencaoCorretiva;
	}

	public PessoaView getExecutante() {
		return executante;
	}

	public void setExecutante(PessoaView executante) {
		this.executante = executante;
	}

	public Grupo getSubGrupo() {
		return subGrupo;
	}

	public void setSubGrupo(Grupo subGrupo) {
		this.subGrupo = subGrupo;
	}

	public Acao getAcao() {
		return acao;
	}

	public void setAcao(Acao acao) {
		this.acao = acao;
	}

	public Integer getHoraAtividade() {
		return horaAtividade;
	}

	public void setHoraAtividade(Integer horaAtividade) {
		this.horaAtividade = horaAtividade;
	}

	public Integer getMinutosAtividade() {
		return minutosAtividade;
	}

	public void setMinutosAtividade(Integer minutosAtividade) {
		this.minutosAtividade = minutosAtividade;
	}

	public Integer getMesReferencia() {
		return mesReferencia;
	}

	public void setMesReferencia(Integer mesReferencia) {
		this.mesReferencia = mesReferencia;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}
	
	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	
	public Componente getComponente() {
		return componente;
	}

	public void setComponente(Componente componente) {
		this.componente = componente;
	}

	public Set<AtividadeMaterialCorretiva> getMateriais() {
		return materiais;
	}

	public void setMateriais(Set<AtividadeMaterialCorretiva> materiais) {
		this.materiais = materiais;
	}

	public BigDecimal getSalario() {
		return salario;
	}

	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}

	public Integer getHorasSemParalisacao() {
		return horasSemParalisacao;
	}

	public void setHorasSemParalisacao(Integer horasSemParalisacao) {
		this.horasSemParalisacao = horasSemParalisacao;
	}

	public Integer getMinutosSemParalisacao() {
		return minutosSemParalisacao;
	}

	public void setMinutosSemParalisacao(Integer minutosSemParalisacao) {
		this.minutosSemParalisacao = minutosSemParalisacao;
	}

	public Integer getHorasComParalisacao() {
		return horasComParalisacao;
	}

	public void setHorasComParalisacao(Integer horasComParalisacao) {
		this.horasComParalisacao = horasComParalisacao;
	}

	public Integer getMinutosComParalisacao() {
		return minutosComParalisacao;
	}

	public void setMinutosComParalisacao(Integer minutosComParalisacao) {
		this.minutosComParalisacao = minutosComParalisacao;
	}

	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof AtividadeCorretiva)) {
			return false;
		}
		AtividadeCorretiva castOther = (AtividadeCorretiva) other;
		return Objects.equal(id, castOther.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}
	
}
