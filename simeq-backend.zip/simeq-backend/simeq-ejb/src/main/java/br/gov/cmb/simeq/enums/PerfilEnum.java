package br.gov.cmb.simeq.enums;

import java.util.List;

import br.gov.cmb.common.util.CollectionUtils;

public enum PerfilEnum {
	
	ADMINISTRADOR (1),
	TECNICO (2),
	SOLICITANTE (3),
	MASTER (4),
	GESTOR (5),
	VISITANTE (6);
	
	private Integer idPerfil;
	
	private PerfilEnum(Integer idPerfil) {
		this.idPerfil = idPerfil;
	}

	public Integer getIdPerfil() {
		return idPerfil;
	}
	
	public static boolean isContemPerfil(List<Long> perfis, PerfilEnum perfil) {
		if(!CollectionUtils.isNullOrEmpty(perfis)) {
			return perfis.stream().filter(p -> perfil.getIdPerfil().equals(p)).findFirst().isPresent();
		}
		return false;
	}
	
}
