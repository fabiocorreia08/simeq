package br.gov.cmb.simeq.vo;

import java.util.List;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AvaliacaoManutencaoCorretivaVO extends ModeloVO {

	private static final long serialVersionUID = -6954926872697382148L;

	@ParametroNomeado
    private String matriculaUsuarioLogado;
	
	@ParametroNomeado
    private List<Long> perfisUsuarioLogado;
    
    public AvaliacaoManutencaoCorretivaVO() {
    }
    
    public AvaliacaoManutencaoCorretivaVO(String matriculaUsuarioLogado, List<Long> perfisUsuarioLogado) {
        this.matriculaUsuarioLogado = matriculaUsuarioLogado;
        this.perfisUsuarioLogado = perfisUsuarioLogado;
    }

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public List<Long> getPerfisUsuarioLogado() {
		return perfisUsuarioLogado;
	}

	public void setPerfisUsuarioLogado(List<Long> perfisUsuarioLogado) {
		this.perfisUsuarioLogado = perfisUsuarioLogado;
	}
}
