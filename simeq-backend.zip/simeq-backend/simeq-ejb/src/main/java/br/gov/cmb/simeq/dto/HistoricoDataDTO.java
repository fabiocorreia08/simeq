package br.gov.cmb.simeq.dto;

import java.util.Date;

public class HistoricoDataDTO {
	private Date dataCriacao;
	private Long idStatus;
	private Date dataStatus;

	public HistoricoDataDTO() {
		super();
	}

	public HistoricoDataDTO(Date dataCriacao, Long idStatus, Date dataStatus) {
		super();
		this.dataCriacao = dataCriacao;
		this.idStatus = idStatus;
		this.dataStatus = dataStatus;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public Date getDataStatus() {
		return dataStatus;
	}

	public void setDataStatus(Date dataStatus) {
		this.dataStatus = dataStatus;
	}
}
