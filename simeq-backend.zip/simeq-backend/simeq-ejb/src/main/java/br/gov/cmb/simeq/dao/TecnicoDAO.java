package br.gov.cmb.simeq.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.entidade.CorpoTecnicoView;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.utils.StringUtil;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;

public class TecnicoDAO extends GenericoPaginadoDAO<Tecnico, Long> implements Serializable{

	private static final long serialVersionUID = -32861979582801811L;
	
	private static final String NULL = "null";

	public CorpoTecnicoView buscarInformacoesTecnicoPor(String matricula) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("ct")
				.from(CorpoTecnicoView.class,"ct")
				.innerJoinFetch("ct.centroCusto", "c")
				.where("ct.codigoMatricula = ?");
		return buscaSeguraUmResultado(builder.builder(), CorpoTecnicoView.class, matricula);
	}
	
	public Tecnico buscarTecnicoPorMatricula(String matricula) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("t")
				.from(Tecnico.class,"t")
				.leftJoin("t.realocacoes", "r")
				.innerJoinFetch("t.informacoesTecnico", "i")
				.innerJoinFetch("i.centroCusto", "c")
				.where("t.codigoMatricula = ?");
		return buscaSeguraUmResultado(builder.builder(), Tecnico.class, matricula);
	}
	
	public AlocacaoCadastrarVO buscarPerfilTecnico(String matricula) {
    	IJPQLBuilder builder = JPQLBuilder.getInstance()
    			.select("DISTINCT new br.gov.cmb.simeq.vo.AlocacaoCadastrarVO(t.codigoMatricula, it.nomeEmpregado, it.nomeCargo, it.nomeFuncao, t.idTecnico, it.codigoSituacaoFolha,"
    					+ "tv.nome)")
    			.from(Tecnico.class, "t")
    			.innerJoin("t.informacoesTecnico", "it")
    			.innerJoin("t.tecnico", "pessoaView")
    			.innerJoin("pessoaView.turnoView", "tv")
    			.where("t.codigoMatricula = ?");
    	return buscarUmResultado(builder.builder(), AlocacaoCadastrarVO.class, matricula);
    }
	
	public CorpoTecnicoView buscarTecnicoviewPorMatricula(String matricula) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("i")
				.from(Tecnico.class,"t")
				.leftJoin("t.realocacoes", "r")
				.innerJoin("t.informacoesTecnico", "i")
				.innerJoin("i.centroCusto", "c")
				.where("t.codigoMatricula = ?");
		List<CorpoTecnicoView> tecnicoView = buscar(builder.builder(), CorpoTecnicoView.class, matricula);
		if(CollectionUtils.isNullOrEmpty(tecnicoView)) {
			return null;
		}
		return tecnicoView.get(0);
	}

	@SuppressWarnings("unchecked")
	public Pagina<TecnicoDTO> buscarPaginaPor(Pagina<TecnicoDTO> pagina) {

		StringBuilder stringBuilder = new StringBuilder("select new br.gov.cmb.simeq.dto.TecnicoDTO(t.idTecnico, t.codigoMatricula, ct.nomeEmpregado, c.codigoCentroCusto, c.textoHierarquiaCentroCusto, ct.nomeCargo, ct.nomeFuncao, ct.codigoSituacaoFolha, ct.descricaoSituacaoFolha) from Tecnico t "+
														"	inner join t.informacoesTecnico as ct "+
														"   inner join ct.centroCusto as c "+
														"	left join t.realocacoes as rt with (rt.dataPeriodoAte IS NULL OR CONVERT(VARCHAR(10), getdate(),23) <= CONVERT(VARCHAR(10), rt.dataPeriodoAte,23)) " + 
														"														AND CONVERT(VARCHAR(10), getdate(),23) >= CONVERT(VARCHAR(10), rt.dataPeriodoDe,23) "+
														"	where (:matricula is null or t.codigoMatricula LIKE :matricula) "+
														"		and (:nome is null or ct.nomeEmpregado LIKE :nome) "+
														"		and (:cargo is null or ct.nomeCargo LIKE :cargo) "+
														"		and (:funcao is null or ct.nomeFuncao LIKE :funcao) "+
														"		and (:hierarquiaCentroCusto is null or c.codigoCentroCusto = :hierarquiaCentroCusto) "+
														"		and (:realocado is null or ((:realocado = 'S' and rt.idRealocacaoTecnico is not null) or (:realocado = 'N' and rt.idRealocacaoTecnico is null)))");
		
		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("matricula", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("matricula")));
		query.setParameter("nome", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("nome")));
		query.setParameter("cargo", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("cargo")));
		query.setParameter("funcao", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("funcao")));
		query.setParameter("hierarquiaCentroCusto", NULL.equals(pagina.getModelVO().getParametros().get("hierarquiaCentroCusto")) ? null : pagina.getModelVO().getParametros().get("hierarquiaCentroCusto"));
		query.setParameter("realocado", NULL.equals(pagina.getModelVO().getParametros().get("realocado")) ? null : pagina.getModelVO().getParametros().get("realocado"));
		query.setFirstResult(pagina.getPrimeiroRegistro()).setMaxResults(pagina.getTamanho());
		pagina.setRegistros(this.buscar(query, List.class));
		pagina.setTotalDeRegistros(this.buscarPaginaPorNumeroDeRegistros(pagina));
		return pagina;
	}
	
	public Integer buscarPaginaPorNumeroDeRegistros(Pagina<TecnicoDTO> pagina) {
		StringBuilder stringBuilder = new StringBuilder("select distinct new java.lang.Long(count(*)) from Tecnico t "+
														"	inner join t.informacoesTecnico as ct "+
														"   inner join ct.centroCusto as c "+
														"	left join t.realocacoes as rt with (rt.dataPeriodoAte IS NULL OR CONVERT(VARCHAR(10), getdate(),23) <= CONVERT(VARCHAR(10), rt.dataPeriodoAte,23)) " + 
														"														AND CONVERT(VARCHAR(10), getdate(),23) >= CONVERT(VARCHAR(10), rt.dataPeriodoDe,23) "+
														"	where (:matricula is null or t.codigoMatricula LIKE :matricula) "+
														"		and (:nome is null or ct.nomeEmpregado LIKE :nome) "+
														"		and (:cargo is null or ct.nomeCargo LIKE :cargo) "+
														"		and (:funcao is null or ct.nomeFuncao LIKE :funcao) "+
														"		and (:hierarquiaCentroCusto is null or c.codigoCentroCusto = :hierarquiaCentroCusto) "+
														"		and (:realocado is null or ((:realocado = 'S' and rt.idRealocacaoTecnico is not null) or (:realocado = 'N' and rt.idRealocacaoTecnico is null)))");
										
		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("matricula", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("matricula")));
		query.setParameter("nome", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("nome")));
		query.setParameter("cargo", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("cargo")));
		query.setParameter("funcao", StringUtil.getParametroComLike(pagina.getModelVO().getParametros().get("funcao")));
		query.setParameter("hierarquiaCentroCusto", NULL.equals(pagina.getModelVO().getParametros().get("hierarquiaCentroCusto")) ? null : pagina.getModelVO().getParametros().get("hierarquiaCentroCusto"));
		query.setParameter("realocado", NULL.equals(pagina.getModelVO().getParametros().get("realocado")) ? null : pagina.getModelVO().getParametros().get("realocado"));
		return ((Long)this.buscar(query, List.class).get(0)).intValue();
	}
	
	public List<LabelValueDTO> buscarTodosTecnico() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(i.nomeEmpregado, t.idTecnico)")
				.from(Tecnico.class, "t")
				.innerJoin("t.informacoesTecnico", "i");
		return buscar(builder.builder(), LabelValueDTO.class);
	}
	
	public List<LabelValueDTO> buscarTodosCargos() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO(i.nomeCargo, i.nomeCargo)")
				.from(Tecnico.class, "t")
				.innerJoin("t.informacoesTecnico", "i");
		return buscar(builder.builder(), LabelValueDTO.class);
	}
	
	public List<LabelValueDTO> buscarTodasFuncoes() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO(i.nomeFuncao, i.nomeFuncao)")
				.from(Tecnico.class, "t")
				.innerJoin("t.informacoesTecnico", "i");
		
		List<LabelValueDTO> aux = new ArrayList<LabelValueDTO>();
		List<LabelValueDTO> resultados = buscar(builder.builder(), LabelValueDTO.class);
		
		for (LabelValueDTO valor : resultados) {
			if(valor.getValue() != null) {
				aux.add(valor);
			}
		}
		
		return aux;
	}
	
}
