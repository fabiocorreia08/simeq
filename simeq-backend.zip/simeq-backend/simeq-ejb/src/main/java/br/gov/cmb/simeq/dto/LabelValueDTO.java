package br.gov.cmb.simeq.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class LabelValueDTO {

	private String label;
	private Object value;
	
	public LabelValueDTO(){}

	public LabelValueDTO(String label, Object value) {
		this.label = label;
		this.value = value;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String chave) {
		this.label = chave;
	}

	public Object getValue() {
		return value;
	}

	public void setValue(Object valor) {
		this.value = valor;
	}

}
