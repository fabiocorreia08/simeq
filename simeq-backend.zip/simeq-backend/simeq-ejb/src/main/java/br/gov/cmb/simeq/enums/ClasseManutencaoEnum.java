package br.gov.cmb.simeq.enums;

import java.util.List;

import com.google.common.collect.Lists;

import br.gov.cmb.simeq.dto.LabelValueDTO;

public enum ClasseManutencaoEnum {
	
	C("Corretiva"),
	S("Serviço de Apoio"),
	P("Preventiva");
	
	private String descricao;
	
	private ClasseManutencaoEnum(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public static List<LabelValueDTO> getClassesManutencaoCorretiva() {
		List<LabelValueDTO> classesManutencao = Lists.newArrayList();
		for (ClasseManutencaoEnum classe : values()) {
			if(!classe.name().equals(ClasseManutencaoEnum.P.name())) {
				classesManutencao.add(new LabelValueDTO(classe.descricao, classe.name()));
			}
		}
		return classesManutencao;
	}
	
	public static ClasseManutencaoEnum getClasseManutencaoEnumPor(String chave) {
		if (ClasseManutencaoEnum.C.name().equals(chave)) {
			return ClasseManutencaoEnum.C;
		} else if (ClasseManutencaoEnum.S.name().equals(chave)) {
			return ClasseManutencaoEnum.S;
		} else {
			return null;
		}
	}
}
