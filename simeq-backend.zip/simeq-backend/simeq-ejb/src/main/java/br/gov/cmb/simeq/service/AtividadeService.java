package br.gov.cmb.simeq.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.simeq.converter.AtividadeConverter;
import br.gov.cmb.simeq.converter.ManutencaoCorretivaConverter;
import br.gov.cmb.simeq.dao.AcaoDAO;
import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.AtividadeMaterialCorretivaDAO;
import br.gov.cmb.simeq.dao.AtividadeMaterialPreventivaDAO;
import br.gov.cmb.simeq.dao.AtividadePreventivaDAO;
import br.gov.cmb.simeq.dao.ComponenteDAO;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaTecnicoDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaTecnicoDAO;
import br.gov.cmb.simeq.dao.MaterialViewDAO;
import br.gov.cmb.simeq.dao.ParametroDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.MesEnum;
import br.gov.cmb.simeq.enums.ParametroEnum;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.utils.VerificaClasseUtil;
import br.gov.cmb.simeq.validador.AtividadeValidador;
import br.gov.cmb.simeq.validador.ManutencaoCorretivaValidador;
import br.gov.cmb.simeq.validador.ManutencaoPreventivaValidador;
import br.gov.cmb.simeq.vo.AtividadeConsultaVO;
import br.gov.cmb.simeq.vo.AtividadeDetalharVO;
import br.gov.cmb.simeq.vo.AtividadeFiltroVO;
import br.gov.cmb.simeq.vo.AtividadeVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.MaterialVO;

@Stateless
public class AtividadeService {
	
	@Inject
	private AtividadeCorretivaDAO atividadeCorretivaDAO;
	
	@Inject
	private AtividadePreventivaDAO atividadePreventivaDAO;
	
	@Inject
	private CentroCustoService centroCustoService;
	
	@Inject
	private AcaoDAO acaoDAO;
	
	@Inject
	private ComponenteDAO componenteDAO;
	
	@Inject
	private ManutencaoCorretivaDAO manutencaoCorretivaDAO;
	
	@Inject
	private ManutencaoPreventivaDAO manutencaoPreventivaDAO;
	
	@Inject
	private ManutencaoCorretivaTecnicoDAO manutencaoCorretivaTecnicoDAO;
	
	@Inject
	private ManutencaoPreventivaTecnicoDAO manutencaoPreventivaTecnicoDAO;
	
	@Inject
	private MaterialViewDAO materialViewDAO;
	
	@Inject 
	private HistoricoStatusManutencaoCorretivaDAO historicoManutencaoDAO;
	
	@Inject
	private ManutencaoCorretivaValidador manutencaoCorretivaValidador;
	
	@Inject
	private ManutencaoPreventivaValidador manutencaoPreventivaValidador;
	
	@Inject
	private EmailService emailService;
	
	@Inject
	private AtividadeMaterialCorretivaDAO atividadeMaterialCorretivaDAO;
	
	@Inject
	private AtividadeMaterialPreventivaDAO atividadeMaterialPreventivaDAO;
	
	@Inject
	private AtividadeValidador atividadeValidador;
	
	@Inject
	private ParametroDAO parametroDAO;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	public Pagina<AtividadeConsultaVO> filtrar(Pagina<AtividadeConsultaVO> pagina) {
		getInformacoes(pagina);
		
		AtividadeFiltroVO filtro = pagina.getModeloVO(AtividadeFiltroVO.class);
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(filtro.getNumeroSolicitacao()); 
		
		Pagina<AtividadeConsultaVO> paginaConsulta = pagina;
		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			paginaConsulta = this.atividadeCorretivaDAO.filtrar(pagina);
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 			
			 paginaConsulta  = this.atividadePreventivaDAO.filtrar(pagina);
		}
		
		return paginaConsulta;
	}

	
	
	public Pagina<AtividadeConsultaVO> filtrarAtividadePreventiva(Pagina<AtividadeConsultaVO> pagina) {
		getInformacoes(pagina);
		return this.atividadePreventivaDAO.filtrar(pagina);
	}

	
	private void getInformacoes(Pagina<AtividadeConsultaVO> pagina) {
		String matricula = ((AtividadeFiltroVO)pagina.getModelVO()).getMatricula();
		Integer perfil = ((AtividadeFiltroVO)pagina.getModelVO()).getPerfil();
		
		if(!PerfilEnum.TECNICO.getIdPerfil().equals(perfil)) {			
			List<String> codigosCentroCusto = centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
			((AtividadeFiltroVO)pagina.getModelVO()).setCentroCustosHierarquia(codigosCentroCusto);
		}
	}
	
	public List<LabelValueDTO> buscarTodasAcoesLabelValue() {
		return acaoDAO.buscarTodosLabelValue();
	}
	
	public List<LabelValueDTO> buscarTodosComponentesLabelValue() {
		return componenteDAO.buscarTodosLabelValue();
	}
	
	public List<LabelValueDTO> buscarMeses(String numeroSolicitacao){
		List<LabelValueDTO> meses = Lists.newArrayList();
		SimpleDateFormat sdf = new SimpleDateFormat("MM");
		Calendar cal = Calendar.getInstance();
		int mes = cal.get(Calendar.MONTH) + 1;
		meses.add(new LabelValueDTO(MesEnum.getDescricaoMesPorCodigo(mes), mes));
		
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		int mesManutencao = 0;
		
		if(numeroSolicitacao != null){
			if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
				ManutencaoCorretiva manutencaoCorretiva = manutencaoCorretivaDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
				mesManutencao = Integer.valueOf(sdf.format(manutencaoCorretiva.getDataCriacao()));
			}
			int diaAtual = cal.get(Calendar.DATE);
			if(mesManutencao < mes && diaAtual <= 5) {
				meses.add(new LabelValueDTO(MesEnum.getDescricaoMesPorCodigo(mes - 1), mes - 1));
			}
		}
		return meses;
	}
	
	public Pagina<MaterialVO> filtrarMaterial(Pagina<MaterialVO> pagina) {
		return materialViewDAO.filtrar(pagina);
	}
	
	public MaterialVO buscarMaterialPorId(String codigo) {
		return materialViewDAO.buscarPorId(codigo);
	}
	
	public List<LabelValueDTO> buscarUnidadesLabelValue() {
		return materialViewDAO.buscarUnidadesLabelValue();
	}
	
	public AtividadeVO atualizar(AtividadeVO atividadeVO) {
		
		AtividadeVO atividadeAtualizar = new AtividadeVO();
		
	 if(atividadeVO.getTipoManutencao().equals(ClasseManutencaoEnum.C.name())) {
			atividadeValidador.validarCadastroIguaisCorretiva(atividadeVO);
			atividadeValidador.validarHoraComESemParalisacao(atividadeVO);
			atividadeValidador.validarHorasComSemParasalicaoIgualHhht(atividadeVO);
			AtividadeCorretiva atividadeAtualizado = atividadeCorretivaDAO.atualizar(AtividadeConverter.converter(atividadeVO));
			ManutencaoCorretivaVO manutencaoCorretivaVO = ManutencaoCorretivaConverter.converter(manutencaoCorretivaDAO.buscarPorId(atividadeVO.getIdManutencao()));
			manutencaoCorretivaVO.setMatriculaUsuarioLogado(atividadeVO.getMatriculaUsuarioLogado());
			manutencaoCorretivaVO.setNomeSolicitante(atividadeVO.getNomeUsuarioLogado());
			this.adicionarHistoricoStatusConcluidaManutencaoCorretiva(manutencaoCorretivaVO, StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo());
			atividadeAtualizar = AtividadeConverter.converter(atividadeCorretivaDAO.buscarPorId(atividadeAtualizado.getId()));
		}else if(atividadeVO.getTipoManutencao().equals(ClasseManutencaoEnum.P.name())) {	
			atividadeValidador.validarCadastroIguaisPreventiva(atividadeVO);
			AtividadePreventiva atividadeAtualizado = atividadePreventivaDAO.atualizar(AtividadeConverter.converterPreventiva(atividadeVO));
	 		
			atividadeAtualizar = AtividadeConverter.converterPreventiva(atividadePreventivaDAO.buscarPorId(atividadeAtualizado.getId()));
		}
		
		return atividadeAtualizar;
	}
	
	public AtividadeVO salvar(AtividadeVO atividadeVO) {
		
		AtividadeVO atividadeSalvar = new AtividadeVO();
		
	    if(atividadeVO.getTipoManutencao().equals(ClasseManutencaoEnum.C.name())) {
	    	atividadeValidador.validarCadastroIguaisCorretiva(atividadeVO);
	    	atividadeValidador.validarHoraComESemParalisacao(atividadeVO);
	    	//atividadeValidador.validarHorasComSemParasalicaoIgualHhht(atividadeVO);
	    	AtividadeCorretiva atividadeCorretivaSalvar = atividadeCorretivaDAO.salvar(AtividadeConverter.converter(atividadeVO));
			ManutencaoCorretivaVO manutencaoCorretivaVO = ManutencaoCorretivaConverter.converter(manutencaoCorretivaDAO.buscarPorId(atividadeVO.getIdManutencao()));
			manutencaoCorretivaVO.setMatriculaUsuarioLogado(atividadeVO.getMatriculaUsuarioLogado());
			manutencaoCorretivaVO.setNomeSolicitante(atividadeVO.getNomeUsuarioLogado());
			this.adicionarHistoricoStatusConcluidaManutencaoCorretiva(manutencaoCorretivaVO, StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo());
			atividadeSalvar = AtividadeConverter.converter(atividadeCorretivaSalvar);
	 	}else if(atividadeVO.getTipoManutencao().equals(ClasseManutencaoEnum.P.name())) {	
	 		atividadeValidador.validarCadastroIguaisPreventiva(atividadeVO);
	 		AtividadePreventiva atividadePreventivaSalvar = atividadePreventivaDAO.salvar(AtividadeConverter.converterPreventiva(atividadeVO));
	 		
	 		atividadeSalvar = AtividadeConverter.converterPreventiva(atividadePreventivaSalvar);
	 	} 
		
		
		return atividadeSalvar;
	}
	
	private void adicionarHistoricoStatusConcluidaManutencaoCorretiva(ManutencaoCorretivaVO manutencaoCorretivaVO, Long idStatus) {
		HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoManutencaoDAO.buscarUltimoHistoricoInserido(manutencaoCorretivaVO.getIdManutencao());
		HistoricoStatusManutencaoCorretiva historico;
		historico = new HistoricoStatusManutencaoCorretiva(manutencaoCorretivaVO.getIdManutencao(), idStatus, new Long(1), manutencaoCorretivaVO.getMatriculaUsuarioLogado());
		if(ultimoHistoricoCadastrado.getStatusManutencaoCorretiva().getId().equals(StatusManutencaoCorretivaEnum.AG_APROPRIACAO.getCodigo()) 
				&& !idStatus.equals(ultimoHistoricoCadastrado.getId().getIdStatusManutencao())) {
			historico = new HistoricoStatusManutencaoCorretiva(manutencaoCorretivaVO.getIdManutencao(), idStatus, ultimoHistoricoCadastrado.getProximoSequencial(), 
					manutencaoCorretivaVO.getMatriculaUsuarioLogado());
			historicoManutencaoDAO.salvar(historico);
			String destinatario = parametroDAO.buscar(ParametroEnum.DEMAN.getCodigoParametro()).getValor();
			emailService.enviarEmailStatusConcluidaManutencaoCorretiva(destinatario, manutencaoCorretivaVO);
		}
	}
	
	public AtividadeVO buscarAtividadeVOPorId(Long id, String numeroSolicitacao) {
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			return AtividadeConverter.converter(atividadeCorretivaDAO.buscarPorId(id));
		} else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 
			return AtividadeConverter.converterPreventiva(atividadePreventivaDAO.buscarPorId(id));
		}
		
		return null;
	}
	
	public void removerAtividade(Long idAtividade, String numeroSolicitacao) {
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			AtividadeCorretiva atividadeRemover = atividadeCorretivaDAO.buscarPorId(idAtividade);
			atividadeCorretivaDAO.remover(atividadeRemover);
		} 
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 
			AtividadePreventiva atividadeRemover = atividadePreventivaDAO.buscarPorId(idAtividade);
			atividadePreventivaDAO.remover(atividadeRemover);
		}
	}
	
	public boolean permitirEditar(String numeroSolicitacao, String matricula, Long idAtividade, Integer idPerfil) {
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		List<String> codigosCentroCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(idPerfil, matricula);
				 		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			AtividadeCorretiva atividade = atividadeCorretivaDAO.buscarPorId(idAtividade);
			String setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
			ManutencaoCorretiva manutencaoCorretiva = manutencaoCorretivaDAO.buscarPorNumeroSolicitacaoPorHierarquia(atividade.getManutencaoCorretiva().getNumeroSolicitacao(), codigosCentroCustoHierarquia, setor);
			try {			
				manutencaoCorretivaValidador.validarManutencaoCorretivaPermissao(manutencaoCorretiva, atividade.getManutencaoCorretiva().getNumeroSolicitacao());
			} catch (ValidacaoException e) {
				return false;
			}
			
			if(manutencaoCorretiva == null) {
				return false;
			}
		} else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 		
			AtividadePreventiva atividade = atividadePreventivaDAO.buscarPorId(idAtividade);
			ManutencaoPreventiva manutencaoPreventiva = manutencaoPreventivaDAO.buscarPorNumeroSolicitacaoPorHierarquia(atividade.getManutencaoPreventiva().getNumeroSolicitacao(), codigosCentroCustoHierarquia);
			
			try {			
				manutencaoPreventivaValidador.validarManutencaoPreventivaPermissao(manutencaoPreventiva, atividade.getManutencaoPreventiva().getNumeroSolicitacao());
			} catch (ValidacaoException e) {
				return false;
			}
			
			if(manutencaoPreventiva == null) {
				return false;
			}
			
		}
		return true;
	}
	
	public ManutencaoVO buscarSolicitacaoTecnicoAlocado(String numeroSolicitacao, String matriculaTecnico) {
		
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao); 
		ManutencaoVO manutencaoVO = new ManutencaoVO();
		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			ManutencaoCorretivaTecnico manutencaoCorretivaTecnico = manutencaoCorretivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
			if (manutencaoCorretivaTecnico == null) {
				return null;
			}
			ManutencaoCorretiva manutencao = manutencaoCorretivaTecnico.getManutencaoCorretiva();
			ManutencaoCorretivaVO manutencaoCorretivaVO = ManutencaoCorretivaConverter.converter(manutencao);
			atividadeValidador.validarPersistenciaAtividadeTecnicoAlocado(manutencaoCorretivaVO);
			manutencaoVO.setNomeEquipamento(manutencao.getEquipamento().getCodigoManutencao() + " - " +manutencao.getEquipamento().getNomeEquipamento());
			manutencaoVO.setSiglaCentroCusto(manutencao.getCentroCusto().getTextoHierarquiaCentroCusto());
			manutencaoVO.setIdManutencao(manutencao.getId());
			manutencaoVO.setIdEquipamento(manutencaoCorretivaVO.getIdEquipamento());
			manutencaoVO.setDataCriacao(manutencaoCorretivaVO.getDataCriacao());
			manutencaoVO.setCentroCustoEquipamento(manutencao.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + 
					manutencao.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getCodigoCentroCusto());
			manutencaoVO.setClasseManutencao(manutencaoCorretivaVO.getClasseManutencao().getLabel());
			manutencaoVO.setTipoManutencao(ClasseManutencaoEnum.C.name().charAt(0));
			
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 			
			ManutencaoPreventivaTecnico  manutencaoPreventivaTecnico = manutencaoPreventivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
			
			if (manutencaoPreventivaTecnico == null) {
				return null;
			}
			
			ManutencaoPreventiva manutencao = manutencaoPreventivaTecnico.getManutencaoPreventiva();
			manutencaoVO.setNomeEquipamento(manutencao.getEquipamento().getCodigoManutencao() + " - " +manutencao.getEquipamento().getNomeEquipamento());
			manutencaoVO.setSiglaCentroCusto(manutencao.getCentroCusto().getTextoHierarquiaCentroCusto());
			manutencaoVO.setIdManutencao(manutencao.getId());
			manutencaoVO.setIdEquipamento(manutencao.getEquipamento().getIdEquipamento());
			manutencaoVO.setDataCriacao(manutencao.getTextoDataCriacao());
			manutencaoVO.setCentroCustoEquipamento(manutencao.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + 
					manutencao.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto().getCodigoCentroCusto());
			manutencaoVO.setClasseManutencao(ClasseManutencaoEnum.P.getDescricao());
			manutencaoVO.setTipoManutencao(ClasseManutencaoEnum.P.name().charAt(0));
		}
	
		return manutencaoVO;
	}
	
	public AtividadeDetalharVO buscarAtividadeDetalhe(Long idAtividade, String numeroSolicitacao) {
		
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao); 
		AtividadeDetalharVO atividadeDetalharVO = new AtividadeDetalharVO();
		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			atividadeDetalharVO = atividadeCorretivaDAO.buscarAtividadeDetalhe(idAtividade);
			atividadeDetalharVO.setMateriais(atividadeMaterialCorretivaDAO.buscarMaterialDetalharVOPorAtividade(idAtividade));
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 			
			atividadeDetalharVO = atividadePreventivaDAO.buscarAtividadeDetalhe(idAtividade);
			atividadeDetalharVO.setMateriais(atividadeMaterialPreventivaDAO.buscarMaterialDetalharVOPorAtividade(idAtividade));
		}
		
		return atividadeDetalharVO;
	}
	
	public List<AtividadeConsultaVO> buscarAtividadeConsultaPorManutencao(Long idManutencao, String numeroSolicitacao) {
		IniciaisClasseManutencaoEnum classeManutencao  = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao); 
		
		List<AtividadeConsultaVO> atividades = new ArrayList<>();
		
		if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			atividades = atividadeCorretivaDAO.buscarAtividadeConsultaPorManutencao(idManutencao);
		}else if(classeManutencao == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) { 	
			atividades = atividadePreventivaDAO.buscarAtividadeConsultaPorManutencao(idManutencao);
		}
		return atividades;
	}

}
