package br.gov.cmb.simeq.producer;


import br.gov.cmb.common.ejb.configuracao.AbstractConfiguracaoProducer;
import br.gov.cmb.common.ejb.configuracao.Configuracao;
import br.gov.cmb.common.ejb.configuracao.ConfiguracaoResolver;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.inject.Inject;
import javax.inject.Named;

@Named
public class ParametroConfiguracaoProducer extends AbstractConfiguracaoProducer {

    @Inject
    private ParametroConfiguracaoResolver resolver;

    @Override
    public ConfiguracaoResolver getResolver() {
        return resolver;
    }

    @Produces
    @Configuracao
    public String getStringConfigValue(InjectionPoint ip) {
        return super.getStringConfigValue(ip);
    }

    @Produces
    @Configuracao
    public Double getDoubleConfigValue(InjectionPoint ip) {
        return super.getDoubleConfigValue(ip);
    }

    @Produces
    @Configuracao
    public Long getLongConfigValue(InjectionPoint ip) {
        return super.getLongConfigValue(ip);
    }

    @Produces
    @Configuracao
    public Integer getIntegerConfigValue(InjectionPoint ip) {
        return super.getIntegerConfigValue(ip);
    }
}
