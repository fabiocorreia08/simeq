package br.gov.cmb.simeq.converter;

import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;

public class CadastroAlocacaoTecnicoConverter {
	
	public static ManutencaoCorretivaTecnico converterCorretiva(AlocacaoCadastrarVO alocacao) {
		return new ManutencaoCorretivaTecnico(alocacao.getIdManutencao(), alocacao.getIdTecnico(), alocacao.getAlocadoPor());
	}
	
	public static ManutencaoPreventivaTecnico converterPreventiva(AlocacaoCadastrarVO alocacao) {
		return new ManutencaoPreventivaTecnico(alocacao.getIdManutencao(), alocacao.getIdTecnico(), alocacao.getAlocadoPor());
	}

}
