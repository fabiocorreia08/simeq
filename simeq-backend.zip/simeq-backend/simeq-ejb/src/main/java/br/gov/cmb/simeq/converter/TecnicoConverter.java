package br.gov.cmb.simeq.converter;

import java.util.Objects;

import br.gov.cmb.simeq.dto.TecnicoDTO;
import br.gov.cmb.simeq.entidade.CorpoTecnicoView;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.utils.StringUtil;

public class TecnicoConverter {

	public static Tecnico converter(TecnicoDTO tecnicoDTO) {
		return new Tecnico(tecnicoDTO.getMatricula());
	}

	public static TecnicoDTO converter(Tecnico tecnico) {
		return new TecnicoDTO(tecnico.getIdTecnico(), tecnico.getCodigoMatricula());
	}

	public static TecnicoDTO converter(Tecnico tecnico, CorpoTecnicoView informacoestecnico) {
		return new TecnicoDTO(tecnico.getIdTecnico(), 
							tecnico.getCodigoMatricula(), 
							informacoestecnico.getNomeEmpregado(),
							informacoestecnico.getCentroCusto().getCodigoCentroCusto(), 
							informacoestecnico.getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + informacoestecnico.getCentroCusto().getCodigoCentroCusto(),
							informacoestecnico.getNomeCargo(), 
							informacoestecnico.getNomeFuncao(),
							informacoestecnico.getCodigoSituacaoFolha(), 
							informacoestecnico.getDescricaoSituacaoFolha());
	}

	public static TecnicoDTO converter(CorpoTecnicoView informacoesTecnico) {
		if(Objects.nonNull(informacoesTecnico)) {	
			return new TecnicoDTO(StringUtil.trim(informacoesTecnico.getCodigoMatricula()),
					StringUtil.trim(informacoesTecnico.getNomeEmpregado()),
					StringUtil.trim(informacoesTecnico.getCentroCusto().getCodigoCentroCusto()), 
					StringUtil.trim(informacoesTecnico.getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + informacoesTecnico.getCentroCusto().getCodigoCentroCusto()),
					StringUtil.trim(informacoesTecnico.getNomeCargo()),
					StringUtil.trim(informacoesTecnico.getNomeFuncao()), 
					StringUtil.trim(informacoesTecnico.getCodigoSituacaoFolha()),
					StringUtil.trim(informacoesTecnico.getDescricaoSituacaoFolha()));
		}
		return new TecnicoDTO();
	}

}
