package br.gov.cmb.simeq.converter;

import java.util.Objects;

import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;

public class ManutencaoCorretivaConverter {
	
	public static ManutencaoCorretiva converter(ManutencaoCorretivaVO manutencaoCorretivaVO) {
		return new ManutencaoCorretiva(Objects.nonNull(manutencaoCorretivaVO.getIdManutencao()) ? manutencaoCorretivaVO.getIdManutencao() : null,
				manutencaoCorretivaVO.getNumeroSolicitacao(), 
				manutencaoCorretivaVO.getIdEquipamento(), 
				manutencaoCorretivaVO.getCodigoCentroCusto(), 
				manutencaoCorretivaVO.getMatriculaAssistenteProducao(), 
				(String)manutencaoCorretivaVO.getClasseManutencao().getValue(), 
				manutencaoCorretivaVO.getParalizacao(), 
				manutencaoCorretivaVO.getAvaria(), 
				manutencaoCorretivaVO.getMatriculaSolicitante(),
				manutencaoCorretivaVO.getIdSetor());
	}
	
	public static ManutencaoCorretivaVO converter(ManutencaoCorretiva manutencao) {
		return new ManutencaoCorretivaVO(manutencao.getId(), 
				manutencao.getTextoDataCriacao(), 
				manutencao.getHoraCriacao(), 
				manutencao.getNumeroSolicitacao(), 
				manutencao.getEquipamento().getIdEquipamento(), 
				manutencao.getCentroCusto().getCodigoCentroCusto(), 
				manutencao.getAssitenteProducao() != null ? manutencao.getAssitenteProducao().getMatricula() : null, 
				manutencao.getAssitenteProducao() != null ? manutencao.getAssitenteProducao().getNome() : null, 
				new LabelValueDTO(manutencao.getFlagClasseManutencao().getDescricao(), manutencao.getFlagClasseManutencao().name()), 
				manutencao.getParalisacao(), 
				manutencao.getObservacao(), 
				manutencao.getMatriculaSolicitante(),
				manutencao.getSetor().getIdSetor(),
				manutencao.getSetor().getNomeSetor());
	}
	
	public static ManutencaoVO converterGenerica(ManutencaoCorretiva manutencao) {
		return new ManutencaoVO(manutencao.getId(), 
				manutencao.getNumeroSolicitacao(), 
				manutencao.getFlagClasseManutencao().getDescricao());
	}
}
