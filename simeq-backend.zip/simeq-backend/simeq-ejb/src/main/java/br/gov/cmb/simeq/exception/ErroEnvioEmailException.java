package br.gov.cmb.simeq.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class ErroEnvioEmailException extends RuntimeException {

	private static final long serialVersionUID = 8411159519613222817L;

	public ErroEnvioEmailException() {
		super();
	}
}
