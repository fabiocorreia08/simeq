package br.gov.cmb.simeq.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class FamiliaSetorDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private Long idSetor;

	public FamiliaSetorDTO() {
	}

	public FamiliaSetorDTO(Long id, Long idSetor) {
		super();
		this.id = id;
		this.idSetor = idSetor;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdSetor() {
		return idSetor;
	}

	public void setIdSetor(Long idSetor) {
		this.idSetor = idSetor;
	}

}
