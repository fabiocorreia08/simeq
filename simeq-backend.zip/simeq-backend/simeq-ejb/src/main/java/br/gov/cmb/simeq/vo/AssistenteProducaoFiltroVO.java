package br.gov.cmb.simeq.vo;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AssistenteProducaoFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 4344298303397816848L;

	@ParametroNomeado
	private String matricula;
	
	@ParametroNomeado(like = true)
	private String nome;

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	
}
