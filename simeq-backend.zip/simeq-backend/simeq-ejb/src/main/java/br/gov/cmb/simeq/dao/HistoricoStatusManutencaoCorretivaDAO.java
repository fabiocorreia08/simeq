package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.vo.HistoricoManutencaoEquipamentoVO;
import br.gov.cmb.simeq.vo.HistoricoStatusManutencaoVO;

public class HistoricoStatusManutencaoCorretivaDAO extends GenericoPaginadoDAO<HistoricoStatusManutencaoCorretiva, Long>{

	private static final long serialVersionUID = -4375792137044684653L;
	
	public HistoricoStatusManutencaoCorretiva buscarUltimoHistoricoInserido(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("h")
				.from(HistoricoStatusManutencaoCorretiva.class, "h")
				.innerJoin("h.statusManutencaoCorretiva", "sm")
				.where("h.id.idManutencaoCorretiva = ?1")
				.and("h.id.idSequencial = (SELECT MAX(h2.id.idSequencial) FROM HistoricoStatusManutencaoCorretiva h2 where h2.id.idManutencaoCorretiva = ?1)");
		List<HistoricoStatusManutencaoCorretiva> historico = buscar(builder.builder(), HistoricoStatusManutencaoCorretiva.class, idManutencao);
		if(!CollectionUtils.isNullOrEmpty(historico)) {
			return historico.get(0);
		}
		
		return null;
	}

	public HistoricoStatusManutencaoCorretiva buscarUltimoHistoricoInseridoComManutencaoCorretivaEUsuarioResponsavelPelaAlteracao(Long idManutencao) {

		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("h")
				.from(HistoricoStatusManutencaoCorretiva.class, "h")
				.innerJoin("h.statusManutencaoCorretiva", "sm")
				.innerJoinFetch("h.manutencaoCorretiva", "mc")
				.innerJoinFetch("h.usuarioResponsavelPelaAlteracao", "ura")
				.where("h.id.idSequencial = (SELECT MAX(h2.id.idSequencial) FROM HistoricoStatusManutencaoCorretiva h2 where h2.id.idManutencaoCorretiva = ?1)")
				.and("h.id.idManutencaoCorretiva = ?1");
		List<HistoricoStatusManutencaoCorretiva> historico = buscar(builder.builder(), HistoricoStatusManutencaoCorretiva.class, idManutencao);
		if(!CollectionUtils.isNullOrEmpty(historico)) {
			return historico.get(0);
		}
		return null;
	}
	
	public List<HistoricoStatusManutencaoCorretiva> buscarPorManutencao(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("h")
				.from(HistoricoStatusManutencaoCorretiva.class, "h")
				.where("h.id.idManutencaoCorretiva =  ?");
		return buscar(builder.builder(), HistoricoStatusManutencaoCorretiva.class, idManutencao);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<HistoricoStatusManutencaoVO> filtrar(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.HistoricoStatusManutencaoVO(h.id.idSequencial, h.dataCriacao, s.nome, p.matricula, p.nome)")
				.from(HistoricoStatusManutencaoCorretiva.class, "h")
				.innerJoin("h.statusManutencaoCorretiva", "s")
				.leftJoin("h.usuarioResponsavelPelaAlteracao", "p")
				.where(pagina.getModelVO(), "h.id.idManutencaoCorretiva =  [idManutencao]")
				.order("h.id.idSequencial");	
		return (Pagina<HistoricoStatusManutencaoVO>)buscar(pagina, builder.builder(), "distinct h.id.idSequencial");
	}
	
	@SuppressWarnings({"unchecked", "rawtypes"})
	public Pagina<HistoricoManutencaoEquipamentoVO> buscarHistoricoPorEquipamento(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.vo.HistoricoManutencaoEquipamentoVO(mc.id, mc.numeroSolicitacao, e.nomeEquipamento, "
						+ " h.dataCriacao, e.codigoManutencao, CONCAT(cc.textoHierarquiaCentroCusto, ' - ', cc.codigoCentroCusto), mc.dataCriacao)")
				.from(HistoricoStatusManutencaoCorretiva.class, "h")
				.innerJoin("h.manutencaoCorretiva", "mc")
				.innerJoin("mc.equipamento", "e")
				.innerJoin("mc.centroCusto", "cc")
				.where(pagina.getModelVO(),"e.idEquipamento = [idEquipamento]")
				.and("h.dataCriacao >= [dtUltimaManutencao]")
				.and("(h.id.idStatusManutencao IN ([idsStatus]) AND h.id.idSequencial = (SELECT MAX(h2.id.idSequencial) FROM HistoricoStatusManutencaoCorretiva h2 where h2.id.idManutencaoCorretiva = mc.id))");
				
		return (Pagina<HistoricoManutencaoEquipamentoVO>)buscar(pagina, builder.builder());
	}

}
