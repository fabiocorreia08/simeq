package br.gov.cmb.simeq.producer;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.gov.cmb.common.ejb.configuracao.GerenciadorConfiguracao;

@Startup
@Singleton
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
public class ParametroConfiguracaoResolver extends GerenciadorConfiguracao {
    private static final Logger logger = LoggerFactory.getLogger(ParametroConfiguracaoResolver.class);

    @PostConstruct
    @Lock(LockType.WRITE)
    public void onStartup() {
        logger.info("[CONFIGURACAO] Carregando parametros de configuracao Simeq ");
        try {
            this.carregarConfiguracao();
        } catch (ConfigurationException e) {
            logger.error("Ocorreu um erro carregando os parametros de configuracao:", e);
        }
    }


    @Override
    protected List<Configuration> buscarConfiguracoes() throws ConfigurationException {

        List<Configuration> configurations = new ArrayList<>();

        PropertiesConfiguration config = new PropertiesConfiguration("configuracao.properties");

        configurations.add(config);

        return configurations;
    }
}
