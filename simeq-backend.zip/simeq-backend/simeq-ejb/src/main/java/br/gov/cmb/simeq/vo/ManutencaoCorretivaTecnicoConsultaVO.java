package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

import br.gov.cmb.simeq.utils.CalendarioUtil;

public class ManutencaoCorretivaTecnicoConsultaVO implements Serializable{

    private static final long serialVersionUID = -1352536633859412451L;
    
    private String matricula;
    private String nomeTecnico;
    private String cargo;
    private String centroCusto;
    private String turno;
    private String numeroSolicitacao;
    private String classeManutencao;
    private Date dataHoraAlocacao;
    private String dataHoraAlocacaoFormatada;
    private String alocadoPor;
    
    public ManutencaoCorretivaTecnicoConsultaVO(String matricula, String nomeTecnico, String cargo, String centroCusto,
            String turno, String numeroSolicitacao, String classeManutencao, Date dataHoraAlocacao, String alocadoPor) {
        super();
        this.matricula = matricula;
        this.nomeTecnico = nomeTecnico;
        this.cargo = cargo;
        this.centroCusto = centroCusto;
        this.turno = turno;
        this.numeroSolicitacao = numeroSolicitacao;
        this.classeManutencao = classeManutencao;
        this.dataHoraAlocacao = dataHoraAlocacao;
        this.dataHoraAlocacaoFormatada = CalendarioUtil.formatarDataHoraBr(dataHoraAlocacao);
        this.alocadoPor = alocadoPor;
    }
    
    
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public String getNomeTecnico() {
        return nomeTecnico;
    }
    public void setNomeTecnico(String nomeTecnico) {
        this.nomeTecnico = nomeTecnico;
    }
    public String getCargo() {
        return cargo;
    }
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    public String getCentroCusto() {
        return centroCusto;
    }
    public void setCentroCusto(String centroCusto) {
        this.centroCusto = centroCusto;
    }
    public String getTurno() {
        return turno;
    }
    public void setTurno(String turno) {
        this.turno = turno;
    }
    public String getNumeroSolicitacao() {
        return numeroSolicitacao;
    }
    public void setNumeroSolicitacao(String numeroSolicitacao) {
        this.numeroSolicitacao = numeroSolicitacao;
    }
    public String getClasseManutencao() {
        return classeManutencao;
    }
    public void setClasseManutencao(String classeManutencao) {
        this.classeManutencao = classeManutencao;
    }
    public Date getDataHoraAlocacao() {
        return dataHoraAlocacao;
    }
    public void setDataHoraAlocacao(Date dataHoraAlocacao) {
        this.dataHoraAlocacao = dataHoraAlocacao;
    }
    public String getAlocadoPor() {
        return alocadoPor;
    }
    public void setAlocadoPor(String alocadoPor) {
        this.alocadoPor = alocadoPor;
    }


	public String getDataHoraAlocacaoFormatada() {
		return dataHoraAlocacaoFormatada;
	}


	public void setDataHoraAlocacaoFormatada(String dataHoraAlocacaoFormatada) {
		this.dataHoraAlocacaoFormatada = dataHoraAlocacaoFormatada;
	}
}