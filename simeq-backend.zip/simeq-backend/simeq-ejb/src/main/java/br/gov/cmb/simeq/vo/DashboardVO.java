package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.List;


public class DashboardVO implements Serializable {

	private static final long serialVersionUID = 6701353826002114096L;

	private List<String> listaCC;
	private String matricula;
	private Integer perfil;
	
	public DashboardVO() {
	}	

	public DashboardVO(List<String> listaCC, String matricula, Integer perfil) {
		super();
		this.listaCC = listaCC;
		this.matricula = matricula;
		this.perfil = perfil;
	}

	public List<String> getListaCC() {
		return listaCC;
	}

	public void setListaCC(List<String> listaCC) {
		this.listaCC = listaCC;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}
	
}
