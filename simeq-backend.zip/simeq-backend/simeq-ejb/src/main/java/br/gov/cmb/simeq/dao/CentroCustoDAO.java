package br.gov.cmb.simeq.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Query;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.CentroCustoView;

public class CentroCustoDAO extends GenericoPaginadoDAO<CentroCustoView, String>{

	private static final long serialVersionUID = 1L;

	public List<LabelValueDTO> buscarTodos() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(CONCAT(cc.textoHierarquiaCentroCusto, ' - ', cc.codigoCentroCusto), cc.codigoCentroCusto)")
				.from(CentroCustoView.class, "cc")
				.order("cc.textoHierarquiaCentroCusto, cc.codigoCentroCusto");
		return buscar(builder.builder(), LabelValueDTO.class);
	}
	
	public List<LabelValueDTO> buscarTodosNomes() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(cc.nomeCentroCusto, cc.codigoCentroCusto)")
				.from(CentroCustoView.class, "cc");
		return buscar(builder.builder(), LabelValueDTO.class);
	}
	
	public List<String> buscarTodosCodigoCentroCusto() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("cc.codigoCentroCusto")
				.from(CentroCustoView.class, "cc");
		return buscar(builder.builder(), String.class);
	}
	
	@SuppressWarnings("unchecked")
	public CentroCustoView buscarCentroCustoViewPorHierarquia(String numeroCentroCusto) {
		String sql = queryHierarquiaCentroCustos();
		sql = sql + "select * from cteCentroCusto c where c.CD_CENTRO_CUSTO = :numeroCentroCusto";
		
		Query query = getEntityManager().createNativeQuery(sql, CentroCustoView.class);
		query.setParameter("numeroCentroCusto", numeroCentroCusto);
		Set<CentroCustoView> centroCusto = new HashSet<CentroCustoView>(query.getResultList());
		if(!CollectionUtils.isNullOrEmpty(centroCusto)) {
			return centroCusto.iterator().next();
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<String> buscarStringHierarquiaCentroCustoView(String numeroCentroCusto) {
		String sql = queryHierarquiaCentroCustos();
		sql = sql + "select DISTINCT * from cteCentroCusto order by TX_HIERARQUIA_CENTRO_CUSTO, CD_CENTRO_CUSTO";
		
		Query query = getEntityManager().createNativeQuery(sql, CentroCustoView.class);
		query.setParameter("numeroCentroCusto", numeroCentroCusto);
		Set<CentroCustoView> centroCusto = new HashSet<CentroCustoView>(query.getResultList());
		List<String> centroCustoLabelValueDTO = centroCusto.stream()
				.map(c -> c.getCodigoCentroCusto())
				.collect(Collectors.toList());
		return centroCustoLabelValueDTO;
	}
	
	@SuppressWarnings("unchecked")
	public List<LabelValueDTO> buscarHierarquiaCentroCustoView(String numeroCentroCusto) {
		String sql = queryHierarquiaCentroCustos();
		sql = sql + "select DISTINCT * from cteCentroCusto order by TX_HIERARQUIA_CENTRO_CUSTO, CD_CENTRO_CUSTO";
		Query query = getEntityManager().createNativeQuery(sql, CentroCustoView.class);
		query.setParameter("numeroCentroCusto", numeroCentroCusto);
		Set<CentroCustoView> centroCusto = new HashSet<CentroCustoView>(query.getResultList());
		List<LabelValueDTO> centroCustoLabelValueDTO = centroCusto.stream()
				.map(c -> new LabelValueDTO(c.getTextoHierarquiaCentroCusto()+" - "+c.getCodigoCentroCusto(), c.getCodigoCentroCusto()))
				.collect(Collectors.toList());
		return centroCustoLabelValueDTO;
	}
	
	@SuppressWarnings("unchecked")
	public List<String> buscarHierarquiaCodigoCentroCusto(String numeroCentroCusto) {
		String sql = queryHierarquiaCentroCustos();
		sql = sql + "select DISTINCT * from cteCentroCusto ORDER BY TX_HIERARQUIA_CENTRO_CUSTO, CD_CENTRO_CUSTO";
		
		Query query = getEntityManager().createNativeQuery(sql, CentroCustoView.class);
		query.setParameter("numeroCentroCusto", numeroCentroCusto);
		Set<CentroCustoView> centroCusto = new HashSet<CentroCustoView>(query.getResultList());
		return centroCusto.stream().map(c -> c.getCodigoCentroCusto()).collect(Collectors.toList());
	}
	
	private String queryHierarquiaCentroCustos() {
		 StringBuilder sql = new StringBuilder();
	        sql
	                .append("WITH cteCentroCusto (CD_CENTRO_CUSTO_PAI, CD_CENTRO_CUSTO, TX_SIGLA_CENTRO_CUSTO, NM_CENTRO_CUSTO, TX_HIERARQUIA_CENTRO_CUSTO) AS ")
	                .append("(SELECT CD_CENTRO_CUSTO_PAI, CD_CENTRO_CUSTO, TX_SIGLA_CENTRO_CUSTO, NM_CENTRO_CUSTO, TX_HIERARQUIA_CENTRO_CUSTO FROM VW_DN_CENTRO_CUSTO WHERE CD_CENTRO_CUSTO_PAI = :numeroCentroCusto  or CD_CENTRO_CUSTO = :numeroCentroCusto ")
	                .append("UNION ALL ")
	                .append("SELECT v.CD_CENTRO_CUSTO_PAI, v.CD_CENTRO_CUSTO, v.TX_SIGLA_CENTRO_CUSTO, v.NM_CENTRO_CUSTO, v.TX_HIERARQUIA_CENTRO_CUSTO FROM VW_DN_CENTRO_CUSTO v ")
	                .append("JOIN cteCentroCusto c ON c.CD_CENTRO_CUSTO = v.CD_CENTRO_CUSTO_PAI) ");
	                
	        return sql.toString();
	 }
}
