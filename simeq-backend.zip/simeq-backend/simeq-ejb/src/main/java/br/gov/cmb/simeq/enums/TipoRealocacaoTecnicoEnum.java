package br.gov.cmb.simeq.enums;

public enum TipoRealocacaoTecnicoEnum {
	A,
	T
}
