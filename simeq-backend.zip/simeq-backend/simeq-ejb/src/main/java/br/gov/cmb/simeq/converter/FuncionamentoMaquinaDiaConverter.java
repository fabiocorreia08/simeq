package br.gov.cmb.simeq.converter;

import java.util.List;
import java.util.stream.Collectors;

import br.gov.cmb.simeq.dto.FuncionamentoMaquinaDiaDTO;
import br.gov.cmb.simeq.entidade.FuncionamentoMaquinaDia;

public class FuncionamentoMaquinaDiaConverter {

	public static FuncionamentoMaquinaDia converter(FuncionamentoMaquinaDiaDTO funcionamentoDTO) {
		return new FuncionamentoMaquinaDia(funcionamentoDTO.getId(), funcionamentoDTO.getDia(), funcionamentoDTO.getQuantidadeHoras());
	}
	
	public static FuncionamentoMaquinaDiaDTO converter(FuncionamentoMaquinaDia funcionamento) {
		return new FuncionamentoMaquinaDiaDTO(funcionamento.getId(), funcionamento.getNumeroDia(), funcionamento.getQuantidadeHoras());
	}
	
	public static List<FuncionamentoMaquinaDia> converterLista(List<FuncionamentoMaquinaDiaDTO> funcionamentoDTO) {
		return funcionamentoDTO.stream().map(n -> converter(n)).collect(Collectors.toList());
	}
	
	public static List<FuncionamentoMaquinaDiaDTO> converterListaDTO(List<FuncionamentoMaquinaDia> funcionamento) {
		return funcionamento.stream().map(n -> converter(n)).collect(Collectors.toList());
	}
	

}
