package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.converter.EquipamentoConverter;
import br.gov.cmb.simeq.dao.EquipamentoDAO;
import br.gov.cmb.simeq.dto.EquipamentoDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.Equipamento;
import br.gov.cmb.simeq.vo.RelatorioCapacidadeProdutivaEquipamentoFiltroVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioCapacidadeProdutivaEquipamentoVO;

@Stateless
public class EquipamentoService {

	@Inject
	private EquipamentoDAO equipamentoDAO;
	
	@Inject
	private CentroCustoService centroCustoService;

	public EquipamentoDTO buscarPor(Long idEquipamento) {
		Equipamento equipamento = equipamentoDAO.buscar(idEquipamento);
		return EquipamentoConverter.converter(equipamento);
	}

	public Pagina<EquipamentoDTO> filtrar(Pagina<EquipamentoDTO> pagina) {
		return equipamentoDAO.filtrar(pagina);
	}

	public List<EquipamentoDTO> buscarPorCodigoManutencaoNomeEquipamento(String codigoManutencao,
			String nomeEquipamento) {
		return equipamentoDAO.buscarPorCodigoManutencaoNomeEquipamento(codigoManutencao, nomeEquipamento);
	}

	public List<LabelValueDTO> buscarTodosEquipamentoLabelValue() {
		return this.equipamentoDAO.buscarEquipamentoLabelValue();
	}
	
	public EquipamentoDTO salvar(EquipamentoDTO equipamentoDTO) {
		return equipamentoDAO.salvar(equipamentoDTO);
	}

	public EquipamentoDTO atualizar(EquipamentoDTO equipamentoDTO) {
		Equipamento equipamento = EquipamentoConverter.converter(equipamentoDTO);
		return EquipamentoConverter.converter(equipamentoDAO.atualizar(equipamento));
	}

	public List<SubRelatorioCapacidadeProdutivaEquipamentoVO> gerarSubRelatorioCapacidadeProdutivaEquipamento(RelatorioCapacidadeProdutivaEquipamentoFiltroVO filtro) {
		return equipamentoDAO.gerarSubRelatorioCapacidadeProdutivaEquipamento(filtro);
	}
	
	public List<LabelValueDTO> buscarHierarquiaCCUsuarioLogado(Integer perfil, String matricula){
		List<String> CCs = this.centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		return this.equipamentoDAO.buscarHierarquiaCCUsuarioLogado(CCs);		
	}
	
	public List<LabelValueDTO> buscarHierarquiaFamilia(Integer perfil, String matricula){
		List<String> CCs = this.centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		return this.equipamentoDAO.buscarHierarquiaFamilia(CCs);		
	}
}
