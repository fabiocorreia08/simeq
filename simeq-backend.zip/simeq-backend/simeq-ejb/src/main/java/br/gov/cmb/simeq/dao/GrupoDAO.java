package br.gov.cmb.simeq.dao;

import java.util.List;

import javax.persistence.Query;

import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.GrupoDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.Grupo;

public class GrupoDAO extends GenericoPaginadoDAO<Grupo, Long> {

	private static final long serialVersionUID = 77267396936984048L;

	@SuppressWarnings("unchecked")
	public List<GrupoDTO> buscarGruposPai(Long idEquipamento) {
		StringBuilder stringBuilder = new StringBuilder("select new br.gov.cmb.simeq.dto.GrupoDTO(g.idGrupo, gp.idGrupo, e.idEquipamento, g.codigoSequencia, gp.codigoSequencia, g.descricaoGrupo, g.flagMecanico, g.flagEletricista, g.flagEletronico, g.flagTI, g.flagUtilidades, g.flagEngenharia, g.flagPreventiva, g.flagPreventiva, g.descricaoObservacao) from Grupo g "+
														"	inner join g.equipamento as e "+
														"	left join g.grupoPai as gp "+
														"	where e.idEquipamento = :idEquipamento and gp.idGrupo is null ");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("idEquipamento", idEquipamento);
		return this.buscar(query, List.class);
	}
	
	@SuppressWarnings("unchecked")
	public List<LabelValueDTO> buscarGruposPorEquipamento(Long idEquipamento) {
		StringBuilder stringBuilder = new StringBuilder("select new br.gov.cmb.simeq.dto.LabelValueDTO(g.descricaoGrupo, g.idGrupo) from Grupo g "+
														"	inner join g.equipamento as e "+
														"	left join g.grupoPai as gp "+
														"	where e.idEquipamento = :idEquipamento and gp.idGrupo is null ");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("idEquipamento", idEquipamento);
		return this.buscar(query, List.class);
	}

	@SuppressWarnings("unchecked")
	public List<GrupoDTO> buscarGruposFilho(Long idGrupoPai) {
		StringBuilder stringBuilder = new StringBuilder("select new br.gov.cmb.simeq.dto.GrupoDTO(g.idGrupo, gp.idGrupo, e.idEquipamento, g.codigoSequencia, gp.codigoSequencia, g.descricaoGrupo, g.flagMecanico, g.flagEletricista, g.flagEletronico, g.flagTI, g.flagUtilidades, g.flagEngenharia, g.flagPreventiva, g.flagPreventiva, g.descricaoObservacao) from Grupo g "+
														"	inner join g.equipamento as e "+
														"	inner join g.grupoPai as gp "+
														"	where gp.idGrupo = :idGrupoPai ");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("idGrupoPai", idGrupoPai);
		return this.buscar(query, List.class);
	}
	
	public Long inserirGrupo(GrupoDTO grupoDTO, Boolean retornarCodigo) {
		StringBuilder stringBuilder = new StringBuilder("insert into GRUPO (ID_EQUIPAMENTO, DS_GRUPO, FL_MECANICO, FL_ELETRICISTA, FL_ELETRONICO, FL_TI, FL_UTILIDADES, FL_ENGENHARIA, FL_PREVENTIVA, DS_OBSERVACAO, ID_GRUPO_PAI, CD_SEQUENCIA) output "+(retornarCodigo?"Inserted.CD_SEQUENCIA":"Inserted.ID_GRUPO")+" values ( "+
														"	:idEquipamento, "+
														"	:descricaoGrupo, "+
														"	:flagMecanico, "+
														"	:flagEletricista, "+
														"	:flagEletronico, "+
														"	:flagTI, "+
														"	:flagUtilidades, "+
														"	:flagEngenharia, "+
														"	:flagPreventiva, "+
														"	:descricaoObservacao, "+
														"	:idGrupoPai, "+
														"	(select coalesce(max(CD_SEQUENCIA+1), 1) from GRUPO where ((:idGrupoPai is null and ID_GRUPO_PAI is null) or (:idGrupoPai is not null and ID_GRUPO_PAI = :idGrupoPai)) and (ID_EQUIPAMENTO = :idEquipamento)))");

		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString());
		query.setParameter("idEquipamento", grupoDTO.getIdEquipamento());
		query.setParameter("descricaoGrupo", grupoDTO.getDescricaoGrupo());
		query.setParameter("flagMecanico", grupoDTO.getFlagMecanico().label);
		query.setParameter("flagEletricista", grupoDTO.getFlagEletricista().label);
		query.setParameter("flagEletronico", grupoDTO.getFlagEletronico().label);
		query.setParameter("flagTI", grupoDTO.getFlagTI().label);
		query.setParameter("flagUtilidades", grupoDTO.getFlagUtilidades().label);
		query.setParameter("flagEngenharia", grupoDTO.getFlagEngenharia().label);
		query.setParameter("flagPreventiva", grupoDTO.getFlagPreventiva().label);
		query.setParameter("descricaoObservacao", grupoDTO.getDescricaoObservacao());
		query.setParameter("idGrupoPai", grupoDTO.getIdGrupoPai());
		return new Long(query.getSingleResult().toString());
	}

	public void atualizarTipoRevisaoDosSubgrupos(Long idGrupoPai) {
		StringBuilder stringBuilder = new StringBuilder("update GRUPO set FL_PREVENTIVA = 'S' where ID_GRUPO in (select ID_GRUPO from GRUPO g where ID_GRUPO_PAI = "+ idGrupoPai +")");
		this.getEntityManager().createNativeQuery(stringBuilder.toString()).executeUpdate();
	}
}
