package br.gov.cmb.simeq.enums;

import java.util.List;

import com.google.common.collect.Lists;

public enum StatusManutencaoPreventivaEnum {
	
	ABERTA(1L, "Solicitação criada.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), IMPROCEDENTE.getCodigo());
		}

		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	RECURSO_ALOCADO(2L, "Chamado já possui pelo menos um técnico alocado.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), EM_MANUTENCAO.getCodigo(), AG_FORNECEDOR.getCodigo(), CONCLUIDA.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return true;
		}
	},
	APROVADA_GESTOR(3L, "Aprovada pelo Gestor.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	REPROVADA_GESTOR(4L, "Reprovada pelo Gestor.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), IMPROCEDENTE.getCodigo(), REABERTA.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	AG_FORNECEDOR(5L, "Aguardando alguma peça ou serviço de algum fornecedor.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), EM_MANUTENCAO.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	CANCELADA(6L, "Solicitação que por algum motivo deixará se existir e seguir o fluxo de atendimento.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	CONCLUIDA(7L, "Manutenção preventiva foi realizada, e o fluxo chega ao fim.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;	
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	EM_MANUTENCAO(8L, "Técnico está efetivamente realizando a manutenção.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), AG_FORNECEDOR.getCodigo(), CONCLUIDA.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return true;
		}
	},
	REPROGRAMADA(9L, "Manutenção é reprogramada, porém deverá necessariamente ocorrer dentro do mesmo mês.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), EM_MANUTENCAO.getCodigo(), AG_FORNECEDOR.getCodigo(), CONCLUIDA.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return true;
		}
	},
	MANUTENCAO_EXPERIDA(10L, "Caso o período pré-programado para um MP tenha sido ultrapassado, essa solicitação terá status de Manutenção expirada.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	REABERTA(11L, "Caso seja reprovada pelo Gestor, a solicitação pode ser reaberta, devendo seguir todo o fluxo de status novamente.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo());
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	},
	IMPROCEDENTE(12L, "Chamados que não se enquadram nas atividades realizadas pela área.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
		
		@Override
		public boolean isVerificarAtividadeCadastrada() {
			return false;
		}
	};
	
	private Long codigo;
	private String descricao;
	
	private StatusManutencaoPreventivaEnum(Long codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public abstract List<Long> getIdsStatusCombo();
	public abstract boolean isVerificarAtividadeCadastrada();
	
	public static StatusManutencaoPreventivaEnum getStatus(Long idStatus) {
		for (StatusManutencaoPreventivaEnum status : values()) {
			if(status.codigo.equals(idStatus)) {
				return status;
			}
		}
		return null;
	}
	
}
