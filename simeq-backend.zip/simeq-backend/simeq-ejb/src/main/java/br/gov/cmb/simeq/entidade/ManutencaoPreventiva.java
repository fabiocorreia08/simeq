package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.google.common.base.Objects;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoPreventivaAnualVO;

@Audited
@Entity
@Table(name = "MANUTENCAO_PREVENTIVA")
@SqlResultSetMappings({
	@SqlResultSetMapping(name="filtrarManutencaoMapping",
		classes={@ConstructorResult(
			targetClass=SubRelatorioManutencaoPreventivaAnualVO.class,
				columns={	@ColumnResult(name="equipamento", type=String.class),
							@ColumnResult(name="jan", type=String.class),
							@ColumnResult(name="fev", type=String.class),
							@ColumnResult(name="mar", type=String.class),
							@ColumnResult(name="abr", type=String.class),
							@ColumnResult(name="mai", type=String.class),
							@ColumnResult(name="jun", type=String.class),
							@ColumnResult(name="jul", type=String.class),
							@ColumnResult(name="ago", type=String.class),
							@ColumnResult(name="sete", type=String.class),
							@ColumnResult(name="outu", type=String.class),
							@ColumnResult(name="nov", type=String.class),
							@ColumnResult(name="dez", type=String.class)}
			)}
		)
})
@NamedNativeQueries({
    @NamedNativeQuery(
        name = "filtrarManutencao",
        query = "	SELECT eq.CD_MANUTENCAO+'-'+eq.NM_EQUIPAMENTO equipamento," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=1 AND mp.NR_ANO= :ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as jan," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=2 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as fev," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=3 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as mar," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=4 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as abr," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=5 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as mai," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=6 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as jun," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=7 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as jul," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=8 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as ago," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=9 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as sete," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=10 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as outu," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=11 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as nov," + 
				"		(SELECT STUFF((SELECT Char(10)+CONVERT(varchar, mp.NR_DIA_INICIO)+' - '+mp.QT_HORAS FROM MANUTENCAO_PREVENTIVA mp WHERE mp.ID_EQUIPAMENTO = eq.ID_EQUIPAMENTO AND mp.NR_MES=12 AND mp.NR_ANO=:ano AND (:centrosCustoSize = 0 OR mp.CD_CENTRO_CUSTO IN (:centrosCusto)) ORDER BY mp.NR_DIA_INICIO FOR XML PATH('')),1,1,'')) as dez " + 
				"	FROM EQUIPAMENTO eq"+
				"   ORDER BY equipamento",
                resultSetMapping="filtrarManutencaoMapping"
    )
})
public class ManutencaoPreventiva implements Serializable {

	private static final long serialVersionUID = 7703359600625053680L;
	
	@Id
	@Column(name = "ID_MANUTENCAO_PREVENTIVA")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "ID_EQUIPAMENTO")
	private Equipamento equipamento;
	
	@NotAudited
	@ManyToOne
	@JoinColumn(name = "CD_CENTRO_CUSTO")
	private CentroCustoView centroCusto;
	
	@Column(name = "NR_SOLICITACAO")
	private String numeroSolicitacao;
	
	@Column(name = "NR_ANO")
	private Integer ano;
	
	@Column(name = "NR_MES")
	private Integer mes;
	
	@Column(name = "NR_DIA_INICIO")
	private Integer diaInicio;
	
	@Column(name = "NR_DIA_FIM")
	private Integer diaFim;
	
	@Column(name = "QT_HORAS")
	private String qtdHoras;
	
	@Column(name = "DT_SOLICITACAO", updatable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataCriacao = new Date();
	
	@Column(name = "CD_MATRIC_SOLICITANTE")
	private String matriculaSolicitante;
	
	@OneToMany(mappedBy="manutencaoPreventiva")
	private List<HistoricoStatusManutencaoPreventiva> historicoStatus = new ArrayList<>();
	public ManutencaoPreventiva(){}
	
	@ManyToOne
	@JoinColumn(name = "ID_SETOR_MANUTENCAO")
	private SetorManutencao setor;
	
	@Column(name = "QT_HORAS_GASTA")
	private String qtdHorasExecutadas;
	
	public ManutencaoPreventiva(Long id){
		this.id = id;
	}
	
	public ManutencaoPreventiva(Long id, String numeroSolicitacao, Long idEquipamento, String codigoCentroCusto, Integer ano, Integer mes, Integer diaInicio, 
			Integer diaFim, String qtdHoras, String matriculaSolicitante, Long idSetor, String qtdHorasExecutadas) {
		this.id = id;
		this.numeroSolicitacao = numeroSolicitacao;
		this.equipamento = new Equipamento(idEquipamento);
		this.centroCusto = new CentroCustoView(codigoCentroCusto);
		this.ano = ano;
		this.mes = mes;
		this.diaInicio = diaInicio;
		this.diaFim = diaFim;
		this.qtdHoras = qtdHoras;
		this.matriculaSolicitante = matriculaSolicitante;
		this.setor = new SetorManutencao(idSetor);
		this.qtdHorasExecutadas = qtdHorasExecutadas; 
	}

	public String getQtdHorasExecutadas() {
		return qtdHorasExecutadas;
	}

	public void setQtdHorasExecutadas(String qtdHorasExecutadas) {
		this.qtdHorasExecutadas = qtdHorasExecutadas;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Equipamento getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(Equipamento equipamento) {
		this.equipamento = equipamento;
	}

	public CentroCustoView getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(CentroCustoView centroCusto) {
		this.centroCusto = centroCusto;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public Integer getDiaInicio() {
		return diaInicio;
	}

	public void setDiaInicio(Integer diaInicio) {
		this.diaInicio = diaInicio;
	}

	public Integer getDiaFim() {
		return diaFim;
	}

	public void setDiaFim(Integer diaFim) {
		this.diaFim = diaFim;
	}

	public String getQtdHoras() {
		return qtdHoras;
	}

	public void setQtdHoras(String qtdHoras) {
		this.qtdHoras = qtdHoras;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}
	
	public String getTextoDataCriacao(){		
		return DataUtils.formatarddMMyyyy(dataCriacao);
	}

	public String getMatriculaSolicitante() {
		return matriculaSolicitante;
	}

	public void setMatriculaSolicitante(String matriculaSolicitante) {
		this.matriculaSolicitante = matriculaSolicitante;
	}
	
	public List<HistoricoStatusManutencaoPreventiva> getHistoricoStatus() {
		return historicoStatus;
	}

	public void setHistoricoStatus(List<HistoricoStatusManutencaoPreventiva> historicoStatus) {
		this.historicoStatus = historicoStatus;
	}
	
	public String getTextoDataInicio(){
		String mesTexto = mes.toString();
		String diaInicioTexto = diaInicio.toString();
		if (mesTexto.toString().length() == 1) {
			mesTexto = "0".concat(mesTexto);
		}
		if (diaInicioTexto.toString().length() == 1) {
			diaInicioTexto = "0".concat(diaInicioTexto);
		}
		Date dataInicio = DataUtils.parseyyyyMMdd(ano.toString().concat(mesTexto).concat(diaInicioTexto));
		return DataUtils.formatarddMMyyyy(dataInicio);
	}
	
	public String getTextoDataFim(){
		String mesTexto = mes.toString();
		String diaFimTexto = diaFim.toString();
		if (mesTexto.toString().length() == 1) {
			mesTexto = "0".concat(mesTexto);
		}
		if (diaFimTexto.toString().length() == 1) {
			diaFimTexto = "0".concat(diaFimTexto);
		}
		Date dataFim = DataUtils.parseyyyyMMdd(ano.toString().concat(mesTexto).concat(diaFimTexto));
		return DataUtils.formatarddMMyyyy(dataFim);
	}
	
	public List<HistoricoStatusManutencaoPreventiva> historicoOrdenadoDescSequencial() {
		Collections.sort(historicoStatus, new Comparator<HistoricoStatusManutencaoPreventiva>() {
			@Override
			public int compare(HistoricoStatusManutencaoPreventiva h1, HistoricoStatusManutencaoPreventiva h2){
				return h1.getId().getIdSequencial().compareTo(h2.getId().getIdSequencial());
			}
		});
		return historicoStatus;
	}

	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof ManutencaoPreventiva)) {
			return false;
		}
		ManutencaoPreventiva castOther = (ManutencaoPreventiva) other;
		return Objects.equal(id, castOther.id);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(id);
	}

	public SetorManutencao getSetor() {
		return setor;
	}

	public void setSetor(SetorManutencao setor) {
		this.setor = setor;
	}
	
}
