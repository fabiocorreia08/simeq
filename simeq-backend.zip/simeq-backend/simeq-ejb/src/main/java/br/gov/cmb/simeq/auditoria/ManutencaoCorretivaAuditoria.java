package br.gov.cmb.simeq.auditoria;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;

@Entity
@Table(name = "MANUTENCAO_CORRETIVA_AUD")
public class ManutencaoCorretivaAuditoria implements Serializable {

	private static final long serialVersionUID = 2196546943917010478L;
	
	@EmbeddedId
	private AuditoriaId auditoriaId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_MANUTENCAO_CORRETIVA", referencedColumnName = "ID_MANUTENCAO_CORRETIVA", insertable = false, updatable = false)
	private ManutencaoCorretiva manutencaoCorretiva;
	
	@Column(name = "DT_CRIACAO")
	private Date dataCriacao;
	
	@Column(name = "NR_SOLICITACAO")
	private String numeroSolicitacao;
	
	@Column(name = "ID_EQUIPAMENTO")
	private Long idEquipamento;
	
	@Column(name = "CD_CENTRO_CUSTO")
	private String centroCusto;
	
	@Column(name = "CD_MATRICULA_ASSISTENTE_PRODUCAO")
	private String assistenteProducao;
	
	@Column(name = "FL_CLASSE_MANUTENCAO")
	private String classeManutencao;
	
	@Column(name = "DS_OBSERVACAO")
	private String observacao;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "HR_PRODUCAO_INICIAL")
	private Date horaInicialProducao;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "HR_PRODUCAO_FINAL")
	private Date horaFinalProducao;
	
	@Column(name = "TP_OPERACAO")
	private Short tipoOperacao;

	public AuditoriaId getAuditoriaId() {
		return auditoriaId;
	}

	public void setAuditoriaId(AuditoriaId auditoriaId) {
		this.auditoriaId = auditoriaId;
	}

	public ManutencaoCorretiva getManutencaoCorretiva() {
		return manutencaoCorretiva;
	}

	public void setManutencaoCorretiva(ManutencaoCorretiva manutencaoCorretiva) {
		this.manutencaoCorretiva = manutencaoCorretiva;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public String getAssistenteProducao() {
		return assistenteProducao;
	}

	public void setAssistenteProducao(String assistenteProducao) {
		this.assistenteProducao = assistenteProducao;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public Date getHoraInicialProducao() {
		return horaInicialProducao;
	}

	public void setHoraInicialProducao(Date horaInicialProducao) {
		this.horaInicialProducao = horaInicialProducao;
	}

	public Date getHoraFinalProducao() {
		return horaFinalProducao;
	}

	public void setHoraFinalProducao(Date horaFinalProducao) {
		this.horaFinalProducao = horaFinalProducao;
	}

	public Short getTipoOperacao() {
		return tipoOperacao;
	}

	public void setTipoOperacao(Short tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}

}
