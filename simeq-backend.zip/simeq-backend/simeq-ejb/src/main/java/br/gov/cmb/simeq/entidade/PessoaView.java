package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.NotAudited;

@Entity
@Table(name = "VW_DN_PESSOA")
public class PessoaView implements Serializable {

	private static final long serialVersionUID = 2116991721421951753L;
	
	@Id
	@Column(name = "CD_MATRICULA")
	private String matricula;
	
	@Column(name = "NM_PESSOA")
	private String nome;
	
	@Column(name = "CD_CENTRO_CUSTO")
	private String centroCusto;
	
	@Column(name = "TX_HIERARQUIA_CENTRO_CUSTO")
	private String hierarquia;
	
	@Column(name = "TX_SIGLA_CENTRO_CUSTO")
	private String siglaCentroCusto;
	
	@Column(name = "FL_SITUACAO_PESSOA")
	private String flagSituacaoPessoa;
	
	@Column(name = "SALARIO")
	private BigDecimal salario;
	
	@NotAudited
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CD_TURNO")
	private TurnoView turnoView;
	
	public PessoaView(){}
	
	public PessoaView(String matricula) {
		this.matricula = matricula;
	}
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public String getHierarquia() {
		return hierarquia;
	}

	public void setHierarquia(String hierarquia) {
		this.hierarquia = hierarquia;
	}

	public String getFlagSituacaoPessoa() {
		return flagSituacaoPessoa;
	}

	public void setFlagSituacaoPessoa(String flagSituacaoPessoa) {
		this.flagSituacaoPessoa = flagSituacaoPessoa;
	}

	public TurnoView getTurnoView() {
		return turnoView;
	}

	public void setTurnoView(TurnoView turnoView) {
		this.turnoView = turnoView;
	}

	public BigDecimal getSalario() {
		return salario;
	}

	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}

	public String getSiglaCentroCusto() {
		return siglaCentroCusto;
	}

	public void setSiglaCentroCusto(String siglaCentroCusto) {
		this.siglaCentroCusto = siglaCentroCusto;
	}
	
}
