package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class AprovacaoReprovacaoManutencaoPreventivaDTO implements Serializable {

	private static final long serialVersionUID = -8718754367668151160L;

	private List<Long> ids;
	private String motivo;
	private String matriculaUsuarioLogado;
    
	public AprovacaoReprovacaoManutencaoPreventivaDTO() {
	}
	
    public AprovacaoReprovacaoManutencaoPreventivaDTO(List<Long> ids, String motivo, String matriculaUsuarioLogado) {
    	this.ids = ids;
    	this.motivo = motivo;
    	this.matriculaUsuarioLogado = matriculaUsuarioLogado;
    }

	public List<Long> getIds() {
		return ids;
	}

	public void setIds(List<Long> ids) {
		this.ids = ids;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}
}
