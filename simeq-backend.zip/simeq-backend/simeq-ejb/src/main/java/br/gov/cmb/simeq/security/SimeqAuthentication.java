package br.gov.cmb.simeq.security;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.cmb.common.ejb.vo.UsuarioVO;
import br.gov.cmb.common.rest.security.Authentication;

public class SimeqAuthentication extends Authentication {

	
	private static final long serialVersionUID = -3069432052488357044L;

	private String token;
	
	private String senha;
	
	public SimeqAuthentication() {
	}

	public SimeqAuthentication(String username, List<String> permissions) {
		super(username, permissions, null);
	}

	public SimeqAuthentication(String username, List<String> permissions, String token) {
		this(username, permissions);
		this.token = token;
	}
	
	public SimeqAuthentication(String username, List<String> permissions, Object details) {
		super(username, permissions, details);
	}
	
	public SimeqAuthentication(String username, Object details) {
		super(username, null, details);
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	@Override
	public UsuarioVO getDetails() {
		ObjectMapper e = new ObjectMapper();
		UsuarioVO u = null;
		try {
			byte[] bytes = e.writeValueAsBytes(super.getDetails());
			u = e.readValue(bytes, UsuarioVO.class);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return u;
	}
}
