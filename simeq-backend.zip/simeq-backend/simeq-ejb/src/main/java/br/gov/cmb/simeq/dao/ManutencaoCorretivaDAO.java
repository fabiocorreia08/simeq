package br.gov.cmb.simeq.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IWhere;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.auditoria.ManutencaoCorretivaAuditoria;
import br.gov.cmb.simeq.dto.AvaliacaoManutencaoCorretivaDTO;
import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.relatorio.vo.RankEquipamentoVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaConsultaVO;
import br.gov.cmb.simeq.vo.RelatorioGestaoEstrategicaFiltroVO;
import br.gov.cmb.simeq.vo.RelatorioRankEquipamentoFiltroVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaParametrosVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaDiaVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaGrupoVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaMaterialVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioGestaoEstrategicaSolicitacaoVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoAtividadesVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoMateriaisVO;

@Named
@RequestScoped
public class ManutencaoCorretivaDAO extends GenericoPaginadoDAO<ManutencaoCorretiva, Long> {

	private static final int MAX_CHART = 10;
	private static final int MIM_CHART = 10;
	private static final long serialVersionUID = -9053276334349013299L;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<ManutencaoCorretivaConsultaVO> filtrar(Pagina pagina, String setor) {

		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.ManutencaoCorretivaConsultaVO(m.id, m.numeroSolicitacao, s.nome, m.dataCriacao, ma.auditoriaId.auditoria.dataAuditoria, e.codigoManutencao, "
						+ "CONCAT(c.textoHierarquiaCentroCusto, ' - ', c.codigoCentroCusto), m.paralisacao, s.id)")
				.from(ManutencaoCorretivaAuditoria.class, "ma").innerJoin("ma.manutencaoCorretiva", "m")
				.innerJoin("m.setor", "sm")
				.innerJoin("m.historicoStatus", "h").innerJoin("m.equipamento", "e").innerJoin("m.centroCusto", "c")
				.leftJoin("e.grupos", "g").leftJoin("g.subgrupos", "subg").innerJoin("h.statusManutencaoCorretiva", "s")
				.where(pagina.getModelVO(), "(c.codigoCentroCusto IN ([centroCustosHierarquia]) OR (c.codigoCentroCusto NOT IN ([centroCustosHierarquia]) AND sm.nomeSetor = '" + setor +"'))")
				.and("m.numeroSolicitacao = [numeroSolicitacao]").and("e.idEquipamento = [idEquipamento]")
				.and("m.matriculaSolicitante IN (SELECT p.matricula FROM PessoaView p WHERE p.nome like [solicitante])")
				.and("cast(ma.auditoriaId.auditoria.dataAuditoria as date) >= cast([periodoInicio] as date)")
				.and("cast(ma.auditoriaId.auditoria.dataAuditoria as date) <= cast([periodoFim] as date)")
				.and("h.id.idStatusManutencao IN ([idsStatus])")
				.and("g.idGrupo = [idGrupo]")
				.and("c.codigoCentroCusto IN ([centroCustos])")
				.and("subg.idGrupo IN ([idsSubGrupo])")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoCorretiva h2 WHERE h2.id.idManutencaoCorretiva = m.id)",
						false)
				.and("ma.auditoriaId.auditoria.idAuditoria = (SELECT MAX (ma2.auditoriaId.auditoria.idAuditoria) FROM ManutencaoCorretivaAuditoria ma2 WHERE ma2.numeroSolicitacao = m.numeroSolicitacao)",
						false)
				.order("m.dataCriacao DESC");

		return (Pagina<ManutencaoCorretivaConsultaVO>) buscar(pagina, builder.builder(),
				"distinct m.numeroSolicitacao");
	}
	

	public ManutencaoCorretiva buscarUltimoRegistroCadastradoPorCentroCusto(String codigoCentroCusto) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoCorretiva.class, "m")
				.innerJoin("m.centroCusto", "c")
				.where("m.id = (SELECT MAX(m2.id) FROM ManutencaoCorretiva m2 WHERE m2.centroCusto.codigoCentroCusto = ?1)")
				.and("c.codigoCentroCusto = ?1");
		List<ManutencaoCorretiva> manutencaoCorretivas = buscar(builder.builder(), ManutencaoCorretiva.class,
				codigoCentroCusto);
		if (!CollectionUtils.isNullOrEmpty(manutencaoCorretivas)) {
			return manutencaoCorretivas.get(0);
		}

		return null;
	}

	public ManutencaoCorretiva buscarUltimoRegistroCadastradoPorSetor(Long idSetor) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoCorretiva.class, "m")
				.innerJoin("m.setor", "setor")
				.where("m.id = (SELECT MAX(m2.id) FROM ManutencaoCorretiva m2 WHERE m2.setor.idSetor = ?1)")
				.and("setor.idSetor = ?1");
		List<ManutencaoCorretiva> manutencaoCorretivas = buscar(builder.builder(), ManutencaoCorretiva.class, idSetor);
		if (!CollectionUtils.isNullOrEmpty(manutencaoCorretivas)) {
			return manutencaoCorretivas.get(0);
		}

		return null;
	}

	public ManutencaoCorretiva buscarPorId(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoCorretiva.class, "m")
				.innerJoin("m.equipamento", "e").innerJoin("m.centroCusto", "c").where("m.id = ?");
		List<ManutencaoCorretiva> manutencaoCorretivas = buscar(builder.builder(), ManutencaoCorretiva.class,
				idManutencao);
		if (!CollectionUtils.isNullOrEmpty(manutencaoCorretivas)) {
			return manutencaoCorretivas.get(0);
		}

		return null;
	}

	public ManutencaoCorretiva buscarPorNumeroSolicitacao(String numeroSolicitacao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoCorretiva.class, "m")
				.innerJoin("m.equipamento", "e").innerJoin("e.historicosSituacaoEquipamento", "h")
				.innerJoin("h.centroCusto", "hc").innerJoin("m.centroCusto", "c").where("m.numeroSolicitacao = ?")
				.and("h.idHistoricoSituacaoEquipamento = (SELECT MAX (h2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento h2 WHERE h2.equipamento.idEquipamento = e.idEquipamento)");
		List<ManutencaoCorretiva> manutencaoCorretivas = buscar(builder.builder(), ManutencaoCorretiva.class,
				numeroSolicitacao);
		if (!CollectionUtils.isNullOrEmpty(manutencaoCorretivas)) {
			return manutencaoCorretivas.get(0);
		}

		return null;
	}

	public ManutencaoCorretiva buscarPorNumeroSolicitacaoPorHierarquia(String numeroSolicitacao,
			List<String> codigosCentroCustoHierarquia, String setor) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoCorretiva.class, "m")
				.innerJoin("m.setor", "sm")
				.innerJoin("m.equipamento", "e").innerJoin("e.historicosSituacaoEquipamento", "h")
				.innerJoin("h.centroCusto", "hc").innerJoin("m.centroCusto", "c").where("m.numeroSolicitacao = ?1")
				.and("(c.codigoCentroCusto in (?2) OR (c.codigoCentroCusto NOT IN (?2) AND sm.nomeSetor = '" + setor +"'))")
				.and("h.idHistoricoSituacaoEquipamento = (SELECT MAX (h2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento h2 WHERE h2.equipamento.idEquipamento = e.idEquipamento)");
		List<ManutencaoCorretiva> manutencaoCorretivas = buscar(builder.builder(), ManutencaoCorretiva.class,
				numeroSolicitacao, codigosCentroCustoHierarquia);
		if (!CollectionUtils.isNullOrEmpty(manutencaoCorretivas)) {
			return manutencaoCorretivas.get(0);
		}

		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<ManutencaoCorretivaConsultaVO> buscarPaginadaAbertaReaberta(Pagina pagina, List<Long> setores)
			throws ParseException {

		StringBuilder stringBuilder = new StringBuilder(
				"SELECT DISTINCT mv.ID_MANUTENCAO, mv.NR_SOLICITACAO, mv.TIPO, mv.NM_STATUS, mv.DT_CRIACAO, mv.DT_STATUS, mv.CD_mANUTENCAO, "
						+ "CONCAT(mv.TX_SIGLA_CENTRO_CUSTO, ' - ', mv.CD_CENTRO_CUSTO) "
						+ "FROM VW_SIMEQ_MANUTENCAO_STATUS mv "
						+ "INNER JOIN MANUTENCAO_CORRETIVA MC ON MC.ID_MANUTENCAO_CORRETIVA = mv.ID_MANUTENCAO "
						+ "WHERE (mv.CD_CENTRO_CUSTO IN (:centrosCusto) "
						+ "OR MC.ID_SETOR_MANUTENCAO IN (:querySetores) )"
						+ "AND (mv.ID_TECNICO IS NULL OR mv.ID_TECNICO <> (:idTecnico))");
		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString());
		query.setParameter("centrosCusto", pagina.getModelVO().getParametros().get("centroCustosHierarquia"));
		query.setParameter("querySetores", setores);
		query.setParameter("idTecnico", pagina.getModelVO().getParametros().get("idTecnico"));
		pagina.setPrimeiroRegistro(pagina.getPrimeiroRegistro());
		pagina.setTamanho(pagina.getTamanho());
		pagina.setRegistros(this.processarRetornoAlocacoes(query.getResultList(), pagina.getPrimeiroRegistro(), pagina.getTamanho()));
		pagina.setTotalDeRegistros(query.getResultList().size());
		return pagina;

	}

	private List<ManutencaoCorretivaConsultaVO> processarRetornoAlocacoes(List<Object[]> alocacoesNaoTratadas,
			Integer primeiroRegistro, Integer tamanho) throws ParseException {
		List<ManutencaoCorretivaConsultaVO> alocacoes = new ArrayList<ManutencaoCorretivaConsultaVO>();
		for(int i = primeiroRegistro; i < ((primeiroRegistro + tamanho -1) > 9 ? (primeiroRegistro + tamanho -1): alocacoesNaoTratadas.size()); i++) {
			ManutencaoCorretivaConsultaVO alocacao = new ManutencaoCorretivaConsultaVO(
					new Long(alocacoesNaoTratadas.get(i)[0].toString()));
			alocacao.setNumeroSolicitacao(alocacoesNaoTratadas.get(i)[1].toString());
			alocacao.setTipo(alocacoesNaoTratadas.get(i)[2].toString());
			alocacao.setStatus(alocacoesNaoTratadas.get(i)[3].toString());
			alocacao.setDataCadastro(new SimpleDateFormat("yyyy-MM-dd").parse(alocacoesNaoTratadas.get(i)[4].toString()));
			alocacao.setDataAlteracao(new SimpleDateFormat("yyyy-MM-dd").parse(alocacoesNaoTratadas.get(i)[5].toString()));
			alocacao.setCodigoManutencaoEquipamento(alocacoesNaoTratadas.get(i)[6].toString());
			alocacao.setCentroCusto(alocacoesNaoTratadas.get(i)[7].toString());
			alocacoes.add(alocacao);
		}
		
		return alocacoes;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<ManutencaoCorretivaConsultaVO> buscarPaginadaAbertaReaberta2(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.ManutencaoCorretivaConsultaVO(m.id, m.numeroSolicitacao, s.nome, m.dataCriacao, ma.auditoriaId.auditoria.dataAuditoria, e.codigoManutencao, "
						+ "CONCAT(c.textoSiglaCentroCusto, ' - ', c.codigoCentroCusto))")
				.from(ManutencaoCorretivaAuditoria.class, "ma").innerJoin("ma.manutencaoCorretiva", "m")
				.innerJoin("m.historicoStatus", "h").innerJoin("m.equipamento", "e").innerJoin("m.centroCusto", "c")
				.innerJoin("h.statusManutencaoCorretiva", "s")
				.where(pagina.getModelVO(), "h.id.idStatusManutencao IN [idsStatus]")
				.and("c.codigoCentroCusto IN ([centroCustosHierarquia])")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoCorretiva h2 WHERE h2.id.idManutencaoCorretiva = m.id)",
						false)
				.and("ma.auditoriaId.auditoria.idAuditoria = (SELECT MAX (ma2.auditoriaId.auditoria.idAuditoria) FROM ManutencaoCorretivaAuditoria ma2 WHERE ma2.numeroSolicitacao = m.numeroSolicitacao)",
						false)
				.and("m.id NOT IN (SELECT mt.manutencaoCorretiva.id FROM ManutencaoCorretivaTecnico mt WHERE mt.id.idManutencaoCorretiva = m.id AND mt.id.idTecnico = [idTecnico])");
		return (Pagina<ManutencaoCorretivaConsultaVO>) buscar(pagina, builder.builder(),
				"distinct m.numeroSolicitacao");
	}

	@SuppressWarnings("unchecked")
	public Pagina<AvaliacaoManutencaoCorretivaDTO> filtrarAvaliacoes(Pagina<AvaliacaoManutencaoCorretivaDTO> pagina,
			String setor) {

		StringBuilder stringBuilder = new StringBuilder(
				" WITH cteCentroCusto (CD_CENTRO_CUSTO_PAI, CD_CENTRO_CUSTO) AS "
						+ " (SELECT CD_CENTRO_CUSTO_PAI, CD_CENTRO_CUSTO FROM VW_DN_CENTRO_CUSTO WHERE CD_CENTRO_CUSTO = (select CD_CENTRO_CUSTO from VW_DN_PESSOA where CD_MATRICULA = :matriculaUsuarioLogado ) "
						+ " UNION ALL " + " SELECT v.CD_CENTRO_CUSTO_PAI, v.CD_CENTRO_CUSTO FROM VW_DN_CENTRO_CUSTO v "
						+ " JOIN cteCentroCusto c ON c.CD_CENTRO_CUSTO = v.CD_CENTRO_CUSTO_PAI) " + " select * from ( "
						+ " select " + " mc.ID_MANUTENCAO_CORRETIVA as id, "
						+ " case when mc.FL_CLASSE_MANUTENCAO = 'C' then 'Corretiva' else 'Serviço de Apoio' end as classeManutencao, "
						+ " mc.NR_SOLICITACAO as numeroSolicitacao, " + " stt_mc.NM_STATUS as descricaoStatus, "
						+ " convert(varchar, stt_completo.DT_STATUS, 103)+' '+substring(convert(varchar, stt_completo.DT_STATUS, 108), 1, 5) as dataAlteracao, "
						+ " e.CD_MANUTENCAO as codigoManutencao, "
						+ " cc.TX_HIERARQUIA_CENTRO_CUSTO as centroCustoInstalacao, "
						+ " convert(varchar, mc.DT_CRIACAO, 103)+' '+substring(convert(varchar, mc.DT_CRIACAO, 108), 1, 5) as dataCadastro, "
						+ " row_number() OVER ( ORDER BY mc.ID_MANUTENCAO_CORRETIVA ) AS numeroLinha " + " from "
						+ " MANUTENCAO_CORRETIVA mc "
						+ " INNER JOIN EQUIPAMENTO e ON mc.ID_EQUIPAMENTO = e.ID_EQUIPAMENTO "
						+ " INNER JOIN (select ID_MANUTENCAO_CORRETIVA, max(ID_SEQUENCIAL) ID_SEQUENCIAL from RE_STT_MANUTENCAO_CORRETIVA group by ID_MANUTENCAO_CORRETIVA) stt on stt.ID_MANUTENCAO_CORRETIVA = mc.ID_MANUTENCAO_CORRETIVA "
						+ " INNER JOIN RE_STT_MANUTENCAO_CORRETIVA stt_completo on stt.ID_MANUTENCAO_CORRETIVA=stt_completo.ID_MANUTENCAO_CORRETIVA and stt.ID_SEQUENCIAL = stt_completo.ID_SEQUENCIAL "
						+ " INNER JOIN STT_MANUTENCAO_CORRETIVA stt_mc on stt_mc.ID_STATUS=stt_completo.ID_STATUS "
						+ " INNER JOIN VW_DN_CENTRO_CUSTO cc ON cc.CD_CENTRO_CUSTO = mc.CD_CENTRO_CUSTO "
						+ " INNER JOIN SETOR_MANUTENCAO s ON mc.ID_SETOR_MANUTENCAO = s.ID_SETOR_MANUTENCAO"
						+ " where ( ( 4 in :perfisUsuarioLogado ) or ( 6 in :perfisUsuarioLogado ) "
						+ " or (s.NM_SETOR_MANUTENCAO = :setor) or ( mc.CD_CENTRO_CUSTO in (select CD_CENTRO_CUSTO from cteCentroCusto))) "
						+ " and stt_completo.ID_STATUS=3 "
						+ " ) tabela_final where tabela_final.numeroLinha between :paginaInicio and :paginaFim ORDER BY tabela_final.dataAlteracao DESC");

		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString());
		query.setParameter("matriculaUsuarioLogado", pagina.getModelVO().getParametros().get("matriculaUsuarioLogado"));
		query.setParameter("perfisUsuarioLogado", pagina.getModelVO().getParametros().get("perfisUsuarioLogado"));
		query.setParameter("paginaInicio", pagina.getPrimeiroRegistro() + 1);
		query.setParameter("setor", setor);
		query.setParameter("paginaFim", pagina.getPrimeiroRegistro() + pagina.getTamanho());
		pagina.setRegistros(processarRetornoBuscaFiltrarAvaliacoes(query.getResultList()));
		pagina.setTotalDeRegistros(this.filtrarAvaliacoesNumeroDeRegistros(pagina, setor));
		return pagina;
	}
	private Integer filtrarAvaliacoesNumeroDeRegistros(Pagina<AvaliacaoManutencaoCorretivaDTO> pagina, String setor) {
		StringBuilder stringBuilder = new StringBuilder(
				" WITH cteCentroCusto (CD_CENTRO_CUSTO_PAI, CD_CENTRO_CUSTO) AS "
						+ " (SELECT CD_CENTRO_CUSTO_PAI, CD_CENTRO_CUSTO FROM VW_DN_CENTRO_CUSTO WHERE CD_CENTRO_CUSTO = (select CD_CENTRO_CUSTO from VW_DN_PESSOA where CD_MATRICULA = :matriculaUsuarioLogado ) "
						+ " UNION ALL " + " SELECT v.CD_CENTRO_CUSTO_PAI, v.CD_CENTRO_CUSTO FROM VW_DN_CENTRO_CUSTO v "
						+ " JOIN cteCentroCusto c ON c.CD_CENTRO_CUSTO = v.CD_CENTRO_CUSTO_PAI) " + " select "
						+ "	count(*) as quantidade_registros " + " from " + " MANUTENCAO_CORRETIVA mc "
						+ " INNER JOIN EQUIPAMENTO e ON mc.ID_EQUIPAMENTO = e.ID_EQUIPAMENTO "
						+ " INNER JOIN (select ID_MANUTENCAO_CORRETIVA, max(ID_SEQUENCIAL) ID_SEQUENCIAL from RE_STT_MANUTENCAO_CORRETIVA group by ID_MANUTENCAO_CORRETIVA) stt on stt.ID_MANUTENCAO_CORRETIVA = mc.ID_MANUTENCAO_CORRETIVA "
						+ " INNER JOIN RE_STT_MANUTENCAO_CORRETIVA stt_completo on stt.ID_MANUTENCAO_CORRETIVA=stt_completo.ID_MANUTENCAO_CORRETIVA and stt.ID_SEQUENCIAL = stt_completo.ID_SEQUENCIAL "
						+ " INNER JOIN STT_MANUTENCAO_CORRETIVA stt_mc on stt_mc.ID_STATUS=stt_completo.ID_STATUS "
						+ " INNER JOIN VW_DN_CENTRO_CUSTO cc ON cc.CD_CENTRO_CUSTO = mc.CD_CENTRO_CUSTO "
						+ " INNER JOIN SETOR_MANUTENCAO s ON mc.ID_SETOR_MANUTENCAO = s.ID_SETOR_MANUTENCAO"
						+ " where ( ( 4 in :perfisUsuarioLogado ) or ( 6 in :perfisUsuarioLogado ) or ( mc.CD_CENTRO_CUSTO in (select CD_CENTRO_CUSTO from cteCentroCusto)) or (s.NM_SETOR_MANUTENCAO = :setor)) and stt_completo.ID_STATUS=3 ");

		Query query = this.getEntityManager().createNativeQuery(stringBuilder.toString());
		query.setParameter("matriculaUsuarioLogado", pagina.getModelVO().getParametros().get("matriculaUsuarioLogado"));
		query.setParameter("perfisUsuarioLogado", pagina.getModelVO().getParametros().get("perfisUsuarioLogado"));
		query.setParameter("setor", setor);
		return (Integer) query.getSingleResult();
	}

	List<AvaliacaoManutencaoCorretivaDTO> processarRetornoBuscaFiltrarAvaliacoes(List<Object[]> lista) {
		List<AvaliacaoManutencaoCorretivaDTO> avaliacoes = new ArrayList<AvaliacaoManutencaoCorretivaDTO>();
		for (Object[] item : lista) {
			AvaliacaoManutencaoCorretivaDTO avaliacao = new AvaliacaoManutencaoCorretivaDTO();
			avaliacao.setId(new Long(item[0].toString()));
			avaliacao.setClasseManutencao(item[1].toString());
			avaliacao.setNumeroSolicitacao(item[2].toString());
			avaliacao.setDescricaoStatus(item[3].toString());
			avaliacao.setDataAlteracao(item[4].toString());
			avaliacao.setCodigoManutencao(item[5].toString());
			avaliacao.setCentroCustoInstalacao(item[6].toString());
			avaliacao.setDataCadastro(item[7].toString());
			avaliacoes.add(avaliacao);
		}
		return avaliacoes;
	}

	public RelatorioManutencaoCorretivaVO bsucarRelatorioManutencaoCorretiva(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoCorretivaVO(m.id, m.numeroSolicitacao, e.codigoManutencao, c.textoHierarquiaCentroCusto,"
						+ "m.matriculaSolicitante, (SELECT p.nome FROM PessoaView p WHERE p.matricula = m.matriculaSolicitante), m.dataCriacao, m.observacao, m.flagClasseManutencao, "
						+ "m.paralisacao, h.statusManutencaoCorretiva, "
						+ "(SELECT SUM(a.horasSemParalisacao) FROM AtividadeCorretiva a WHERE a.manutencaoCorretiva.id = m.id), "
						+ "(SELECT SUM(a.minutosSemParalisacao) FROM AtividadeCorretiva a WHERE a.manutencaoCorretiva.id = m.id), "
						+ "(SELECT SUM(a.horasComParalisacao) FROM AtividadeCorretiva a WHERE a.manutencaoCorretiva.id = m.id), "
						+ "(SELECT SUM(a.minutosComParalisacao) FROM AtividadeCorretiva a WHERE a.manutencaoCorretiva.id = m.id), "
						+ "(SELECT h2.dataCriacao " + "		FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "		WHERE h2.id.idManutencaoCorretiva = m.id "
						+ "		AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "									FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "									WHERE h3.id.idStatusManutencao = ?2"
						+ "									AND h3.id.idManutencaoCorretiva = m.id)), "
						+ "(SELECT h2.matriculaUsuario " + "		FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "		WHERE h2.id.idManutencaoCorretiva = m.id "
						+ "		AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "									FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "									WHERE h3.id.idStatusManutencao = ?2"
						+ "									AND h3.id.idManutencaoCorretiva = m.id)), "
						+ "(SELECT p.nome " + "		FROM PessoaView p"
						+ "		WHERE p.matricula = (SELECT h2.matriculaUsuario "
						+ "								FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "								WHERE h2.id.idManutencaoCorretiva = m.id "
						+ "								AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "																	FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "																	WHERE h3.id.idStatusManutencao = ?2"
						+ "																	AND h3.id.idManutencaoCorretiva = m.id))), "
						+ "(SELECT h2.dataCriacao " + "		FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "		WHERE h2.id.idManutencaoCorretiva = ?1 "
						+ "		AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "									FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "									WHERE h3.id.idStatusManutencao = ?3"
						+ "									AND h3.id.idManutencaoCorretiva = ?1)), "
						+ "(SELECT p.nome " + "		FROM PessoaView p"
						+ "		WHERE p.matricula = (SELECT h2.matriculaUsuario "
						+ "								FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "								WHERE h2.id.idManutencaoCorretiva = m.id "
						+ "								AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "																	FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "																	WHERE h3.id.idStatusManutencao = ?3"
						+ "																	AND h3.id.idManutencaoCorretiva = ?1))),"
						+ "(SELECT h2.dataCriacao " + "		FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "		WHERE h2.id.idManutencaoCorretiva = m.id "
						+ "		AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "									FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "									WHERE h3.id.idStatusManutencao = ?4"
						+ "									AND h3.id.idManutencaoCorretiva = m.id)), "
						+ "(SELECT p.nome " + "		FROM PessoaView p"
						+ "		WHERE p.matricula = (SELECT h2.matriculaUsuario "
						+ "								FROM HistoricoStatusManutencaoCorretiva h2 "
						+ "								WHERE h2.id.idManutencaoCorretiva = m.id "
						+ "								AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "																	FROM HistoricoStatusManutencaoCorretiva h3 "
						+ "																	WHERE h3.id.idStatusManutencao = ?4"
						+ "																	AND h3.id.idManutencaoCorretiva = m.id))))")
				.from(ManutencaoCorretiva.class, "m").innerJoin("m.equipamento", "e").innerJoin("m.centroCusto", "c")
				.innerJoin("m.historicoStatus", "h").where("m.id = ?1")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoCorretiva h2 WHERE h2.id.idManutencaoCorretiva = m.id)");
		List<RelatorioManutencaoCorretivaVO> resultado = buscar(builder.builder(), RelatorioManutencaoCorretivaVO.class,
				idManutencao, StatusManutencaoCorretivaEnum.RECURSO_ALOCADO.getCodigo(),
				StatusManutencaoCorretivaEnum.AG_ACEITE.getCodigo(),
				StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo());
		return resultado.get(0);

	}

	public List<SubRelatorioManutencaoAtividadesVO> buscarSubRelatorioCorretivaAtividades(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoAtividadesVO(a.id, sub.grupoPai.descricaoGrupo, sub.descricaoGrupo, a.acao.nome,"
						+ "a.componente.nome, a.executante.matricula, a.horaAtividade, a.minutosAtividade, a.observacao)")
				.from(AtividadeCorretiva.class, "a").innerJoin("a.manutencaoCorretiva", "m")
				.innerJoin("a.subGrupo", "sub").where("m.id = ?").order("a.id");
		return buscar(builder.builder(), SubRelatorioManutencaoAtividadesVO.class, idManutencao);

	}

	public List<SubRelatorioManutencaoMateriaisVO> buscarSubRelatorioCorretivaMateriais(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoMateriaisVO(materiais.descricaoMaterialOutros, "
						+ "materialView.codigo, materialView.descricao, materiais.quantidadeMaterial)")
				.from(AtividadeCorretiva.class, "a").innerJoin("a.manutencaoCorretiva", "m")
				.innerJoin("a.materiais", "materiais").leftJoin("materiais.materialView", "materialView")
				.where("m.id = ?");
		return buscar(builder.builder(), SubRelatorioManutencaoMateriaisVO.class, idManutencao);

	}

	public List<RankEquipamentoVO> gerarRankEquipamento(RelatorioRankEquipamentoFiltroVO filtro) {
		IWhere builder = JPQLBuilder.getInstance().select(
				" new br.gov.cmb.simeq.relatorio.vo.RankEquipamentoVO(e.codigoManutencao, COUNT(m.id) as quantSolicitacao, e.idEquipamento, e.nomeEquipamento)")
				.from(ManutencaoCorretivaAuditoria.class, "ma").innerJoin("ma.manutencaoCorretiva", "m")
				.innerJoin("m.equipamento", "e").innerJoin("m.centroCusto", "c").where("c.codigoCentroCusto IN (?1)")
				.and("cast(ma.auditoriaId.auditoria.dataAuditoria as date) >= cast(?2 as date)")
				.and("cast(ma.auditoriaId.auditoria.dataAuditoria as date) <= cast(?3 as date)");

		StringBuilder hql = new StringBuilder(builder.builder());
		hql.append(" GROUP BY e.idEquipamento, e.codigoManutencao, e.nomeEquipamento");
		hql.append(" ORDER BY quantSolicitacao DESC");
		List<RankEquipamentoVO> relatorioRankEquipamento = buscar(hql, RankEquipamentoVO.class,
				filtro.getCentroCustos(), filtro.getPeriodoInicio(), filtro.getPeriodoFim());

		return ajusteQuantGraficos(relatorioRankEquipamento);
	}

	public List<RankEquipamentoVO> ajusteQuantGraficos(List<RankEquipamentoVO> relatorioRankEquipamento) {
		String esp = "";

		if (relatorioRankEquipamento.size() < MIM_CHART) {
			for (int i = 0; i < MIM_CHART; i++) {
				if (relatorioRankEquipamento.size() < MIM_CHART) {
					relatorioRankEquipamento.add(new RankEquipamentoVO(esp, null, (long) i, null));
				}
				esp += " ";
			}
		} else if (relatorioRankEquipamento.size() > MAX_CHART) {
			int aux = relatorioRankEquipamento.size() - MAX_CHART;
			for (int i = 0; i < aux; i++) {
				relatorioRankEquipamento.remove(MAX_CHART);
			}
		}

		return relatorioRankEquipamento;
	}

	public List<SubRelatorioGestaoEstrategicaDiaVO> gerarSubRelatorioGestaoEstrategicaDia(
			RelatorioGestaoEstrategicaFiltroVO filtro) {

		@SuppressWarnings("unchecked")
		List<SubRelatorioGestaoEstrategicaDiaVO> registros = ((TypedQuery<SubRelatorioGestaoEstrategicaDiaVO>) this
				.preencherParametrosGestaoEstrategica(this.getEntityManager().createNamedQuery(
						"filtrarGestaoEstrategicaDia", SubRelatorioGestaoEstrategicaDiaVO.class), filtro))
								.getResultList();
		return registros;
	}

	public List<SubRelatorioGestaoEstrategicaGrupoVO> gerarSubRelatorioGestaoEstrategicaGrupo(
			RelatorioGestaoEstrategicaFiltroVO filtro) {

		@SuppressWarnings("unchecked")
		List<SubRelatorioGestaoEstrategicaGrupoVO> registros = ((TypedQuery<SubRelatorioGestaoEstrategicaGrupoVO>) this
				.preencherParametrosGestaoEstrategica(this.getEntityManager().createNamedQuery(
						"filtrarGestaoEstrategicaGrupo", SubRelatorioGestaoEstrategicaGrupoVO.class), filtro))
								.getResultList();
		return registros;
	}

	public List<SubRelatorioGestaoEstrategicaMaterialVO> gerarSubRelatorioGestaoEstrategicaMaterial(
			RelatorioGestaoEstrategicaFiltroVO filtro) {

		@SuppressWarnings("unchecked")
		List<SubRelatorioGestaoEstrategicaMaterialVO> registros = ((TypedQuery<SubRelatorioGestaoEstrategicaMaterialVO>) this
				.preencherParametrosGestaoEstrategica(this.getEntityManager().createNamedQuery(
						"filtrarGestaoEstrategicaMaterial", SubRelatorioGestaoEstrategicaMaterialVO.class), filtro))
								.getResultList();
		return registros;
	}

	public List<SubRelatorioGestaoEstrategicaSolicitacaoVO> geraSubRelatorioGestaoEstrategicaSolicitacao(
			RelatorioGestaoEstrategicaFiltroVO filtro) {

		@SuppressWarnings("unchecked")
		List<SubRelatorioGestaoEstrategicaSolicitacaoVO> registros = ((TypedQuery<SubRelatorioGestaoEstrategicaSolicitacaoVO>) this
				.preencherParametrosGestaoEstrategica(
						this.getEntityManager().createNamedQuery("filtrarGestaoEstrategicaSolicitacao",
								SubRelatorioGestaoEstrategicaSolicitacaoVO.class),
						filtro)).getResultList();
		return registros;
	}

	@SuppressWarnings("unchecked")
	public RelatorioGestaoEstrategicaParametrosVO geraSubRelatorioGestaoEstrategicaParametros(
			RelatorioGestaoEstrategicaFiltroVO filtro) {

		RelatorioGestaoEstrategicaParametrosVO relatorioGestaoEstrategicaParametrosVO = new RelatorioGestaoEstrategicaParametrosVO();

		relatorioGestaoEstrategicaParametrosVO.setDataInicial(filtro.getDataInicial());
		relatorioGestaoEstrategicaParametrosVO.setDataFinal(filtro.getDataFinal());

		relatorioGestaoEstrategicaParametrosVO.setQuantidadeSolicitacoes(
				((TypedQuery<Integer>) this.preencherParametrosGestaoEstrategica(this.getEntityManager()
						.createNamedQuery("retornarGestaoEstrategicaQuantidadeSolicitacoes", Integer.class), filtro))
								.getSingleResult());

		relatorioGestaoEstrategicaParametrosVO.setValorMaterial(
				((TypedQuery<Double>) this.preencherParametrosGestaoEstrategica(this.getEntityManager()
						.createNamedQuery("retornarGestaoEstrategicaValorMaterial", Double.class), filtro))
								.getSingleResult());

		relatorioGestaoEstrategicaParametrosVO.setPrincipalAvaria(
				((TypedQuery<String>) this.preencherParametrosGestaoEstrategica(this.getEntityManager()
						.createNamedQuery("retornarGestaoEstrategicaPrincipalAvaria", String.class), filtro))
								.getSingleResult());

		relatorioGestaoEstrategicaParametrosVO
				.setValorMaoObra(((TypedQuery<Double>) this.preencherParametrosGestaoEstrategica(
						this.getEntityManager().createNamedQuery("retornarGestaoEstrategicaValorMaoObra", Double.class),
						filtro)).getSingleResult());

		relatorioGestaoEstrategicaParametrosVO.setGrupoQueMaisFalha(
				((TypedQuery<String>) this.preencherParametrosGestaoEstrategica(this.getEntityManager()
						.createNamedQuery("retornarGestaoEstrategicaGrupoQueMaisFalha", String.class), filtro))
								.getSingleResult());

		return relatorioGestaoEstrategicaParametrosVO;
	}

	@SuppressWarnings("rawtypes")
	private TypedQuery preencherParametrosGestaoEstrategica(TypedQuery typedQuery,
			RelatorioGestaoEstrategicaFiltroVO relatorio) {
		Integer centrosCustoSize = centrosCustoSize(relatorio.getCentrosCusto());
		List<String> centrosCusto = buscarCentroCusto(relatorio.getCentrosCusto());

		typedQuery.setParameter("dataInicial", relatorio.getDataInicial())
				.setParameter("dataFinal", relatorio.getDataFinal()).setParameter("centrosCustoSize", centrosCustoSize)
				.setParameter("centrosCusto", centrosCusto);

		return typedQuery;
	}

	private Integer centrosCustoSize(List<String> centroCusto) {
		if (centroCusto != null && centroCusto.size() > 0) {
			return centroCusto.size();
		}
		return 0;
	}

	private List<String> buscarCentroCusto(List<String> centrosCusto) {
		if (centrosCusto != null && centrosCusto.size() > 0) {
			return centrosCusto;
		}
		return Arrays.asList("0");
	}
}
