package br.gov.cmb.simeq.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.TypedQuery;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.entidade.AtividadePreventiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.vo.AprovacaoPreventivaConsultaTabelaVO;
import br.gov.cmb.simeq.vo.PreventivaCadastroVO;
import br.gov.cmb.simeq.vo.PreventivaConsultaTabelaVO;
import br.gov.cmb.simeq.vo.RelatorioManutencaoPreventivaAnualFiltro;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoAtividadesVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoMateriaisVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoPreventivaAnualVO;

public class ManutencaoPreventivaDAO extends GenericoPaginadoDAO<ManutencaoPreventiva, Long> {

	private static final long serialVersionUID = 5858008959932499428L;
	
	public List<PreventivaCadastroVO> buscarPreventivasPorEquipamentoCentroCusto(Long idEquipamento, String codigoCentroCusto) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.PreventivaCadastroVO(mp.id, e.idEquipamento, c.codigoCentroCusto, c.textoHierarquiaCentroCusto, mp.numeroSolicitacao, "
						+ " mp.mes, mp.ano, mp.diaInicio, mp.diaFim, mp.qtdHoras, mp.matriculaSolicitante, h.id.idStatusManutencao, mp.setor.idSetor, mp.setor.nomeSetor, "
						+ " mp.qtdHorasExecutadas)")
				.from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "e")
				.innerJoin("mp.centroCusto", "c")
				.innerJoin("mp.historicoStatus", "h")
				.where("e.idEquipamento = ?1")
				.and("(mp.ano = YEAR(GETDATE()) OR mp.ano = (YEAR(GETDATE()) + 1))")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)");
		return buscar(builder.builder(), PreventivaCadastroVO.class, idEquipamento);
	}

	public List<ManutencaoPreventiva> buscarPreventivasJaCadastrada(Long idEquipamento, String codigoCentroCusto,
			Integer ano, Integer mes, Long idPreventiva) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("mp").from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "e").innerJoin("mp.centroCusto", "c").where("e.idEquipamento = ?1")
				.and("c.codigoCentroCusto = ?2").and("mp.ano = ?3").and("mp.mes = ?4").and("mp.id <> ?5");
		return buscar(builder.builder(), ManutencaoPreventiva.class, idEquipamento, codigoCentroCusto, ano, mes,
				idPreventiva);
	}

	public HistoricoStatusManutencaoPreventiva buscarDataUltimaConcluidaPorEquipamento(Long idEquipamento) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("hs").from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "e").innerJoin("mp.historicoStatus", "hs").where("e.idEquipamento = ?1")
				.and("hs.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)")
				.and("hs.id.idStatusManutencao = ?2").order("hs.dataCriacao");
		List<HistoricoStatusManutencaoPreventiva> result = buscar(builder.builder(),
				HistoricoStatusManutencaoPreventiva.class, idEquipamento,
				StatusManutencaoPreventivaEnum.CONCLUIDA.getCodigo());
		if (!result.isEmpty()) {
			return result.get(0);
		} else {
			return null;
		}
	}

	public ManutencaoPreventiva buscarPorNumeroSolicitacao(String numeroSolicitacao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoPreventiva.class, "m")
				.innerJoin("m.equipamento", "e").innerJoin("e.historicosSituacaoEquipamento", "h")
				.innerJoin("h.centroCusto", "hc").innerJoin("m.centroCusto", "c").where("m.numeroSolicitacao = ?")
				.and("h.idHistoricoSituacaoEquipamento = (SELECT MAX (h2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento h2 WHERE h2.equipamento.idEquipamento = e.idEquipamento)");
		List<ManutencaoPreventiva> manutencaoPreventivas = buscar(builder.builder(), ManutencaoPreventiva.class,
				numeroSolicitacao);
		if (!CollectionUtils.isNullOrEmpty(manutencaoPreventivas)) {
			return manutencaoPreventivas.get(0);
		}

		return null;
	}

	public ManutencaoPreventiva buscarUltimoRegistroCadastradoPorCentroCusto(String codigoCentroCusto) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoPreventiva.class, "m")
				.innerJoin("m.centroCusto", "c")
				.where("m.id = (SELECT MAX(m2.id) FROM ManutencaoPreventiva m2 WHERE m2.centroCusto.codigoCentroCusto = ?1)")
				.and("c.codigoCentroCusto = ?1");
		List<ManutencaoPreventiva> manutencaopreventivas = buscar(builder.builder(), ManutencaoPreventiva.class,
				codigoCentroCusto);
		if (!CollectionUtils.isNullOrEmpty(manutencaopreventivas)) {
			return manutencaopreventivas.get(0);
		}

		return null;
	}
	
	public ManutencaoPreventiva buscarUltimoRegistroCadastradoPorSetor(Long idSetor) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("m")
				.from(ManutencaoPreventiva.class, "m")
				.innerJoin("m.setor", "setor")
				.where("m.id = (SELECT MAX(m2.id) FROM ManutencaoPreventiva m2 WHERE m2.setor.idSetor = ?1)")
				.and("setor.idSetor = ?1");
		List<ManutencaoPreventiva> manutencaoCorretivas = buscar(builder.builder(), ManutencaoPreventiva.class, idSetor);
		if(!CollectionUtils.isNullOrEmpty(manutencaoCorretivas)) {
			return manutencaoCorretivas.get(0);
		}
		
		return null;
	}
	
	public PreventivaCadastroVO buscarPreventivaPorNumeroSolicitacao(String numeroSolicitacao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.PreventivaCadastroVO(mp.id, e.idEquipamento, c.codigoCentroCusto, c.textoHierarquiaCentroCusto, mp.numeroSolicitacao, "
						+ " mp.mes, mp.ano, mp.diaInicio, mp.diaFim, mp.qtdHoras, mp.matriculaSolicitante, h.id.idStatusManutencao, mp.setor.idSetor, mp.setor.nomeSetor, "
						+ " mp.qtdHorasExecutadas)")
				.from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "e")
				.innerJoin("mp.centroCusto", "c")
				.innerJoin("mp.historicoStatus", "h")
				.where("mp.numeroSolicitacao = ?1")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)");
		List<PreventivaCadastroVO> preventivas = buscar(builder.builder(), PreventivaCadastroVO.class,
				numeroSolicitacao);
		if (CollectionUtils.isNullOrEmpty(preventivas)) {
			return null;
		}
		return preventivas.get(0);
	}

	public ManutencaoPreventiva buscarPorNumeroSolicitacaoPorHierarquia(String numeroSolicitacao,
			List<String> codigosCentroCustoHierarquia) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("m").from(ManutencaoPreventiva.class, "m")
				.innerJoin("m.equipamento", "e").innerJoin("e.historicosSituacaoEquipamento", "h")
				.innerJoin("h.centroCusto", "hc").innerJoin("m.centroCusto", "c").where("m.numeroSolicitacao = ?1")
				.and("h.idHistoricoSituacaoEquipamento = (SELECT MAX (h2.idHistoricoSituacaoEquipamento) FROM HistoricoSituacaoEquipamento h2 WHERE h2.equipamento.idEquipamento = e.idEquipamento)");
		List<ManutencaoPreventiva> manutencoess = buscar(builder.builder(), ManutencaoPreventiva.class,
				numeroSolicitacao);
		if (!CollectionUtils.isNullOrEmpty(manutencoess)) {
			return manutencoess.get(0);
		}

		return null;
	}

	public ManutencaoPreventiva buscarPorNumeroSolicitacaoStatus(String numeroSolicitacao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("mp").from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "e").innerJoin("mp.centroCusto", "c").innerJoin("mp.historicoStatus", "h")
				.where("mp.numeroSolicitacao = ?1")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)");
		List<ManutencaoPreventiva> preventivas = buscar(builder.builder(), ManutencaoPreventiva.class,
				numeroSolicitacao);
		if (!CollectionUtils.isNullOrEmpty(preventivas)) {
			return preventivas.get(0);
		}
		return null;
	}

	public List<ManutencaoPreventiva> buscarPreventivaComQuinzeDiasAntecedencia() {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("mp").from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "e").innerJoin("mp.centroCusto", "c")
				.where("mp.ano = YEAR(DATEADD(DAY, 15, GETDATE()))").and("mp.mes = MONTH(DATEADD(DAY, 15, GETDATE()))")
				.and("mp.diaInicio = DATEPART(DAY, DATEADD(DAY, 15, GETDATE()))");
		return buscar(builder.builder(), ManutencaoPreventiva.class);
	}

	public List<ManutencaoPreventiva> buscarPreventivaComQuinzeDiasRealizada() {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("distinct mp").from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.centroCusto", "centroCusto").innerJoin("mp.historicoStatus", "hs")
				.where("DATEDIFF(DAY, CAST(CAST(mp.ano AS string) + '-' + CAST(mp.mes AS string) + '-' + CAST(mp.diaFim AS string) as date), CAST(GETDATE() as date)) >= 15")
				.and("hs.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)")
				.and("hs.id.idStatusManutencao in (?1)");
		return buscar(builder.builder(), ManutencaoPreventiva.class,
				Lists.newArrayList(StatusManutencaoPreventivaEnum.ABERTA.getCodigo()));
	}

	public List<ManutencaoPreventiva> buscarPreventivaExperida() {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("distinct mp").from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.centroCusto", "centroCusto").innerJoin("mp.equipamento", "equipamento")
				.innerJoin("mp.historicoStatus", "hs")
				.where("CAST(GETDATE() as date) > CAST( CAST(mp.ano AS string) + '-' + CAST(mp.mes AS string) + '-' + CAST(mp.diaFim AS string) AS date)")
				.and("hs.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)")
				.and("hs.id.idStatusManutencao not in (?1)");
		return buscar(builder.builder(), ManutencaoPreventiva.class,
				Lists.newArrayList(StatusManutencaoPreventivaEnum.CONCLUIDA.getCodigo(),
						StatusManutencaoPreventivaEnum.MANUTENCAO_EXPERIDA.getCodigo()));
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<PreventivaConsultaTabelaVO> filtrar(Pagina pagina, String setor) {
		
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.PreventivaConsultaTabelaVO(mp.id, eq.codigoManutencao, eq.nomeEquipamento, mp.dataCriacao, s.nome, s.id, mp.numeroSolicitacao, "
						+ "CONCAT(c.textoHierarquiaCentroCusto, ' - ', c.codigoCentroCusto), "
						+ "CONCAT(CAST(mp.ano AS text), '-',  CAST(mp.mes AS text), '-',CAST(mp.diaInicio AS text) ), "
						+ "CAST( CAST(mp.ano AS string) + '-' + CAST(mp.mes AS string) + '-' + CAST(mp.diaFim AS string) AS date)   )")
				.from(ManutencaoPreventiva.class, "mp")
				.innerJoin("mp.equipamento", "eq")
				.innerJoin("mp.setor", "sm")
				.innerJoin("mp.historicoStatus", "h")
				.innerJoin("mp.centroCusto", "c")
				.leftJoin("eq.grupos", "g")
				.leftJoin("g.subgrupos", "subg")
				.innerJoin("h.statusManutencaoPreventiva", "s")
				.where(pagina.getModelVO(), "(c.codigoCentroCusto IN ([centroCustosHierarquia]) OR (c.codigoCentroCusto NOT IN ([centroCustosHierarquia]) AND sm.nomeSetor = '" + setor +"'))")
				.and("mp.numeroSolicitacao = [numeroSolicitacao]")
				.and("eq.idEquipamento = [idEquipamento]")
				.and("mp.matriculaSolicitante IN (SELECT p.matricula FROM PessoaView p WHERE p.nome like [solicitante])")
				.and("CAST( CAST(mp.ano AS string) + '-' + CAST(mp.mes AS string) + '-' + CAST(mp.diaFim AS string) AS date)  >= cast([periodoInicio] as date)")
				.and("CAST( CAST(mp.ano AS string) + '-' + CAST(mp.mes AS string) + '-' + CAST(mp.diaFim AS string) AS date) <= cast([periodoFim] as date)")
				.and("h.id.idStatusManutencao IN ([idsStatus])")
				.and("c.codigoCentroCusto IN ([centroCustos])")
				.and("g.idGrupo = [idGrupo]")
				.and("subg.idGrupo IN ([idsSubGrupo])")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)",
						false)
				.order("CAST( CAST(mp.ano AS string) + '-' + CAST(mp.mes AS string) + '-' + CAST(mp.diaFim AS string) AS date) ");
		return (Pagina<PreventivaConsultaTabelaVO>) buscar(pagina, builder.builder(), "distinct mp.numeroSolicitacao");
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<AprovacaoPreventivaConsultaTabelaVO> filtrarManutencaoAprovacao(Pagina pagina, List<Long> setores) {
		String querySetores = setores.toString().replace('[', ' ').replace(']', ' ');
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.AprovacaoPreventivaConsultaTabelaVO(mp.id, mp.numeroSolicitacao, mp.mes, mp.diaInicio, mp.diaFim, "
						+ " mp.qtdHoras)")
				.from(ManutencaoPreventiva.class, "mp").innerJoin("mp.equipamento", "eq")
				.innerJoin("mp.historicoStatus", "h").innerJoin("mp.centroCusto", "c")
				.innerJoin("h.statusManutencaoPreventiva", "s")
				.where(pagina.getModelVO(), "(mp.setor.idSetor IN ("+ (setores.size() > 0 ? querySetores : 0) + ") OR c.codigoCentroCusto = [centroCusto])")
				.and("eq.idEquipamento = [idEquipamento]").and("mp.ano = [ano]")
				.and("h.id.idStatusManutencao = [idStatus]")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = mp.id)",
						false);
		return (Pagina<AprovacaoPreventivaConsultaTabelaVO>) buscar(pagina, builder.builder(),
				"distinct mp.numeroSolicitacao");
	}

	public RelatorioManutencaoPreventivaVO buscarRelatorioManutencaoPreventiva(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoPreventivaVO(m.id, m.numeroSolicitacao, e.codigoManutencao, e.nomeEquipamento, c.textoHierarquiaCentroCusto, "
						+ " (SELECT h2.dataCriacao"
						+ "		FROM HistoricoStatusManutencaoPreventiva h2"
						+ "		WHERE h2.id.idManutencaoPreventiva = m.id "
						+ "		AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial)"
						+ "									FROM HistoricoStatusManutencaoPreventiva h3 "
						+ "									WHERE h3.id.idStatusManutencao = ?2"
						+ "									AND h3.id.idManutencaoPreventiva = m.id)), "
						+ " (SELECT p.nome "
						+ "		FROM PessoaView p"
						+ "		WHERE p.matricula = (SELECT h2.matriculaUsuario "
						+ "								FROM HistoricoStatusManutencaoPreventiva h2 "
						+ "								WHERE h2.id.idManutencaoPreventiva = m.id "
						+ "								AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "																	FROM HistoricoStatusManutencaoPreventiva h3 "
						+ "																	WHERE h3.id.idStatusManutencao = ?2"
						+ "																	AND h3.id.idManutencaoPreventiva = m.id))), "
						+ " m.qtdHoras, m.qtdHorasExecutadas, h.statusManutencaoPreventiva, "
						+ " (SELECT h2.dataCriacao"
						+ "		FROM HistoricoStatusManutencaoPreventiva h2"
						+ "		WHERE h2.id.idManutencaoPreventiva = m.id "
						+ "		AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial)"
						+ "									FROM HistoricoStatusManutencaoPreventiva h3 "
						+ "									WHERE h3.id.idStatusManutencao = ?3"
						+ "									AND h3.id.idManutencaoPreventiva = m.id)), "
						+ " (SELECT p.nome "
						+ "		FROM PessoaView p"
						+ "		WHERE p.matricula = (SELECT h2.matriculaUsuario "
						+ "								FROM HistoricoStatusManutencaoPreventiva h2 "
						+ "								WHERE h2.id.idManutencaoPreventiva = m.id "
						+ "								AND h2.id.idSequencial = (SELECT MIN(h3.id.idSequencial) "
						+ "																	FROM HistoricoStatusManutencaoPreventiva h3 "
						+ "																	WHERE h3.id.idStatusManutencao = ?3"
						+ "																	AND h3.id.idManutencaoPreventiva = m.id))), "
						+ " m.ano, m.mes, m.diaInicio)")
				.from(ManutencaoPreventiva.class, "m")
				.innerJoin("m.equipamento", "e")
				.innerJoin("m.centroCusto", "c")
				.innerJoin("m.historicoStatus", "h")
				.where("m.id = ?1")
				.and("h.id.idSequencial = (SELECT MAX (h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 WHERE h2.id.idManutencaoPreventiva = m.id)");
		List<RelatorioManutencaoPreventivaVO> resultado = buscar(builder.builder(),
				RelatorioManutencaoPreventivaVO.class, idManutencao, StatusManutencaoPreventivaEnum.EM_MANUTENCAO.getCodigo(), 
				StatusManutencaoPreventivaEnum.CONCLUIDA.getCodigo());
		return resultado.get(0);

	}

	public List<SubRelatorioManutencaoAtividadesVO> buscarSubRelatorioPreventivaAtividades(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoAtividadesVO(a.id, sub.grupoPai.descricaoGrupo, sub.descricaoGrupo, a.acao.nome,"
						+ "a.componente.nome, a.executante.matricula, a.horaAtividade, a.minutosAtividade, a.observacao)")
				.from(AtividadePreventiva.class, "a").innerJoin("a.manutencaoPreventiva", "m")
				.innerJoin("a.subGrupo", "sub").where("m.id = ?").order("a.id");
		return buscar(builder.builder(), SubRelatorioManutencaoAtividadesVO.class, idManutencao);

	}

	public List<SubRelatorioManutencaoMateriaisVO> buscarSubRelatorioPreventivaMateriais(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select(
				"DISTINCT new br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoMateriaisVO(materiais.descricaoMaterialOutros, materialView.codigo, "
				+ " materialView.descricao, materiais.quantidadeMaterial)")
				.from(AtividadePreventiva.class, "a")
				.innerJoin("a.manutencaoPreventiva", "m")
				.innerJoin("a.materiais", "materiais")
				.leftJoin("materiais.materialView", "materialView")
				.where("m.id = ?");
		return buscar(builder.builder(), SubRelatorioManutencaoMateriaisVO.class, idManutencao);
	}
		
	public List<SubRelatorioManutencaoPreventivaAnualVO> gerarSubRelatorioManutencaoPreventivaAnual(RelatorioManutencaoPreventivaAnualFiltro filtro) {
		
		List<SubRelatorioManutencaoPreventivaAnualVO> registros =	
				((TypedQuery<SubRelatorioManutencaoPreventivaAnualVO>) this.preencherParametrosPreventivaAnual(this.getEntityManager()
				.createNamedQuery("filtrarManutencao", SubRelatorioManutencaoPreventivaAnualVO.class)
				,filtro))
				.getResultList();
		return registros;
	}

	private TypedQuery<SubRelatorioManutencaoPreventivaAnualVO> preencherParametrosPreventivaAnual(TypedQuery<SubRelatorioManutencaoPreventivaAnualVO> typedQuery, 
			RelatorioManutencaoPreventivaAnualFiltro relatorio) {
		Integer centrosCustoSize = centrosCustoSize(relatorio.getCentrosCusto());
		List<String> centrosCusto = buscarCentroCusto(relatorio.getCentrosCusto());

		typedQuery.setParameter("ano", relatorio.getAno())
				.setParameter("centrosCustoSize", centrosCustoSize)
				.setParameter("centrosCusto", centrosCusto);

		return typedQuery;

	}
	
	private Integer centrosCustoSize(List<String> centroCusto) {
		if (centroCusto != null && centroCusto.size() > 0) {
			return centroCusto.size();
		}
		return 0;
	}
	
	private List<String> buscarCentroCusto(List<String>centrosCusto){
		if(centrosCusto != null && centrosCusto.size() > 0) {
			return centrosCusto;
		}
		return Arrays.asList("0");
	}

}
