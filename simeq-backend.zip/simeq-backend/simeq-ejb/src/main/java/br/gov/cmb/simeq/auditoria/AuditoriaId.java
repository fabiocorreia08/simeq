package br.gov.cmb.simeq.auditoria;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import com.google.common.base.Objects;

@Embeddable
public class AuditoriaId implements Serializable {

	private static final long serialVersionUID = -7597399953491756779L;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ID_AUDITORIA", referencedColumnName = "ID_AUDITORIA")
	private Auditoria auditoria;

	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof AuditoriaId)) {
			return false;
		}
		AuditoriaId castOther = (AuditoriaId) other;
		return Objects.equal(auditoria, castOther.auditoria);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(auditoria);
	}

	public Auditoria getAuditoria() {
		return auditoria;
	}

	public void setAuditoria(Auditoria auditoria) {
		this.auditoria = auditoria;
	}
	
	

}
