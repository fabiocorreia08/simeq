package br.gov.cmb.simeq.validador;

import java.util.Date;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.dao.HistoricoSituacaoEquipamentoDAO;
import br.gov.cmb.simeq.entidade.HistoricoSituacaoEquipamento;

@Stateless
public class SituacaoEquipamentoValidador extends AbstractValidador {
	
	@Inject
	private HistoricoSituacaoEquipamentoDAO  historicoSituacaoEquipamentoDAO;
	
	@RegraDeValidacao
	public void validarDatas(Date dataInicio, Long idEquipamento, Boolean compararComUltimaSituacaoEquipamento) {
		HistoricoSituacaoEquipamento historicoSituacaoEquipamento = historicoSituacaoEquipamentoDAO.buscarUltimoOuPenultimoRegistro(compararComUltimaSituacaoEquipamento, idEquipamento);
		if(!((DataUtils.obterDataComHoraZerada(dataInicio).after(DataUtils.obterDataComHoraZerada(historicoSituacaoEquipamento.getDataInicio()))))) {
			throw new ValidacaoException("O período informado conflita com períodos anteriores.");
		}
	}
	
}
