package br.gov.cmb.simeq.dao;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.vo.HistoricoStatusPreventivaVO;

@Named
@RequestScoped
public class HistStatusManutencaoPreventivaDAO extends GenericoPaginadoDAO<HistoricoStatusManutencaoPreventiva, Long>{

	private static final long serialVersionUID = -9184148277578727733L;
	
	public HistoricoStatusManutencaoPreventiva buscarUltimoHistoricoInserido(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("h")
				.from(HistoricoStatusManutencaoPreventiva.class, "h")
				.innerJoin("h.manutencaoPreventiva", "sm")
				.where("h.id.idManutencaoPreventiva = ?1")
				.and("h.id.idSequencial = (SELECT MAX(h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 where h2.id.idManutencaoPreventiva = ?1)");
		List<HistoricoStatusManutencaoPreventiva> historico = buscar(builder.builder(), HistoricoStatusManutencaoPreventiva.class, idManutencao);
		if(!CollectionUtils.isNullOrEmpty(historico)) {
			return historico.get(0);
		}
		
		return null;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<HistoricoStatusPreventivaVO> filtrar(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.HistoricoStatusPreventivaVO(h.id.idSequencial, h.dataCriacao, s.nome, p.matricula, p.nome)")
				.from(HistoricoStatusManutencaoPreventiva.class, "h")
				.innerJoin("h.statusManutencaoPreventiva", "s")
				.innerJoin("h.manutencaoPreventiva", "m")
				.leftJoin("h.usuarioResponsavelPelaAlteracao", "p")
				.where(pagina.getModelVO(), "m.numeroSolicitacao =  [numeroSolicitacao]")
				.order("h.id.idSequencial");	
		return (Pagina<HistoricoStatusPreventivaVO>)buscar(pagina, builder.builder(), "distinct h.id.idSequencial");
	}
	
	public HistoricoStatusManutencaoPreventiva buscarUltimoHistoricoInseridoComManutencaoCorretivaEUsuarioResponsavelPelaAlteracao(Long idManutencao) {

		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("h")
				.from(HistoricoStatusManutencaoPreventiva.class, "h")
				.innerJoin("h.statusManutencaoPreventiva", "sm")
				.innerJoinFetch("h.manutencaoPreventiva", "mc")
				.innerJoinFetch("h.usuarioResponsavelPelaAlteracao", "ura")
				.where("h.id.idSequencial = (SELECT MAX(h2.id.idSequencial) FROM HistoricoStatusManutencaoPreventiva h2 where h2.id.idManutencaoPreventiva = ?1)")
				.and("h.id.idManutencaoPreventiva = ?1");
		List<HistoricoStatusManutencaoPreventiva> historico = buscar(builder.builder(), HistoricoStatusManutencaoPreventiva.class, idManutencao);
		if(!CollectionUtils.isNullOrEmpty(historico)) {
			return historico.get(0);
		}
		return null;
	}
}
