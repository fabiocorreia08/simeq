package br.gov.cmb.simeq.vo;

import java.util.List;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class ManutencaoCorretivaTecnicoFiltroVO extends ModeloVO {
	
	private static final long serialVersionUID = -7763307763941183124L;

	@ParametroNomeado
	private String numeroSolicitacao;
	
	@ParametroNomeado
	private String nomeCargo;
	
	@ParametroNomeado
	private Long idTecnico;
	
	@ParametroNomeado
	private String centroCusto;
	
	@ParametroNomeado
	private List<String> listaTextoHierarquiaCentroCusto;
	
	@ParametroNomeado
	private String codigoTurno;
	
	@ParametroNomeado
	private String matriculaTecnicoLogado;
	
	private Integer perfil;
	
	private String matricula;
	
	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getNomeCargo() {
		return nomeCargo;
	}

	public void setNomeCargo(String nomeCargo) {
		this.nomeCargo = nomeCargo;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public List<String> getListaTextoHierarquiaCentroCusto() {
		return listaTextoHierarquiaCentroCusto;
	}

	public void setListaTextoHierarquiaCentroCusto(List<String> listaTextoHierarquiaCentroCusto) {
		this.listaTextoHierarquiaCentroCusto = listaTextoHierarquiaCentroCusto;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getCodigoTurno() {
		return codigoTurno;
	}

	public void setCodigoTurno(String codigoTurno) {
		this.codigoTurno = codigoTurno;
	}

	public String getMatriculaTecnicoLogado() {
		return matriculaTecnicoLogado;
	}

	public void setMatriculaTecnicoLogado(String matriculaTecnicoLogado) {
		this.matriculaTecnicoLogado = matriculaTecnicoLogado;
	}
	
}
