package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import br.gov.cmb.simeq.enums.AtivoInativoEnum;

@Audited
@Entity
@Table(name = "HISTORICO_SITUACAO_EQUIPAMENTO")
public class HistoricoSituacaoEquipamento implements Serializable {

	private static final long serialVersionUID = -4751287550420827979L;

	@Id
	@Column(name = "ID_HISTORICO_SITUACAO_EQUIPAMENTO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idHistoricoSituacaoEquipamento;

	@Column(name = "FL_STATUS")
	@Enumerated(EnumType.STRING)
	private AtivoInativoEnum flagStatus;

	@Column(name = "CD_CENTRO_CUSTO")
	private String codigoCentroCusto;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CD_CENTRO_CUSTO", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private CentroCustoView centroCusto;

	@Column(name = "DT_INICIO")
	@Temporal(TemporalType.DATE)
	private Date dataInicio;

	@Column(name = "DT_FIM")
	@Temporal(TemporalType.DATE)
	private Date dataFim;

	@Column(name = "DS_OBSERVACAO")
	private String descricaoObservacao;

	@ManyToOne
	@JoinColumn(name = "ID_EQUIPAMENTO")
	private Equipamento equipamento;

	public HistoricoSituacaoEquipamento() {

	}

	public HistoricoSituacaoEquipamento(Long id, AtivoInativoEnum status, String codigoCentroCusto,
			Date dataInicio, Date dataFim, String observacao, Long idEquipamento, String textoHierarquia) {
		this.idHistoricoSituacaoEquipamento = id;
		this.flagStatus = status;
		this.codigoCentroCusto = codigoCentroCusto;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
		this.descricaoObservacao = observacao;
		this.equipamento = new Equipamento(idEquipamento);
		this.centroCusto = new CentroCustoView(codigoCentroCusto);
		this.centroCusto.setTextoHierarquiaCentroCusto(textoHierarquia);
	}

	public Long getIdHistoricoSituacaoEquipamento() {
		return idHistoricoSituacaoEquipamento;
	}

	public void setIdHistoricoSituacaoEquipamento(Long idHistoricoSituacaoEquipamento) {
		this.idHistoricoSituacaoEquipamento = idHistoricoSituacaoEquipamento;
	}

	public AtivoInativoEnum getFlagStatus() {
		return flagStatus;
	}

	public void setFlagStatus(AtivoInativoEnum flagStatus) {
		this.flagStatus = flagStatus;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String descricaoObservacao) {
		this.descricaoObservacao = descricaoObservacao;
	}

	public Equipamento getEquipamento() {
		return equipamento;
	}

	public void setEquipamento(Equipamento equipamento) {
		this.equipamento = equipamento;
	}

	public CentroCustoView getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(CentroCustoView centroCusto) {
		this.centroCusto = centroCusto;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((idHistoricoSituacaoEquipamento == null) ? 0 : idHistoricoSituacaoEquipamento.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HistoricoSituacaoEquipamento other = (HistoricoSituacaoEquipamento) obj;
		if (idHistoricoSituacaoEquipamento == null) {
			if (other.idHistoricoSituacaoEquipamento != null)
				return false;
		} else if (!idHistoricoSituacaoEquipamento.equals(other.idHistoricoSituacaoEquipamento))
			return false;
		return true;
	}

}
