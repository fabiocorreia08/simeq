package br.gov.cmb.simeq.relatorio.vo;

import java.io.Serializable;

public class RankEquipamentoVO implements Serializable {

	private static final long serialVersionUID = 3665030032188695499L;
	
	private String codigoEquipamento;
	private String nomeEquipamento;
	private Long quantidadeSolicitacoes;
	private Long idEquipamento;
	
	public RankEquipamentoVO(){}
	
	public RankEquipamentoVO(String codigoEquipamento, Long quantidadeSolicitacoes, Long idEquipamento, String nomeEquipamento) {
		this.setCodigoEquipamento(codigoEquipamento);
		this.quantidadeSolicitacoes = quantidadeSolicitacoes;
		this.idEquipamento = idEquipamento;
		this.nomeEquipamento = nomeEquipamento;
	}

	public String getNomeEquipamento() {
		return nomeEquipamento;
	}

	public void setNomeEquipamento(String nomeEquipamento) {
		this.nomeEquipamento = nomeEquipamento;
	}

	public Long getQuantidadeSolicitacoes() {
		return quantidadeSolicitacoes;
	}

	public void setQuantidadeSolicitacoes(Long quantidadeSolicitacoes) {
		this.quantidadeSolicitacoes = quantidadeSolicitacoes;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoEquipamento() {
		return codigoEquipamento;
	}

	public void setCodigoEquipamento(String codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}
}
