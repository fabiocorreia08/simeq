package br.gov.cmb.simeq.vo.relatorio;

import java.util.List;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorioGrupo")
public class RelatorioGestaoEstrategicaGrupoVO extends RelatorioDataSource<SubRelatorioGestaoEstrategicaGrupoVO> {

	private static final long serialVersionUID = 4764113515187319080L;
	
	public RelatorioGestaoEstrategicaGrupoVO(List<SubRelatorioGestaoEstrategicaGrupoVO> lista) {
		super(lista);
		// TODO Auto-generated constructor stub
	}

}
