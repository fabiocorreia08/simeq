package br.gov.cmb.simeq.vo;

import java.util.Date;
import java.util.List;

import javax.ws.rs.QueryParam;

import com.google.common.collect.Lists;

public class RelatorioGestaoEstrategicaFiltroVO {

	@QueryParam(value = "dataInicial")
	private Date dataInicial;
	
	@QueryParam(value = "dataFinal")
	private Date dataFinal;
	
	@QueryParam(value = "centrosCusto")
	private List<String> centrosCusto = Lists.newArrayList();

	public List<String> getCentrosCusto() {
		return centrosCusto;
	}

	public void setCentrosCusto(List<String> centrosCusto) {
		this.centrosCusto = centrosCusto;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(Date dataFim) {
		this.dataFinal = dataFim;
	}
}
