package br.gov.cmb.simeq.vo;

import java.util.Date;
import java.util.List;

import javax.inject.Named;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

@Named
public class ManutencaoCorretivaFiltroVO extends ModeloVO {

	private static final long serialVersionUID = -6810332944018490386L;
	
	@ParametroNomeado
	private String numeroSolicitacao;
	
	@ParametroNomeado
	private List<Long> idsStatus = Lists.newArrayList();
	
	@ParametroNomeado
	private List<String> centroCustos = Lists.newArrayList();
	
	@ParametroNomeado
	private List<String> centroCustosHierarquia = Lists.newArrayList();
	
	@ParametroNomeado
	private Date periodoInicio;
	
	@ParametroNomeado
	private Date periodoFim;
	
	@ParametroNomeado(like = true)
	private String solicitante;
	
	@ParametroNomeado
	private Long idEquipamento;
	
	@ParametroNomeado
	private Long idGrupo;
	
	@ParametroNomeado
	private List<Long> idsSubGrupo = Lists.newArrayList();
	
	private Integer perfil;
	
	private String matricula;
	
	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public List<String> getCentroCustos() {
		return centroCustos;
	}

	public void setCentroCustos(List<String> centroCustos) {
		this.centroCustos = centroCustos;
	}

	public Date getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(Date periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public Date getPeriodoFim() {
		return periodoFim;
	}

	public void setPeriodoFim(Date periodoFim) {
		this.periodoFim = periodoFim;
	}

	public String getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public Long getIdGrupo() {
		return idGrupo;
	}

	public void setIdGrupo(Long idGrupo) {
		this.idGrupo = idGrupo;
	}

	public List<Long> getIdsStatus() {
		return idsStatus;
	}

	public void setIdsStatus(List<Long> idsStatus) {
		this.idsStatus = idsStatus;
	}

	public List<Long> getIdsSubGrupo() {
		return idsSubGrupo;
	}

	public void setIdsSubGrupo(List<Long> idsSubGrupo) {
		this.idsSubGrupo = idsSubGrupo;
	}

	public List<String> getCentroCustosHierarquia() {
		return centroCustosHierarquia;
	}

	public void setCentroCustosHierarquia(List<String> centroCustosHierarquia) {
		this.centroCustosHierarquia = centroCustosHierarquia;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

}
