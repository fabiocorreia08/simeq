package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.Componente;

public class ComponenteDAO extends GenericoPaginadoDAO<Componente, String>{

	private static final long serialVersionUID = -4855686674233218229L;
	
	public List<LabelValueDTO> buscarTodosLabelValue() {
		IJPQLBuilder jpql = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(c.nome, c.codigo) ")
				.from(Componente.class, "c");
		return buscar(jpql.builder(), LabelValueDTO.class);
	}

}
