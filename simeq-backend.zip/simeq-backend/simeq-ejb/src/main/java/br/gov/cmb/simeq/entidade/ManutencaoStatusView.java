package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VW_SIMEQ_MANUTENCAO_STATUS")
public class ManutencaoStatusView implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID_MANUTENCAO")
	private Long id;
	
	@Column(name = "NR_SOLICITACAO")
	private String numeroSolicitacao;
	
	@Column(name = "NM_STATUS")
	private String nomeStatus;
	
	@Column(name = "DT_CRIACAO")
	private Date dataCriacao;
	
	@Column(name = "DT_STATUS")
	private Date dataAlteracao;
	
	@Column(name= "CD_MANUTENCAO")
	private String cdManutencao; 
	
	@Column(name = "CD_CENTRO_CUSTO")
	private String centroCusto;
	
	@Column(name = "TX_SIGLA_CENTRO_CUSTO")
	private String siglaCentroCusto;
	
	@Column(name= "TIPO")
	private String tipo;
	
	@Column(name= "ID_TECNICO")
	private Long tecnico;

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	public String getNomeStatus() {
		return nomeStatus;
	}

	public void setNomeStatus(String nomeStatus) {
		this.nomeStatus = nomeStatus;
	}

	public Long getTecnico() {
		return tecnico;
	}

	public void setTecnico(Long tecnico) {
		this.tecnico = tecnico;
	}

	public Date getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(Date dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSiglaCentroCusto() {
		return siglaCentroCusto;
	}

	public void setSiglaCentroCusto(String siglaCentroCusto) {
		this.siglaCentroCusto = siglaCentroCusto;
	}

	public String getCdManutencao() {
		return cdManutencao;
	}

	public void setCdManutencao(String cdManutencao) {
		this.cdManutencao = cdManutencao;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

}
