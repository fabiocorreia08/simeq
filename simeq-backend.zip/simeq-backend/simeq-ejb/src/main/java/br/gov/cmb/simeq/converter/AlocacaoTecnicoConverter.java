package br.gov.cmb.simeq.converter;

import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;
import br.gov.cmb.simeq.vo.AlocacaoTecnicoVO;

public class AlocacaoTecnicoConverter {
	
	public static ManutencaoCorretivaTecnico converter(AlocacaoTecnicoVO alocacao) {
		return new ManutencaoCorretivaTecnico(alocacao.getIdManutencao(), alocacao.getIdTecnico(), alocacao.getMatriculaTecnico());
	}
	
	public static AlocacaoTecnicoVO converter(ManutencaoCorretivaTecnico alocacao) {
		return new AlocacaoTecnicoVO(alocacao.getId().getIdManutencaoCorretiva(), alocacao.getMatriculaResponsavel().getMatricula(), alocacao.getId().getIdTecnico());
	}
	
	public static ManutencaoPreventivaTecnico converterPreventiva(AlocacaoTecnicoVO alocacao) {
		return new ManutencaoPreventivaTecnico(alocacao.getIdManutencao(), alocacao.getIdTecnico(), alocacao.getMatriculaTecnico());
	}

	public static AlocacaoTecnicoVO converterPreventiva(ManutencaoPreventivaTecnico alocacao) {
		return new AlocacaoTecnicoVO(alocacao.getId().getIdManutencaoPreventiva(), alocacao.getMatriculaResponsavel().getMatricula(), alocacao.getId().getIdTecnico());
	}
}
