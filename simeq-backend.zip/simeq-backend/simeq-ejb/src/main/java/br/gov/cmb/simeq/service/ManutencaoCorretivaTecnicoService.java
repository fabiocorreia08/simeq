package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.google.common.collect.Lists;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.converter.AlocacaoTecnicoConverter;
import br.gov.cmb.simeq.converter.CadastroAlocacaoTecnicoConverter;
import br.gov.cmb.simeq.converter.ManutencaoCorretivaConverter;
import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.HistStatusManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaTecnicoDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaTecnicoDAO;
import br.gov.cmb.simeq.dao.ParametroDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretivaTecnico;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.ManutencaoPreventivaTecnico;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.utils.VerificaClasseUtil;
import br.gov.cmb.simeq.validador.ManutencaoCorretivaTecnicoValidador;
import br.gov.cmb.simeq.validador.ManutencaoCorretivaValidador;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarFiltroVO;
import br.gov.cmb.simeq.vo.AlocacaoCadastrarVO;
import br.gov.cmb.simeq.vo.AlocacaoDetalharVO;
import br.gov.cmb.simeq.vo.AlocacaoTecnicoVO;
import br.gov.cmb.simeq.vo.CadastroAlocacaoTecnicoVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaTecnicoConsultaVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaTecnicoFiltroVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.PreventivaCadastroVO;

@Stateless
public class ManutencaoCorretivaTecnicoService {
	
	@Inject
	private ManutencaoCorretivaTecnicoDAO manutencaoCorretivaTecnicoDAO;
	
	@Inject
	private ManutencaoPreventivaTecnicoDAO manutencaoPreventivaTecnicoDAO;
	
	@Inject
	private HistoricoStatusManutencaoCorretivaDAO historicoStatusManutencaoCorretivaDAO;
	
	@Inject
	private HistStatusManutencaoPreventivaDAO historicoStatusManutencaoPreventivaDAO;
	
	@Inject
	private TecnicoDAO tecnicoDAO;
	
	@Inject
	private CentroCustoService centroCustoService;
	
	@Inject
	private EmailService emailService;
	
	@Inject 
	private ParametroDAO parametroDAO;
	
	@Inject
	private ManutencaoCorretivaDAO manutencaoCorretivaDAO;
	
	@Inject
	private ManutencaoPreventivaDAO manutencaoPreventivaDAO;
	
	@Inject
	private AtividadeCorretivaDAO atividadeDAO;
	
	@Inject
	private ManutencaoCorretivaTecnicoValidador manutencaoCorretivaTecnicoValidador;
	
	@Inject
	private ManutencaoCorretivaValidador manutencaoCorretivaValidador;
	
	@Inject
	private PessoaViewDAO pessoaViewDAO;
	
	private static final Long ID_PARAMETRO_ALOCACAO_TECNICO = new Long(1);
	
	public Pagina<AlocacaoDetalharVO> buscarAlocacaoManutencao(Pagina<AlocacaoDetalharVO> pagina) {
		return manutencaoCorretivaTecnicoDAO.buscarAlocacaoManutencao(pagina);
	}
	
	public Pagina<ManutencaoCorretivaTecnicoConsultaVO> filtrar(Pagina<ManutencaoCorretivaTecnicoConsultaVO> pagina) {
		String matricula = ((ManutencaoCorretivaTecnicoFiltroVO)pagina.getModelVO()).getMatricula();
		Integer perfil = ((ManutencaoCorretivaTecnicoFiltroVO)pagina.getModelVO()).getPerfil();
		if(PerfilEnum.TECNICO.getIdPerfil().equals(perfil)) {
			((ManutencaoCorretivaTecnicoFiltroVO)pagina.getModelVO()).setMatriculaTecnicoLogado(matricula);
		}
		List<String> codigosCentroCusto = this.centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		((ManutencaoCorretivaTecnicoFiltroVO)pagina.getModelVO()).setListaTextoHierarquiaCentroCusto(codigosCentroCusto);
		String setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
		
		return manutencaoCorretivaTecnicoDAO.filtrarView(pagina, setor);
	}
	
	public AlocacaoTecnicoVO salvarTecnico(AlocacaoTecnicoVO alocacaoTecnico) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(alocacaoTecnico.getNumeroSolicitacao());
		Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(alocacaoTecnico.getMatriculaTecnico());
		alocacaoTecnico.setIdTecnico(tecnico.getIdTecnico());
		
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			ManutencaoCorretivaTecnico manutencaoTecnico = AlocacaoTecnicoConverter.converter(alocacaoTecnico);
			ManutencaoCorretivaTecnico manutencaoTecnicoSalvo = manutencaoCorretivaTecnicoDAO.salvar(manutencaoTecnico);
			this.adicionarHistoricoStatusManutencaoCorretiva(alocacaoTecnico.getIdManutencao(), alocacaoTecnico.getMatriculaTecnico(), StatusManutencaoCorretivaEnum.RECURSO_ALOCADO.getCodigo());
			return AlocacaoTecnicoConverter.converter(manutencaoTecnicoSalvo);
		} else {
			ManutencaoPreventivaTecnico manutencaoPrevTecnico = AlocacaoTecnicoConverter.converterPreventiva(alocacaoTecnico);
			ManutencaoPreventivaTecnico manutencaoPrevTecnicoSalvo = manutencaoPreventivaTecnicoDAO.salvar(manutencaoPrevTecnico);
			this.adicionarHistoricoStatusManutencaoPreventiva(alocacaoTecnico.getIdManutencao(), alocacaoTecnico.getMatriculaTecnico(), StatusManutencaoCorretivaEnum.RECURSO_ALOCADO.getCodigo());
			return AlocacaoTecnicoConverter.converterPreventiva(manutencaoPrevTecnicoSalvo);
		}
	}
	
	public CadastroAlocacaoTecnicoVO salvarAlocacao(CadastroAlocacaoTecnicoVO cadastroAlocacaoTecnicoVO) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(cadastroAlocacaoTecnicoVO.getNumeroSolicitacao());
		
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			ManutencaoCorretiva manutencaoCorretiva = manutencaoCorretivaDAO.buscarPorNumeroSolicitacao(cadastroAlocacaoTecnicoVO.getNumeroSolicitacao());
			this.removerTecnicosAlocacaoCorretiva(cadastroAlocacaoTecnicoVO);
			boolean isEnviarEmailAlocacao = false;
			ManutencaoCorretivaVO maCorretivaVO = null;
			
			for (AlocacaoCadastrarVO alocacaoCadastrarVO : cadastroAlocacaoTecnicoVO.getListaAlocacaoCadastroTabela()) {
				Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(alocacaoCadastrarVO.getMatricula());
				alocacaoCadastrarVO.setIdTecnico(tecnico.getIdTecnico());
				if(alocacaoCadastrarVO.getIdManutencao() == null){				
					alocacaoCadastrarVO.setIdManutencao(manutencaoCorretiva.getId());
					ManutencaoCorretivaTecnico manutencaoTecnico = CadastroAlocacaoTecnicoConverter.converterCorretiva(alocacaoCadastrarVO);
					manutencaoCorretivaTecnicoDAO.salvar(manutencaoTecnico);
					maCorretivaVO = ManutencaoCorretivaConverter.converter(manutencaoCorretiva);
					maCorretivaVO.setNomeSolicitante(cadastroAlocacaoTecnicoVO.getNomeUsuarioLogado());
					isEnviarEmailAlocacao = true;
				}
			}
			
			if(CollectionUtils.isNullOrEmpty(manutencaoCorretivaTecnicoDAO.buscarTecnicosAlocados(cadastroAlocacaoTecnicoVO.getNumeroSolicitacao()))) {
				this.adicionarHistoricoStatusManutencaoCorretiva(manutencaoCorretiva.getId(), cadastroAlocacaoTecnicoVO.getMatriculaUsuarioLogado(), StatusManutencaoCorretivaEnum.ABERTA.getCodigo());
			} else {
				this.adicionarHistoricoStatusManutencaoCorretiva(manutencaoCorretiva.getId(), cadastroAlocacaoTecnicoVO.getMatriculaUsuarioLogado(), StatusManutencaoCorretivaEnum.RECURSO_ALOCADO.getCodigo());
			}	
			
			if(isEnviarEmailAlocacao) {
				String destinatario = parametroDAO.buscar(ID_PARAMETRO_ALOCACAO_TECNICO).getValor();
				emailService.enviarEmailAlocacaoTecnico(destinatario, maCorretivaVO.getNumeroSolicitacao(), maCorretivaVO.getNomeSolicitante(), maCorretivaVO.getClasseManutencao().getLabel(), maCorretivaVO.getParalizacao());
			}	
		}
		
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) {
			PreventivaCadastroVO manutencaoPreventiva = manutencaoPreventivaDAO.buscarPreventivaPorNumeroSolicitacao(cadastroAlocacaoTecnicoVO.getNumeroSolicitacao());
			manutencaoCorretivaTecnicoValidador.validarStatusAlocacaoPreventiva(cadastroAlocacaoTecnicoVO.getNumeroSolicitacao());
			this.removerTecnicosAlocacaoPreventiva(cadastroAlocacaoTecnicoVO);
			boolean isEnviarEmailAlocacao = false;
			//PreventivaCadastroVO maPreventivaVO = null;
			
			for (AlocacaoCadastrarVO alocacaoCadastrarVO : cadastroAlocacaoTecnicoVO.getListaAlocacaoCadastroTabela()) {
				Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(alocacaoCadastrarVO.getMatricula());
				alocacaoCadastrarVO.setIdTecnico(tecnico.getIdTecnico());
				if(alocacaoCadastrarVO.getIdManutencao() == null){				
					alocacaoCadastrarVO.setIdManutencao(manutencaoPreventiva.getId());
					ManutencaoPreventivaTecnico manutencaoTecnico = CadastroAlocacaoTecnicoConverter.converterPreventiva(alocacaoCadastrarVO);
					manutencaoPreventivaTecnicoDAO.salvar(manutencaoTecnico);
					//maPreventivaVO = ManutencaoPreventivaConverter.converter(manutencaoPreventiva);
					//maPreventivaVO.setNomeSolicitante(cadastroAlocacaoTecnicoVO.getNomeUsuarioLogado());
					isEnviarEmailAlocacao = true;
				}
			}
			
			if(CollectionUtils.isNullOrEmpty(manutencaoPreventivaTecnicoDAO.buscarTecnicosAlocados(cadastroAlocacaoTecnicoVO.getNumeroSolicitacao()))) {
				this.adicionarHistoricoStatusManutencaoPreventiva(manutencaoPreventiva.getId(), cadastroAlocacaoTecnicoVO.getMatriculaUsuarioLogado(), StatusManutencaoPreventivaEnum.APROVADA_GESTOR.getCodigo());
			} else {
				if(manutencaoPreventiva.getIdStatus() == StatusManutencaoPreventivaEnum.APROVADA_GESTOR.getCodigo()) {
					this.adicionarHistoricoStatusManutencaoPreventiva(manutencaoPreventiva.getId(), cadastroAlocacaoTecnicoVO.getMatriculaUsuarioLogado(), StatusManutencaoPreventivaEnum.RECURSO_ALOCADO.getCodigo());
				} else {
					this.adicionarHistoricoStatusManutencaoPreventiva(manutencaoPreventiva.getId(), cadastroAlocacaoTecnicoVO.getMatriculaUsuarioLogado(), manutencaoPreventiva.getIdStatus());
				}
			}
			
			if(isEnviarEmailAlocacao) {
				String destinatario = parametroDAO.buscar(ID_PARAMETRO_ALOCACAO_TECNICO).getValor();
				emailService.enviarEmailAlocacaoTecnico(destinatario, manutencaoPreventiva.getNumeroSolicitacao(), manutencaoPreventiva.getMatriculaSolicitante(), "Prevetiva", false);
			}
				
		}
		
		return cadastroAlocacaoTecnicoVO;
	}
	
	public boolean excluirAlocacao(String matriculaTecnico, String numeroSolicitacao) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			ManutencaoCorretiva manutencaoCorretiva = manutencaoCorretivaDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
			manutencaoCorretivaTecnicoValidador.validarSeAlocacaoPossuiAtividadeCorretiva(manutencaoCorretiva.getId(), matriculaTecnico);
			
			ManutencaoCorretivaTecnico manutencaoCorretivaTecnico = manutencaoCorretivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
			manutencaoCorretivaTecnicoDAO.remover(manutencaoCorretivaTecnico);
		}
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) {
			ManutencaoPreventiva manutencaoPreventiva = manutencaoPreventivaDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
			manutencaoCorretivaTecnicoValidador.validarSeAlocacaoPossuiAtividadePreventiva(manutencaoPreventiva.getId(), matriculaTecnico);
			manutencaoCorretivaTecnicoValidador.validarStatusAlocacaoPreventiva(manutencaoPreventiva.getNumeroSolicitacao());
			
			ManutencaoPreventivaTecnico manutencaoPreventivaTecnico = manutencaoPreventivaTecnicoDAO.buscarPorTecnicoAlocado(matriculaTecnico, numeroSolicitacao);
			manutencaoPreventivaTecnicoDAO.remover(manutencaoPreventivaTecnico);
		}
		
		return true;
	}
	
	public boolean isPermitdoexcluirAlocacao(String matriculaTecnico, String numeroSolicitacao) {
		IniciaisClasseManutencaoEnum classe = VerificaClasseUtil.verificaClasseManutencao(numeroSolicitacao);
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA) {
			ManutencaoCorretiva manutencaoCorretiva = manutencaoCorretivaDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
			manutencaoCorretivaTecnicoValidador.validarSeAlocacaoPossuiAtividadeCorretiva(manutencaoCorretiva.getId(), matriculaTecnico);
		}
		if(classe == IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA) {
			ManutencaoPreventiva manutencaoPreventiva = manutencaoPreventivaDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
			manutencaoCorretivaTecnicoValidador.validarSeAlocacaoPossuiAtividadePreventiva(manutencaoPreventiva.getId(), matriculaTecnico);
		}
		return true;
	}
	
	private void removerTecnicosAlocacaoCorretiva(CadastroAlocacaoTecnicoVO cadastroAlocacaoTecnicoVO) {
		if(!CollectionUtils.isNullOrEmpty(cadastroAlocacaoTecnicoVO.getListaAlocacaoRemovidasDaBase())) {
			for(AlocacaoCadastrarVO alocacaoRemovida : cadastroAlocacaoTecnicoVO.getListaAlocacaoRemovidasDaBase()) {
				ManutencaoCorretivaTecnico manutencaoCorretivaTecnico = manutencaoCorretivaTecnicoDAO.buscarPorId(alocacaoRemovida.getIdTecnico(), alocacaoRemovida.getIdManutencao());
				if(atividadeDAO.buscarAtividadePorManutencaoTecnicoAlocadoCorretiva(alocacaoRemovida.getIdManutencao(), alocacaoRemovida.getMatricula()) != null) {
					continue;
				}
				manutencaoCorretivaTecnicoDAO.remover(manutencaoCorretivaTecnico);
			}
		}
	}
	
	private void removerTecnicosAlocacaoPreventiva(CadastroAlocacaoTecnicoVO cadastroAlocacaoTecnicoVO) {
		if(!CollectionUtils.isNullOrEmpty(cadastroAlocacaoTecnicoVO.getListaAlocacaoRemovidasDaBase())) {
			for(AlocacaoCadastrarVO alocacaoRemovida : cadastroAlocacaoTecnicoVO.getListaAlocacaoRemovidasDaBase()) {
				ManutencaoPreventivaTecnico manutencaoCorretivaTecnico = manutencaoPreventivaTecnicoDAO.buscarPorId(alocacaoRemovida.getIdTecnico(), alocacaoRemovida.getIdManutencao());
				if(atividadeDAO.buscarAtividadePorManutencaoTecnicoAlocadoPreventiva(alocacaoRemovida.getIdManutencao(), alocacaoRemovida.getMatricula()) != null) {
					continue;
				}
				manutencaoPreventivaTecnicoDAO.remover(manutencaoCorretivaTecnico);
			}
		}
	}
	
	private void adicionarHistoricoStatusManutencaoCorretiva(Long idManutencao, String matriculaResponsavel, Long idStatus) {
		HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoStatusManutencaoCorretivaDAO.buscarUltimoHistoricoInserido(idManutencao);
		HistoricoStatusManutencaoCorretiva historico;
		if(!idStatus.equals(ultimoHistoricoCadastrado.getStatusManutencaoCorretiva().getId())) {			
			historico = new HistoricoStatusManutencaoCorretiva(idManutencao, idStatus, new Long(1), matriculaResponsavel);
			historico = new HistoricoStatusManutencaoCorretiva(idManutencao, idStatus, ultimoHistoricoCadastrado.getProximoSequencial(), matriculaResponsavel);
			historicoStatusManutencaoCorretivaDAO.salvar(historico);
		}
	}
	
	private void adicionarHistoricoStatusManutencaoPreventiva(Long idManutencao, String matriculaResponsavel, Long idStatus) {
		HistoricoStatusManutencaoPreventiva ultimoHistoricoCadastrado = historicoStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInserido(idManutencao);
		HistoricoStatusManutencaoPreventiva historico;
		if(!idStatus.equals(ultimoHistoricoCadastrado.getStatusManutencaoPreventiva().getId())) {			
			historico = new HistoricoStatusManutencaoPreventiva(idManutencao, idStatus, new Long(1), matriculaResponsavel);
			historico = new HistoricoStatusManutencaoPreventiva(idManutencao, idStatus, ultimoHistoricoCadastrado.getProximoSequencial(), matriculaResponsavel);
			historicoStatusManutencaoPreventivaDAO.salvar(historico);
		}
	}
	
	public Pagina<AlocacaoCadastrarVO> filtrarTecnicosParaCadastro(Pagina<AlocacaoCadastrarVO> pagina) {
		String matricula = ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getMatricula();
		Integer perfil = ((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).getPerfil();
		if(PerfilEnum.TECNICO.getIdPerfil().equals(perfil)) {
			pagina.setTamanho(1);
			pagina.setTotalDeRegistros(1);
			AlocacaoCadastrarVO alocacaoCadastrarVO = tecnicoDAO.buscarPerfilTecnico(matricula);
			pagina.setRegistros(Lists.newArrayList(alocacaoCadastrarVO));
			return pagina;
		}
		List<String> codigosCentroCusto = centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		((AlocacaoCadastrarFiltroVO)pagina.getModelVO()).setCentroCustosHierarquia(codigosCentroCusto);
		
		return manutencaoCorretivaTecnicoDAO.filtrarTecnicosParaCadastroHierarquia(pagina);
	}
	
	public List<AlocacaoCadastrarVO> buscarTecnicosAlocados(String numeroSolicitacao, Integer idPerfil, String matricula) {
		List<String> codigosCentroCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(idPerfil, matricula);
		String setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
		ManutencaoCorretiva manutencao = manutencaoCorretivaDAO.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao, codigosCentroCustoHierarquia, setor);
		manutencaoCorretivaValidador.validarManutencaoCorretivaPermissao(manutencao, numeroSolicitacao);
		return manutencaoCorretivaTecnicoDAO.buscarTecnicosAlocados(numeroSolicitacao);
	}
	
	public boolean buscarManutencaoComPermissaoTecnico(String matriculaTecnico, String numeroSolicitacao) {
		manutencaoCorretivaTecnicoValidador.validarNumeroSolicitacaoTecnico(matriculaTecnico, numeroSolicitacao);
		return true;
	}
	
}
