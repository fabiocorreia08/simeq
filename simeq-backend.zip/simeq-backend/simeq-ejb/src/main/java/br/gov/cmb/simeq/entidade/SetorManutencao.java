package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Audited
@Entity
@Table(name = "SETOR_MANUTENCAO")
public class SetorManutencao implements Serializable {

	private static final long serialVersionUID = -1594126647414972768L;

	@Id
	@Column(name = "ID_SETOR_MANUTENCAO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idSetor;
	
	@Column(name = "NM_SETOR_MANUTENCAO")
	private String nomeSetor;
	
	@OneToMany(mappedBy = "setorManutencao", cascade = {CascadeType.MERGE})
	private List<FamiliaManutencaoSetor> familiasManutencaoSetor;

	public SetorManutencao() {
	}

	public SetorManutencao(Long idSetor, String nomeSetor) {
		this.idSetor = idSetor;
		this.nomeSetor = nomeSetor;
	}
	
	public SetorManutencao(Long idSetor) {
		this.idSetor = idSetor;
	}

	public Long getIdSetor() {
		return idSetor;
	}

	public void setIdSetor(Long idSetor) {
		this.idSetor = idSetor;
	}

	public String getNomeSetor() {
		return nomeSetor;
	}

	public void setNomeSetor(String nomeSetor) {
		this.nomeSetor = nomeSetor;
	}
	
	public List<FamiliaManutencaoSetor> getFamiliasManutencaoSetor() {
		return familiasManutencaoSetor;
	}

	public void setFamiliasManutencaoSetor(
			List<FamiliaManutencaoSetor> familiasManutencaoSetor) {
		this.familiasManutencaoSetor = familiasManutencaoSetor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idSetor == null) ? 0 : idSetor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SetorManutencao other = (SetorManutencao) obj;
		if (idSetor == null) {
			if (other.idSetor != null)
				return false;
		} else if (!idSetor.equals(other.idSetor))
			return false;
		return true;
	}	

}
