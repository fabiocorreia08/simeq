package br.gov.cmb.simeq.enums;

public enum MesEnum {
	
	JANEIRO(1, "Janeiro"),
	FEVEREIRO(2, "Fevereiro"),
	MARCO(3, "Março"),
	ABRIL(4, "Abril"),
	MAIO(5, "Maio"),
	JUNHO(6, "Junho"),
	JULHO(7, "Julho"),
	AGOSTO(8, "Agosto"),
	SETEMBRO(9, "Setembro"),
	OUTRUBRO(10, "Outubro"),
	NOVEMBRO(11, "Novembro"),
	DEZEMBRO(12, "Dezembro");
	
	private int codigo;
	private String descricao;
	
	private MesEnum(int codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public int getCodigo() {
		return codigo;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public static String getDescricaoMesPorCodigo(int codigo) {
		for (MesEnum mes : values()) {
			if(mes.getCodigo() == codigo){
				return mes.getDescricao();
			}
		}
		return null;
	}

}
