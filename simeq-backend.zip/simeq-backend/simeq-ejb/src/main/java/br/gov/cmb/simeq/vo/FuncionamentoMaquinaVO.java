package br.gov.cmb.simeq.vo;

import java.io.Serializable;

import javax.ws.rs.QueryParam;

public class FuncionamentoMaquinaVO implements Serializable {

	private static final long serialVersionUID = -5513464061319954150L;

	@QueryParam("idEquipamento")
	private Long idEquipamento;
	
	@QueryParam("codigoCentroCusto")
	private String codigoCentroCusto;
	
	@QueryParam("ano")
	private Integer ano;
	 
	@QueryParam("mes")
	private Integer mes;

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

}
