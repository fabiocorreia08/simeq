package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VW_DN_TURNO")
public class TurnoView implements Serializable {

	private static final long serialVersionUID = -1951322741733322225L;
	
	@Id
	@Column(name = "CD_TURNO")
	private String codigo;
	
	@Column(name = "NM_TURNO")
	private String nome;

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
