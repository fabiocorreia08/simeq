package br.gov.cmb.simeq.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;

import com.google.common.base.Strings;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.converter.ManutencaoCorretivaConverter;
import br.gov.cmb.simeq.dao.AtividadeCorretivaDAO;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.InformacaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.ParametroDAO;
import br.gov.cmb.simeq.dao.PessoaViewDAO;
import br.gov.cmb.simeq.dao.SetorManutencaoDAO;
import br.gov.cmb.simeq.dao.TecnicoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.AtividadeCorretiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.InformacaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.SetorManutencao;
import br.gov.cmb.simeq.entidade.Tecnico;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.enums.ParametroEnum;
import br.gov.cmb.simeq.enums.PerfilEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoCorretivaEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;
import br.gov.cmb.simeq.relatorio.vo.RankEquipamentoVO;
import br.gov.cmb.simeq.utils.GeradorNumeroSolicitacao;
import br.gov.cmb.simeq.validador.ManutencaoCorretivaValidador;
import br.gov.cmb.simeq.vo.AlocacaoTecnicoFiltroVO;
import br.gov.cmb.simeq.vo.HistoricoManutencaoEquipamentoVO;
import br.gov.cmb.simeq.vo.HistoricoStatusManutencaoFiltroVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaConsultaVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaFiltroVO;
import br.gov.cmb.simeq.vo.ManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.RelatorioGestaoEstrategicaFiltroVO;
import br.gov.cmb.simeq.vo.RelatorioRankEquipamentoFiltroVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaDiaVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaGrupoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaMaterialVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaParametrosVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioGestaoEstrategicaSolicitacaoVO;
import br.gov.cmb.simeq.vo.relatorio.RelatorioManutencaoCorretivaVO;
import br.gov.cmb.simeq.vo.relatorio.SubRelatorioManutencaoAtividadesVO;

@Stateless
public class ManutencaoCorretivaService {

	@Inject
	private ManutencaoCorretivaDAO manutencaoDAO;

	@Inject
	private ManutencaoCorretivaValidador manutencaoValidador;

	@Inject
	private EmailService emailService;

	@Inject
	private ParametroDAO parametroDAO;

	@Inject
	private HistoricoStatusManutencaoCorretivaDAO historicoManutencaoDAO;

	@Inject
	private ManutencaoPreventivaDAO preventivaDAO;

	@Inject
	private PessoaViewDAO pessoaViewDAO;

	@Inject
	private TecnicoDAO tecnicoDAO;

	@Inject
	private CentroCustoService centroCustoService;

	@Inject
	private AtividadeCorretivaDAO atividadeDAO;

	@Inject
	private SetorManutencaoDAO setorManutencaoDAO;

	@Inject
	private InformacaoCorretivaDAO informacaoCorretivaDAO;

	@Inject
	private FamiliaManutencaoService familiaManutencaoService;

	public Pagina<ManutencaoCorretivaConsultaVO> filtrar(Pagina<ManutencaoCorretivaConsultaVO> pagina) {
		String matricula = ((ManutencaoCorretivaFiltroVO) pagina.getModelVO()).getMatricula();
		Integer perfil = ((ManutencaoCorretivaFiltroVO) pagina.getModelVO()).getPerfil();
		List<String> codigosCentroCusto = centroCustoService.getCentroCustoUsuarioLogado(perfil, matricula);
		if (CollectionUtils.isNullOrEmpty(((ManutencaoCorretivaFiltroVO) pagina.getModelVO()).getIdsStatus())) {
			((ManutencaoCorretivaFiltroVO) pagina.getModelVO()).setIdsStatus(null);
		}
		((ManutencaoCorretivaFiltroVO) pagina.getModelVO()).setCentroCustosHierarquia(codigosCentroCusto);
		String setor;
		if (perfil == PerfilEnum.SOLICITANTE.getIdPerfil()) {
			
			setor = "";
		} else {
			setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
		}

		return this.manutencaoDAO.filtrar(pagina, setor);
	}

	
	
	public List<LabelValueDTO> buscarClassesManutencaoCorretiva() {
		return ClasseManutencaoEnum.getClassesManutencaoCorretiva();
	}

	public ManutencaoCorretivaVO salvar(ManutencaoCorretivaVO manutencaoCorretivaVO) {
		ManutencaoCorretiva ultimaManutencaoCadastrada = manutencaoDAO
				.buscarUltimoRegistroCadastradoPorSetor(manutencaoCorretivaVO.getIdSetor());

		SetorManutencao setorManutencao = setorManutencaoDAO.buscar(manutencaoCorretivaVO.getIdSetor());

		String novoNumeroSolicitacao;
		if (ultimaManutencaoCadastrada != null) {
			novoNumeroSolicitacao = GeradorNumeroSolicitacao.gerar(ultimaManutencaoCadastrada.getNumeroSolicitacao(),
					new Date(), setorManutencao.getNomeSetor(), true);
		} else {
			novoNumeroSolicitacao = GeradorNumeroSolicitacao.gerar(null, new Date(), setorManutencao.getNomeSetor(),
					true);
		}
		manutencaoCorretivaVO.setNumeroSolicitacao(novoNumeroSolicitacao);
		ManutencaoCorretivaVO manutencaoSalva = ManutencaoCorretivaConverter
				.converter(manutencaoDAO.salvar(ManutencaoCorretivaConverter.converter(manutencaoCorretivaVO)));
		manutencaoSalva.setMatriculaUsuarioLogado(manutencaoCorretivaVO.getMatriculaUsuarioLogado());
		this.adicionarHistoricoStatusManutencao(manutencaoSalva, StatusManutencaoCorretivaEnum.ABERTA.getCodigo());
		manutencaoSalva.setNomeSolicitante(manutencaoCorretivaVO.getNomeSolicitante());

		return manutencaoSalva;
	}

	public void enviarEmailCriacaoManutencaoCorretiva(ManutencaoCorretivaVO manutencaoSalva) {
		String destinatario = parametroDAO.buscar(ParametroEnum.DEMAN.getCodigoParametro()).getValor();
		emailService.enviarEmailCriacaoManutencaoCorretiva(destinatario, manutencaoSalva);
	}

	@Transactional
	public ManutencaoCorretivaVO atualizar(ManutencaoCorretivaVO manutencaoCorretivaVO) {
		ManutencaoCorretivaVO manutencaoSalva = ManutencaoCorretivaConverter
				.converter(manutencaoDAO.atualizar(ManutencaoCorretivaConverter.converter(manutencaoCorretivaVO)));
		manutencaoSalva.setMatriculaUsuarioLogado(manutencaoCorretivaVO.getMatriculaUsuarioLogado());
		this.adicionarHistoricoStatusManutencao(manutencaoSalva, manutencaoCorretivaVO.getIdStatus());
		return manutencaoSalva;
	}

	private void adicionarHistoricoStatusManutencao(ManutencaoCorretivaVO manutencaoCorretivaVO, Long idStatus) {
		HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoManutencaoDAO
				.buscarUltimoHistoricoInserido(manutencaoCorretivaVO.getIdManutencao());
		HistoricoStatusManutencaoCorretiva historico;
		historico = new HistoricoStatusManutencaoCorretiva(manutencaoCorretivaVO.getIdManutencao(), idStatus,
				new Long(1), manutencaoCorretivaVO.getMatriculaUsuarioLogado());
		if (StatusManutencaoCorretivaEnum.CONCLUIDA.getCodigo().equals(idStatus)) {
			List<AtividadeCorretiva> atividades = atividadeDAO
					.buscarAtividadePorManutencao(manutencaoCorretivaVO.getIdManutencao());
			idStatus = CollectionUtils.isNullOrEmpty(atividades)
					? StatusManutencaoCorretivaEnum.AG_APROPRIACAO.getCodigo()
					: idStatus;
		}
		if (ultimoHistoricoCadastrado != null
				&& !idStatus.equals(ultimoHistoricoCadastrado.getId().getIdStatusManutencao())) {
			historico = new HistoricoStatusManutencaoCorretiva(manutencaoCorretivaVO.getIdManutencao(), idStatus,
					ultimoHistoricoCadastrado.getProximoSequencial(),
					manutencaoCorretivaVO.getMatriculaUsuarioLogado());
			historicoManutencaoDAO.salvar(historico);
			return;
		}
		if (ultimoHistoricoCadastrado == null) {
			historicoManutencaoDAO.salvar(historico);
			return;
		}
	}

	public ManutencaoCorretivaVO buscarPorNumeroSolicitacao(String numeroSolicitacao) {
		ManutencaoCorretiva manutencao = manutencaoDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
		if (manutencao == null) {
			return null;
		}
		ManutencaoCorretivaVO manutencaoVO = ManutencaoCorretivaConverter.converter(manutencao);
		manutencaoVO.setNomeEquipamento(manutencao.getEquipamento().getCodigoManutencao() + " - "
				+ manutencao.getEquipamento().getNomeEquipamento());
		manutencaoVO.setSiglaCentroCusto(manutencao.getCentroCusto().getTextoHierarquiaCentroCusto());
		manutencaoVO.setCentroCustoEquipamento(manutencao.getEquipamento().getUltimoHistoricoSituacaoCadastrado()
				.getCentroCusto().getTextoHierarquiaCentroCusto() + " - "
				+ manutencao.getEquipamento().getUltimoHistoricoSituacaoCadastrado().getCentroCusto()
						.getCodigoCentroCusto());
		return manutencaoVO;
	}

	public ManutencaoVO buscarPorNumeroSolicitacaoPorHierarquia(String numeroSolicitacao, Integer idPerfil,
			String matricula) {
		List<String> codigosCentroCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(idPerfil, matricula);
		String setor = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getSiglaCentroCusto();
		ManutencaoCorretiva manutencao = manutencaoDAO.buscarPorNumeroSolicitacaoPorHierarquia(numeroSolicitacao,
				codigosCentroCustoHierarquia, setor);
		manutencaoValidador.validarManutencaoCorretivaPermissao(manutencao, numeroSolicitacao);
		if (manutencao == null) {
			return null;
		}
		ManutencaoCorretivaVO manutencaoCorretivaVO = ManutencaoCorretivaConverter.converter(manutencao);
		manutencaoCorretivaVO.setSiglaCentroCusto(manutencao.getCentroCusto().getTextoHierarquiaCentroCusto());

		ManutencaoVO manutencaoVO = new ManutencaoVO();
		manutencaoVO.setIdManutencao(manutencao.getId());
		manutencaoVO.setIdEquipamento(manutencaoCorretivaVO.getIdEquipamento());
		manutencaoVO.setNomeEquipamento(manutencao.getEquipamento().getCodigoManutencao() + " - "
				+ manutencao.getEquipamento().getNomeEquipamento());
		manutencaoVO.setDataCriacao(manutencaoCorretivaVO.getDataCriacao());
		manutencaoVO.setCentroCustoEquipamento(manutencao.getEquipamento().getHistoricosSituacaoEquipamento()
				.get(manutencao.getEquipamento()
				.getHistoricosSituacaoEquipamento().size() - 1)
				.getCentroCusto()
				.getTextoHierarquiaCentroCusto()
				+ " - "+ manutencao.getEquipamento()
				.getHistoricosSituacaoEquipamento()
						.get(manutencao.getEquipamento()
						.getHistoricosSituacaoEquipamento().size() - 1)
						.getCentroCusto()
						.getCodigoCentroCusto());
		manutencaoVO.setClasseManutencao(ClasseManutencaoEnum.C.getDescricao().toString());
		manutencaoVO.setTipoManutencao(ClasseManutencaoEnum.C.name().charAt(0));
		manutencaoVO.setParalizacao(manutencao.getParalisacao());

		return manutencaoVO;
	}

	public ManutencaoCorretivaVO buscarPorId(Long id) {
		ManutencaoCorretiva manutencao = manutencaoDAO.buscarPorId(id);
		ManutencaoCorretivaVO manutencaoVO = ManutencaoCorretivaConverter.converter(manutencao);
		HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoManutencaoDAO
				.buscarUltimoHistoricoInserido(id);
		manutencaoVO.setIdStatus(ultimoHistoricoCadastrado.getId().getIdStatusManutencao());
		manutencaoVO.setNomeStatus(ultimoHistoricoCadastrado.getStatusManutencaoCorretiva().getNome());
		manutencaoVO.setNomeEquipamento(manutencao.getEquipamento().getCodigoManutencao());
		manutencaoVO.setSiglaCentroCusto(manutencao.getCentroCusto().getTextoSiglaCentroCusto());
		manutencaoVO.setHierarquiaCentroCusto(manutencao.getCentroCusto().getTextoHierarquiaCentroCusto() + " - "
				+ manutencao.getCentroCusto().getCodigoCentroCusto());
		return manutencaoVO;
	}

	public ManutencaoVO buscarPorIdManutencao(Long id) {
		ManutencaoCorretiva manutencaoCorretiva = manutencaoDAO.buscarPorId(id);
		ManutencaoCorretivaVO manutencaoCorretivaVO = ManutencaoCorretivaConverter.converter(manutencaoCorretiva);
		HistoricoStatusManutencaoCorretiva ultimoHistoricoCadastrado = historicoManutencaoDAO
				.buscarUltimoHistoricoInserido(id);
		manutencaoCorretivaVO.setIdStatus(ultimoHistoricoCadastrado.getId().getIdStatusManutencao());
		manutencaoCorretivaVO.setNomeStatus(ultimoHistoricoCadastrado.getStatusManutencaoCorretiva().getNome());
		manutencaoCorretivaVO.setNomeEquipamento(manutencaoCorretiva.getEquipamento().getCodigoManutencao());
		manutencaoCorretivaVO.setSiglaCentroCusto(manutencaoCorretiva.getCentroCusto().getTextoSiglaCentroCusto());
		manutencaoCorretivaVO
				.setHierarquiaCentroCusto(manutencaoCorretiva.getCentroCusto().getTextoHierarquiaCentroCusto());

		ManutencaoVO manutencaoVO = new ManutencaoVO();
		manutencaoVO.setIdManutencao(manutencaoCorretiva.getId());
		manutencaoVO.setIdEquipamento(manutencaoCorretivaVO.getIdEquipamento());
		manutencaoVO.setNomeEquipamento(manutencaoCorretiva.getEquipamento().getCodigoManutencao() + " - "
				+ manutencaoCorretiva.getEquipamento().getNomeEquipamento());
		manutencaoVO.setDataCriacao(manutencaoCorretivaVO.getDataCriacao());
		manutencaoVO.setCentroCustoEquipamento(manutencaoCorretiva.getEquipamento().getHistoricosSituacaoEquipamento()
				.get(0).getCentroCusto().getTextoHierarquiaCentroCusto() + " - "
				+ manutencaoCorretiva.getEquipamento().getHistoricosSituacaoEquipamento().get(0).getCentroCusto()
						.getCodigoCentroCusto());
		manutencaoVO.setClasseManutencao(ClasseManutencaoEnum.C.getDescricao().toString());
		manutencaoVO.setTipoManutencao(ClasseManutencaoEnum.C.name().charAt(0));

		manutencaoVO.setNumeroSolicitacao(manutencaoCorretiva.getNumeroSolicitacao());
		manutencaoVO.setMatriculaAssistenteProducao(manutencaoCorretivaVO.getMatriculaAssistenteProducao());
		manutencaoVO.setNomeAssistenteProducao(manutencaoCorretivaVO.getNomeAssistenteProducao());
		manutencaoVO.setHierarquiaCentroCusto(manutencaoCorretiva.getCentroCusto().getTextoHierarquiaCentroCusto());

		return manutencaoVO;
	}

	public Pagina<ManutencaoCorretivaConsultaVO> buscarPaginadaAbertaReaberta(
			Pagina<ManutencaoCorretivaConsultaVO> pagina, String matricula) throws ParseException {
		Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(matricula);
		((AlocacaoTecnicoFiltroVO) pagina.getModelVO()).setIdTecnico(tecnico.getIdTecnico());

		String centroCustoUsuario = (this.pessoaViewDAO.buscarPorMatricula(matricula)).getCentroCusto();
		List<Long> setores = this.familiaManutencaoService.buscarSetoresPorCC(centroCustoUsuario);

		return manutencaoDAO.buscarPaginadaAbertaReaberta(pagina, setores.size() > 0 ? setores : null );
	}

	public ManutencaoVO buscarPorPerfil(Integer idPerfil, String matricula, String numeroSolicitacao) {
		ManutencaoCorretiva manutencao = manutencaoDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);

		if (PerfilEnum.TECNICO.getIdPerfil().equals(idPerfil)) {
			Tecnico tecnico = tecnicoDAO.buscarTecnicoPorMatricula(matricula);
			manutencaoValidador.validarAlocacaoTecnincoManutencao(manutencao, tecnico);
		}

//		if (PerfilEnum.SOLICITANTE.getIdPerfil().equals(idPerfil) || PerfilEnum.GESTOR.getIdPerfil().equals(idPerfil)) {
//			List<String> codigosCentroCustoHierarquia = centroCustoService.getCentroCustoUsuarioLogado(idPerfil,
//					matricula);
//			manutencaoValidador.validarCentroCustoManutencao(codigosCentroCustoHierarquia, manutencao);
//		}

		return manutencao != null ? ManutencaoCorretivaConverter.converterGenerica(manutencao) : null;
	}

	public Pagina<HistoricoManutencaoEquipamentoVO> buscarHistoricoPorEquipamento(
			Pagina<HistoricoManutencaoEquipamentoVO> pagina) {
		ManutencaoPreventiva prev = preventivaDAO.buscarPorNumeroSolicitacao(
				((HistoricoStatusManutencaoFiltroVO) pagina.getModelVO()).getNumeroSolicitacao());
		HistoricoStatusManutencaoPreventiva ultima = preventivaDAO
				.buscarDataUltimaConcluidaPorEquipamento(prev.getEquipamento().getIdEquipamento());
		List<Long> status = new ArrayList<Long>();
		status.add(StatusManutencaoPreventivaEnum.CONCLUIDA.getCodigo());
		((HistoricoStatusManutencaoFiltroVO) pagina.getModelVO()).setIdsStatus(status);
		((HistoricoStatusManutencaoFiltroVO) pagina.getModelVO())
				.setIdEquipamento(prev.getEquipamento().getIdEquipamento());
		if (ultima != null) {
			((HistoricoStatusManutencaoFiltroVO) pagina.getModelVO()).setDtUltimaManutencao(ultima.getDataCriacao());
		}
		return historicoManutencaoDAO.buscarHistoricoPorEquipamento(pagina);
	}

	public RelatorioManutencaoCorretivaVO buscarRelatorioManutencaoCorretiva(Long idManutencao) {
		RelatorioManutencaoCorretivaVO relatorio = manutencaoDAO.bsucarRelatorioManutencaoCorretiva(idManutencao);
		relatorio.setAtividades(manutencaoDAO.buscarSubRelatorioCorretivaAtividades(idManutencao));
		int sequencialAtividade = 1;
		relatorio.calcularHorasMinutosTotaisAtividade();
		for (SubRelatorioManutencaoAtividadesVO atividade : relatorio.getAtividades()) {
			if (!Strings.isNullOrEmpty(atividade.getObservacao())) {
				if (Strings.isNullOrEmpty(relatorio.getObservacaoAtividades())) {
					relatorio.setObservacaoAtividades(
							" " + sequencialAtividade + " - " + atividade.getObservacao() + " \n");
					continue;
				}
				relatorio.setObservacaoAtividades(relatorio.getObservacaoAtividades() + " " + (++sequencialAtividade)
						+ " - " + atividade.getObservacao() + " \n");
			}
		}
		List<InformacaoCorretiva> informacoes = informacaoCorretivaDAO
				.buscarPorIdManutencao(relatorio.getIdManutencaoCorretiva());
		relatorio.setarInformacoesCorretiva(informacoes);
		relatorio.setMateriais(manutencaoDAO.buscarSubRelatorioCorretivaMateriais(idManutencao));
		return relatorio;
	}

	public Integer buscarParamentroTempoRefresh() {
		return new Integer(parametroDAO.buscar(ParametroEnum.TEMPO_REFRESH.getCodigoParametro()).getValor());
	}

	public List<RankEquipamentoVO> gerarRankEquipamento(RelatorioRankEquipamentoFiltroVO filtro) {
		return manutencaoDAO.gerarRankEquipamento(filtro);
	}

	public RelatorioGestaoEstrategicaDiaVO gerarRelatorioGestaoEstrategicaDia(
			RelatorioGestaoEstrategicaFiltroVO filtro) {
		return new RelatorioGestaoEstrategicaDiaVO(manutencaoDAO.gerarSubRelatorioGestaoEstrategicaDia(filtro));
	}

	public RelatorioGestaoEstrategicaGrupoVO gerarRelatorioGestaoEstrategicaGrupo(
			RelatorioGestaoEstrategicaFiltroVO filtro) {
		return new RelatorioGestaoEstrategicaGrupoVO(manutencaoDAO.gerarSubRelatorioGestaoEstrategicaGrupo(filtro));
	}

	public RelatorioGestaoEstrategicaMaterialVO gerarRelatorioGestaoEstrategicaMaterial(
			RelatorioGestaoEstrategicaFiltroVO filtro) {
		return new RelatorioGestaoEstrategicaMaterialVO(
				manutencaoDAO.gerarSubRelatorioGestaoEstrategicaMaterial(filtro));
	}

	public RelatorioGestaoEstrategicaSolicitacaoVO gerarRelatorioGestaoEstrategicaSolicitacao(
			RelatorioGestaoEstrategicaFiltroVO filtro) {
		return new RelatorioGestaoEstrategicaSolicitacaoVO(
				manutencaoDAO.geraSubRelatorioGestaoEstrategicaSolicitacao(filtro));
	}

	public RelatorioGestaoEstrategicaParametrosVO gerarRelatorioGestaoEstrategicaParametros(
			RelatorioGestaoEstrategicaFiltroVO filtro) {
		RelatorioGestaoEstrategicaParametrosVO relatorio = manutencaoDAO
				.geraSubRelatorioGestaoEstrategicaParametros(filtro);
		relatorio.setDataInicial(filtro.getDataInicial());
		relatorio.setDataFinal(filtro.getDataFinal());
		return relatorio;
	}

}
