package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.entidade.InformacaoCorretiva;
import br.gov.cmb.simeq.entidade.StatusManutencaoCorretiva;
import br.gov.cmb.simeq.enums.ClasseManutencaoEnum;
import br.gov.cmb.simeq.utils.ConverterHorasMinutosUtil;

public class RelatorioManutencaoCorretivaVO implements Serializable {

	private static final long serialVersionUID = -2202865792238248584L;
	private static final Integer MINUTOS_MAXIMO = 60;
	
	private Long idManutencaoCorretiva;
	private String numeroSolicitacao;
	private String codigoEquipamento;
	private String centroCustoInstalacao;
	private String matriculaSolicitante;
	private String nomeSolicitante;
	private String horaSolicitacao;
	private String dataSolicitacao;
	private String avariaAnormalidade;
	private Boolean isServicoApoio;
	private Boolean isComParalisacao;
	private String observacaoAtividades = "";
	private String horaComParalisacaoTexto;
	private String horaSemParalisacaoTexto;
	private Integer horasSemParalisacao;
	private Integer minutosSemParalisacao;
	private Integer horasComParalisacao;
	private Integer minutosComParalisacao;
	private List<SubRelatorioManutencaoAtividadesVO> atividades = Lists.newArrayList();
	private List<SubRelatorioManutencaoMateriaisVO> materiais = Lists.newArrayList();
	private String dataStatusRecursoAlocado;
	private String horaStatusRecursoAlocado;
	private String matriculaResponsavelStatusRecursoAlocado;
	private String nomeResponsavelStatusRecursoAlocado;
	private String informacoesManutencao = "";
	private String nomeStatusManutencao;
	private String dataStatusAguardandoAceite;
	private String horaStatusAguardandoAceite;
	private String nomeResponsavelStatusAguardandoAceite;
	private String dataStatusConcluida;
	private String horaStatusConcluida;
	private String nomeResponsavelStatusConcluida;
	
	RelatorioManutencaoCorretivaVO(){}
	
	public RelatorioManutencaoCorretivaVO(Long idManutencaoCorretiva, String numeroSolicitacao, String codigoEquipamento, String centroCustoInstalacao, String matriculaSolicitante,
			String nomeSolicitante, Date dataCriacao, String avariaAnormalidade, ClasseManutencaoEnum classeManutencao, Boolean paralisacao,
			StatusManutencaoCorretiva statusManutencaoCorretiva, Long horasSemParalisacao, Long minutosSemParalisacao, Long horasComParalisacao, Long minutosComParalisacao,
			
			Date dataStatusRecursoAlocado, String matriculaResponsavelStatusRecursoAlocado, String nomeResponsavelStatusRecursoAlocado,  
			Date dataStatusAguardandoAceite,  String nomeResponsavelStatusAguardandoAceite, Date dataStatusConcluida, String nomeResponsavelStatusConcluida) {
		this.idManutencaoCorretiva = idManutencaoCorretiva;
		this.codigoEquipamento = codigoEquipamento;
		this.centroCustoInstalacao = centroCustoInstalacao;
		this.matriculaSolicitante = matriculaSolicitante;
		this.nomeSolicitante = nomeSolicitante;
		this.horaSolicitacao = DataUtils.formatarHoraHHmm(dataCriacao);
		this.avariaAnormalidade = avariaAnormalidade != null ? avariaAnormalidade : ""; 
		this.isServicoApoio = ClasseManutencaoEnum.S.name().equals(classeManutencao.name());
		this.isComParalisacao = paralisacao;
		this.dataSolicitacao = DataUtils.formatarddMMyyyy(dataCriacao);
		this.numeroSolicitacao = numeroSolicitacao;
		this.horasSemParalisacao = horasSemParalisacao != null ? new Integer(horasSemParalisacao.toString()) : null;
		this.minutosSemParalisacao = minutosSemParalisacao != null ? new Integer(minutosSemParalisacao.toString()) : null;
		this.horasComParalisacao = horasComParalisacao != null ? new Integer(horasComParalisacao.toString()) : null;
		this.minutosComParalisacao = minutosComParalisacao != null ? new Integer(minutosComParalisacao.toString()) : null;
		this.dataStatusRecursoAlocado = dataStatusRecursoAlocado != null ? DataUtils.formatarddMMyyyy(dataStatusRecursoAlocado) : "";
		this.horaStatusRecursoAlocado = dataStatusRecursoAlocado != null ? DataUtils.formatarHoraHHmm(dataStatusRecursoAlocado) : "";
		this.matriculaResponsavelStatusRecursoAlocado = matriculaResponsavelStatusRecursoAlocado != null ? matriculaResponsavelStatusRecursoAlocado : "";
		this.nomeResponsavelStatusRecursoAlocado = nomeResponsavelStatusRecursoAlocado != null ? nomeResponsavelStatusRecursoAlocado : "";
		this.nomeStatusManutencao = statusManutencaoCorretiva.getNome();
		this.dataStatusAguardandoAceite = dataStatusAguardandoAceite != null ? DataUtils.formatarddMMyyyy(dataStatusAguardandoAceite) : "";
		this.horaStatusAguardandoAceite = dataStatusAguardandoAceite != null ? DataUtils.formatarHoraHHmm(dataStatusAguardandoAceite) : "";
		this.nomeResponsavelStatusAguardandoAceite = nomeResponsavelStatusAguardandoAceite != null ? nomeResponsavelStatusAguardandoAceite : "";
		this.dataStatusConcluida = dataStatusConcluida != null ? DataUtils.formatarddMMyyyy(dataStatusConcluida) : "";
		this.horaStatusConcluida = dataStatusConcluida != null ? DataUtils.formatarHoraHHmm(dataStatusConcluida) : "";
		this.nomeResponsavelStatusConcluida = nomeResponsavelStatusConcluida != null ? nomeResponsavelStatusConcluida : "";
	}
	
	public String getDataStatusRecursoAlocado() {
		return dataStatusRecursoAlocado;
	}

	public void setDataStatusRecursoAlocado(String dataStatusRecursoAlocado) {
		this.dataStatusRecursoAlocado = dataStatusRecursoAlocado;
	}

	public String getHoraStatusRecursoAlocado() {
		return horaStatusRecursoAlocado;
	}

	public void setHoraStatusRecursoAlocado(String horaStatusRecursoAlocado) {
		this.horaStatusRecursoAlocado = horaStatusRecursoAlocado;
	}

	public String getMatriculaResponsavelStatusRecursoAlocado() {
		return matriculaResponsavelStatusRecursoAlocado;
	}

	public void setMatriculaResponsavelStatusRecursoAlocado(String matriculaResponsavelStatusRecursoAlocado) {
		this.matriculaResponsavelStatusRecursoAlocado = matriculaResponsavelStatusRecursoAlocado;
	}

	public String getNomeResponsavelStatusRecursoAlocado() {
		return nomeResponsavelStatusRecursoAlocado;
	}

	public void setNomeResponsavelStatusRecursoAlocado(String nomeResponsavelStatusRecursoAlocado) {
		this.nomeResponsavelStatusRecursoAlocado = nomeResponsavelStatusRecursoAlocado;
	}

	public String getInformacoesManutencao() {
		return informacoesManutencao;
	}

	public void setInformacoesManutencao(String informacoesManutencao) {
		this.informacoesManutencao = informacoesManutencao;
	}

	public String getNomeStatusManutencao() {
		return nomeStatusManutencao;
	}

	public void setNomeStatusManutencao(String nomeStatusManutencao) {
		this.nomeStatusManutencao = nomeStatusManutencao;
	}

	public String getDataStatusAguardandoAceite() {
		return dataStatusAguardandoAceite;
	}

	public void setDataStatusAguardandoAceite(String dataStatusAguardandoAceite) {
		this.dataStatusAguardandoAceite = dataStatusAguardandoAceite;
	}

	public String getHoraStatusAguardandoAceite() {
		return horaStatusAguardandoAceite;
	}

	public void setHoraStatusAguardandoAceite(String horaStatusAguardandoAceite) {
		this.horaStatusAguardandoAceite = horaStatusAguardandoAceite;
	}

	public String getNomeResponsavelStatusAguardandoAceite() {
		return nomeResponsavelStatusAguardandoAceite;
	}

	public void setNomeResponsavelStatusAguardandoAceite(String nomeResponsavelStatusAguardandoAceite) {
		this.nomeResponsavelStatusAguardandoAceite = nomeResponsavelStatusAguardandoAceite;
	}

	public String getDataStatusConcluida() {
		return dataStatusConcluida;
	}

	public void setDataStatusConcluida(String dataStatusConcluida) {
		this.dataStatusConcluida = dataStatusConcluida;
	}

	public String getHoraStatusConcluida() {
		return horaStatusConcluida;
	}

	public void setHoraStatusConcluida(String horaStatusConcluida) {
		this.horaStatusConcluida = horaStatusConcluida;
	}

	public String getNomeResponsavelStatusConcluida() {
		return nomeResponsavelStatusConcluida;
	}

	public void setNomeResponsavelStatusConcluida(String nomeResponsavelStatusConcluida) {
		this.nomeResponsavelStatusConcluida = nomeResponsavelStatusConcluida;
	}

	public Integer getHorasSemParalisacao() {
		return horasSemParalisacao;
	}

	public void setHorasSemParalisacao(Integer horasSemParalisacao) {
		this.horasSemParalisacao = horasSemParalisacao;
	}

	public Integer getMinutosSemParalisacao() {
		return minutosSemParalisacao;
	}

	public void setMinutosSemParalisacao(Integer minutosSemParalisacao) {
		this.minutosSemParalisacao = minutosSemParalisacao;
	}

	public Integer getHorasComParalisacao() {
		return horasComParalisacao;
	}

	public void setHorasComParalisacao(Integer horasComParalisacao) {
		this.horasComParalisacao = horasComParalisacao;
	}

	public Integer getMinutosComParalisacao() {
		return minutosComParalisacao;
	}

	public void setMinutosComParalisacao(Integer minutosComParalisacao) {
		this.minutosComParalisacao = minutosComParalisacao;
	}

	public String getHoraComParalisacaoTexto() {
		return horaComParalisacaoTexto;
	}

	public void setHoraComParalisacaoTexto(String horaComParalisacaoTexto) {
		this.horaComParalisacaoTexto = horaComParalisacaoTexto;
	}

	public String getHoraSemParalisacaoTexto() {
		return horaSemParalisacaoTexto;
	}

	public void setHoraSemParalisacaoTexto(String horaSemParalisacaoTexto) {
		this.horaSemParalisacaoTexto = horaSemParalisacaoTexto;
	}

	public void setMatriculaSolicitante(String matriculaSolicitante) {
		this.matriculaSolicitante = matriculaSolicitante;
	}

	public void setNomeSolicitante(String nomeSolicitante) {
		this.nomeSolicitante = nomeSolicitante;
	}

	public String getObservacaoAtividades() {
		return observacaoAtividades;
	}

	public void setObservacaoAtividades(String observacaoAtividades) {
		this.observacaoAtividades = observacaoAtividades;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getDataSolicitacao() {
		return dataSolicitacao;
	}

	public void setDataSolicitacao(String dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}

	public Boolean getIsComParalisacao() {
		return isComParalisacao;
	}

	public void setIsComParalisacao(Boolean isComParalisacao) {
		this.isComParalisacao = isComParalisacao;
	}

	public Boolean getIsServicoApoio() {
		return isServicoApoio;
	}

	public void setIsServicoApoio(Boolean isServicoApoio) {
		this.isServicoApoio = isServicoApoio;
	}

	public Long getIdManutencaoCorretiva() {
		return idManutencaoCorretiva;
	}

	public void setIdManutencaoCorretiva(Long idManutencaoCorretiva) {
		this.idManutencaoCorretiva = idManutencaoCorretiva;
	}

	public String getCodigoEquipamento() {
		return codigoEquipamento;
	}

	public void setCodigoEquipamento(String codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}

	public String getCentroCustoInstalacao() {
		return centroCustoInstalacao;
	}

	public void setCentroCustoInstalacao(String centroCustoInstalacao) {
		this.centroCustoInstalacao = centroCustoInstalacao;
	}

	public String getMatriculaSolicitante() {
		return matriculaSolicitante;
	}

	public String getNomeSolicitante() {
		return nomeSolicitante;
	}

	public String getHoraSolicitacao() {
		return horaSolicitacao;
	}

	public void setHoraSolicitacao(String horaSolicitacao) {
		this.horaSolicitacao = horaSolicitacao;
	}

	public String getAvariaAnormalidade() {
		return avariaAnormalidade;
	}

	public void setAvariaAnormalidade(String avariaAnormalidade) {
		this.avariaAnormalidade = avariaAnormalidade;
	}

	public List<SubRelatorioManutencaoAtividadesVO> getAtividades() {
		return atividades;
	}

	public void setAtividades(List<SubRelatorioManutencaoAtividadesVO> atividades) {
		this.atividades = atividades;
	}

	public List<SubRelatorioManutencaoMateriaisVO> getMateriais() {
		return materiais;
	}

	public void setMateriais(List<SubRelatorioManutencaoMateriaisVO> materiais) {
		this.materiais = materiais;
	}
	
	public void calcularHorasMinutosTotaisAtividade() {
		if(minutosComParalisacao != null && minutosComParalisacao > MINUTOS_MAXIMO) {
			Integer horas = minutosComParalisacao / 60;
			Integer minutos = (minutosComParalisacao % 60);
			horasComParalisacao += horas;
			minutosComParalisacao = minutos;
		} 
		if(minutosSemParalisacao != null && minutosSemParalisacao > MINUTOS_MAXIMO) {
			Integer horas = minutosSemParalisacao / 60;
			Integer minutos = (minutosSemParalisacao % 60);
			minutosSemParalisacao += horas;
			minutosSemParalisacao = minutos;
			
		}
		this.horaComParalisacaoTexto = ConverterHorasMinutosUtil.getTextoHora(horasComParalisacao, minutosComParalisacao);
		this.horaSemParalisacaoTexto = ConverterHorasMinutosUtil.getTextoHora(horasSemParalisacao, minutosSemParalisacao);
	}
	
	public void setarInformacoesCorretiva(List<InformacaoCorretiva> informacoes) {
		int sequencialInformacoes = 1;
		for (InformacaoCorretiva informacaoCorretiva : informacoes) {
			if(!Strings.isNullOrEmpty(informacaoCorretiva.getDescricaoInformacao())) {				
				if(Strings.isNullOrEmpty(informacoesManutencao)){				
					informacoesManutencao = " " + sequencialInformacoes + " - "+ informacaoCorretiva.getDescricaoInformacao() + " \n";
					continue;
				}
				informacoesManutencao = informacoesManutencao + " " + (++sequencialInformacoes) + " - "+ informacaoCorretiva.getDescricaoInformacao() + " \n";
			}
		}
	}
}
