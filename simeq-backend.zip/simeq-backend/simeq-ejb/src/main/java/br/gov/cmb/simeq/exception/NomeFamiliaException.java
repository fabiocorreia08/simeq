package br.gov.cmb.simeq.exception;

import javax.ejb.ApplicationException;

@ApplicationException
public class NomeFamiliaException extends RuntimeException{

	private static final long serialVersionUID = 6524008791995819488L;

	public NomeFamiliaException() {
		super();
	}
		
}
