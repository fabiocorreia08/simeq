package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.MaterialView;
import br.gov.cmb.simeq.vo.MaterialVO;

public class MaterialViewDAO extends GenericoPaginadoDAO<MaterialView, String> {

	private static final long serialVersionUID = 661249380559288004L;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<MaterialVO> filtrar(Pagina pagina) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.vo.MaterialVO(m.codigo, m.nome, m.descricao, m.quantidade)")
				.from(MaterialView.class, "m")
				.where(pagina.getModelVO(), "m.codigo = [codigoMaterial]")
				.and("m.nome LIKE [nomePradronizado]");
		Pagina<MaterialVO> paginaResultado = ((Pagina<MaterialVO>)buscar(pagina, builder.builder()));
		List<MaterialVO> listaMateriais = paginaResultado.getRegistros();
		int sequencialInicial = paginaResultado.getPrimeiroRegistro();
		for (MaterialVO materialVO : listaMateriais) {
			sequencialInicial++;
			materialVO.setSequencial(sequencialInicial);
		}
		paginaResultado.setRegistros(listaMateriais);
		return paginaResultado;
	}
	
	public List<LabelValueDTO> buscarUnidadesLabelValue() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO(m.unidadeMedida, m.unidadeMedida)")
				.from(MaterialView.class, "m");
		return buscar(builder.builder(), LabelValueDTO.class);
	}
	
	public MaterialVO buscarPorId(String codigo) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.vo.MaterialVO(m.codigo, m.nome, m.descricao, m.quantidade)")
				.from(MaterialView.class, "m")
				.where("m.codigo = ?1");
		List<MaterialVO> materiais = buscar(builder.builder(), MaterialVO.class, codigo);
		if(CollectionUtils.isNullOrEmpty(materiais)) {
			return null;
		}
		return materiais.get(0);
	}

}
