package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

public class PreventivaConsultaTabelaVO implements Serializable{

	
	private static final long serialVersionUID = 4226734882369316098L;
	
	private Long idManutencao;
	private String codigoEquipamento;
	private String descricaoEquipamento;
	private Date dataManutencao;
	private Long idStatus;
	private String status;
	private String numeroSolicitacao;
	private String centroCusto;
	private String dataInicial;
	private Date dataIniManutencao;
	
	public PreventivaConsultaTabelaVO(Long idManutencao, String codigoEquipamento, String descricaoEquipamento,
			Date dataManutencao, String status, Long idStatus, String numeroSolicitacao, String centroCusto) {
		super();
		this.idManutencao = idManutencao;
		this.codigoEquipamento = codigoEquipamento;
		this.descricaoEquipamento = descricaoEquipamento;
		this.dataManutencao = dataManutencao;
		this.status = status;
		this.idStatus = idStatus;
		this.numeroSolicitacao = numeroSolicitacao;
		this.centroCusto = centroCusto;
	}
	
	
	
	public PreventivaConsultaTabelaVO(Long idManutencao, String codigoEquipamento, String descricaoEquipamento,
			Date dataManutencao, String status, Long idStatus, String numeroSolicitacao, String centroCusto, String dataInical) {
		super();
		this.idManutencao = idManutencao;
		this.codigoEquipamento = codigoEquipamento;
		this.descricaoEquipamento = descricaoEquipamento;
		this.dataManutencao = dataManutencao;
		this.status = status;
		this.idStatus = idStatus;
		this.numeroSolicitacao = numeroSolicitacao;
		this.centroCusto = centroCusto;
		this.dataInicial = dataInical;
	}
	
	public PreventivaConsultaTabelaVO(Long idManutencao, String codigoEquipamento, String descricaoEquipamento,
			Date dataManutencao, String status, Long idStatus, String numeroSolicitacao, String centroCusto, String dataInical, Date teste) {
		super();
		this.idManutencao = idManutencao;
		this.codigoEquipamento = codigoEquipamento;
		this.descricaoEquipamento = descricaoEquipamento;
		this.dataManutencao = dataManutencao;
		this.status = status;
		this.idStatus = idStatus;
		this.numeroSolicitacao = numeroSolicitacao;
		this.dataIniManutencao = teste;
		this.centroCusto = centroCusto;
		this.dataInicial = dataInical;
	}
	
	public Long getIdManutencao() {
		return idManutencao;
	}
	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	public String getCodigoEquipamento() {
		return codigoEquipamento;
	}
	public void setCodigoEquipamento(String codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}
	public String getDescricaoEquipamento() {
		return descricaoEquipamento;
	}
	public void setDescricaoEquipamento(String descricaoEquipamento) {
		this.descricaoEquipamento = descricaoEquipamento;
	}
	public Date getDataManutencao() {
		return dataManutencao;
	}
	public void setDataManutencao(Date dataManutencao) {
		this.dataManutencao = dataManutencao;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}
	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}
	public String getCentroCusto() {
		return centroCusto;
	}
	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}
	public Long getIdStatus() {
		return idStatus;
	}
	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public String getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(String dataInicial) {
		this.dataInicial = dataInicial;
	}



	public Date getTeste() {
		return dataIniManutencao;
	}



	public void setTeste(Date teste) {
		this.dataIniManutencao = teste;
	}
}