package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.entidade.InformacaoPreventiva;
import br.gov.cmb.simeq.vo.InformacaoVO;

public class InformacaoPreventivaDAO extends GenericoPaginadoDAO<InformacaoPreventiva, Long>{

	private static final long serialVersionUID = 1L;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<InformacaoVO> filtrar(Pagina pagina) {
		
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.InformacaoVO(i.id, "
											  	+ " status.id, "
											  	+ " i.descricaoInformacao,"
											  	+ " status.nome, "
											  	+ " i.dataCadastro,"
											  	+ " i.codigoMatriculaFuncionario) ")
				.from(InformacaoPreventiva.class, "i")
					.innerJoin("i.historicoStatusManutencaoPreventiva", "historico")
					.innerJoin("historico.manutencaoPreventiva", "manutencao")
					.innerJoin("historico.statusManutencaoPreventiva", "status")
				.where(pagina.getModelVO(), "manutencao.id = [idManutencao]")
				.order("i.dataCadastro")
				.desc();
		
		return (Pagina<InformacaoVO>)buscar(pagina, builder.builder(), "distinct i.id");
	}
	
	public List<InformacaoPreventiva> buscarPorIdManutencao(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("i")
				.from(InformacaoPreventiva.class, "i")
				.innerJoin("i.historicoStatusManutencaoPreventiva", "historico")
				.innerJoin("historico.manutencaoPreventiva", "manutencao")
				.where("manutencao.id = ?");
		return buscar(builder.builder(), idManutencao);
	}

}
