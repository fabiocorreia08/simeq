package br.gov.cmb.simeq.vo;

import java.util.Date;
import java.util.List;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AtividadeFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 4701928756815390316L;
	
	@ParametroNomeado
	private String numeroSolicitacao;
	
	@ParametroNomeado
	private Date periodoInicio;
	
	@ParametroNomeado
	private Date periodoFim;
	
	@ParametroNomeado
	private String matriculaExecutante;
	
	@ParametroNomeado
	private List<String> centroCustosHierarquia;
	
	private String matricula;
	
	private Integer perfil;

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Date getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(Date periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public Date getPeriodoFim() {
		return periodoFim;
	}

	public void setPeriodoFim(Date periodoFim) {
		this.periodoFim = periodoFim;
	}

	public String getMatriculaExecutante() {
		return matriculaExecutante;
	}

	public void setMatriculaExecutante(String matriculaExecutante) {
		this.matriculaExecutante = matriculaExecutante;
	}

	public List<String> getCentroCustosHierarquia() {
		return centroCustosHierarquia;
	}

	public void setCentroCustosHierarquia(List<String> centroCustosHierarquia) {
		this.centroCustosHierarquia = centroCustosHierarquia;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}
	
}
