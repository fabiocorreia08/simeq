package br.gov.cmb.simeq.enums;

import java.util.List;

import com.google.common.collect.Lists;

public enum StatusManutencaoCorretivaEnum {
	ABERTA(1L, "solicitação criada."){
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), IMPROCEDENTE.getCodigo());
		}
	},
	RECURSO_ALOCADO(2L, "chamado já possui pelo menos um técnico alocado.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), IMPROCEDENTE.getCodigo(),
					MANUTENCAO.getCodigo(), AG_FORNECEDOR.getCodigo(), AG_ACEITE.getCodigo());
		}
	},
	AG_ACEITE(3L, "após a execução o técnico solicita o aceite do usuário.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), REPROVADA.getCodigo(),
					CONCLUIDA.getCodigo());
		}
	},
	AG_APROPRIACAO(4L, "se o chamado não tiver atividade cadastrada e horas do técnico lançada.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
	},
	AG_FORNECEDOR(5L, "aguardando alguma peça ou serviço de algum fornecedor.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), AG_ACEITE.getCodigo(), MANUTENCAO.getCodigo());
		}
	},
	CANCELADA(6L, "solicitação que por algum motivo deixará se existir e seguir o fluxo de atendimento."){
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
	},
	CONCLUIDA(7L, "solicitação aprovada pelo cliente e com pelo menos um registro de atividade com hora apropriada."){
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
	},
	MANUTENCAO(8L, "técnico está efetivamente realizando a manutenção.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo(), AG_FORNECEDOR.getCodigo(), AG_ACEITE.getCodigo());
		}
	},
	REPROVADA(9L, "solicitação reprovada pelo cliente, volta para o gestor da área (que faz as alocações) validar a reprovação e, se for o caso, realizar uma nova alocação."){
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(VERIFICANDO_REPROVACAO.getCodigo(), CONCLUIDA.getCodigo(), CANCELADA.getCodigo(), AG_FORNECEDOR.getCodigo(),
					REABERTA.getCodigo());
		}
	},
	IMPROCEDENTE(10L, "chamados que não se enquadram nas atividades realizadas pela área.") {
		@Override
		public List<Long> getIdsStatusCombo() {
			return null;
		}
	},
	VERIFICANDO_REPROVACAO(11L, "após a reprovação, quando o gestor está verificando se a reprovação procede."){
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(REABERTA.getCodigo(), AG_ACEITE.getCodigo(), CANCELADA.getCodigo());
		}
	},
	REABERTA(12L, "solicitação reaberta"){;
		@Override
		public List<Long> getIdsStatusCombo() {
			return Lists.newArrayList(CANCELADA.getCodigo());
		}
	};
	
	private Long codigo;
	private String descricao;
	
	private StatusManutencaoCorretivaEnum(Long codigo, String descricao) {
		this.codigo = codigo;
		this.descricao = descricao;
	}

	public Long getCodigo() {
		return codigo;
	}

	public String getDescricao() {
		return descricao;
	}
	
	public abstract List<Long> getIdsStatusCombo();
	
	public static StatusManutencaoCorretivaEnum getStatus(Long idStatus) {
		for (StatusManutencaoCorretivaEnum status : values()) {
			if(status.codigo.equals(idStatus)) {
				return status;
			}
		}
		return null;
	}
	
}
