package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ManutencaoPreventivaTecnicoId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "ID_MANUTENCAO_PREVENTIVA")
	private Long idManutencaoPreventiva;
	
	@Column(name = "ID_TECNICO")
	private Long idTecnico;
	
	public ManutencaoPreventivaTecnicoId(){}
	
	public ManutencaoPreventivaTecnicoId(Long idManutencaoPreventiva, Long idTecnico) {
		this.idManutencaoPreventiva = idManutencaoPreventiva;
		this.idTecnico = idTecnico;
	}

	public Long getIdTecnico() {
		return idTecnico;
	}

	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public Long getIdManutencaoPreventiva() {
		return idManutencaoPreventiva;
	}

	public void setIdManutencaoPreventiva(Long idManutencaoPreventiva) {
		this.idManutencaoPreventiva = idManutencaoPreventiva;
	}
}
