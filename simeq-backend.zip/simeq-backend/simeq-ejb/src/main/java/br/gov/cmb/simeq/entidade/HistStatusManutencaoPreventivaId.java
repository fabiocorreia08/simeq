package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import com.google.common.base.Objects;

@Embeddable
public class HistStatusManutencaoPreventivaId implements Serializable {

	private static final long serialVersionUID = 5449255670389476530L;
	
	@Column(name = "ID_MANUTENCAO_PREVENTIVA")
	private Long idManutencaoPreventiva;
	
	@Column(name = "ID_STATUS")
	private Long idStatusManutencao;
	
	@Column(name = "ID_SEQUENCIAL")
	private Long idSequencial;

	public HistStatusManutencaoPreventivaId(){}
	
	public HistStatusManutencaoPreventivaId(Long idManutencaoPreventiva, Long idStatusManutencao, Long idSequencial) {
		this.idManutencaoPreventiva = idManutencaoPreventiva;
		this.idStatusManutencao = idStatusManutencao;
		this.idSequencial = idSequencial;
	}

	public Long getIdManutencaoPreventiva() {
		return idManutencaoPreventiva;
	}

	public void setIdManutencaoPreventiva(Long idManutencaoPreventiva) {
		this.idManutencaoPreventiva = idManutencaoPreventiva;
	}

	public Long getIdStatusManutencao() {
		return idStatusManutencao;
	}

	public void setIdStatusManutencao(Long idStatusManutencao) {
		this.idStatusManutencao = idStatusManutencao;
	}

	public Long getIdSequencial() {
		return idSequencial;
	}

	public void setIdSequencial(Long idSequencial) {
		this.idSequencial = idSequencial;
	}
	
	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof HistStatusManutencaoPreventivaId)) {
			return false;
		}
		HistStatusManutencaoPreventivaId castOther = (HistStatusManutencaoPreventivaId) other;
		return Objects.equal(idManutencaoPreventiva, castOther.idManutencaoPreventiva)
				&& Objects.equal(idStatusManutencao, castOther.idStatusManutencao)
				&& Objects.equal(idSequencial, castOther.idSequencial);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(idManutencaoPreventiva, idStatusManutencao, idSequencial);
	}
	
}
