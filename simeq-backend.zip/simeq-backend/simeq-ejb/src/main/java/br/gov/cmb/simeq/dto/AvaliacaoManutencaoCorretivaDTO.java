package br.gov.cmb.simeq.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class AvaliacaoManutencaoCorretivaDTO implements Serializable {
    
	/**
	 * 
	 */
	private static final long serialVersionUID = 9208697153346383153L;
	
	private Long id;
    private String classeManutencao;
    private String numeroSolicitacao;
    private String descricaoStatus;
    private String dataAlteracao;
    private String codigoManutencao;
    private String centroCustoInstalacao;
    private String dataCadastro;
    
    public AvaliacaoManutencaoCorretivaDTO() {
    }
    
    public AvaliacaoManutencaoCorretivaDTO(	Long id,
										    String classeManutencao,
										    String numeroSolicitacao,
										    String descricaoStatus,
										    String dataAlteracao,
										    String codigoManutencao,
										    String centroCustoInstalacao,
										    String dataCadastro) {
    	this.id = id;
    	this.classeManutencao = classeManutencao;
    	this.numeroSolicitacao = numeroSolicitacao;
    	this.descricaoStatus = descricaoStatus;
    	this.dataAlteracao = dataAlteracao;
    	this.codigoManutencao = codigoManutencao;
    	this.centroCustoInstalacao = centroCustoInstalacao;
    	this.dataCadastro = dataCadastro;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getDescricaoStatus() {
		return descricaoStatus;
	}

	public void setDescricaoStatus(String descricaoStatus) {
		this.descricaoStatus = descricaoStatus;
	}

	public String getDataAlteracao() {
		return dataAlteracao;
	}

	public void setDataAlteracao(String dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}

	public String getCodigoManutencao() {
		return codigoManutencao;
	}

	public void setCodigoManutencao(String codigoManutencao) {
		this.codigoManutencao = codigoManutencao;
	}

	public String getCentroCustoInstalacao() {
		return centroCustoInstalacao;
	}

	public void setCentroCustoInstalacao(String centroCustoInstalacao) {
		this.centroCustoInstalacao = centroCustoInstalacao;
	}

	public String getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(String dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
}
