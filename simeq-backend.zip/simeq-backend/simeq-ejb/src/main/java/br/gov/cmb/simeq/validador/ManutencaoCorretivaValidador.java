package br.gov.cmb.simeq.validador;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.ManutencaoCorretivaTecnicoDAO;
import br.gov.cmb.simeq.entidade.ManutencaoCorretiva;
import br.gov.cmb.simeq.entidade.Tecnico;

@Stateless
public class ManutencaoCorretivaValidador extends AbstractValidador {
	
	@Inject
	private ManutencaoCorretivaTecnicoDAO manutencaoCorretivaTecnicoDAO;
	
	@Inject
	private ManutencaoCorretivaDAO manutencaoDAO;
	
	@RegraDeValidacao
	public void validarAlocacaoTecnincoManutencao(ManutencaoCorretiva manutencao, Tecnico tecnico) {
		if(manutencao != null && tecnico != null && manutencaoCorretivaTecnicoDAO.buscarAlocacaoTecnico(manutencao.getId(), tecnico.getIdTecnico()) == null) {
			throw new ValidacaoException("Consulta permitida somente para o técnico alocado na solicitação.");
		}
	}
	
	@RegraDeValidacao
	public void validarCentroCustoManutencao(List<String> centrosCusto, ManutencaoCorretiva manutencao) {
		if(centrosCusto != null && centrosCusto.size() > 0  && manutencao != null && !centrosCusto.contains(manutencao.getCentroCusto().getCodigoCentroCusto())) {
			throw new ValidacaoException("Solicitação não pertence ao seu centro de custo.");
		}
	}

	public void validarManutencaoCorretivaPermissao(ManutencaoCorretiva manutencaoComPermissao, String numeroSolicitacao) throws ValidacaoException {
		ManutencaoCorretiva manutencao = manutencaoDAO.buscarPorNumeroSolicitacao(numeroSolicitacao);
		if(manutencao != null && manutencaoComPermissao == null) {
			throw new ValidacaoException("Usuário sem permissão para acesso a solicitação de outro Centro de Custo.");
		}
	}
}
