package br.gov.cmb.simeq.vo;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class InformacaoFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 398633295290030142L;
	
	@ParametroNomeado
	private Long idManutencao;
	
	private String numeroSolicitacao;

	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}
	
	

}
