package br.gov.cmb.simeq.dao;

import java.util.List;

import javax.persistence.Query;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.SetorManutencao;

public class SetorManutencaoDAO extends GenericoPaginadoDAO<SetorManutencao, Long> {

	private static final long serialVersionUID = -6942967973029920031L;

	public List<LabelValueDTO> buscarTodosSetores() {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(s.nomeSetor, s.idSetor)")
				.from(SetorManutencao.class, "s");
		return buscar(builder.builder(), LabelValueDTO.class);
	}
	
	@SuppressWarnings("unchecked")
	public List<LabelValueDTO> buscarPorIdFamilia(Long idFamilia) {
		StringBuilder stringBuilder = new StringBuilder("select DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO"
				+ "(s.nomeSetor, s.idSetor) from SetorManutencao s "+
				"	inner join s.familiasManutencaoSetor as familiasManutencaoSetor "+
				"	where familiasManutencaoSetor.familiaManutencao.id = :idFamilia ");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("idFamilia", idFamilia);
		
		return this.buscar(query, List.class);
	}
}