package br.gov.cmb.simeq.converter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import br.gov.cmb.simeq.dto.HistoricoSituacaoEquipamentoDTO;
import br.gov.cmb.simeq.entidade.HistoricoSituacaoEquipamento;

public class HistoricoSituacaoEquipamentoConverter {

	public static List<HistoricoSituacaoEquipamentoDTO> converter(List<HistoricoSituacaoEquipamento> historicosSituacaoEquipamento) {
		List<HistoricoSituacaoEquipamentoDTO> historicosSituacaoEquipamentoDTO = new ArrayList<>();
		for (HistoricoSituacaoEquipamento historicoSituacaoEquipamento : historicosSituacaoEquipamento) {
			historicosSituacaoEquipamentoDTO.add(converter(historicoSituacaoEquipamento));
		}
		return historicosSituacaoEquipamentoDTO;
	}

	public static HistoricoSituacaoEquipamentoDTO converter(HistoricoSituacaoEquipamento historicoSituacaoEquipamento) {
		return new HistoricoSituacaoEquipamentoDTO(historicoSituacaoEquipamento.getIdHistoricoSituacaoEquipamento(),
												   historicoSituacaoEquipamento.getFlagStatus(), 
												   historicoSituacaoEquipamento.getCodigoCentroCusto(),
												   historicoSituacaoEquipamento.getDataInicio(), 
												   historicoSituacaoEquipamento.getDataFim(),
												   historicoSituacaoEquipamento.getDescricaoObservacao(), 
												   historicoSituacaoEquipamento.getEquipamento().getIdEquipamento(),
												   historicoSituacaoEquipamento.getCentroCusto().getTextoHierarquiaCentroCusto() + " - " + historicoSituacaoEquipamento.getCodigoCentroCusto());
	}

	public static HistoricoSituacaoEquipamento converter(HistoricoSituacaoEquipamentoDTO historicoSituacaoEquipamentoDTO) {
		return new HistoricoSituacaoEquipamento(Objects.nonNull(historicoSituacaoEquipamentoDTO.getIdHistoricoSituacaoEquipamento()) ? historicoSituacaoEquipamentoDTO.getIdHistoricoSituacaoEquipamento() : null,
												historicoSituacaoEquipamentoDTO.getFlagStatus(), 
												historicoSituacaoEquipamentoDTO.getCodigoCentroCusto(),
												historicoSituacaoEquipamentoDTO.getDataInicio(), 
												historicoSituacaoEquipamentoDTO.getDataFim(),
												historicoSituacaoEquipamentoDTO.getDescricaoObservacao(), 
												historicoSituacaoEquipamentoDTO.getIdEquipamento(),
												historicoSituacaoEquipamentoDTO.getHierarquiaCentroCusto());
	}

}
