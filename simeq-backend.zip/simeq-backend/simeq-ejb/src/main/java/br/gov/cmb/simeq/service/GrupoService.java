package br.gov.cmb.simeq.service;

import java.util.List;
import java.util.Objects;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.simeq.converter.GrupoConverter;
import br.gov.cmb.simeq.dao.GrupoDAO;
import br.gov.cmb.simeq.dto.GrupoDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.Grupo;
import br.gov.cmb.simeq.enums.SimNaoEnum;
import br.gov.cmb.simeq.validador.GrupoValidador;

@Stateless
public class GrupoService {

	@Inject
	private GrupoDAO grupoDAO;

	@Inject
	private GrupoValidador grupoValidador;

	public GrupoDTO buscarGrupo(Long idGrupo) {
		return GrupoConverter.converter(this.grupoDAO.buscar(idGrupo));
	}
	
	public List<LabelValueDTO> buscarGruposPorEquipamento(Long idEquipamento) {
		return this.grupoDAO.buscarGruposPorEquipamento(idEquipamento);
	}
	
	public List<GrupoDTO> buscarGruposPai(Long idEquipamento) {
		return this.grupoDAO.buscarGruposPai(idEquipamento);
	}

	public List<GrupoDTO> buscarGruposFilho(Long idGrupoPai) {
		return this.grupoDAO.buscarGruposFilho(idGrupoPai);
	}

	public Long inserirGrupo(GrupoDTO grupoDTO) {
		return this.grupoDAO.inserirGrupo(grupoDTO, true);
	}

	public Long inserirGrupo(GrupoDTO grupoDTO, Boolean retornarCodigo) {
		return this.grupoDAO.inserirGrupo(grupoDTO, retornarCodigo);
	}

	public GrupoDTO atualizarGrupo(GrupoDTO grupoDTO) {
		atualizarTipoRevisaoDosSubgrupos(grupoDTO);
		return GrupoConverter.converter(this.grupoDAO.atualizar(GrupoConverter.converter(grupoDTO)));
	}

	public void removerGrupo(Long idGrupo) {
		grupoValidador.validarGrupoComSubgrupo(idGrupo);
		grupoValidador.validarSubgrupoComAtividade(idGrupo);
		this.grupoDAO.remover(new Grupo(idGrupo));
	}

	private void atualizarTipoRevisaoDosSubgrupos(GrupoDTO grupoDTO) {
		if (Objects.isNull(grupoDTO.getIdGrupoPai())) {
			if ((!grupoDTO.getFlagPreventivaAnterior().label.equals(grupoDTO.getFlagPreventiva().label))
					&& (SimNaoEnum.S.label.equals(grupoDTO.getFlagPreventiva().label))) {
				grupoDAO.atualizarTipoRevisaoDosSubgrupos(grupoDTO.getIdGrupo());
			}
		}
	}
}
