package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

public class FuncionamentoMaquinaDTO implements Serializable {

	private static final long serialVersionUID = 5846631251884475183L;

	private Long id;
	private Long idEquipamento;
	private String codigoCentroCusto;
	private Integer quantidadeHorasPadrao;
	private Integer ano;
	private Integer mes;
	private String codigoUsuario;
	private String dataUltimaAlteracao;
	private Timestamp timestamp;
	private List<FuncionamentoMaquinaDiaDTO> diasFuncionamento;

	public FuncionamentoMaquinaDTO() {
		super();
	}

	public FuncionamentoMaquinaDTO(Long id, Long idEquipamento, String codigoCentroCusto, Integer ano, Integer mes,
			Integer quantidadeHorasPadrao, String codigoUsuario, String dataUltimaAlteracao,
			List<FuncionamentoMaquinaDiaDTO> diasFuncionamento) {
		super();
		this.id = id;
		this.idEquipamento = idEquipamento;
		this.codigoCentroCusto = codigoCentroCusto;
		this.quantidadeHorasPadrao = quantidadeHorasPadrao;
		this.ano = ano;
		this.mes = mes;
		this.codigoUsuario = codigoUsuario;
		this.dataUltimaAlteracao = dataUltimaAlteracao;
		this.diasFuncionamento = diasFuncionamento;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public List<FuncionamentoMaquinaDiaDTO> getDiasFuncionamento() {
		return diasFuncionamento;
	}

	public void setDiasFuncionamento(List<FuncionamentoMaquinaDiaDTO> diasFuncionamento) {
		this.diasFuncionamento = diasFuncionamento;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public Integer getMes() {
		return mes;
	}

	public void setMes(Integer mes) {
		this.mes = mes;
	}

	public Integer getQuantidadeHorasPadrao() {
		return quantidadeHorasPadrao;
	}

	public void setQuantidadeHorasPadrao(Integer quantidadeHorasPadrao) {
		this.quantidadeHorasPadrao = quantidadeHorasPadrao;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	public String getDataUltimaAlteracao() {
		return dataUltimaAlteracao;
	}

	public void setDataUltimaAlteracao(String dataUltimaAlteracao) {
		this.dataUltimaAlteracao = dataUltimaAlteracao;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

}
