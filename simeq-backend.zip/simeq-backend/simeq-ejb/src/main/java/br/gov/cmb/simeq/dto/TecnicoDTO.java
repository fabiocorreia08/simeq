package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class TecnicoDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3501318363711552824L;
	
	private Long id;
	private String matricula;
	private String nomeEmpregado;
	private String centroCusto;	
	private String hierarquiaCentroCusto;
	private String cargo;	
	private String funcao;	
	private String codigoFolha;	
	private String situacaoFolha;
	private BigDecimal salario;
	
	public TecnicoDTO() {
	}

	
	public TecnicoDTO(Long id, String matricula) {
		this.id = id;
		this.matricula = matricula;
	}
	
	public TecnicoDTO(String matricula) {
		this.matricula = matricula;
	}
	
	public TecnicoDTO(String matricula, String nomeEmpregado) {
		super();
		this.matricula = matricula;
		this.nomeEmpregado = nomeEmpregado;
	}
	
	


	public TecnicoDTO(String matricula, String nomeEmpregado, String centroCusto, String hierarquiaCentroCusto) {
		super();
		this.matricula = matricula;
		this.nomeEmpregado = nomeEmpregado;
		this.centroCusto = centroCusto;
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}


	public TecnicoDTO(Long id, String matricula, String nomeEmpregado, String centroCusto, String hierarquiaCentroCusto, String cargo, String funcao, String codigoFolha, String situacaoFolha) {
		this.id = id;
		this.matricula = matricula;
		this.nomeEmpregado = nomeEmpregado;
		this.centroCusto = centroCusto;
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
		this.cargo = cargo;
		this.funcao = funcao;
		this.codigoFolha = codigoFolha;
		this.situacaoFolha = situacaoFolha;
	}


	public TecnicoDTO(String matricula, String nomeEmpregado, String centroCusto, String hierarquiaCentroCusto, String cargo, String funcao,
			String codigoFolha, String situacaoFolha) {
		this.matricula = matricula;
		this.nomeEmpregado = nomeEmpregado;
		this.centroCusto = centroCusto;
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
		this.cargo = cargo;
		this.funcao = funcao;
		this.codigoFolha = codigoFolha;
		this.situacaoFolha = situacaoFolha;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getNomeEmpregado() {
		return nomeEmpregado;
	}

	public void setNomeEmpregado(String nomeEmpregado) {
		this.nomeEmpregado = nomeEmpregado;
	}

	public String getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(String centroCusto) {
		this.centroCusto = centroCusto;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

	public String getCodigoFolha() {
		return codigoFolha;
	}

	public void setCodigoFolha(String codigoFolha) {
		this.codigoFolha = codigoFolha;
	}

	public String getSituacaoFolha() {
		return situacaoFolha;
	}

	public void setSituacaoFolha(String situacaoFolha) {
		this.situacaoFolha = situacaoFolha;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}
	
	public BigDecimal getSalario() {
		return salario;
	}
	
	public void setSalario(BigDecimal salario) {
		this.salario = salario;
	}
	

}
