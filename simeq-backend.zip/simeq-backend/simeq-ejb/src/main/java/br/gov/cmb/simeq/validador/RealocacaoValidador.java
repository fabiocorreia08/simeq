package br.gov.cmb.simeq.validador;

import java.util.Date;
import java.util.Objects;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.anotacao.RegraDeValidacao;
import br.gov.cmb.common.ejb.validacao.AbstractValidador;
import br.gov.cmb.common.exception.ValidacaoException;
import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.dao.RealocacaoTecnicoDAO;
import br.gov.cmb.simeq.entidade.RealocacaoTecnico;

@Stateless
public class RealocacaoValidador  extends AbstractValidador {

	@Inject
	private RealocacaoTecnicoDAO realocacaoTecnicoDAO;

	@RegraDeValidacao
	public void validarDatas(Date dataInicio, Long idTecnico, Boolean compararComUltimaRealocacaoTecnico) {
		RealocacaoTecnico realocacaoTecnico = realocacaoTecnicoDAO.buscarUltimoOuPenultimoRegistro(compararComUltimaRealocacaoTecnico, idTecnico);
		if(Objects.nonNull(realocacaoTecnico)) {
			if(!((DataUtils.obterDataComHoraZerada(dataInicio).after(DataUtils.obterDataComHoraZerada(realocacaoTecnico.getDataPeriodoDe()))) &&
				(Objects.isNull(realocacaoTecnico.getDataPeriodoAte() ) || DataUtils.obterDataComHoraZerada(dataInicio).after(DataUtils.obterDataComHoraZerada(realocacaoTecnico.getDataPeriodoAte()))))) {
				throw new ValidacaoException("O período informado conflita com períodos anteriores.");
			}
		}
	}
}
