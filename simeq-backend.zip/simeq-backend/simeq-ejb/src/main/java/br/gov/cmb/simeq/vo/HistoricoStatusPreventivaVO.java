package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

import br.gov.cmb.common.util.DataUtils;

public class HistoricoStatusPreventivaVO implements Serializable {

	private static final long serialVersionUID = 4312275522399577929L;
	
	private Long sequencial;
	private String dataHoraAlteracao;
	private String status;
	private String matriculaUsuarioAlteracao;
	private String nomeUsuarioAlteracao;
	
	public HistoricoStatusPreventivaVO(Long sequencial, Date dataHoraAlteracao, String status, String matriculaUsuarioAlteracao, String nomeUsuarioAlteracao) {
		this.sequencial = sequencial;
		this.dataHoraAlteracao = DataUtils.formatar(dataHoraAlteracao, DataUtils.FORMATO_HORA_DDMMYYYY_HHMM);
		this.status = status;
		this.matriculaUsuarioAlteracao = matriculaUsuarioAlteracao != null ? matriculaUsuarioAlteracao : "";
		this.nomeUsuarioAlteracao = matriculaUsuarioAlteracao != null ? nomeUsuarioAlteracao : "Gerado automáticamente pelo sistema";
	}

	public Long getSequencial() {
		return sequencial;
	}

	public void setSequencial(Long sequencial) {
		this.sequencial = sequencial;
	}

	public String getDataHoraAlteracao() {
		return dataHoraAlteracao;
	}

	public void setDataHoraAlteracao(String dataHoraAlteracao) {
		this.dataHoraAlteracao = dataHoraAlteracao;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMatriculaUsuarioAlteracao() {
		return matriculaUsuarioAlteracao;
	}

	public void setMatriculaUsuarioAlteracao(String matriculaUsuarioAlteracao) {
		this.matriculaUsuarioAlteracao = matriculaUsuarioAlteracao;
	}

	public String getNomeUsuarioAlteracao() {
		return nomeUsuarioAlteracao;
	}

	public void setNomeUsuarioAlteracao(String nomeUsuarioAlteracao) {
		this.nomeUsuarioAlteracao = nomeUsuarioAlteracao;
	}

}
