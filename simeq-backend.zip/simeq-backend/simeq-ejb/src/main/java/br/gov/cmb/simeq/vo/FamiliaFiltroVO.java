package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.List;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class FamiliaFiltroVO extends ModeloVO implements Serializable{

	private static final long serialVersionUID = 1992449214600155442L;
	
	@ParametroNomeado
	private List<String> centrosCusto;
	
	@ParametroNomeado
	private List<Long> setoresManutencao;
	
	@ParametroNomeado
	private List<Long> familias;

	public List<String> getCentrosCusto() {
		return centrosCusto;
	}

	public void setCentrosCusto(List<String> centrosCusto) {
		this.centrosCusto = centrosCusto;
	}

	public List<Long> getSetoresManutencao() {
		return setoresManutencao;
	}

	public void setSetoresManutencao(List<Long> setoresManutencao) {
		this.setoresManutencao = setoresManutencao;
	}

	public List<Long> getFamilias() {
		return familias;
	}

	public void setFamilias(List<Long> familias) {
		this.familias = familias;
	}
}

