package br.gov.cmb.simeq.service;

import java.util.List;
import java.util.Objects;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.converter.RealocacaoTecnicoConverter;
import br.gov.cmb.simeq.dao.RealocacaoTecnicoDAO;
import br.gov.cmb.simeq.dto.RealocacaoTecnicoDTO;
import br.gov.cmb.simeq.entidade.RealocacaoTecnico;
import br.gov.cmb.simeq.validador.RealocacaoValidador;

@Stateless
public class RealocacaoTecnicoService {

	@Inject
	private RealocacaoTecnicoDAO realocacaoTecnicoDAO;
	
	@Inject
	private RealocacaoValidador realocacaoValidador;
	
	public List<RealocacaoTecnicoDTO> buscarPor(Long idTecnico){
		List<RealocacaoTecnico> realocacaoTecnico = realocacaoTecnicoDAO.buscarPor(idTecnico);
		return RealocacaoTecnicoConverter.converter(realocacaoTecnico);
	}

	public void remover(Long idRealocacao) {
		RealocacaoTecnico realocacao = realocacaoTecnicoDAO.buscarPorId(idRealocacao);
		realocacaoTecnicoDAO.remover(realocacao);
	}
	
	public RealocacaoTecnicoDTO buscarRealocacaoPorId(Long idRealocacao) {
		RealocacaoTecnico realocacao = realocacaoTecnicoDAO.buscarPorId(idRealocacao);
		RealocacaoTecnicoDTO realocacaoDTO = RealocacaoTecnicoConverter.converter(realocacao);
		realocacaoDTO.setHierarquiaCentroCusto(realocacao.getCentroCusto().getTextoHierarquiaCentroCusto());
		return realocacaoDTO;
	}
	
	public RealocacaoTecnicoDTO salvar(RealocacaoTecnicoDTO realocacaoTecnicoDTO) {
		RealocacaoTecnico ultimaRealocacaoTecnico = this.realocacaoTecnicoDAO.buscarUltimoOuPenultimoRegistro(true, realocacaoTecnicoDTO.getTecnico());
		if (Objects.nonNull(ultimaRealocacaoTecnico)) {
			realocacaoValidador.validarDatas(realocacaoTecnicoDTO.getPeriodoInicio(), realocacaoTecnicoDTO.getTecnico(), true);
			if (Objects.isNull(ultimaRealocacaoTecnico.getDataPeriodoAte())) {
				ultimaRealocacaoTecnico.setDataPeriodoAte(DataUtils.subtrairDias(realocacaoTecnicoDTO.getPeriodoInicio(), 1).toDate());
				this.realocacaoTecnicoDAO.atualizar(ultimaRealocacaoTecnico);
			}
		}
		RealocacaoTecnicoDTO realocacaoSalva = RealocacaoTecnicoConverter.converter(this.realocacaoTecnicoDAO.salvar(RealocacaoTecnicoConverter.converter(realocacaoTecnicoDTO)));
		realocacaoSalva.setHierarquiaCentroCusto(realocacaoTecnicoDTO.getHierarquiaCentroCusto());
		return realocacaoSalva;
	}
	
	public RealocacaoTecnicoDTO atualizar(RealocacaoTecnicoDTO realocacaoTecnicoDTO) {
		if(realocacaoTecnicoDTO.getIsUltima()) {
			realocacaoValidador.validarDatas(realocacaoTecnicoDTO.getPeriodoInicio(), realocacaoTecnicoDTO.getTecnico(), false);
		}
		RealocacaoTecnicoDTO realocacaoSalva = RealocacaoTecnicoConverter.converter(this.realocacaoTecnicoDAO.atualizar(RealocacaoTecnicoConverter.converter(realocacaoTecnicoDTO)));
		realocacaoSalva.setHierarquiaCentroCusto(realocacaoTecnicoDTO.getHierarquiaCentroCusto());
		return realocacaoSalva;
	}

}
