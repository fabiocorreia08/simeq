package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.Acao;

public class AcaoDAO extends GenericoPaginadoDAO<Acao, String>{

	private static final long serialVersionUID = -8043448223374712576L;
	
	public List<LabelValueDTO> buscarTodosLabelValue() {
		IJPQLBuilder jpql = JPQLBuilder.getInstance()
				.select("new br.gov.cmb.simeq.dto.LabelValueDTO(a.nome, a.codigo) ")
				.from(Acao.class, "a");
		return buscar(jpql.builder(), LabelValueDTO.class);
	}
}
