package br.gov.cmb.simeq.converter;

import java.util.Date;

import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.entidade.InformacaoPreventiva;
import br.gov.cmb.simeq.vo.InformacaoVO;

public class InformacaoPreventivaConverter {
	
	public static InformacaoPreventiva converter(InformacaoVO informacaoVO) {
		
		return new InformacaoPreventiva(informacaoVO.getMatriculaUsuarioLogado(), 
								new Date(), 
								informacaoVO.getDescricaoInformacao());
		
	}
	
	public static InformacaoVO converter(InformacaoPreventiva informacao) {
		HistoricoStatusManutencaoPreventiva historicoStatusManutencaoPreventiva = 
								informacao.getHistoricoStatusManutencaoPreventiva() != null ? 
								informacao.getHistoricoStatusManutencaoPreventiva() : 
								null;
													
		return new InformacaoVO(informacao.getId(), 
				historicoStatusManutencaoPreventiva != null ? historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getId(): null,
						historicoStatusManutencaoPreventiva != null ? historicoStatusManutencaoPreventiva.getManutencaoPreventiva().getNumeroSolicitacao(): null, 
								historicoStatusManutencaoPreventiva != null ? historicoStatusManutencaoPreventiva.getId().getIdStatusManutencao(): null, 
								informacao.getCodigoMatriculaFuncionario(), 
								informacao.getDescricaoInformacao());
	}

}
