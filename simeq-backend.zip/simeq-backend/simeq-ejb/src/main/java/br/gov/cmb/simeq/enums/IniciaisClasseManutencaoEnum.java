package br.gov.cmb.simeq.enums;

public enum IniciaisClasseManutencaoEnum {
	
	INICIAIS_CORRETIVA("SMA"),
	INICIAIS_PREVENTIVA("OMP");
	
	private String descricao;
	
	private IniciaisClasseManutencaoEnum(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public static IniciaisClasseManutencaoEnum getClasseManutencaoEnumPor(String chave) {
		if (IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA.getDescricao().equals(chave)) {
			return IniciaisClasseManutencaoEnum.INICIAIS_CORRETIVA;
		} else if (IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA.getDescricao().equals(chave)) {
			return IniciaisClasseManutencaoEnum.INICIAIS_PREVENTIVA;
		} else {
			return null;
		}
	}
}
