package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "VW_DN_CENTRO_CUSTO")
public class CentroCustoView implements Serializable {

	private static final long serialVersionUID = 2374714531850699720L;
	
	@Id
	@Column(name = "CD_CENTRO_CUSTO")
	private String codigoCentroCusto;

	@Column(name = "TX_SIGLA_CENTRO_CUSTO")
	private String textoSiglaCentroCusto;
	
	@Column(name = "TX_HIERARQUIA_CENTRO_CUSTO")
	private String textoHierarquiaCentroCusto;

	@Column(name = "NM_CENTRO_CUSTO")
	private String nomeCentroCusto;

	@Column(name = "CD_CENTRO_CUSTO_PAI")
	private String nomeCentroCustoPai;

	public CentroCustoView() {}
	
	public CentroCustoView(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}
	
	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public String getTextoSiglaCentroCusto() {
		return textoSiglaCentroCusto;
	}

	public void setTextoSiglaCentroCusto(String textoSiglaCentroCusto) {
		this.textoSiglaCentroCusto = textoSiglaCentroCusto;
	}

	public String getTextoHierarquiaCentroCusto() {
		return textoHierarquiaCentroCusto;
	}

	public void setTextoHierarquiaCentroCusto(String textoHierarquiaCentroCusto) {
		this.textoHierarquiaCentroCusto = textoHierarquiaCentroCusto;
	}

	public String getNomeCentroCusto() {
		return nomeCentroCusto;
	}

	public void setNomeCentroCusto(String nomeCentroCusto) {
		this.nomeCentroCusto = nomeCentroCusto;
	}

	public String getNomeCentroCustoPai() {
		return nomeCentroCustoPai;
	}

	public void setNomeCentroCustoPai(String nomeCentroCustoPai) {
		this.nomeCentroCustoPai = nomeCentroCustoPai;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((textoHierarquiaCentroCusto == null) ? 0 : textoHierarquiaCentroCusto.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CentroCustoView other = (CentroCustoView) obj;
		if (textoHierarquiaCentroCusto == null) {
			if (other.textoHierarquiaCentroCusto != null)
				return false;
		} else if (!textoHierarquiaCentroCusto.equals(other.textoHierarquiaCentroCusto))
			return false;
		return true;
	}

}
