package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.util.Date;

import br.gov.cmb.simeq.utils.CalendarioUtil;

public class AlocacaoCadastrarVO implements Serializable {

	private static final long serialVersionUID = -6793347277713807610L;
	
	private String matricula;
    private String nomeTecnico;
    private String cargo;
    private String funcao;
    private Date dataHoraAlocacao;
    private String dataHoraAlocacaoFormatada;
    private String alocadoPor;
    private Long idManutencao;
    private Long idTecnico;
    private String codigoSituacaoFolha; 
    public String nomeTurmo;
    
    public AlocacaoCadastrarVO(){}
    
	public AlocacaoCadastrarVO(String matricula, String nomeTecnico, String cargo, String funcao, Date dataHoraAlocacao,
			String alocadoPor, Long idManutencao, Long idTecnico, String codigoSituacaoFolha, String nomeTurmo) {
		super();
		this.matricula = matricula;
		this.nomeTecnico = nomeTecnico;
		this.cargo = cargo;
		this.funcao = funcao;
		this.dataHoraAlocacao = dataHoraAlocacao;
		this.dataHoraAlocacaoFormatada = CalendarioUtil.formatarDataHoraBr(dataHoraAlocacao);
		this.alocadoPor = alocadoPor;
		this.idManutencao = idManutencao;
		this.idTecnico = idTecnico;
		this.codigoSituacaoFolha = codigoSituacaoFolha;
		this.nomeTurmo = nomeTurmo;
	}
	
	public AlocacaoCadastrarVO(String matricula, String nomeTecnico, String cargo, String funcao, Long idTecnico,String codigoSituacaoFolha, String nomeTurmo) {
		super();
		this.matricula = matricula;
		this.nomeTecnico = nomeTecnico;
		this.cargo = cargo;
		this.funcao = funcao;
		this.idTecnico = idTecnico;
		this.codigoSituacaoFolha = codigoSituacaoFolha;
		this.nomeTurmo = nomeTurmo;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public String getNomeTecnico() {
		return nomeTecnico;
	}
	
	public void setNomeTecnico(String nomeTecnico) {
		this.nomeTecnico = nomeTecnico;
	}
	
	public String getCargo() {
		return cargo;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	
	public String getFuncao() {
		return funcao;
	}
	
	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

	public Date getDataHoraAlocacao() {
		return dataHoraAlocacao;
	}

	public void setDataHoraAlocacao(Date dataHoraAlocacao) {
		this.dataHoraAlocacao = dataHoraAlocacao;
	}

	public String getAlocadoPor() {
		return alocadoPor;
	}

	public void setAlocadoPor(String alocadoPor) {
		this.alocadoPor = alocadoPor;
	}
	
	public Long getIdManutencao() {
		return idManutencao;
	}
	
	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
	
	public Long getIdTecnico() {
		return idTecnico;
	}
	
	public void setIdTecnico(Long idTecnico) {
		this.idTecnico = idTecnico;
	}

	public String getCodigoSituacaoFolha() {
		return codigoSituacaoFolha;
	}

	public void setCodigoSituacaoFolha(String codigoSituacaoFolha) {
		this.codigoSituacaoFolha = codigoSituacaoFolha;
	}

	public String getNomeTurmo() {
		return nomeTurmo;
	}

	public void setNomeTurmo(String nomeTurmo) {
		this.nomeTurmo = nomeTurmo;
	}

	public String getDataHoraAlocacaoFormatada() {
		return dataHoraAlocacaoFormatada;
	}

	public void setDataHoraAlocacaoFormatada(String dataHoraAlocacaoFormatada) {
		this.dataHoraAlocacaoFormatada = dataHoraAlocacaoFormatada;
	}
}
