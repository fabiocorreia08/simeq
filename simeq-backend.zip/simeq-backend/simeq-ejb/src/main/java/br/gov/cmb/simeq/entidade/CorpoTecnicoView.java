package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.NotAudited;

@Entity
@Table(name="VW_ERP_CORPO_TECNICO")
public class CorpoTecnicoView implements Serializable {
	
	private static final long serialVersionUID = 6868154239524812217L;

	@Id
	@Column(name="CD_MATRICULA")
	private String codigoMatricula;
	
	@Column(name="NM_EMPREGADO")
	private String nomeEmpregado;
	
	@Column(name="TX_HIERARQUIA_CENTRO_CUSTO")
	private String textoHierarquiaCentroCusto;
	
	@ManyToOne
    @JoinColumn(name = "CD_CENTRO_CUSTO")
	@NotAudited
	private CentroCustoView centroCusto;
	
	@Column(name="TX_SIGLA_CENTRO_CUSTO")
	private String textoSiglaCentroCusto;
	
	@Column(name="NM_CARGO")
	private String nomeCargo;
	
	@Column(name="NM_FUNCAO")
	private String nomeFuncao;
	
	@Column(name="CD_SIT_FOLHA")
	private String codigoSituacaoFolha;
	
	@Column(name="DS_SIT_FOLHA")
	private String descricaoSituacaoFolha;

	public String getCodigoMatricula() {
		return codigoMatricula;
	}

	public void setCodigoMatricula(String codigoMatricula) {
		this.codigoMatricula = codigoMatricula;
	}

	public String getNomeEmpregado() {
		return nomeEmpregado;
	}

	public void setNomeEmpregado(String nomeEmpregado) {
		this.nomeEmpregado = nomeEmpregado;
	}

	public String getTextoHierarquiaCentroCusto() {
		return textoHierarquiaCentroCusto;
	}

	public void setTextoHierarquiaCentroCusto(String textoHierarquiaCentroCusto) {
		this.textoHierarquiaCentroCusto = textoHierarquiaCentroCusto;
	}

	public String getTextoSiglaCentroCusto() {
		return textoSiglaCentroCusto;
	}

	public void setTextoSiglaCentroCusto(String textoSiglaCentroCusto) {
		this.textoSiglaCentroCusto = textoSiglaCentroCusto;
	}

	public String getNomeCargo() {
		return nomeCargo;
	}

	public void setNomeCargo(String nomeCargo) {
		this.nomeCargo = nomeCargo;
	}

	public String getNomeFuncao() {
		return nomeFuncao;
	}

	public void setNomeFuncao(String nomeFuncao) {
		this.nomeFuncao = nomeFuncao;
	}

	public String getCodigoSituacaoFolha() {
		return codigoSituacaoFolha;
	}

	public void setCodigoSituacaoFolha(String codigoSituacaoFolha) {
		this.codigoSituacaoFolha = codigoSituacaoFolha;
	}

	public String getDescricaoSituacaoFolha() {
		return descricaoSituacaoFolha;
	}

	public void setDescricaoSituacaoFolha(String descricaoSituacaoFolha) {
		this.descricaoSituacaoFolha = descricaoSituacaoFolha;
	}

	public CentroCustoView getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(CentroCustoView centroCusto) {
		this.centroCusto = centroCusto;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigoMatricula == null) ? 0 : codigoMatricula.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CorpoTecnicoView other = (CorpoTecnicoView) obj;
		if (codigoMatricula == null) {
			if (other.codigoMatricula != null)
				return false;
		} else if (!codigoMatricula.equals(other.codigoMatricula))
			return false;
		return true;
	}
}
