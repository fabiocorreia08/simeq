package br.gov.cmb.simeq.utils;

import br.gov.cmb.simeq.enums.IniciaisClasseManutencaoEnum;

public class VerificaClasseUtil {

	public static IniciaisClasseManutencaoEnum verificaClasseManutencao(String sValor) {
		if(sValor != null){
			String iniciasNumFiltro = sValor.substring(0,3);
			
			IniciaisClasseManutencaoEnum classeManutencao = IniciaisClasseManutencaoEnum.getClasseManutencaoEnumPor(iniciasNumFiltro);
			return classeManutencao ;
		}
		return null;
	}
}
