package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Audited
@Entity
@Table(name = "MANUTENCAO_PREVENTIVA_TECNICO")
public class ManutencaoPreventivaTecnico implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private ManutencaoPreventivaTecnicoId id;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_MANUTENCAO_PREVENTIVA", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
    private ManutencaoPreventiva manutencaoPreventiva;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_TECNICO", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private Tecnico tecnico;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DT_ALOCACAO", updatable=false)
	private Date dataAlocacao = new Date();
	
	@ManyToOne
	@JoinColumn(name = "CD_MATRICULA_RESPONSAVEL")
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private PessoaView matriculaResponsavel;
	
	public ManutencaoPreventivaTecnico(){}
	
	public ManutencaoPreventivaTecnico(Long idManutencao, Long idTecnico, String matriculaResponsavel) {
		this.id = new ManutencaoPreventivaTecnicoId(idManutencao, idTecnico);
		this.matriculaResponsavel = new PessoaView(matriculaResponsavel);
	}
	
	public ManutencaoPreventivaTecnicoId getId() {
		return id;
	}

	public void setId(ManutencaoPreventivaTecnicoId id) {
		this.id = id;
	}

	public Tecnico getTecnico() {
		return tecnico;
	}

	public void setTecnico(Tecnico tecnico) {
		this.tecnico = tecnico;
	}

	public Date getDataAlocacao() {
		return dataAlocacao;
	}

	public void setDataAlocacao(Date dataAlocacao) {
		this.dataAlocacao = dataAlocacao;
	}

	public PessoaView getMatriculaResponsavel() {
		return matriculaResponsavel;
	}

	public void setMatriculaResponsavel(PessoaView matriculaResponsavel) {
		this.matriculaResponsavel = matriculaResponsavel;
	}
	
	public ManutencaoPreventiva getManutencaoPreventiva() {
		return manutencaoPreventiva;
	}

	public void setManutencaoPreventiva(ManutencaoPreventiva manutencaoPreventiva) {
		this.manutencaoPreventiva = manutencaoPreventiva;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ManutencaoPreventivaTecnico other = (ManutencaoPreventivaTecnico) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}


}
