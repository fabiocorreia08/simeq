package br.gov.cmb.simeq.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.gov.cmb.simeq.enums.AtivoInativoEnum;

@JsonIgnoreProperties(ignoreUnknown=true)
public class HistoricoSituacaoEquipamentoDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idHistoricoSituacaoEquipamento;
	private AtivoInativoEnum flagStatus;
	private String codigoCentroCusto;
	private String hierarquiaCentroCusto;
	private Date dataInicio;
	private Date dataFim;
	private String descricaoObservacao;
	private Long idEquipamento;
	
	public HistoricoSituacaoEquipamentoDTO(){
		
	}

	public HistoricoSituacaoEquipamentoDTO(Long idHistoricoSituacaoEquipamento, AtivoInativoEnum flagStatus,
			String codigoCentroCusto, Date dataInicio, Date dataFim, String descricaoObservacao,
			Long idEquipamento, String hierarquiaCentroCusto) {
		this.idHistoricoSituacaoEquipamento = idHistoricoSituacaoEquipamento;
		this.flagStatus = flagStatus;
		this.codigoCentroCusto = codigoCentroCusto;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
		this.descricaoObservacao = descricaoObservacao;
		this.idEquipamento = idEquipamento;
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

	public Long getIdHistoricoSituacaoEquipamento() {
		return idHistoricoSituacaoEquipamento;
	}

	public void setIdHistoricoSituacaoEquipamento(Long id) {
		this.idHistoricoSituacaoEquipamento = id;
	}

	public AtivoInativoEnum getFlagStatus() {
		return flagStatus;
	}

	public void setFlagStatus(AtivoInativoEnum status) {
		this.flagStatus = status;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(Date dataInicio) {
		this.dataInicio = dataInicio;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public void setDataFim(Date dataFim) {
		this.dataFim = dataFim;
	}

	public String getDescricaoObservacao() {
		return descricaoObservacao;
	}

	public void setDescricaoObservacao(String observacao) {
		this.descricaoObservacao = observacao;
	}

	public Long getIdEquipamento() {
		return idEquipamento;
	}

	public void setIdEquipamento(Long idEquipamento) {
		this.idEquipamento = idEquipamento;
	}

	public String getHierarquiaCentroCusto() {
		return hierarquiaCentroCusto;
	}

	public void setHierarquiaCentroCusto(String hierarquiaCentroCusto) {
		this.hierarquiaCentroCusto = hierarquiaCentroCusto;
	}

}
