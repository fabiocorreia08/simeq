package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class MaterialDetalharVO implements Serializable {

	private static final long serialVersionUID = -8231416752833034715L;
	
	private Long id;
	private String codigo;
	private String nome;
	private BigDecimal qtd;
	private String unidade;
	
	public MaterialDetalharVO() {}
	
	public MaterialDetalharVO(Long id, String codigo, String descricaoOutros, String nomeMaterialOutros, String nomeView, BigDecimal qtd, String unidade) {
		this.id = id;
		this.codigo = codigo == null ? descricaoOutros : codigo;
		this.nome = descricaoOutros == null || descricaoOutros.isEmpty() ? nomeView : nomeMaterialOutros;
		this.qtd = qtd;
		this.unidade = unidade;
	}
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public BigDecimal getQtd() {
		return qtd;
	}
	
	public void setQtd(BigDecimal qtd) {
		this.qtd = qtd;
	}
	
	public String getUnidade() {
		return unidade;
	}
	
	public void setUnidade(String unidade) {
		this.unidade = unidade;
	}
	
}
