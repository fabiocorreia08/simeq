package br.gov.cmb.simeq.vo;

import br.gov.cmb.common.ejb.anotacao.ParametroNomeado;
import br.gov.cmb.common.ejb.vo.ModeloVO;

public class AlocacaoDetalharFiltroVO extends ModeloVO {

	private static final long serialVersionUID = 1913315655079136295L;
	
	@ParametroNomeado
	private Long idManutencao;

	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}
}
