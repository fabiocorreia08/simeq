package br.gov.cmb.simeq.vo.relatorio;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorio")
public class RelatorioCapacidadeProdutivaEquipamentoVO
		extends RelatorioDataSource<SubRelatorioCapacidadeProdutivaEquipamentoVO> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6885614148066982238L;

	private Date dataInicial;
	private Date dataFinal;
	private boolean soPreventivas;
	private InputStream logo;
	
	
	public RelatorioCapacidadeProdutivaEquipamentoVO(Date dataInicial, Date dataFinal, boolean soPreventivas, List<SubRelatorioCapacidadeProdutivaEquipamentoVO> lista) {
		super(lista);
		this.dataFinal = dataFinal;
		this.dataInicial = dataInicial;
		this.soPreventivas = soPreventivas;
	}

	public Date getDataInicial() {
		return dataInicial;
	}

	public void setDataInicial(Date dataInicial) {
		this.dataInicial = dataInicial;
	}

	public Date getDataFinal() {
		return dataFinal;
	}

	public void setDataFinal(Date dataFinal) {
		this.dataFinal = dataFinal;
	}

	public InputStream getLogo() {
		return logo;
	}

	public void setLogo(InputStream logo) {
		this.logo = logo;
	}

	public boolean getSoPreventivas() {
		return soPreventivas;
	}

	public void setSoPreventivas(boolean soPreventivas) {
		this.soPreventivas = soPreventivas;
	}

}
