package br.gov.cmb.simeq.utils;

import com.google.common.base.Strings;

public class ConverterHorasMinutosUtil {

	public static String getTextoHora(Integer horaAtividade, Integer minutosAtividade){
		String horas = horaAtividade != null ? horaAtividade.toString() : "000";
		String minutos = minutosAtividade != null ? minutosAtividade.toString() : "00";
		while (horas.length() < 3) {
			horas = "0" + horas;
		}
		while (minutos.length() < 2) {
			minutos = "0" + minutos;
		}
		return horas.concat(":").concat(minutos);
	}
	
	public static Integer getMinutos(String horasAtividade) {
		if (!Strings.isNullOrEmpty(horasAtividade) && horasAtividade.trim().length() > 2) {
			String minutos;
			if(!":".equals(horasAtividade.substring(3, 4))) {				
				minutos = horasAtividade.substring(3, 5);
			}else {
				minutos = horasAtividade.substring(4, 6);
			}
			return new Integer(minutos);
		}
		return new Integer("00");
	}
	
	public static Integer getHora(String horasAtividade) {
		String horas = horasAtividade;
		if (!Strings.isNullOrEmpty(horasAtividade) && horasAtividade.trim().length() > 2) {			
			horas = horas.substring(0, 3);
			return new Integer(horas);
		}
		return new Integer("00");
	}
}
