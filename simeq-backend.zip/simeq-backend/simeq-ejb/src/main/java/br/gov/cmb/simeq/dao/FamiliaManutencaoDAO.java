package br.gov.cmb.simeq.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.dto.FamiliaTabelaDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.entidade.FamiliaManutencao;

public class FamiliaManutencaoDAO extends GenericoPaginadoDAO<FamiliaManutencao, Long> {

	private static final long serialVersionUID = 9182268917357815665L;

	public FamiliaManutencao buscarPorNome(String nomeFamilia) {
		IJPQLBuilder builder = JPQLBuilder.getInstance().select("fm").from(FamiliaManutencao.class, "fm")
				.where("fm.nomeFamilia = ?");
		return buscaSeguraUmResultado(builder.builder(), FamiliaManutencao.class, nomeFamilia);
	}

	@SuppressWarnings("unchecked")
	public Pagina<FamiliaTabelaDTO> filtrar(Pagina<FamiliaTabelaDTO> pagina) {

		List<FamiliaTabelaDTO> registros = ((TypedQuery<FamiliaTabelaDTO>) this
				.preencherParametros(this.getEntityManager().createNamedQuery("filtrar", FamiliaTabelaDTO.class)
						.setParameter("primeiroRegistro", pagina.getPrimeiroRegistro())
						.setParameter("numeroRegistros", pagina.getTamanho()), pagina)).getResultList();
		pagina.setRegistros(registros);
		pagina.setTotalDeRegistros(this.filtrarNumeroDeRegistros(pagina));
		return pagina;
	}

	@SuppressWarnings("unchecked")
	private Integer filtrarNumeroDeRegistros(Pagina<FamiliaTabelaDTO> pagina) {

		Integer numeroDeRegistros = ((TypedQuery<Integer>) this.preencherParametros(
				this.getEntityManager().createNamedQuery("filtrarNumeroDeRegistros", Integer.class), pagina))
						.getSingleResult();
		return numeroDeRegistros;
	}

	@SuppressWarnings("rawtypes")
	private TypedQuery preencherParametros(TypedQuery typedQuery, Pagina<FamiliaTabelaDTO> pagina) {
		Integer familiasSize = getFamiliasSizeFiltro(pagina);
		Integer centrosCustoSize = getCentrosCustoSizeFiltro(pagina);
		Integer setoresManutencaoSize = getSetoresManutencaoSizeFiltro(pagina);
		List<Integer> familias = getFamiliasFiltro(pagina);
		List<String> centrosCusto = getCentrosCustoFiltro(pagina);
		List<Integer> setoresManutencao = getSetoresManutencaoFiltro(pagina);

		return typedQuery.setParameter("familias", familias).setParameter("centrosCusto", centrosCusto)
				.setParameter("setoresManutencao", setoresManutencao).setParameter("familiasSize", familiasSize)
				.setParameter("centrosCustoSize", centrosCustoSize)
				.setParameter("setoresManutencaoSize", setoresManutencaoSize);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<Integer> getFamiliasFiltro(Pagina<FamiliaTabelaDTO> pagina) {
		if (pagina.getModelVO().getParametros().get("familias") != null
				&& ((List) pagina.getModelVO().getParametros().get("familias")).size() > 0) {
			return (List) pagina.getModelVO().getParametros().get("familias");
		}
		return Arrays.asList(0);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<String> getCentrosCustoFiltro(Pagina<FamiliaTabelaDTO> pagina) {
		if(pagina.getModelVO().getParametros().get("centrosCusto") != null &&
				((List)pagina.getModelVO().getParametros().get("centrosCusto")).size() > 0) {
			return (List)pagina.getModelVO().getParametros().get("centrosCusto");
		}
		return Arrays.asList("0");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<Integer> getSetoresManutencaoFiltro(Pagina<FamiliaTabelaDTO> pagina) {
		if (pagina.getModelVO().getParametros().get("setoresManutencao") != null
				&& ((List) pagina.getModelVO().getParametros().get("setoresManutencao")).size() > 0) {
			return (List) pagina.getModelVO().getParametros().get("setoresManutencao");
		}
		return Arrays.asList(0);
	}

	@SuppressWarnings("rawtypes")
	private Integer getFamiliasSizeFiltro(Pagina<FamiliaTabelaDTO> pagina) {
		if (pagina.getModelVO().getParametros().get("familias") != null
				&& ((List) pagina.getModelVO().getParametros().get("familias")).size() > 0) {
			return ((List) pagina.getModelVO().getParametros().get("familias")).size();
		}
		return 0;
	}

	@SuppressWarnings("rawtypes")
	private Integer getCentrosCustoSizeFiltro(Pagina<FamiliaTabelaDTO> pagina) {
		if (pagina.getModelVO().getParametros().get("centrosCusto") != null
				&& ((List) pagina.getModelVO().getParametros().get("centrosCusto")).size() > 0) {
			return ((List) pagina.getModelVO().getParametros().get("centrosCusto")).size();
		}
		return 0;
	}

	@SuppressWarnings("rawtypes")
	private Integer getSetoresManutencaoSizeFiltro(Pagina<FamiliaTabelaDTO> pagina) {
		if (pagina.getModelVO().getParametros().get("setoresManutencao") != null
				&& ((List) pagina.getModelVO().getParametros().get("setoresManutencao")).size() > 0) {
			return ((List) pagina.getModelVO().getParametros().get("setoresManutencao")).size();
		}
		return 0;
	}

	@SuppressWarnings("unchecked")
	public List<LabelValueDTO> buscarPorCentroCustoAssistenteProducao(String centroCusto) {
		StringBuilder stringBuilder = new StringBuilder("select DISTINCT new br.gov.cmb.simeq.dto.LabelValueDTO"
				+ "(f.nomeFamilia, f.id) from FamiliaManutencao f "
				+ "	inner join f.familiasManutencaoCC as familiasManutencaoCC "
				+ "	where familiasManutencaoCC.codigoCC = :centroCusto ");

		Query query = this.criarConsulta(stringBuilder);
		query.setParameter("centroCusto", centroCusto);

		return this.buscar(query, List.class);
	}

	public List<Long> buscarSetoresPorCC(String centroCusto) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT(s.setorManutencao.idSetor)")
				.from(FamiliaManutencao.class, "fm")
				.innerJoin("fm.familiasManutencaoCC", "cc")
				.innerJoin("fm.familiasManutencaoSetor", "s")
				.where("cc.codigoCC = ?");
				
		List<Long> resultados = buscar(builder.builder(), Long.class, centroCusto);
		
		return resultados;
	}
	
}
