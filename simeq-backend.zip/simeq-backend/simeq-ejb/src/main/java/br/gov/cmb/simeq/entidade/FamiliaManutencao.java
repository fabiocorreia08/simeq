package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.SqlResultSetMappings;
import javax.persistence.ConstructorResult;
import javax.persistence.ColumnResult;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

import br.gov.cmb.simeq.dto.FamiliaTabelaDTO;

@Entity
@Audited
@Table(name = "FAMILIA_MANUTENCAO")
@SqlResultSetMappings({
	@SqlResultSetMapping(name="filtrarMapping",
		classes={@ConstructorResult(
			targetClass=FamiliaTabelaDTO.class,
				columns={	@ColumnResult(name="id", type=Long.class),
							@ColumnResult(name="nomeFamilia", type=String.class),
							@ColumnResult(name="centrosCusto", type=String.class),
							@ColumnResult(name="setoresManutencao", type=String.class)}
			)}
		),
	@SqlResultSetMapping(name="filtrarNumeroDeRegistrosMapping",
		classes={@ConstructorResult(
			targetClass=Integer.class,
				columns={	@ColumnResult(name="totalRegistros", type=String.class)}
			)}
		)
})
@NamedNativeQueries({
    @NamedNativeQuery(
        name = "filtrar",
        query = " declare @primeiroRegistro int = :primeiroRegistro ; "
				+ " declare @numeroRegistros int = :numeroRegistros ; "
				+ " select top(@numeroRegistros)	tabela_final.idFamilia as id, "
				+ " 								tabela_final.nomeFamilia as nomeFamilia, "
				+ " 								tabela_final.setoresFamilia as setoresManutencao, "
				+ " 								tabela_final.centrosCustoFamilia as centrosCusto from ( "
				+ " select ROW_NUMBER() over (order by nomeFamilia) as indice, * from ( "
				+ " 		select distinct	fm.ID_FAMILIA_MANUTENCAO as idFamilia, "
				+ " 				fm.NM_FAMILIA_MANUTENCAO nomeFamilia, "
				+ " 				stuff((select ', ' + sm.NM_SETOR_MANUTENCAO from RE_FAMILIA_MANUTENCAO_SETOR fsm inner join SETOR_MANUTENCAO sm on fsm.ID_SETOR_MANUTENCAO = sm.ID_SETOR_MANUTENCAO where fsm.ID_FAMILIA_MANUTENCAO=fm.ID_FAMILIA_MANUTENCAO for xml path ('')), 1, 1, '') as setoresFamilia, "
				+ " 				stuff((select ', ' + cc.CD_CENTRO_CUSTO from RE_FAMILIA_MANUTENCAO_CC fcc inner join VW_DN_CENTRO_CUSTO cc on fcc.CD_CENTRO_CUSTO = cc.CD_CENTRO_CUSTO where fcc.ID_FAMILIA_MANUTENCAO=fm.ID_FAMILIA_MANUTENCAO for xml path ('')), 1, 1, '') as centrosCustoFamilia "
				+ " 		from FAMILIA_MANUTENCAO fm"
				+ "		    inner join RE_FAMILIA_MANUTENCAO_SETOR fsm_j on (fm.ID_FAMILIA_MANUTENCAO = fsm_j.ID_FAMILIA_MANUTENCAO) AND (:setoresManutencaoSize = 0 OR fsm_j.ID_SETOR_MANUTENCAO IN (:setoresManutencao))"
				+ "			inner join RE_FAMILIA_MANUTENCAO_CC fcc_j on (fm.ID_FAMILIA_MANUTENCAO = fcc_j.ID_FAMILIA_MANUTENCAO) AND (:centrosCustoSize = 0 OR fcc_j.CD_CENTRO_CUSTO in (:centrosCusto))"
				+ "		    where :familiasSize = 0 OR fm.ID_FAMILIA_MANUTENCAO IN :familias ) tabela where tabela.setoresFamilia is not null and tabela.centrosCustoFamilia is not null) tabela_final where tabela_final.indice >= @primeiroRegistro; ",
                    resultSetMapping="filtrarMapping"
    ),
    @NamedNativeQuery(
        name = "filtrarNumeroDeRegistros",
        query = " select count(1) as totalRegistros from ( "
				+ " 	select distinct	fm.ID_FAMILIA_MANUTENCAO as idFamilia, "
				+ " 			fm.NM_FAMILIA_MANUTENCAO nomeFamilia, "
				+ " 			stuff((select ', ' + sm.NM_SETOR_MANUTENCAO from RE_FAMILIA_MANUTENCAO_SETOR fsm inner join SETOR_MANUTENCAO sm on fsm.ID_SETOR_MANUTENCAO = sm.ID_SETOR_MANUTENCAO where fsm.ID_FAMILIA_MANUTENCAO=fm.ID_FAMILIA_MANUTENCAO for xml path ('')), 1, 1, '') as setoresFamilia, "
				+ " 			stuff((select ', ' + cc.CD_CENTRO_CUSTO from RE_FAMILIA_MANUTENCAO_CC fcc inner join VW_DN_CENTRO_CUSTO cc on fcc.CD_CENTRO_CUSTO = cc.CD_CENTRO_CUSTO where fcc.ID_FAMILIA_MANUTENCAO=fm.ID_FAMILIA_MANUTENCAO for xml path ('')), 1, 1, '') as centrosCustoFamilia "
				+ "from FAMILIA_MANUTENCAO fm"
				+ "		    inner join RE_FAMILIA_MANUTENCAO_SETOR fsm_j on (fm.ID_FAMILIA_MANUTENCAO = fsm_j.ID_FAMILIA_MANUTENCAO) AND (:setoresManutencaoSize = 0 OR fsm_j.ID_SETOR_MANUTENCAO IN (:setoresManutencao))"
				+ "			inner join RE_FAMILIA_MANUTENCAO_CC fcc_j on (fm.ID_FAMILIA_MANUTENCAO = fcc_j.ID_FAMILIA_MANUTENCAO) AND (:centrosCustoSize = 0 OR fcc_j.CD_CENTRO_CUSTO in (:centrosCusto))"
				+ " 	 where :familiasSize = 0 OR fm.ID_FAMILIA_MANUTENCAO IN :familias ) tabela where tabela.setoresFamilia is not null and tabela.centrosCustoFamilia is not null; ",
				resultSetMapping="filtrarNumeroDeRegistrosMapping"
    )
})
public class FamiliaManutencao implements Serializable{

	private static final long serialVersionUID = 3949074887121473098L;

	@Id
	@Column(name = "ID_FAMILIA_MANUTENCAO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "NM_FAMILIA_MANUTENCAO")
	private String nomeFamilia;
	
	@OneToMany(mappedBy = "familiaManutencao", orphanRemoval=true,  cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH })
	private List<FamiliaManutencaoCC> familiasManutencaoCC = new ArrayList<>();
	
	@OneToMany(mappedBy = "familiaManutencao", orphanRemoval=true, cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REMOVE, CascadeType.REFRESH })
	private List<FamiliaManutencaoSetor> familiasManutencaoSetor = new ArrayList<>();
	
	
	public FamiliaManutencao() {
	}


	public FamiliaManutencao(Long id, String nomeFamilia, List<FamiliaManutencaoCC> familiasManutencaoCC,
			List<FamiliaManutencaoSetor> familiasManutencaoSetor) {
		super();
		this.id = id;
		this.nomeFamilia = nomeFamilia;
		this.familiasManutencaoCC = familiasManutencaoCC;
		this.familiasManutencaoSetor = familiasManutencaoSetor;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNomeFamilia() {
		return nomeFamilia;
	}


	public void setNomeFamilia(String nomeFamilia) {
		this.nomeFamilia = nomeFamilia;
	}


	public List<FamiliaManutencaoCC> getFamiliasManutencaoCC() {
		return familiasManutencaoCC;
	}


	public void setFamiliasManutencaoCC(List<FamiliaManutencaoCC> familiasManutencaoCC) {
		this.familiasManutencaoCC = familiasManutencaoCC;
	}
	
	public void setFamiliasManutencaoCCEdit(List<FamiliaManutencaoCC> familiasManutencaoCC) {
		this.familiasManutencaoCC.clear();
		this.familiasManutencaoCC.addAll(familiasManutencaoCC);
	}


	public List<FamiliaManutencaoSetor> getFamiliasManutencaoSetor() {
		return familiasManutencaoSetor;
	}


	public void setFamiliasManutencaoSetor(List<FamiliaManutencaoSetor> familiasManutencaoSetor) {
		this.familiasManutencaoSetor = familiasManutencaoSetor;
	}
	
	public void setFamiliasManutencaoSetorEdit(List<FamiliaManutencaoSetor> familiasManutencaoSetor) {
		this.familiasManutencaoSetor.clear();
		this.familiasManutencaoSetor.addAll(familiasManutencaoSetor);
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FamiliaManutencao other = (FamiliaManutencao) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
}
