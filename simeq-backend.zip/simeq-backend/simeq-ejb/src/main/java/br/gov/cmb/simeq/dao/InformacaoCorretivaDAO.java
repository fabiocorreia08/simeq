package br.gov.cmb.simeq.dao;

import java.util.List;

import br.gov.cmb.common.ejb.builder.JPQLBuilder;
import br.gov.cmb.common.ejb.builder.query.IJPQLBuilder;
import br.gov.cmb.common.ejb.dao.GenericoPaginadoDAO;
import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.entidade.InformacaoCorretiva;
import br.gov.cmb.simeq.vo.InformacaoVO;

public class InformacaoCorretivaDAO extends GenericoPaginadoDAO<InformacaoCorretiva, Long>{

	private static final long serialVersionUID = -4375792137044684653L;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Pagina<InformacaoVO> filtrar(Pagina pagina) {
		
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("DISTINCT new br.gov.cmb.simeq.vo.InformacaoVO(i.id, "
											  	+ " status.id, "
											  	+ " i.descricaoInformacao,"
											  	+ " status.nome, "
											  	+ " i.dataCadastro,"
											  	+ " i.codigoMatriculaFuncionario) ")
				.from(InformacaoCorretiva.class, "i")
					.innerJoin("i.historicoStatusManutencaoCorretiva", "historico")
					.innerJoin("historico.manutencaoCorretiva", "manutencao")
					.innerJoin("historico.statusManutencaoCorretiva", "status")
				.where(pagina.getModelVO(), "manutencao.id = [idManutencao]")
				.order("i.dataCadastro")
				.desc();
		
		return (Pagina<InformacaoVO>)buscar(pagina, builder.builder(), "distinct i.id");
	}
	
	public List<InformacaoCorretiva> buscarPorIdManutencao(Long idManutencao) {
		IJPQLBuilder builder = JPQLBuilder.getInstance()
				.select("i")
				.from(InformacaoCorretiva.class, "i")
				.innerJoin("i.historicoStatusManutencaoCorretiva", "historico")
				.innerJoin("historico.manutencaoCorretiva", "manutencao")
				.where("manutencao.id = ?");
		return buscar(builder.builder(), idManutencao);
	}
}
