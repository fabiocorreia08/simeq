package br.gov.cmb.simeq.converter;

import br.gov.cmb.common.util.CollectionUtils;
import br.gov.cmb.simeq.entidade.ManutencaoPreventiva;
import br.gov.cmb.simeq.vo.ManutencaoVO;
import br.gov.cmb.simeq.vo.PreventivaCadastroVO;

public class ManutencaoPreventivaConverter {
	
	public static ManutencaoPreventiva converter(PreventivaCadastroVO preventiva) {
		return new ManutencaoPreventiva(preventiva.getId(), 
				preventiva.getNumeroSolicitacao(), 
				preventiva.getIdEquipamento(), 
				preventiva.getCodigoCentroCusto(), 
				preventiva.getAno(), 
				preventiva.getMes(), 
				preventiva.getDiaInicio(), 
				preventiva.getDiaFim(), 
				preventiva.getQtdHoras(), 
				preventiva.getMatriculaSolicitante(),
				preventiva.getIdSetor(),
				preventiva.getQtdHorasExecutadas());
	}
	
	public static PreventivaCadastroVO converter(ManutencaoPreventiva manutencaoPreventiva) {
		return new PreventivaCadastroVO(manutencaoPreventiva.getId(), 
				manutencaoPreventiva.getEquipamento().getIdEquipamento(), 
				manutencaoPreventiva.getCentroCusto().getCodigoCentroCusto(),
				manutencaoPreventiva.getCentroCusto().getTextoHierarquiaCentroCusto(),
				manutencaoPreventiva.getNumeroSolicitacao(), 
				manutencaoPreventiva.getMes(), 
				manutencaoPreventiva.getAno(), 
				manutencaoPreventiva.getDiaInicio(), 
				manutencaoPreventiva.getDiaFim(),
				manutencaoPreventiva.getQtdHoras(), 
				manutencaoPreventiva.getMatriculaSolicitante(),
				CollectionUtils.isNullOrEmpty(manutencaoPreventiva.getHistoricoStatus()) ? null :
					manutencaoPreventiva.historicoOrdenadoDescSequencial().get((manutencaoPreventiva.historicoOrdenadoDescSequencial().size()-1)).getId().getIdStatusManutencao(),
				manutencaoPreventiva.getSetor().getIdSetor(),
				manutencaoPreventiva.getSetor().getNomeSetor(),
				manutencaoPreventiva.getQtdHorasExecutadas());
	}
	
	public static ManutencaoVO converterGenerica(ManutencaoPreventiva manutencao) {
		return new ManutencaoVO(manutencao.getId(), 
				manutencao.getNumeroSolicitacao(), 
				"Preventiva");
	}
}
