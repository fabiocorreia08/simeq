package br.gov.cmb.simeq.service;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;

import br.gov.cmb.simeq.dao.HistStatusManutencaoPreventivaDAO;
import br.gov.cmb.simeq.dao.ParametroDAO;
import br.gov.cmb.simeq.dto.AprovacaoReprovacaoManutencaoPreventivaDTO;
import br.gov.cmb.simeq.entidade.HistoricoStatusManutencaoPreventiva;
import br.gov.cmb.simeq.enums.ParametroEnum;
import br.gov.cmb.simeq.enums.StatusManutencaoPreventivaEnum;

@Stateless
public class HistoricoStatusManutencaoPreventivaService {

	@Inject
	private HistStatusManutencaoPreventivaDAO historicoStatusManutencaoPreventivaDAO;
	
	@Inject
	private ParametroDAO parametroDAO;
	
	@Inject
	private EmailService emailService;
	
	@Transactional
	public void reprovar(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		List<HistoricoStatusManutencaoPreventiva> historicosStatusManutencaoPreventiva = construirHistoricosStatusManutencaoPreventivaReprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO);
		for(HistoricoStatusManutencaoPreventiva historicoStatusManutencaoPreventiva: historicosStatusManutencaoPreventiva) {
			historicoStatusManutencaoPreventivaDAO.salvar(historicoStatusManutencaoPreventiva);
		}
	}
	
	@Transactional
	public void aprovar(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		List<HistoricoStatusManutencaoPreventiva> historicosStatusManutencaoPreventiva = construirHistoricosStatusManutencaoPreventivaAprovacao(aprovacaoReprovacaoManutencaoPreventivaDTO);
		for(HistoricoStatusManutencaoPreventiva historicoStatusManutencaoPreventiva: historicosStatusManutencaoPreventiva) {
			historicoStatusManutencaoPreventivaDAO.salvar(historicoStatusManutencaoPreventiva);
		}
	}
	
	private List<HistoricoStatusManutencaoPreventiva> construirHistoricosStatusManutencaoPreventivaAprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		List<HistoricoStatusManutencaoPreventiva> historicosStatusManutencaoPreventiva = new ArrayList<HistoricoStatusManutencaoPreventiva>();
		for(Long id: aprovacaoReprovacaoManutencaoPreventivaDTO.getIds()) {
			HistoricoStatusManutencaoPreventiva ultimoHistoricoCadastrado = historicoStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInserido(id);
			historicosStatusManutencaoPreventiva.add(new HistoricoStatusManutencaoPreventiva(id, StatusManutencaoPreventivaEnum.APROVADA_GESTOR.getCodigo(), ultimoHistoricoCadastrado.getProximoSequencial(), aprovacaoReprovacaoManutencaoPreventivaDTO.getMatriculaUsuarioLogado(), aprovacaoReprovacaoManutencaoPreventivaDTO.getMotivo()));
		}
		return historicosStatusManutencaoPreventiva;
	}
	
	private List<HistoricoStatusManutencaoPreventiva> construirHistoricosStatusManutencaoPreventivaReprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO aprovacaoReprovacaoManutencaoPreventivaDTO) {
		List<HistoricoStatusManutencaoPreventiva> historicosStatusManutencaoPreventiva = new ArrayList<HistoricoStatusManutencaoPreventiva>();
		for(Long id: aprovacaoReprovacaoManutencaoPreventivaDTO.getIds()) {
			HistoricoStatusManutencaoPreventiva ultimoHistoricoCadastrado = historicoStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInserido(id);
			historicosStatusManutencaoPreventiva.add(new HistoricoStatusManutencaoPreventiva(id, StatusManutencaoPreventivaEnum.REPROVADA_GESTOR.getCodigo(), ultimoHistoricoCadastrado.getProximoSequencial(), aprovacaoReprovacaoManutencaoPreventivaDTO.getMatriculaUsuarioLogado(), aprovacaoReprovacaoManutencaoPreventivaDTO.getMotivo()));
		}
		return historicosStatusManutencaoPreventiva;
	}
	
	public void enviarEmailAprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO AprovacaoReprovacaoManutencaoPreventivaDTO) {
		String destinatario = parametroDAO.buscar(ParametroEnum.SETOR_MANUTENCAO.getCodigoParametro()).getValor();
		for(Long id: AprovacaoReprovacaoManutencaoPreventivaDTO.getIds()) {
			HistoricoStatusManutencaoPreventiva ultimoHistoricoCadastrado = historicoStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInseridoComManutencaoCorretivaEUsuarioResponsavelPelaAlteracao(id);
			emailService.enviarEmailAprovacaoSolicitacaoPreventiva(destinatario, ultimoHistoricoCadastrado);
		}
	}

	public void enviarEmailReprovacao(AprovacaoReprovacaoManutencaoPreventivaDTO AprovacaoReprovacaoManutencaoPreventivaDTO) {
		String destinatario = parametroDAO.buscar(ParametroEnum.SETOR_MANUTENCAO.getCodigoParametro()).getValor();
		for(Long id: AprovacaoReprovacaoManutencaoPreventivaDTO.getIds()) {
			HistoricoStatusManutencaoPreventiva ultimoHistoricoCadastrado = historicoStatusManutencaoPreventivaDAO.buscarUltimoHistoricoInseridoComManutencaoCorretivaEUsuarioResponsavelPelaAlteracao(id);
			emailService.enviarEmailReprovacaoSolicitacaoPreventiva(destinatario, ultimoHistoricoCadastrado);
		}
	}
}
