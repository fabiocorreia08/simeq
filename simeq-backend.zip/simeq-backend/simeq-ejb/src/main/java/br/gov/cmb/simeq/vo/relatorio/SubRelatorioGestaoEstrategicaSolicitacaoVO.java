package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

public class SubRelatorioGestaoEstrategicaSolicitacaoVO implements Serializable {
	

	private static final long serialVersionUID = -3128366617506997962L;
	
	private String codigoEquipamento;
	private String numeroSolicitacao;
	private String avariaAnormalidade;
	private String tempoComParalisacao;
	private String tempoSemParalisacao;
	
	public SubRelatorioGestaoEstrategicaSolicitacaoVO() {
		super();
	}

	public SubRelatorioGestaoEstrategicaSolicitacaoVO(String codigoEquipamento, String numeroSolicitacao,
			String avariaAnormalidade, String tempoComParalisacao, String tempoSemParalisacao) {
		super();
		this.codigoEquipamento = codigoEquipamento;
		this.numeroSolicitacao = numeroSolicitacao;
		this.avariaAnormalidade = avariaAnormalidade;
		this.tempoComParalisacao = tempoComParalisacao;
		this.tempoSemParalisacao = tempoSemParalisacao;
	}

	public String getCodigoEquipamento() {
		return codigoEquipamento;
	}

	public void setCodigoEquipamento(String codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public String getAvariaAnormalidade() {
		return avariaAnormalidade;
	}

	public void setAvariaAnormalidade(String avariaAnormalidade) {
		this.avariaAnormalidade = avariaAnormalidade;
	}

	public String getTempoComParalisacao() {
		return tempoComParalisacao;
	}

	public void setTempoComParalisacao(String tempoComParalisacao) {
		this.tempoComParalisacao = tempoComParalisacao;
	}

	public String getTempoSemParalisacao() {
		return tempoSemParalisacao;
	}

	public void setTempoSemParalisacao(String tempoSemParalisacao) {
		this.tempoSemParalisacao = tempoSemParalisacao;
	}

	
	
	

}
