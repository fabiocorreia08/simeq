package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.enums.TipoRealocacaoTecnicoEnum;

@Audited
@Entity
@Table(name = "REALOCACAO_TECNICO")
public class RealocacaoTecnico implements Serializable {

	private static final long serialVersionUID = -8461015330738885597L;

	@Id
	@Column(name = "ID_REALOCACAO_TECNICO")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idRealocacaoTecnico;

	@ManyToOne
	@JoinColumn(name = "ID_TECNICO")
	private Tecnico tecnico;

	@Column(name = "FL_TIPO_REALOCACAO")
	@Enumerated(EnumType.STRING)
	private TipoRealocacaoTecnicoEnum flagTipoRealocacao;

	@Column(name = "CD_CENTRO_CUSTO")
	private String codigoCentroCusto;
	
	@ManyToOne()
    @JoinColumn(name = "CD_CENTRO_CUSTO", insertable=false, updatable=false)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	private CentroCustoView centroCusto;

	@Column(name = "DT_PERIODO_DE")
	@Temporal(TemporalType.DATE)
	private Date dataPeriodoDe;

	@Column(name = "DT_PERIODO_ATE")
	@Temporal(TemporalType.DATE)
	private Date dataPeriodoAte;

	@Column(name = "DS_MOTIVO")
	private String descricaoMotivo;

	public RealocacaoTecnico() {
	}

	public RealocacaoTecnico(Long id,Long idTecnico, TipoRealocacaoTecnicoEnum tipoRealocacao, String codigoCentroCusto,
			Date periodoInicio, Date periodoFim, String motivo) {
		this.idRealocacaoTecnico = id;
		this.tecnico = new Tecnico(idTecnico);
		this.flagTipoRealocacao = tipoRealocacao;
		this.codigoCentroCusto = codigoCentroCusto;
		this.dataPeriodoDe = periodoInicio;
		this.dataPeriodoAte = periodoFim;
		this.descricaoMotivo = motivo;
	}

	public Long getIdRealocacaoTecnico() {
		return idRealocacaoTecnico;
	}

	public void setIdRealocacaoTecnico(Long idRealocacaoTecnico) {
		this.idRealocacaoTecnico = idRealocacaoTecnico;
	}

	public Tecnico getTecnico() {
		return tecnico;
	}

	public void setTecnico(Tecnico tecnico) {
		this.tecnico = tecnico;
	}

	public TipoRealocacaoTecnicoEnum getFlagTipoRealocacao() {
		return flagTipoRealocacao;
	}

	public void setFlagTipoRealocacao(TipoRealocacaoTecnicoEnum flagTipoRealocacao) {
		this.flagTipoRealocacao = flagTipoRealocacao;
	}

	public String getCodigoCentroCusto() {
		return codigoCentroCusto;
	}

	public void setCodigoCentroCusto(String codigoCentroCusto) {
		this.codigoCentroCusto = codigoCentroCusto;
	}

	public Date getDataPeriodoDe() {
		return dataPeriodoDe;
	}

	public void setDataPeriodoDe(Date dataPeriodoDe) {
		this.dataPeriodoDe = dataPeriodoDe;
	}

	public Date getDataPeriodoAte() {
		return dataPeriodoAte;
	}

	public void setDataPeriodoAte(Date dataPeriodoAte) {
		this.dataPeriodoAte = dataPeriodoAte;
	}

	public String getDescricaoMotivo() {
		return descricaoMotivo;
	}

	public void setDescricaoMotivo(String descricaoMotivo) {
		this.descricaoMotivo = descricaoMotivo;
	}
	
	public boolean isTecnicoPeriodoAlocaco() {
		return (dataPeriodoDe.before(DataUtils.obterDataAtualComHoraZerada()) || dataPeriodoDe.equals(DataUtils.obterDataAtualComHoraZerada())) &&
				(dataPeriodoAte == null || (dataPeriodoAte.after(DataUtils.obterDataAtualComHoraZerada()) || dataPeriodoAte.equals(DataUtils.obterDataAtualComHoraZerada())));
	}
	
	public CentroCustoView getCentroCusto() {
		return centroCusto;
	}

	public void setCentroCusto(CentroCustoView centroCusto) {
		this.centroCusto = centroCusto;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idRealocacaoTecnico == null) ? 0 : idRealocacaoTecnico.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RealocacaoTecnico other = (RealocacaoTecnico) obj;
		if (idRealocacaoTecnico == null) {
			if (other.idRealocacaoTecnico != null)
				return false;
		} else if (!idRealocacaoTecnico.equals(other.idRealocacaoTecnico))
			return false;
		return true;
	}

}
