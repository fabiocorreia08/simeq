package br.gov.cmb.simeq.vo;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InformacaoVO implements Serializable {

	private static final long serialVersionUID = -4255138644451716790L;

	private Long idInformacao;
	private Long idManutencao;
	private String numeroSolicitacao;
	private Long idStatus;
	private String matriculaUsuarioLogado;
	private String descricaoInformacao;
	private String classeManutencao;
	private String nomeUsuarioLogado;
	private Integer perfil;
	private String descricaoStatus;
	private Date dataCadastro;
	

	public InformacaoVO() {
	}

	public InformacaoVO(Long idInformacao, Long idManutencao, String numeroSolicitacao, Long idStatus,
			String matriculaUsuarioLogado, String descricaoInformacao) {
		super();
		this.idInformacao = idInformacao;
		this.idManutencao = idManutencao;
		this.numeroSolicitacao = numeroSolicitacao;
		this.idStatus = idStatus;
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
		this.descricaoInformacao = descricaoInformacao;
	}

	public InformacaoVO(Long idInformacao, Long idStatus, String descricaoInformacao, 
			String descricaoStatus, Date dataCadastro, String matricula) {
		super();
		this.idInformacao = idInformacao;
		this.idStatus = idStatus;
		this.descricaoInformacao = descricaoInformacao;
		this.descricaoStatus = descricaoStatus;
		this.dataCadastro = dataCadastro;
		this.matriculaUsuarioLogado = matricula;
	}

	public Long getIdInformacao() {
		return idInformacao;
	}

	public void setIdInformacao(Long idInformacao) {
		this.idInformacao = idInformacao;
	}

	public Long getIdManutencao() {
		return idManutencao;
	}

	public void setIdManutencao(Long idManutencao) {
		this.idManutencao = idManutencao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Long getIdStatus() {
		return idStatus;
	}

	public void setIdStatus(Long idStatus) {
		this.idStatus = idStatus;
	}

	public String getMatriculaUsuarioLogado() {
		return matriculaUsuarioLogado;
	}

	public void setMatriculaUsuarioLogado(String matriculaUsuarioLogado) {
		this.matriculaUsuarioLogado = matriculaUsuarioLogado;
	}

	public String getDescricaoInformacao() {
		return descricaoInformacao;
	}

	public void setDescricaoInformacao(String descricaoInformacao) {
		this.descricaoInformacao = descricaoInformacao;
	}

	public String getClasseManutencao() {
		return classeManutencao;
	}

	public void setClasseManutencao(String classeManutencao) {
		this.classeManutencao = classeManutencao;
	}

	public String getNomeUsuarioLogado() {
		return nomeUsuarioLogado;
	}

	public void setNomeUsuarioLogado(String nomeUsuarioLogado) {
		this.nomeUsuarioLogado = nomeUsuarioLogado;
	}

	public Integer getPerfil() {
		return perfil;
	}

	public void setPerfil(Integer perfil) {
		this.perfil = perfil;
	}

	public String getDescricaoStatus() {
		return descricaoStatus;
	}

	public void setDescricaoStatus(String descricaoStatus) {
		this.descricaoStatus = descricaoStatus;
	}

	public String getDataCadastro() {
		if(dataCadastro != null) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			return dateFormat.format(dataCadastro);
		}
		return "";
	}

	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
	
	
}
