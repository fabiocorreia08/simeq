package br.gov.cmb.simeq.entidade;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

@Audited
@Entity
@Table(name = "ATIVIDADE_MATERIAL_CORRETIVA")
public class AtividadeMaterialCorretiva implements Serializable {

	private static final long serialVersionUID = 6183764410233799439L;
	
	@Id
	@Column(name = "ID_ATIVIDADE_MATERIAL")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_ATIVIDADE")
    private AtividadeCorretiva atividade;
	
	@Column(name = "CD_MATERIAL")
	private String codigoMaterial;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CD_MATERIAL", insertable=false, updatable=false)
	@NotAudited
	private MaterialView materialView;
	
	@Column(name = "DS_MATERIAL_OUTROS")
	private String descricaoMaterialOutros;
	
	@Column(name = "NM_MATERIAL_OUTROS")
	private String nomeMaterialOutros;
	
	@Column(name = "QT_MATERIAL")
	private BigDecimal quantidadeMaterial;
	
	@Column(name = "DS_UNIDADE_MEDICA")
	private String descricaoUnidadeMedica;
	
	public AtividadeMaterialCorretiva(){}
	
	public AtividadeMaterialCorretiva(Long id, String codigo, String descricaoMaterialOutros, String nomeMaterialOutros, BigDecimal quantidadeMaterial, String descricaoUnidadeMedica) {
		this.id = id;
		if (descricaoMaterialOutros == null || descricaoMaterialOutros.length() == 0 ) {
			this.codigoMaterial = codigo;
		}
		this.descricaoMaterialOutros = descricaoMaterialOutros;
		this.nomeMaterialOutros = nomeMaterialOutros;
		this.quantidadeMaterial = quantidadeMaterial;
		this.descricaoUnidadeMedica = descricaoUnidadeMedica;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public AtividadeCorretiva getAtividade() {
		return atividade;
	}

	public void setAtividade(AtividadeCorretiva atividade) {
		this.atividade = atividade;
	}

	public MaterialView getMaterialView() {
		return materialView;
	}

	public void setMaterialView(MaterialView materialView) {
		this.materialView = materialView;
	}

	public String getDescricaoMaterialOutros() {
		return descricaoMaterialOutros;
	}

	public void setDescricaoMaterialOutros(String descricaoMaterialOutros) {
		this.descricaoMaterialOutros = descricaoMaterialOutros;
	}

	public BigDecimal getQuantidadeMaterial() {
		return quantidadeMaterial;
	}

	public void setQuantidadeMaterial(BigDecimal quantidadeMaterial) {
		this.quantidadeMaterial = quantidadeMaterial;
	}

	public String getDescricaoUnidadeMedica() {
		return descricaoUnidadeMedica;
	}

	public void setDescricaoUnidadeMedica(String descricaoUnidadeMedica) {
		this.descricaoUnidadeMedica = descricaoUnidadeMedica;
	}

	public String getCodigoMaterial() {
		return codigoMaterial;
	}

	public void setCodigoMaterial(String codigoMaterial) {
		this.codigoMaterial = codigoMaterial;
	}

	public String getNomeMaterialOutros() {
		return nomeMaterialOutros;
	}

	public void setNomeMaterialOutros(String nomeMaterialOutros) {
		this.nomeMaterialOutros = nomeMaterialOutros;
	}
	
}
