package br.gov.cmb.simeq.service;

import java.util.List;
import java.util.Objects;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.converter.HistoricoSituacaoEquipamentoConverter;
import br.gov.cmb.simeq.dao.HistoricoSituacaoEquipamentoDAO;
import br.gov.cmb.simeq.dto.HistoricoSituacaoEquipamentoDTO;
import br.gov.cmb.simeq.entidade.HistoricoSituacaoEquipamento;
import br.gov.cmb.simeq.enums.AtivoInativoEnum;
import br.gov.cmb.simeq.validador.SituacaoEquipamentoValidador;

@Stateless
public class HistoricoSituacaoEquipamentoService {

	@Inject
	private HistoricoSituacaoEquipamentoDAO historicoSituacaoEquipamentoDAO;

	@Inject
	private SituacaoEquipamentoValidador situacaoEquipamentoValidador;

	public List<HistoricoSituacaoEquipamentoDTO> buscarTodosPor(Long idEquipamento) {
		List<HistoricoSituacaoEquipamento> historicoSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscarTodosPor(idEquipamento);
		return HistoricoSituacaoEquipamentoConverter.converter(historicoSituacaoEquipamento);
	}

	public HistoricoSituacaoEquipamentoDTO buscarPor(Long idHistoricoSituacaoEquipamento) {
		HistoricoSituacaoEquipamento historicoSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscar(idHistoricoSituacaoEquipamento);
		return HistoricoSituacaoEquipamentoConverter.converter(historicoSituacaoEquipamento);
	}

	public void remover(Long idHistoricoSituacaoEquipamento) {
		HistoricoSituacaoEquipamento historicoSituacaoEquipamentoARemover = historicoSituacaoEquipamentoDAO
				.buscar(idHistoricoSituacaoEquipamento);
		HistoricoSituacaoEquipamento ultimaSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscarUltimoOuPenultimoRegistro(false,
						historicoSituacaoEquipamentoARemover.getEquipamento().getIdEquipamento());
		if (Objects.nonNull(ultimaSituacaoEquipamento)) {
			ultimaSituacaoEquipamento.setDataFim(null);
			ultimaSituacaoEquipamento.setFlagStatus(AtivoInativoEnum.A);
			historicoSituacaoEquipamentoDAO.atualizar(ultimaSituacaoEquipamento);
		}
		historicoSituacaoEquipamentoDAO.remover(idHistoricoSituacaoEquipamento);
	}

	public HistoricoSituacaoEquipamentoDTO salvar(HistoricoSituacaoEquipamentoDTO historicoSituacaoEquipamentoDTO) {
		HistoricoSituacaoEquipamento ultimaSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscarUltimoOuPenultimoRegistro(true, historicoSituacaoEquipamentoDTO.getIdEquipamento());
		
		if (Objects.nonNull(ultimaSituacaoEquipamento)) {
			situacaoEquipamentoValidador.validarDatas(historicoSituacaoEquipamentoDTO.getDataInicio(),
					historicoSituacaoEquipamentoDTO.getIdEquipamento(), true);
			ultimaSituacaoEquipamento
					.setDataFim(DataUtils.subtrairDias(historicoSituacaoEquipamentoDTO.getDataInicio(), 1).toDate());
			ultimaSituacaoEquipamento.setFlagStatus(AtivoInativoEnum.I);
			historicoSituacaoEquipamentoDAO.atualizar(ultimaSituacaoEquipamento);
		}
		return HistoricoSituacaoEquipamentoConverter.converter(historicoSituacaoEquipamentoDAO
				.salvar(HistoricoSituacaoEquipamentoConverter.converter(historicoSituacaoEquipamentoDTO)));
	}

	public HistoricoSituacaoEquipamentoDTO atualizar(HistoricoSituacaoEquipamentoDTO historicoSituacaoEquipamentoDTO) {
		HistoricoSituacaoEquipamento historicoSituacaoEquipamento;
		HistoricoSituacaoEquipamento ultimaSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscarUltimoOuPenultimoRegistro(false, historicoSituacaoEquipamentoDTO.getIdEquipamento());
		if (Objects.nonNull(ultimaSituacaoEquipamento)) {
			situacaoEquipamentoValidador.validarDatas(historicoSituacaoEquipamentoDTO.getDataInicio(),
					historicoSituacaoEquipamentoDTO.getIdEquipamento(), false);
			ultimaSituacaoEquipamento
					.setDataFim(DataUtils.subtrairDias(historicoSituacaoEquipamentoDTO.getDataInicio(), 1).toDate());
			ultimaSituacaoEquipamento.setFlagStatus(AtivoInativoEnum.I);
			historicoSituacaoEquipamentoDAO.atualizar(ultimaSituacaoEquipamento);
		}
		historicoSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.atualizar(HistoricoSituacaoEquipamentoConverter.converter(historicoSituacaoEquipamentoDTO));

		return HistoricoSituacaoEquipamentoConverter.converter(historicoSituacaoEquipamento);
	}

	public HistoricoSituacaoEquipamentoDTO buscarCentroCustoInstalacao(Long idEquipamento) {
		HistoricoSituacaoEquipamento ultimaSituacaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscarCentroCustoInstalacao(idEquipamento);
		return HistoricoSituacaoEquipamentoConverter.converter(ultimaSituacaoEquipamento);
	}
	
	public HistoricoSituacaoEquipamentoDTO buscarUltimoCentroCusto(Long idEquipamento) {
		HistoricoSituacaoEquipamento situaçaoEquipamento = historicoSituacaoEquipamentoDAO
				.buscarUltimoCentroCusto(idEquipamento);
		return HistoricoSituacaoEquipamentoConverter.converter(situaçaoEquipamento);
	}

}
