package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

@SuppressWarnings("unused")
public class SubRelatorioManutencaoGestapEstrategicaVO implements Serializable {

	private static final long serialVersionUID = -4625161873259295892L;
	
	private String codigoequipamento;
	private String numeroSolicitacao;
	private String avaria;
	private String horasComParalisacao;
	private String horasSemParalisacao;
	private String codigoGrupo;
	private String descricaoGrupo;
	private String horasManutencao;

}
