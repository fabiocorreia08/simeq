package br.gov.cmb.simeq.service;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.converter.InformacaoCorretivaConverter;
import br.gov.cmb.simeq.dao.HistoricoStatusManutencaoCorretivaDAO;
import br.gov.cmb.simeq.dao.InformacaoCorretivaDAO;
import br.gov.cmb.simeq.entidade.InformacaoCorretiva;
import br.gov.cmb.simeq.vo.InformacaoVO;

@Stateless
public class InformacaoCorretivaService {

	@Inject
	private InformacaoCorretivaDAO informacaoDAO;

	@Inject
	private HistoricoStatusManutencaoCorretivaDAO historicoStatusManutencaoCorretivaDAO;

	public InformacaoVO salvar(InformacaoVO informacaoVO) {
		InformacaoCorretiva informacao = InformacaoCorretivaConverter.converter(informacaoVO);
		informacao.setHistoricoStatusManutencaoCorretiva(
				historicoStatusManutencaoCorretivaDAO.buscarUltimoHistoricoInserido(informacaoVO.getIdManutencao()));

		return InformacaoCorretivaConverter.converter(informacaoDAO.salvar(informacao));
	}
	
	public Pagina<InformacaoVO> filtrar(Pagina<InformacaoVO> pagina) {
		return this.informacaoDAO.filtrar(pagina);
	}

}
