package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import br.gov.cmb.common.util.DataUtils;
import br.gov.cmb.simeq.entidade.InformacaoPreventiva;
import br.gov.cmb.simeq.entidade.StatusManutencaoPreventiva;

public class RelatorioManutencaoPreventivaVO implements Serializable {

	private static final long serialVersionUID = -8147823208041943435L;
	
	private Long idManutencaoPreventiva;
	private String numeroSolicitacao;
	private String codigoEquipamento;
	private String descricaoEquipamento;
	private String centroCustoInstalacao;
	private String dataStatusEmManutencao;
	private String horaStatusEmManutencao;
	private String nomeResponsavelStatusEmManutencao;
	private String horasTotaisPrevista;
	private String informacaoManutencao = "";
	private String observacaoAtividade = "";
	private String dataSolicitacao;
	private String quantidadeHorasExecucao;
	private String statusAtual;
	private String dataStatusConcluido;
	private String horasStatusConcluido;
	private String nomeResponsavelStatusConcluido;
	private List<SubRelatorioManutencaoAtividadesVO> atividades = Lists.newArrayList();
	private List<SubRelatorioManutencaoMateriaisVO> materiais = Lists.newArrayList();
	
	RelatorioManutencaoPreventivaVO(){}
	
	public RelatorioManutencaoPreventivaVO(Long idManutencaoPreventiva, String numeroSolicitacao, String codigoEquipamento, String descricaoEquipamento,
			String centroCustoInstalacao, Date dataEmManutencao, String nomeResponsavelEmManutencao, String quantidadeHorasPrevista,
			String quantidadeHorasExecucao, StatusManutencaoPreventiva statusAtual, Date dataStatusConcluida, String nomeResponsavelStatusConcluida, Integer ano,
			Integer mes, Integer diaInicio) {
		this.idManutencaoPreventiva= idManutencaoPreventiva;
		this.numeroSolicitacao= numeroSolicitacao;
		this.codigoEquipamento = codigoEquipamento;
		this.descricaoEquipamento = descricaoEquipamento;
		this.centroCustoInstalacao= centroCustoInstalacao;
		this.dataSolicitacao = getTextoDiaOuMes(diaInicio).concat("/" + getTextoDiaOuMes(mes)).concat("/" + ano.toString());
		this.dataStatusEmManutencao = dataEmManutencao != null ? DataUtils.formatarddMMyyyy(dataEmManutencao) : "";
		this.horaStatusEmManutencao = dataEmManutencao != null ? DataUtils.formatarHoraHHmm(dataEmManutencao) : "";
		this.nomeResponsavelStatusEmManutencao = nomeResponsavelEmManutencao != null ? nomeResponsavelEmManutencao : "";
		this.horasTotaisPrevista = quantidadeHorasPrevista;
		this.quantidadeHorasExecucao = quantidadeHorasExecucao != null ? quantidadeHorasExecucao : "";
		this.statusAtual = statusAtual.getNome();
		this.dataStatusConcluido = dataStatusConcluida != null ? DataUtils.formatarddMMyyyy(dataStatusConcluida) : "";
		this.horasStatusConcluido = dataStatusConcluida != null ? DataUtils.formatarHoraHHmm(dataStatusConcluida) : "";
		this.nomeResponsavelStatusConcluido = nomeResponsavelStatusConcluida != null ? nomeResponsavelStatusConcluida : "";
	}
	
	public String getTextoDiaOuMes(Integer mesOuDia) {
		if(mesOuDia.toString().length() > 1) {
			return mesOuDia.toString();
		}
		return "0" + mesOuDia.toString();
	}

	public String getDescricaoEquipamento() {
		return descricaoEquipamento;
	}

	public void setDescricaoEquipamento(String descricaoEquipamento) {
		this.descricaoEquipamento = descricaoEquipamento;
	}

	public String getDataSolicitacao() {
		return dataSolicitacao;
	}

	public String getNumeroSolicitacao() {
		return numeroSolicitacao;
	}

	public void setNumeroSolicitacao(String numeroSolicitacao) {
		this.numeroSolicitacao = numeroSolicitacao;
	}

	public Long getIdManutencaoPreventiva() {
		return idManutencaoPreventiva;
	}

	public String getCodigoEquipamento() {
		return codigoEquipamento;
	}

	public String getCentroCustoInstalacao() {
		return centroCustoInstalacao;
	}

	public List<SubRelatorioManutencaoAtividadesVO> getAtividades() {
		return atividades;
	}

	public void setAtividades(List<SubRelatorioManutencaoAtividadesVO> atividades) {
		this.atividades = atividades;
	}

	public List<SubRelatorioManutencaoMateriaisVO> getMateriais() {
		return materiais;
	}

	public void setMateriais(List<SubRelatorioManutencaoMateriaisVO> materiais) {
		this.materiais = materiais;
	}

	public String getDataStatusEmManutencao() {
		return dataStatusEmManutencao;
	}

	public void setDataStatusEmManutencao(String dataStatusEmManutencao) {
		this.dataStatusEmManutencao = dataStatusEmManutencao;
	}

	public String getHoraStatusEmManutencao() {
		return horaStatusEmManutencao;
	}

	public void setHoraStatusEmManutencao(String horaStatusEmManutencao) {
		this.horaStatusEmManutencao = horaStatusEmManutencao;
	}

	public String getNomeResponsavelStatusEmManutencao() {
		return nomeResponsavelStatusEmManutencao;
	}

	public void setNomeResponsavelStatusEmManutencao(String nomeResponsavelStatusEmManutencao) {
		this.nomeResponsavelStatusEmManutencao = nomeResponsavelStatusEmManutencao;
	}

	public String getHorasTotaisPrevista() {
		return horasTotaisPrevista;
	}

	public void setHorasTotaisPrevista(String horasTotaisPrevista) {
		this.horasTotaisPrevista = horasTotaisPrevista;
	}

	public String getInformacaoManutencao() {
		return informacaoManutencao;
	}

	public void setInformacaoManutencao(String informacaoManutencao) {
		this.informacaoManutencao = informacaoManutencao;
	}

	public String getObservacaoAtividade() {
		return observacaoAtividade;
	}

	public void setObservacaoAtividade(String observacaoAtividade) {
		this.observacaoAtividade = observacaoAtividade;
	}

	public String getQuantidadeHorasExecucao() {
		return quantidadeHorasExecucao;
	}

	public void setQuantidadeHorasExecucao(String quantidadeHorasExecucao) {
		this.quantidadeHorasExecucao = quantidadeHorasExecucao;
	}

	public String getStatusAtual() {
		return statusAtual;
	}

	public void setStatusAtual(String statusAtual) {
		this.statusAtual = statusAtual;
	}

	public String getDataStatusConcluido() {
		return dataStatusConcluido;
	}

	public void setDataStatusConcluido(String dataStatusConcluido) {
		this.dataStatusConcluido = dataStatusConcluido;
	}

	public String getHorasStatusConcluido() {
		return horasStatusConcluido;
	}

	public void setHorasStatusConcluido(String horasStatusConcluido) {
		this.horasStatusConcluido = horasStatusConcluido;
	}

	public String getNomeResponsavelStatusConcluido() {
		return nomeResponsavelStatusConcluido;
	}

	public void setNomeResponsavelStatusConcluido(String nomeResponsavelStatusConcluido) {
		this.nomeResponsavelStatusConcluido = nomeResponsavelStatusConcluido;
	}

	public void setIdManutencaoPreventiva(Long idManutencaoPreventiva) {
		this.idManutencaoPreventiva = idManutencaoPreventiva;
	}

	public void setCodigoEquipamento(String codigoEquipamento) {
		this.codigoEquipamento = codigoEquipamento;
	}

	public void setCentroCustoInstalacao(String centroCustoInstalacao) {
		this.centroCustoInstalacao = centroCustoInstalacao;
	}

	public void setDataSolicitacao(String dataSolicitacao) {
		this.dataSolicitacao = dataSolicitacao;
	}

	public void setarInformacoesPreventiva(List<InformacaoPreventiva> informacoes) {
		int sequencialInformacoes = 1;
		for (InformacaoPreventiva informacaopreventiva : informacoes) {
			if(!Strings.isNullOrEmpty(informacaopreventiva.getDescricaoInformacao())) {				
				if(Strings.isNullOrEmpty(informacaoManutencao)){				
					informacaoManutencao = " " + sequencialInformacoes + " - "+ informacaopreventiva.getDescricaoInformacao() + " \n";
					continue;
				}
				informacaoManutencao = informacaoManutencao + " " + (++sequencialInformacoes) + " - "+ informacaopreventiva.getDescricaoInformacao() + " \n";
			}
		}
	}
}
