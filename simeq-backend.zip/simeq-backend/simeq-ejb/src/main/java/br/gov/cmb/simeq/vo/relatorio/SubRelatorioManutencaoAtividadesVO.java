package br.gov.cmb.simeq.vo.relatorio;

import java.io.Serializable;

import br.gov.cmb.simeq.utils.ConverterHorasMinutosUtil;

public class SubRelatorioManutencaoAtividadesVO implements Serializable {
	
	private static final long serialVersionUID = -8832363837891837548L;
	
	private Long id;
	private String grupo;
	private String subgrupo;
	private String acao;
	private String componente;
	private String matricula;
	private String hht;
	private String observacao;
	
	SubRelatorioManutencaoAtividadesVO(){}
	
	public SubRelatorioManutencaoAtividadesVO(Long id, String grupo, String subgrupo, String acao, String componente, 
			String matricula, Integer horaAtividade, Integer minutosAtividade, String observacao) {
		this.id = id;
		this.grupo = grupo;
		this.subgrupo = subgrupo;
		this.acao = acao;
		this.componente = componente;
		this.matricula = matricula;
		this.hht = ConverterHorasMinutosUtil.getTextoHora(horaAtividade, minutosAtividade);
		this.observacao = observacao;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public String getSubgrupo() {
		return subgrupo;
	}

	public void setSubgrupo(String subgrupo) {
		this.subgrupo = subgrupo;
	}

	public String getAcao() {
		return acao;
	}

	public void setAcao(String acao) {
		this.acao = acao;
	}

	public String getComponente() {
		return componente;
	}

	public void setComponente(String componente) {
		this.componente = componente;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getHht() {
		return hht;
	}

	public void setHht(String hht) {
		this.hht = hht;
	}
	
	

}
