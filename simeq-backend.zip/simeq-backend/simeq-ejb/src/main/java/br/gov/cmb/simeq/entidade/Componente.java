package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import com.google.common.base.Objects;

@Audited
@Entity
@Table(name = "COMPONENTE")
public class Componente implements Serializable {

	private static final long serialVersionUID = -5187132445168357551L;
	
	@Id
	@Column(name = "CD_COMPONENTE")
	private String codigo;
	
	@Column(name = "NM_COMPONENTE")
	private String nome;
	
	@Column(name = "NM_CLASSE")
	private String nomeClasse;
	
	public Componente(){}
	
	public Componente(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNomeClasse() {
		return nomeClasse;
	}

	public void setNomeClasse(String nomeClasse) {
		this.nomeClasse = nomeClasse;
	}
	
	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof Componente)) {
			return false;
		}
		Componente castOther = (Componente) other;
		return Objects.equal(codigo, castOther.codigo);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(codigo);
	}
}
