package br.gov.cmb.simeq.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import com.google.common.base.Objects;

@Embeddable
public class HistStatusManutencaoCorretivaId implements Serializable {

	private static final long serialVersionUID = 1282131708002076983L;
	
	@Column(name = "ID_MANUTENCAO_CORRETIVA")
	private Long idManutencaoCorretiva;
	
	@Column(name = "ID_STATUS")
	private Long idStatusManutencao;
	
	@Column(name = "ID_SEQUENCIAL")
	private Long idSequencial;
	
	public HistStatusManutencaoCorretivaId(){}
	
	public HistStatusManutencaoCorretivaId(Long idManutencaoCorretiva, Long idStatusManutencao, Long idSequencial) {
		this.idManutencaoCorretiva = idManutencaoCorretiva;
		this.idStatusManutencao = idStatusManutencao;
		this.idSequencial = idSequencial;
	}

	public Long getIdManutencaoCorretiva() {
		return idManutencaoCorretiva;
	}

	public void setIdManutencaoCorretiva(Long idManutencaoCorretiva) {
		this.idManutencaoCorretiva = idManutencaoCorretiva;
	}

	public Long getIdStatusManutencao() {
		return idStatusManutencao;
	}

	public void setIdStatusManutencao(Long idStatusManutencao) {
		this.idStatusManutencao = idStatusManutencao;
	}

	public Long getIdSequencial() {
		return idSequencial;
	}

	public void setIdSequencial(Long idSequencial) {
		this.idSequencial = idSequencial;
	}
	
	@Override
	public boolean equals(final Object other) {
		if (!(other instanceof HistStatusManutencaoCorretivaId)) {
			return false;
		}
		HistStatusManutencaoCorretivaId castOther = (HistStatusManutencaoCorretivaId) other;
		return Objects.equal(idManutencaoCorretiva, castOther.idManutencaoCorretiva)
				&& Objects.equal(idStatusManutencao, castOther.idStatusManutencao)
				&& Objects.equal(idSequencial, castOther.idSequencial);
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(idManutencaoCorretiva, idStatusManutencao, idSequencial);
	}
	

}
