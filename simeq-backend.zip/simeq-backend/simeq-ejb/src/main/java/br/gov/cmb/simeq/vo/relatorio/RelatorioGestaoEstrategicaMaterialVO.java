package br.gov.cmb.simeq.vo.relatorio;

import java.util.List;

import br.gov.cmb.simeq.anotacao.ParametroRelatorioAnotacao;

@ParametroRelatorioAnotacao(nome="relatorioMaterial")
public class RelatorioGestaoEstrategicaMaterialVO extends RelatorioDataSource<SubRelatorioGestaoEstrategicaMaterialVO> {

	private static final long serialVersionUID = 7339419037132821983L;

	public RelatorioGestaoEstrategicaMaterialVO(List<SubRelatorioGestaoEstrategicaMaterialVO> lista) {
		super(lista);
		// TODO Auto-generated constructor stub
	}

}
