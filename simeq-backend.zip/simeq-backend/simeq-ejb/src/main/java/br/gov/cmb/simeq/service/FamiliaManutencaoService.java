package br.gov.cmb.simeq.service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.InternalServerErrorException;

import br.gov.cmb.common.ejb.paginacao.Pagina;
import br.gov.cmb.simeq.converter.FamiliaConverter;
import br.gov.cmb.simeq.dao.FamiliaManutencaoDAO;
import br.gov.cmb.simeq.dto.FamiliaDTO;
import br.gov.cmb.simeq.dto.FamiliaTabelaDTO;
import br.gov.cmb.simeq.dto.LabelValueDTO;
import br.gov.cmb.simeq.exception.NomeFamiliaException;

@Stateless
public class FamiliaManutencaoService {

	@Inject
	private FamiliaManutencaoDAO familiaManutencaoDAO;

	public List<FamiliaDTO> buscarTodos() {
		return FamiliaConverter.converterFamiliasParaDTOList(familiaManutencaoDAO.buscar());
	}

	public FamiliaDTO buscarPorId(Long id) {
		return FamiliaConverter.converterFamiliaParaDTO(familiaManutencaoDAO.buscar(id));
	}

	public void salvarFamilia(FamiliaDTO familiaDTO) {

		if (familiaManutencaoDAO.buscarPorNome(familiaDTO.getNomeFamilia()) != null) {
			throw new NomeFamiliaException();
		} else {
			familiaManutencaoDAO.salvar(FamiliaConverter.converteDTOParaFamiliaSalvar(familiaDTO));
		}
	}

	public void editarFamilia(FamiliaDTO familiaDTO) {
		if (familiaManutencaoDAO.buscarPorNome(familiaDTO.getNomeFamilia()) != null) {
			if (familiaManutencaoDAO.buscarPorNome(familiaDTO.getNomeFamilia()).getId().equals(familiaDTO.getId())) {
				familiaManutencaoDAO.atualizar(FamiliaConverter.converteDTOParaFamiliaEditar(familiaDTO));
			} else {
				throw new NomeFamiliaException();
			}			
		} else {
			try {
				familiaManutencaoDAO.atualizar(FamiliaConverter.converteDTOParaFamiliaEditar(familiaDTO));
			} catch (Exception e) {
				throw new InternalServerErrorException();
			}
		}

	}

	public Pagina<FamiliaTabelaDTO> filtrar(Pagina<FamiliaTabelaDTO> pagina) {
		return familiaManutencaoDAO.filtrar(pagina);
	}

	public void deletarFamilia(Long id) {
		familiaManutencaoDAO.remover(id);

	}
	
	public List<LabelValueDTO> buscarPorCentroCustoAssistenteProducao(String centroCusto) {
		return familiaManutencaoDAO.buscarPorCentroCustoAssistenteProducao(centroCusto);
	}
	
	public List<Long> buscarSetoresPorCC(String centroCusto){
		return this.familiaManutencaoDAO.buscarSetoresPorCC(centroCusto);
	}
	
}
